# ============================================================
# IMPLEMENTATION 35
# UCI SENTINEL, MISSING-VALUE AND OUTLIER AUDIT
#
# Purpose:
#   Verify that UCI missing-value sentinels such as -9.0 have
#   not survived into the harmonized external-validation data.
#
# IMPORTANT:
#   - No model training
#   - No imputation
#   - No threshold tuning
#   - No modification of datasets
#   - No UCI labels used for model selection
#
# Cohorts:
#   Cleveland
#   Hungarian
#   Switzerland
#   VA Long Beach
#
# ============================================================

from pathlib import Path
import zipfile
import io
import json
import hashlib
from datetime import datetime

import numpy as np
import pandas as pd


# ============================================================
# 1. PATHS
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

HARMONIZED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "uci_harmonized"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# 2. RAW UCI FILES
# ============================================================

RAW_FILES = {
    "cleveland": "processed.cleveland.data",
    "hungarian": "processed.hungarian.data",
    "switzerland": "processed.switzerland.data",
    "va": "processed.va.data",
}


# ============================================================
# 3. HARMONIZED FILES
# ============================================================

HARMONIZED_FILES = {
    "cleveland":
        "uci_cleveland_harmonized_shared_features.csv",

    "hungarian":
        "uci_hungarian_harmonized_shared_features.csv",

    "switzerland":
        "uci_switzerland_harmonized_shared_features.csv",

    "va":
        "uci_va_harmonized_shared_features.csv",
}


# ============================================================
# 4. RAW UCI COLUMN NAMES
# ============================================================

UCI_COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target",
]


# ============================================================
# 5. EXPECTED HARMONIZED SHARED FEATURES
# ============================================================

SHARED_FEATURES = [
    "age",
    "sex",
    "systolic_bp",
    "cholesterol_category",
    "elevated_glucose",
    "target",
]


# ============================================================
# 6. SENTINEL / MISSING VALUES TO CHECK
# ============================================================

SENTINEL_VALUES = [
    -9,
    -9.0,
]

MISSING_STRINGS = [
    "?",
    "",
    "nan",
    "NaN",
    "None",
    "none",
]


# ============================================================
# 7. CLINICAL PLAUSIBILITY RANGES
#
# These are AUDIT ranges only.
# They are NOT being used as automatic cleaning rules.
#
# Target is intentionally excluded because it is a label,
# not a continuous clinical measurement.
# ============================================================

PLAUSIBILITY = {

    "age": {
        "minimum": 18,
        "maximum": 100,
    },

    "sex": {
        "minimum": 0,
        "maximum": 1,
    },

    "trestbps": {
        "minimum": 70,
        "maximum": 250,
    },

    "chol": {
        "minimum": 100,
        "maximum": 600,
    },

    "fbs": {
        "minimum": 0,
        "maximum": 1,
    },

    "systolic_bp": {
        "minimum": 70,
        "maximum": 250,
    },

    "cholesterol_category": {
        "minimum": 1,
        "maximum": 3,
    },

    "elevated_glucose": {
        "minimum": 0,
        "maximum": 1,
    },
}


# ============================================================
# 8. HELPER FUNCTIONS
# ============================================================

def sha256_file(path):

    h = hashlib.sha256()

    with open(path, "rb") as f:

        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b""
        ):

            h.update(chunk)

    return h.hexdigest()


def safe_numeric(series):

    return pd.to_numeric(
        series,
        errors="coerce"
    )


def count_exact_sentinel(
    series,
    sentinel=-9
):

    numeric = safe_numeric(series)

    return int(
        (numeric == sentinel).sum()
    )


def count_negative(series):

    numeric = safe_numeric(series)

    return int(
        (numeric < 0).sum()
    )


def count_zero(series):

    numeric = safe_numeric(series)

    return int(
        (numeric == 0).sum()
    )


def descriptive_numeric(series):

    numeric = safe_numeric(series)

    valid = numeric.dropna()

    if len(valid) == 0:

        return {
            "n_nonmissing": 0,
            "min": np.nan,
            "max": np.nan,
            "mean": np.nan,
            "median": np.nan,
        }

    return {
        "n_nonmissing": int(
            len(valid)
        ),

        "min": float(
            valid.min()
        ),

        "max": float(
            valid.max()
        ),

        "mean": float(
            valid.mean()
        ),

        "median": float(
            valid.median()
        ),
    }


def plausibility_flags(
    series,
    minimum,
    maximum
):

    numeric = safe_numeric(series)

    below = int(
        (numeric < minimum).sum()
    )

    above = int(
        (numeric > maximum).sum()
    )

    return below, above


# ============================================================
# 9. LOAD RAW UCI FILE FROM ZIP
# ============================================================

def load_raw_from_zip(
    zf,
    filename
):

    with zf.open(filename) as f:

        raw_bytes = f.read()

    df = pd.read_csv(
        io.BytesIO(raw_bytes),
        header=None,
        names=UCI_COLUMNS,
        sep=",",
        dtype=str,
        na_values=["?"],
        keep_default_na=True,
    )

    return df


# ============================================================
# 10. RAW COHORT AUDIT
# ============================================================

def audit_raw_cohort(
    df,
    cohort
):

    rows = []

    print("\n" + "=" * 90)
    print(
        f"RAW UCI AUDIT: "
        f"{cohort.upper()}"
    )
    print("=" * 90)

    print(
        f"Rows: {len(df):,}"
    )

    print(
        f"Columns: {len(df.columns)}"
    )

    audit_features = [
        "age",
        "sex",
        "trestbps",
        "chol",
        "fbs",
        "target",
    ]

    for feature in audit_features:

        series = df[feature]

        sentinel_count = (
            count_exact_sentinel(
                series,
                -9
            )
        )

        negative_count = (
            count_negative(series)
        )

        zero_count = (
            count_zero(series)
        )

        missing_count = int(
            series.isna().sum()
        )

        desc = descriptive_numeric(
            series
        )

        # ----------------------------------------------------
        # Target is a label and therefore has no clinical
        # plausibility range.
        # ----------------------------------------------------

        if feature in PLAUSIBILITY:

            minimum = (
                PLAUSIBILITY[
                    feature
                ]["minimum"]
            )

            maximum = (
                PLAUSIBILITY[
                    feature
                ]["maximum"]
            )

            below, above = (
                plausibility_flags(
                    series,
                    minimum,
                    maximum
                )
            )

        else:

            below = np.nan
            above = np.nan

        row = {

            "dataset":
                cohort,

            "stage":
                "raw",

            "feature":
                feature,

            "n_rows":
                len(df),

            "missing_count":
                missing_count,

            "sentinel_minus9_count":
                sentinel_count,

            "negative_count":
                negative_count,

            "zero_count":
                zero_count,

            "n_nonmissing":
                desc["n_nonmissing"],

            "min":
                desc["min"],

            "max":
                desc["max"],

            "mean":
                desc["mean"],

            "median":
                desc["median"],

            "below_plausibility_count":
                below,

            "above_plausibility_count":
                above,
        }

        rows.append(row)

        print(
            f"{feature:18s} | "
            f"missing={missing_count:4d} | "
            f"-9={sentinel_count:4d} | "
            f"negative={negative_count:4d} | "
            f"zero={zero_count:4d} | "
            f"min={desc['min']} | "
            f"max={desc['max']} | "
            f"mean={desc['mean']}"
        )

    return rows


# ============================================================
# 11. RAW VALUE DISTRIBUTION AUDIT
# ============================================================

def print_raw_distributions(
    df,
    cohort
):

    print("\n" + "-" * 90)
    print(
        f"RAW DISTRIBUTIONS: "
        f"{cohort.upper()}"
    )
    print("-" * 90)

    for feature in [
        "age",
        "sex",
        "trestbps",
        "chol",
        "fbs",
        "target",
    ]:

        print(
            f"\n{feature}:"
        )

        values = (
            df[feature]
            .value_counts(
                dropna=False
            )
            .sort_index()
        )

        print(
            values.head(30).to_string()
        )


# ============================================================
# 12. HARMONIZED COHORT AUDIT
# ============================================================

def audit_harmonized_cohort(
    df,
    cohort
):

    rows = []

    print("\n" + "=" * 90)
    print(
        f"HARMONIZED UCI AUDIT: "
        f"{cohort.upper()}"
    )
    print("=" * 90)

    print(
        f"Rows: {len(df):,}"
    )

    print(
        f"Columns: {len(df.columns)}"
    )

    print("\nColumns:")
    print(
        list(df.columns)
    )

    missing_columns = [
        c
        for c in SHARED_FEATURES
        if c not in df.columns
    ]

    if missing_columns:

        print(
            "ERROR: Missing expected "
            "columns:",
            missing_columns
        )

    for feature in SHARED_FEATURES:

        if feature not in df.columns:
            continue

        series = df[feature]

        missing_count = int(
            series.isna().sum()
        )

        sentinel_count = (
            count_exact_sentinel(
                series,
                -9
            )
        )

        negative_count = (
            count_negative(series)
        )

        zero_count = (
            count_zero(series)
        )

        desc = descriptive_numeric(
            series
        )

        if feature in PLAUSIBILITY:

            minimum = (
                PLAUSIBILITY[
                    feature
                ]["minimum"]
            )

            maximum = (
                PLAUSIBILITY[
                    feature
                ]["maximum"]
            )

            below, above = (
                plausibility_flags(
                    series,
                    minimum,
                    maximum
                )
            )

        else:

            below = np.nan
            above = np.nan

        row = {

            "dataset":
                cohort,

            "stage":
                "harmonized",

            "feature":
                feature,

            "n_rows":
                len(df),

            "missing_count":
                missing_count,

            "sentinel_minus9_count":
                sentinel_count,

            "negative_count":
                negative_count,

            "zero_count":
                zero_count,

            "n_nonmissing":
                desc["n_nonmissing"],

            "min":
                desc["min"],

            "max":
                desc["max"],

            "mean":
                desc["mean"],

            "median":
                desc["median"],

            "below_plausibility_count":
                below,

            "above_plausibility_count":
                above,
        }

        rows.append(row)

        print(
            f"{feature:22s} | "
            f"missing={missing_count:4d} | "
            f"-9={sentinel_count:4d} | "
            f"negative={negative_count:4d} | "
            f"zero={zero_count:4d} | "
            f"min={desc['min']} | "
            f"max={desc['max']} | "
            f"mean={desc['mean']}"
        )

    return rows


# ============================================================
# 13. EXTERNAL VALIDATION ELIGIBILITY
# ============================================================

def audit_external_eligibility(
    df,
    cohort
):

    required = [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
        "target",
    ]

    available = [
        c
        for c in required
        if c in df.columns
    ]

    complete_mask = (
        df[available]
        .notna()
        .all(axis=1)
    )

    negative_mask = pd.Series(
        False,
        index=df.index
    )

    for feature in [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
    ]:

        if feature in df.columns:

            numeric = safe_numeric(
                df[feature]
            )

            negative_mask |= (
                numeric < 0
            )

    sentinel_mask = pd.Series(
        False,
        index=df.index
    )

    for feature in available:

        numeric = safe_numeric(
            df[feature]
        )

        sentinel_mask |= (
            numeric == -9
        )

    eligible = (
        complete_mask
        & ~negative_mask
        & ~sentinel_mask
    )

    print("\n" + "-" * 90)
    print(
        f"EXTERNAL ELIGIBILITY: "
        f"{cohort.upper()}"
    )
    print("-" * 90)

    print(
        f"Total records       : "
        f"{len(df):,}"
    )

    print(
        f"Complete records    : "
        f"{complete_mask.sum():,}"
    )

    print(
        f"Negative-value rows : "
        f"{negative_mask.sum():,}"
    )

    print(
        f"-9 sentinel rows    : "
        f"{sentinel_mask.sum():,}"
    )

    print(
        f"Eligible records    : "
        f"{eligible.sum():,}"
    )

    print(
        f"Eligibility rate    : "
        f"{100 * eligible.mean():.3f}%"
    )

    return {

        "dataset":
            cohort,

        "total_records":
            int(len(df)),

        "complete_records":
            int(
                complete_mask.sum()
            ),

        "negative_value_rows":
            int(
                negative_mask.sum()
            ),

        "minus9_sentinel_rows":
            int(
                sentinel_mask.sum()
            ),

        "eligible_records":
            int(
                eligible.sum()
            ),

        "eligibility_rate_percent":
            float(
                100 * eligible.mean()
            ),
    }


# ============================================================
# 14. RAW -> HARMONIZED SENTINEL COMPARISON
# ============================================================

def compare_raw_and_harmonized(
    raw_df,
    harmonized_df,
    cohort
):

    print("\n" + "=" * 90)
    print(
        f"DIRECT RAW -> HARMONIZED "
        f"CHECK: {cohort.upper()}"
    )
    print("=" * 90)

    results = []

    mappings = {

        "age":
            "age",

        "sex":
            "sex",

        "trestbps":
            "systolic_bp",

        "chol":
            "cholesterol_category",

        "fbs":
            "elevated_glucose",
    }

    for raw_feature, harm_feature in (
        mappings.items()
    ):

        raw_numeric = safe_numeric(
            raw_df[raw_feature]
        )

        sentinel_rows = (
            raw_numeric == -9
        )

        raw_sentinel_count = int(
            sentinel_rows.sum()
        )

        harm_numeric = safe_numeric(
            harmonized_df[
                harm_feature
            ]
        )

        harm_sentinel_count = int(
            (
                harm_numeric == -9
            ).sum()
        )

        print(
            f"{raw_feature:12s} -> "
            f"{harm_feature:24s} | "
            f"raw -9="
            f"{raw_sentinel_count:4d} | "
            f"harmonized -9="
            f"{harm_sentinel_count:4d}"
        )

        results.append({

            "dataset":
                cohort,

            "raw_feature":
                raw_feature,

            "harmonized_feature":
                harm_feature,

            "raw_minus9_count":
                raw_sentinel_count,

            "harmonized_minus9_count":
                harm_sentinel_count,
        })

    return results


# ============================================================
# 15. HARMONIZED FEATURE SUMMARY
# ============================================================

def print_harmonized_summary():

    print("\n" + "=" * 100)
    print(
        "HARMONIZED SHARED-FEATURE SUMMARY"
    )
    print("=" * 100)

    for cohort in HARMONIZED_FILES:

        path = (
            HARMONIZED_DIR
            / HARMONIZED_FILES[cohort]
        )

        if not path.exists():

            print(
                f"\n{cohort.upper()}: "
                f"HARMONIZED FILE NOT FOUND"
            )

            continue

        df = pd.read_csv(path)

        print(
            f"\n{cohort.upper()}"
        )

        for feature in [
            "age",
            "sex",
            "systolic_bp",
            "cholesterol_category",
            "elevated_glucose",
            "target",
        ]:

            if feature not in df.columns:
                continue

            numeric = safe_numeric(
                df[feature]
            )

            valid = numeric.dropna()

            if len(valid) == 0:

                print(
                    f"  {feature:24s}: "
                    f"no valid observations"
                )

                continue

            print(
                f"  {feature:24s}: "
                f"n={len(valid):4d}, "
                f"min={valid.min():.4f}, "
                f"max={valid.max():.4f}, "
                f"mean={valid.mean():.4f}, "
                f"median={valid.median():.4f}"
            )


# ============================================================
# 16. MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 35"
    )
    print(
        "UCI SENTINEL, MISSING-VALUE "
        "AND OUTLIER AUDIT"
    )
    print("=" * 100)

    print(
        "Timestamp: "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    print(
        f"\nProject root: "
        f"{PROJECT_ROOT}"
    )

    print(
        f"UCI archive : "
        f"{UCI_ZIP}"
    )

    print(
        f"Harmonized  : "
        f"{HARMONIZED_DIR}"
    )

    # ========================================================
    # PATH CHECK
    # ========================================================

    errors = []

    if not PROJECT_ROOT.exists():

        errors.append(
            f"Project root not found: "
            f"{PROJECT_ROOT}"
        )

    if not UCI_ZIP.exists():

        errors.append(
            f"UCI ZIP not found: "
            f"{UCI_ZIP}"
        )

    if not HARMONIZED_DIR.exists():

        errors.append(
            f"Harmonized directory not found: "
            f"{HARMONIZED_DIR}"
        )

    if errors:

        for error in errors:

            print(
                "ERROR:",
                error
            )

        raise FileNotFoundError(
            "Required project paths are missing."
        )

    # ========================================================
    # UCI ARCHIVE INTEGRITY
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "UCI ARCHIVE INTEGRITY"
    )
    print("=" * 100)

    sha256 = sha256_file(
        UCI_ZIP
    )

    print(
        f"SHA-256: {sha256}"
    )

    with zipfile.ZipFile(
        UCI_ZIP,
        "r"
    ) as zf:

        names = zf.namelist()

        print(
            f"Archive entries: "
            f"{len(names)}"
        )

        missing_raw = [
            filename
            for filename in RAW_FILES.values()
            if filename not in names
        ]

        if missing_raw:

            print(
                "ERROR: Missing raw files:",
                missing_raw
            )

            raise FileNotFoundError(
                "Required UCI raw files "
                "not found in ZIP."
            )

        print(
            "All required raw processed "
            "files found."
        )

        # ====================================================
        # COLLECTIONS
        # ====================================================

        raw_summary = []

        harmonized_summary = []

        eligibility_summary = []

        direct_comparison = []

        # ====================================================
        # COHORT LOOP
        # ====================================================

        for cohort, raw_filename in (
            RAW_FILES.items()
        ):

            print("\n\n")

            print(
                "#" * 100
            )

            print(
                f"# COHORT: "
                f"{cohort.upper()}"
            )

            print(
                "#" * 100
            )

            # ------------------------------------------------
            # RAW DATA
            # ------------------------------------------------

            raw_df = load_raw_from_zip(
                zf,
                raw_filename
            )

            raw_rows = audit_raw_cohort(
                raw_df,
                cohort
            )

            raw_summary.extend(
                raw_rows
            )

            print_raw_distributions(
                raw_df,
                cohort
            )

            # ------------------------------------------------
            # HARMONIZED DATA
            # ------------------------------------------------

            harmonized_path = (
                HARMONIZED_DIR
                / HARMONIZED_FILES[
                    cohort
                ]
            )

            if not harmonized_path.exists():

                print(
                    "\nWARNING: Harmonized "
                    "file missing:"
                )

                print(
                    harmonized_path
                )

                continue

            harmonized_df = pd.read_csv(
                harmonized_path
            )

            harm_rows = (
                audit_harmonized_cohort(
                    harmonized_df,
                    cohort
                )
            )

            harmonized_summary.extend(
                harm_rows
            )

            # ------------------------------------------------
            # EXTERNAL ELIGIBILITY
            # ------------------------------------------------

            eligibility = (
                audit_external_eligibility(
                    harmonized_df,
                    cohort
                )
            )

            eligibility_summary.append(
                eligibility
            )

            # ------------------------------------------------
            # DIRECT SENTINEL COMPARISON
            # ------------------------------------------------

            comparison = (
                compare_raw_and_harmonized(
                    raw_df,
                    harmonized_df,
                    cohort
                )
            )

            direct_comparison.extend(
                comparison
            )

    # ========================================================
    # SAVE TABLES
    # ========================================================

    raw_df_out = pd.DataFrame(
        raw_summary
    )

    harm_df_out = pd.DataFrame(
        harmonized_summary
    )

    eligibility_df = pd.DataFrame(
        eligibility_summary
    )

    comparison_df = pd.DataFrame(
        direct_comparison
    )

    raw_output = (
        RESULTS_DIR
        / "audit35_uci_raw_feature_quality.csv"
    )

    harm_output = (
        RESULTS_DIR
        / "audit35_uci_harmonized_feature_quality.csv"
    )

    eligibility_output = (
        RESULTS_DIR
        / "audit35_uci_external_eligibility.csv"
    )

    comparison_output = (
        RESULTS_DIR
        / "audit35_uci_raw_harmonized_sentinel_comparison.csv"
    )

    raw_df_out.to_csv(
        raw_output,
        index=False
    )

    harm_df_out.to_csv(
        harm_output,
        index=False
    )

    eligibility_df.to_csv(
        eligibility_output,
        index=False
    )

    comparison_df.to_csv(
        comparison_output,
        index=False
    )

    # ========================================================
    # GLOBAL SENTINEL CHECK
    # ========================================================

    raw_minus9_total = int(
        raw_df_out[
            "sentinel_minus9_count"
        ].sum()
    )

    harmonized_minus9_total = int(
        harm_df_out[
            "sentinel_minus9_count"
        ].sum()
    )

    harmonized_negative_total = int(
        harm_df_out[
            "negative_count"
        ].sum()
    )

    print("\n" + "=" * 100)
    print(
        "GLOBAL SENTINEL CHECK"
    )
    print("=" * 100)

    print(
        "Raw -9 sentinel occurrences       : "
        f"{raw_minus9_total:,}"
    )

    print(
        "Harmonized -9 sentinel occurrences: "
        f"{harmonized_minus9_total:,}"
    )

    print(
        "Harmonized negative-value count   : "
        f"{harmonized_negative_total:,}"
    )

    # ========================================================
    # HARMONIZED FEATURE SUMMARY
    # ========================================================

    print_harmonized_summary()

    # ========================================================
    # ADDITIONAL COHORT-LEVEL SUMMARY
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "COHORT-LEVEL ELIGIBILITY SUMMARY"
    )
    print("=" * 100)

    if len(eligibility_df) > 0:

        print(
            eligibility_df.to_string(
                index=False
            )
        )

    # ========================================================
    # IMPORTANT OUTLIER REVIEW
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "IMPORTANT RAW OUTLIER REVIEW"
    )
    print("=" * 100)

    outlier_rows = raw_df_out[
        (
            raw_df_out[
                "below_plausibility_count"
            ].fillna(0) > 0
        )
        |
        (
            raw_df_out[
                "above_plausibility_count"
            ].fillna(0) > 0
        )
    ]

    if len(outlier_rows) == 0:

        print(
            "No values outside the defined "
            "audit plausibility ranges."
        )

    else:

        print(
            outlier_rows[
                [
                    "dataset",
                    "feature",
                    "below_plausibility_count",
                    "above_plausibility_count",
                    "min",
                    "max",
                    "mean",
                ]
            ].to_string(
                index=False
            )
        )

    # ========================================================
    # FINAL STATUS
    # ========================================================

    critical_harmonized_sentinel = (
        harmonized_minus9_total > 0
    )

    critical_harmonized_negative = (
        harmonized_negative_total > 0
    )

    if critical_harmonized_sentinel:

        final_status = (
            "FAIL_SENTINEL_REMAINS"
        )

    elif critical_harmonized_negative:

        final_status = (
            "REVIEW_NEGATIVE_VALUES"
        )

    else:

        final_status = (
            "PASS_NO_MINUS9_OR_NEGATIVE_VALUES"
        )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 35 FINAL STATUS"
    )
    print("=" * 100)

    print(
        "Raw -9 occurrences        : "
        f"{raw_minus9_total:,}"
    )

    print(
        "Harmonized -9 occurrences : "
        f"{harmonized_minus9_total:,}"
    )

    print(
        "Harmonized negative values: "
        f"{harmonized_negative_total:,}"
    )

    print(
        f"FINAL STATUS: "
        f"{final_status}"
    )

    # ========================================================
    # PROTOCOL JSON
    # ========================================================

    protocol = {

        "implementation":
            "35",

        "title":
            (
                "UCI Sentinel, Missing-Value "
                "and Outlier Audit"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "purpose":
            (
                "Audit raw and harmonized UCI "
                "external-validation data before "
                "interpreting external model "
                "performance."
            ),

        "raw_archive":
            str(UCI_ZIP),

        "raw_archive_sha256":
            sha256,

        "harmonized_directory":
            str(HARMONIZED_DIR),

        "sentinel_values_checked":
            [
                -9,
                -9.0
            ],

        "missing_markers_checked":
            [
                "?",
                "",
                "nan",
                "NaN",
                "None",
                "none",
            ],

        "clinical_plausibility_ranges":
            PLAUSIBILITY,

        "no_model_training":
            True,

        "no_imputation":
            True,

        "no_threshold_tuning":
            True,

        "no_dataset_modification":
            True,

        "raw_minus9_total":
            raw_minus9_total,

        "harmonized_minus9_total":
            harmonized_minus9_total,

        "harmonized_negative_total":
            harmonized_negative_total,

        "final_status":
            final_status,

        "outputs":
            [
                str(raw_output),
                str(harm_output),
                str(eligibility_output),
                str(comparison_output),
            ],
    }

    protocol_path = (
        RESULTS_DIR
        / "audit35_uci_sentinel_outlier_protocol.json"
    )

    with open(
        protocol_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            protocol,
            f,
            indent=2
        )

    # ========================================================
    # OUTPUT LOCATIONS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        raw_output
    )

    print(
        harm_output
    )

    print(
        eligibility_output
    )

    print(
        comparison_output
    )

    print(
        protocol_path
    )

    # ========================================================
    # COMPLETION
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "AUDIT 35 COMPLETE"
    )
    print("=" * 100)

    print(
        "No model was trained."
    )

    print(
        "No dataset was modified."
    )

    print(
        "No UCI threshold or hyperparameter "
        "was selected."
    )


# ============================================================
# 17. ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()