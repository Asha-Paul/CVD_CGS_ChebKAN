from pathlib import Path
import zipfile

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

TARGET_FILES = [
    "cleveland.data",
    "hungarian.data",
    "switzerland.data",
    "long-beach-va.data",
    "processed.cleveland.data",
    "processed.hungarian.data",
    "processed.switzerland.data",
    "processed.va.data",
]

print("=" * 80)
print("CVD CGS-ChebKAN — UCI DATASET AUDIT")
print("=" * 80)

with zipfile.ZipFile(UCI_ZIP, "r") as z:

    all_files = z.namelist()

    print("\nFiles selected for inspection:")
    print("-" * 80)

    for filename in TARGET_FILES:

        print("\n" + "=" * 80)
        print(filename)
        print("=" * 80)

        if filename not in all_files:
            print("NOT FOUND IN ZIP")
            continue

        info = z.getinfo(filename)

        print(f"Compressed size   : {info.compress_size:,} bytes")
        print(f"Uncompressed size : {info.file_size:,} bytes")

        with z.open(filename) as f:
            raw = f.read()

        text = raw.decode("latin-1", errors="replace")

        lines = text.splitlines()

        print(f"Number of lines   : {len(lines):,}")

        print("\nFirst 15 lines:")
        print("-" * 80)

        for i, line in enumerate(lines[:15], start=1):
            print(f"{i:3d}: {line}")

        print("\nLast 5 lines:")
        print("-" * 80)

        for i, line in enumerate(lines[-5:], start=max(1, len(lines) - 4)):
            print(f"{i:3d}: {line}")

print("\n" + "=" * 80)
print("UCI AUDIT COMPLETED")
print("=" * 80)

print("\nIMPORTANT:")
print("The ZIP archive was read only.")
print("No files were extracted.")
print("No UCI data were modified.")