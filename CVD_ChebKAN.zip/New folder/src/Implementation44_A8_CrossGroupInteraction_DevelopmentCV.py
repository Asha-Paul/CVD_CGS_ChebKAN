"""
IMPLEMENTATION 44
A8: SPARSE CLINICALLY-GROUPED CHEBYSHEV-KAN
    WITH EXPLICIT CROSS-GROUP INTERACTION
DEVELOPMENT OUTER-CV ONLY

Purpose
-------
Controlled architecture experiment to test whether explicit interactions
between clinical-group embeddings recover information lost by independent
group fusion in A6.

STRICT PROTOCOL
---------------
- Development cohort only: 49,000 records.
- Same 5 outer folds as A6 (SEED=2026).
- Same 4-inner-fold protocol is NOT used here because A6 hyperparameters
  were already selected; the A6 selected configuration is frozen.
- Same 11-feature representation.
- Same clinical groups.
- Same Chebyshev first-kind K=5.
- Same 16-dimensional group embeddings.
- Same SiLU activation.
- Same fold-specific median imputation.
- Same MinMax scaling to [-1, 1].
- Same A6 regularization:
      learning rate = 1e-3
      L2 = 1e-4
      KAN L1 = 1e-5
      gate L1 = 1e-4
- Same batch size = 1024.
- Same maximum epochs = 100.
- Same patience = 10.
- No ADASYN.
- No conformal prediction.
- No calibration data.
- No locked-test data.
- No UCI data.
- No model selection using the locked test.

A8 ARCHITECTURE
---------------
Each clinical group is represented by a Chebyshev-KAN embedding.

Three group embeddings:
    h_demo
    h_phys
    h_life

Sparse gated fusion:
    h_gate = sum_g alpha_g h_g

Explicit cross-group interactions:
    h_dp = h_demo * h_phys
    h_dl = h_demo * h_life
    h_pl = h_phys * h_life

Interaction projection:
    h_int = SiLU(W_int [h_dp, h_dl, h_pl] + b_int)

Final representation:
    h_final = [h_gate, h_int]

Output:
    logit = W_out h_final + b_out

This tests whether pairwise cross-group information can be recovered
without removing the clinical grouping or sparse gates.

OUTPUTS
-------
results/tables/implementation44_a8_outer_results.csv
results/tables/implementation44_a8_outer_predictions.csv
results/tables/implementation44_a8_gate_stability.csv
results/tables/implementation44_a8_protocol.json
results/tables/implementation44_a8_summary.json
results/tables/implementation44_a8_report.txt
results/models/implementation44_a8_fold1.pt ... fold5.pt

IMPORTANT
---------
This is an exploratory Development-CV experiment. It must NOT be used to
claim final locked-test performance. If A8 is promising, it must first be
statistically compared against A6 and the established baselines before
any decision about a future final evaluation.
"""

import os
import json
import time
import random
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

warnings.filterwarnings("ignore")


# =============================================================================
# 1. REPRODUCIBILITY
# =============================================================================

SEED = 2026


def seed_everything(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


seed_everything()


# =============================================================================
# 2. PATHS
# =============================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
MODELS_DIR = PROJECT_ROOT / "results" / "models"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"

# A8 deliberately does not load calibration or locked-test data.


# =============================================================================
# 3. FEATURES AND GROUPS
# =============================================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"

GROUPS = {
    "demographic": [
        "age",
        "gender",
    ],
    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],
    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}

GROUP_ORDER = list(GROUPS.keys())

GROUP_INDEXES = {
    group_name: [FEATURES.index(f) for f in feature_list]
    for group_name, feature_list in GROUPS.items()
}


# =============================================================================
# 4. FROZEN A6 TRAINING SETTINGS
# =============================================================================

CHEB_K = 5
GROUP_EMBED_DIM = 16

# A6 reduced-runtime search selected lr=1e-3 in all five outer folds.
# For this controlled architecture experiment, these values are frozen.
LEARNING_RATE = 1e-3
L2 = 1e-4
KAN_L1 = 1e-5
GATE_L1 = 1e-4

BATCH_SIZE = 1024
MAX_EPOCHS = 100
PATIENCE = 10
OUTER_FOLDS = 5

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# =============================================================================
# 5. METRICS
# =============================================================================

def expected_calibration_error(y_true, probabilities, n_bins=10):
    y_true = np.asarray(y_true).astype(int)
    probabilities = np.asarray(probabilities)

    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0

    for i in range(n_bins):
        if i == n_bins - 1:
            mask = (
                (probabilities >= bins[i])
                & (probabilities <= bins[i + 1])
            )
        else:
            mask = (
                (probabilities >= bins[i])
                & (probabilities < bins[i + 1])
            )

        if not np.any(mask):
            continue

        confidence = np.mean(probabilities[mask])
        accuracy = np.mean(
            y_true[mask] == (probabilities[mask] >= 0.5)
        )

        ece += (
            np.sum(mask) / len(y_true)
        ) * abs(accuracy - confidence)

    return float(ece)


def calculate_metrics(y_true, probabilities):
    probabilities = np.asarray(probabilities).reshape(-1)
    predictions = (probabilities >= 0.5).astype(int)

    tn = np.sum(
        (y_true == 0) & (predictions == 0)
    )
    fp = np.sum(
        (y_true == 0) & (predictions == 1)
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else np.nan
    )

    return {
        "accuracy": accuracy_score(y_true, predictions),
        "precision": precision_score(
            y_true, predictions, zero_division=0
        ),
        "sensitivity": recall_score(
            y_true, predictions, zero_division=0
        ),
        "specificity": specificity,
        "f1": f1_score(
            y_true, predictions, zero_division=0
        ),
        "roc_auc": roc_auc_score(
            y_true, probabilities
        ),
        "pr_auc": average_precision_score(
            y_true, probabilities
        ),
        "brier": brier_score_loss(
            y_true, probabilities
        ),
        "ece": expected_calibration_error(
            y_true, probabilities
        ),
    }


# =============================================================================
# 6. PREPROCESSING
# =============================================================================

def fit_preprocessor(X_raw):
    """
    Fit imputation and scaling ONLY on the current training partition.
    """
    imputer = SimpleImputer(strategy="median")
    X_imputed = imputer.fit_transform(X_raw)

    scaler = MinMaxScaler(
        feature_range=(-1.0, 1.0)
    )
    X_scaled = scaler.fit_transform(X_imputed)

    return imputer, scaler, X_scaled.astype(np.float32)


def transform_preprocessor(X_raw, imputer, scaler):
    X_imputed = imputer.transform(X_raw)
    X_scaled = scaler.transform(X_imputed)
    return X_scaled.astype(np.float32)


# =============================================================================
# 7. CHEBYSHEV-KAN LAYER
# =============================================================================

class ChebyshevKAN(nn.Module):

    def __init__(self, input_dim, output_dim, degree):
        super().__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                output_dim,
                input_dim,
                degree + 1,
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(output_dim)
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02,
        )

    def forward(self, x):

        # x is expected to be in [-1, 1].
        x = torch.clamp(x, -1.0, 1.0)

        t0 = torch.ones_like(x)

        terms = [t0]

        if self.degree >= 1:
            terms.append(x)

        for k in range(2, self.degree + 1):
            terms.append(
                2.0 * x * terms[-1] - terms[-2]
            )

        basis = torch.stack(
            terms,
            dim=-1,
        )

        # basis: [batch, input_dim, degree+1]
        # coefficients: [output_dim, input_dim, degree+1]
        output = torch.einsum(
            "bid,oid->bo",
            basis,
            self.coefficients,
        )

        return output + self.bias


# =============================================================================
# 8. A8 MODEL
# =============================================================================

class A8CrossGroupInteractionChebKAN(nn.Module):

    def __init__(
        self,
        group_sizes,
        embedding_dim=16,
        degree=5,
    ):
        super().__init__()

        self.embedding_dim = embedding_dim

        self.demographic_kan = ChebyshevKAN(
            group_sizes["demographic"],
            embedding_dim,
            degree,
        )

        self.physiological_kan = ChebyshevKAN(
            group_sizes[
                "physiological_anthropometric_metabolic"
            ],
            embedding_dim,
            degree,
        )

        self.lifestyle_kan = ChebyshevKAN(
            group_sizes["lifestyle"],
            embedding_dim,
            degree,
        )

        self.interaction_projection = nn.Linear(
            embedding_dim * 3,
            embedding_dim,
        )

        self.output_layer = nn.Linear(
            embedding_dim * 2,
            1,
        )

        self.gate_logits = nn.Parameter(
            torch.zeros(3)
        )

        self.activation = nn.SiLU()

    def forward(self, group_inputs):

        h_demo = self.activation(
            self.demographic_kan(
                group_inputs["demographic"]
            )
        )

        h_phys = self.activation(
            self.physiological_kan(
                group_inputs[
                    "physiological_anthropometric_metabolic"
                ]
            )
        )

        h_life = self.activation(
            self.lifestyle_kan(
                group_inputs["lifestyle"]
            )
        )

        # ---------------------------------------------------------
        # Sparse gated clinical fusion
        # ---------------------------------------------------------

        gates = torch.softmax(
            self.gate_logits,
            dim=0,
        )

        h_gate = (
            gates[0] * h_demo
            + gates[1] * h_phys
            + gates[2] * h_life
        )

        # ---------------------------------------------------------
        # Explicit cross-group interactions
        # ---------------------------------------------------------

        interaction_demo_phys = (
            h_demo * h_phys
        )

        interaction_demo_life = (
            h_demo * h_life
        )

        interaction_phys_life = (
            h_phys * h_life
        )

        interactions = torch.cat(
            [
                interaction_demo_phys,
                interaction_demo_life,
                interaction_phys_life,
            ],
            dim=1,
        )

        h_interaction = self.activation(
            self.interaction_projection(
                interactions
            )
        )

        # ---------------------------------------------------------
        # Final representation
        # ---------------------------------------------------------

        h_final = torch.cat(
            [
                h_gate,
                h_interaction,
            ],
            dim=1,
        )

        return self.output_layer(
            h_final
        ).squeeze(1)

    def coefficient_l1(self):
        return (
            self.demographic_kan.coefficients.abs().sum()
            + self.physiological_kan.coefficients.abs().sum()
            + self.lifestyle_kan.coefficients.abs().sum()
        )

    def gate_l1(self):
        return self.gate_logits.abs().sum()

    def gate_values(self):
        return (
            torch.softmax(
                self.gate_logits,
                dim=0,
            )
            .detach()
            .cpu()
            .numpy()
        )


# =============================================================================
# 9. GROUP TENSOR CREATION
# =============================================================================

def make_group_tensors(X):
    return {
        group_name: torch.tensor(
            X[:, GROUP_INDEXES[group_name]],
            dtype=torch.float32,
            device=DEVICE,
        )
        for group_name in GROUP_ORDER
    }


# =============================================================================
# 10. DATA LOADER
# =============================================================================

def create_training_loader(X, y):

    tensors = [
        torch.tensor(
            X[:, GROUP_INDEXES[group_name]],
            dtype=torch.float32,
        )
        for group_name in GROUP_ORDER
    ]

    tensors.append(
        torch.tensor(
            y.astype(np.float32),
            dtype=torch.float32,
        )
    )

    dataset = TensorDataset(*tensors)

    generator = torch.Generator()
    generator.manual_seed(SEED)

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        generator=generator,
        drop_last=False,
        pin_memory=torch.cuda.is_available(),
    )


# =============================================================================
# 11. INTERNAL EARLY-STOPPING SPLIT
# =============================================================================

def make_internal_split(y, seed):

    splitter = StratifiedKFold(
        n_splits=10,
        shuffle=True,
        random_state=seed,
    )

    dummy = np.zeros(
        (len(y), 1)
    )

    train_idx, stop_idx = next(
        splitter.split(dummy, y)
    )

    return train_idx, stop_idx


# =============================================================================
# 12. MODEL TRAINING
# =============================================================================

def fit_model(
    X_train,
    y_train,
    X_stop,
    y_stop,
    seed,
):
    seed_everything(seed)

    if len(X_train) != len(y_train):
        raise RuntimeError(
            f"Training mismatch: X={len(X_train)}, "
            f"y={len(y_train)}"
        )

    if len(X_stop) != len(y_stop):
        raise RuntimeError(
            f"Stopping mismatch: X={len(X_stop)}, "
            f"y={len(y_stop)}"
        )

    model = A8CrossGroupInteractionChebKAN(
        group_sizes={
            group_name: len(GROUPS[group_name])
            for group_name in GROUP_ORDER
        },
        embedding_dim=GROUP_EMBED_DIM,
        degree=CHEB_K,
    ).to(DEVICE)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=L2,
    )

    criterion = nn.BCEWithLogitsLoss()

    loader = create_training_loader(
        X_train,
        y_train,
    )

    stop_groups = make_group_tensors(
        X_stop
    )

    stop_target = torch.tensor(
        y_stop.astype(np.float32),
        dtype=torch.float32,
        device=DEVICE,
    )

    best_state = None
    best_loss = np.inf
    best_epoch = 0
    patience_counter = 0

    for epoch in range(
        1,
        MAX_EPOCHS + 1,
    ):

        model.train()

        for batch in loader:

            group_inputs = {}

            for i, group_name in enumerate(
                GROUP_ORDER
            ):
                group_inputs[group_name] = (
                    batch[i]
                    .to(
                        DEVICE,
                        non_blocking=True,
                    )
                )

            batch_y = (
                batch[len(GROUP_ORDER)]
                .to(
                    DEVICE,
                    non_blocking=True,
                )
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(
                group_inputs
            )

            bce_loss = criterion(
                logits,
                batch_y,
            )

            total_loss = (
                bce_loss
                + KAN_L1 * model.coefficient_l1()
                + GATE_L1 * model.gate_l1()
            )

            total_loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=5.0,
            )

            optimizer.step()

        model.eval()

        with torch.no_grad():
            stop_logits = model(
                stop_groups
            )

            stop_loss = criterion(
                stop_logits,
                stop_target,
            ).item()

        if stop_loss < best_loss - 1e-6:

            best_loss = stop_loss

            best_state = {
                key: value.detach().cpu().clone()
                for key, value
                in model.state_dict().items()
            }

            best_epoch = epoch
            patience_counter = 0

        else:
            patience_counter += 1

        if patience_counter >= PATIENCE:
            break

    if best_state is not None:
        model.load_state_dict(
            best_state
        )

    model.eval()

    return (
        model,
        best_epoch,
        best_loss,
    )


# =============================================================================
# 13. PREDICTION
# =============================================================================

def predict_model(model, X):

    model.eval()

    group_tensors = make_group_tensors(
        X
    )

    with torch.no_grad():

        logits = model(
            group_tensors
        )

        probabilities = (
            torch.sigmoid(logits)
            .detach()
            .cpu()
            .numpy()
        )

    return probabilities


# =============================================================================
# 14. MAIN
# =============================================================================

def main():

    start_time = time.time()

    print("=" * 80)
    print("IMPLEMENTATION 44")
    print("A8: CROSS-GROUP INTERACTION SPARSE GROUPED CHEBYSHEV-KAN")
    print("DEVELOPMENT OUTER-CV ONLY")
    print("=" * 80)

    print()
    print("STRICT PROTECTION:")
    print("  Development cohort only: YES")
    print("  Calibration data loaded: NO")
    print("  Locked test loaded: NO")
    print("  UCI data loaded: NO")
    print("  Retraining on locked test: NO")
    print()

    print("=" * 80)
    print("1. CONFIGURATION")
    print("=" * 80)

    print("Seed:", SEED)
    print("Chebyshev degree:", CHEB_K)
    print("Group embedding:", GROUP_EMBED_DIM)
    print("Learning rate:", LEARNING_RATE)
    print("L2:", L2)
    print("KAN L1:", KAN_L1)
    print("Gate L1:", GATE_L1)
    print("Batch size:", BATCH_SIZE)
    print("Maximum epochs:", MAX_EPOCHS)
    print("Patience:", PATIENCE)
    print("Outer folds:", OUTER_FOLDS)
    print("Device:", DEVICE)

    print()
    print("Clinical groups:")
    for group_name in GROUP_ORDER:
        print(
            f"  {group_name}: "
            f"{GROUPS[group_name]}"
        )

    # -------------------------------------------------------------------------
    # Load development
    # -------------------------------------------------------------------------

    print()
    print("=" * 80)
    print("2. LOADING DEVELOPMENT DATA")
    print("=" * 80)

    if not DEV_FILE.exists():
        raise FileNotFoundError(
            f"Development file not found:\n{DEV_FILE}"
        )

    dev_df = pd.read_csv(
        DEV_FILE
    )

    print("File:", DEV_FILE)
    print("Rows:", f"{len(dev_df):,}")
    print("Columns:", list(dev_df.columns))

    if len(dev_df) != 49000:
        raise RuntimeError(
            f"Expected 49,000 development rows; "
            f"found {len(dev_df):,}."
        )

    if dev_df["id"].duplicated().any():
        raise RuntimeError(
            "Duplicate development IDs detected."
        )

    required = FEATURES + [TARGET, "id"]

    missing = [
        c for c in required
        if c not in dev_df.columns
    ]

    if missing:
        raise RuntimeError(
            f"Missing required columns: {missing}"
        )

    print(
        "PASS: exactly 49,000 unique development IDs."
    )

    # -------------------------------------------------------------------------
    # Development arrays
    # -------------------------------------------------------------------------

    X_dev = dev_df[
        FEATURES
    ].to_numpy(
        dtype=np.float32
    )

    y_dev = dev_df[
        TARGET
    ].to_numpy(
        dtype=np.int64
    )

    if len(X_dev) != len(y_dev):
        raise RuntimeError(
            "X/y length mismatch."
        )

    print(
        "Development X shape:",
        X_dev.shape,
    )
    print(
        "Development y shape:",
        y_dev.shape,
    )

    # -------------------------------------------------------------------------
    # Model parameter count
    # -------------------------------------------------------------------------

    temp_model = A8CrossGroupInteractionChebKAN(
        group_sizes={
            group_name: len(GROUPS[group_name])
            for group_name in GROUP_ORDER
        },
        embedding_dim=GROUP_EMBED_DIM,
        degree=CHEB_K,
    ).to(DEVICE)

    parameter_count = sum(
        p.numel()
        for p in temp_model.parameters()
    )

    del temp_model

    print(
        "A8 parameter count:",
        f"{parameter_count:,}",
    )

    # -------------------------------------------------------------------------
    # Outer CV
    # -------------------------------------------------------------------------

    outer_splitter = StratifiedKFold(
        n_splits=OUTER_FOLDS,
        shuffle=True,
        random_state=SEED,
    )

    outer_results = []
    prediction_frames = []
    gate_rows = []

    for outer_fold, (
        train_idx,
        val_idx,
    ) in enumerate(
        outer_splitter.split(
            X_dev,
            y_dev,
        ),
        start=1,
    ):

        print()
        print("=" * 80)
        print(
            f"OUTER FOLD {outer_fold}/{OUTER_FOLDS}"
        )
        print("=" * 80)

        X_outer_train_raw = X_dev[
            train_idx
        ]

        y_outer_train = y_dev[
            train_idx
        ]

        X_outer_val_raw = X_dev[
            val_idx
        ]

        y_outer_val = y_dev[
            val_idx
        ]

        print(
            "Outer training:",
            len(X_outer_train_raw),
        )
        print(
            "Outer validation:",
            len(X_outer_val_raw),
        )

        # -----------------------------------------------------
        # Fold-specific preprocessing
        # -----------------------------------------------------

        imputer, scaler, X_outer_train = (
            fit_preprocessor(
                X_outer_train_raw
            )
        )

        X_outer_val = (
            transform_preprocessor(
                X_outer_val_raw,
                imputer,
                scaler,
            )
        )

        # -----------------------------------------------------
        # Early stopping split
        # -----------------------------------------------------

        fit_idx, stop_idx = (
            make_internal_split(
                y_outer_train,
                seed=SEED + outer_fold,
            )
        )

        X_fit = X_outer_train[
            fit_idx
        ]

        y_fit = y_outer_train[
            fit_idx
        ]

        X_stop = X_outer_train[
            stop_idx
        ]

        y_stop = y_outer_train[
            stop_idx
        ]

        print(
            "Training subset:",
            len(X_fit),
        )
        print(
            "Early-stopping subset:",
            len(X_stop),
        )

        # -----------------------------------------------------
        # Train A8
        # -----------------------------------------------------

        model, best_epoch, best_stop_loss = (
            fit_model(
                X_fit,
                y_fit,
                X_stop,
                y_stop,
                seed=SEED + 10000 + outer_fold,
            )
        )

        # -----------------------------------------------------
        # Validation prediction
        # -----------------------------------------------------

        probabilities = predict_model(
            model,
            X_outer_val,
        )

        metrics = calculate_metrics(
            y_outer_val,
            probabilities,
        )

        gates = model.gate_values()

        coefficient_l1 = float(
            model.coefficient_l1()
            .detach()
            .cpu()
            .item()
        )

        gate_l1 = float(
            model.gate_l1()
            .detach()
            .cpu()
            .item()
        )

        row = {
            "outer_fold": outer_fold,
            **metrics,
            "best_epoch": best_epoch,
            "best_stop_loss": best_stop_loss,
            "kan_coefficient_l1_value": coefficient_l1,
            "gate_logit_l1_value": gate_l1,
            "gate_demographic": gates[0],
            "gate_physiological_anthropometric_metabolic": gates[1],
            "gate_lifestyle": gates[2],
            "n_parameters": parameter_count,
        }

        outer_results.append(row)

        gate_rows.append(
            {
                "outer_fold": outer_fold,
                "demographic": gates[0],
                "physiological_anthropometric_metabolic": gates[1],
                "lifestyle": gates[2],
            }
        )

        prediction_frames.append(
            pd.DataFrame(
                {
                    "row_index": val_idx,
                    "outer_fold": outer_fold,
                    "y_true": y_outer_val,
                    "probability": probabilities,
                }
            )
        )

        print()
        print("Outer-fold results:")

        for metric in [
            "accuracy",
            "precision",
            "sensitivity",
            "specificity",
            "f1",
            "roc_auc",
            "pr_auc",
            "brier",
            "ece",
        ]:
            print(
                f"{metric:12s}: "
                f"{metrics[metric]:.6f}"
            )

        print(
            "Best epoch:",
            best_epoch,
        )
        print(
            "Parameters:",
            f"{parameter_count:,}",
        )

        print("Group gates:")
        print(
            f"  Demographic: "
            f"{gates[0]:.6f}"
        )
        print(
            f"  Physiological: "
            f"{gates[1]:.6f}"
        )
        print(
            f"  Lifestyle: "
            f"{gates[2]:.6f}"
        )

        # -----------------------------------------------------
        # Save fold model
        # -----------------------------------------------------

        model_path = (
            MODELS_DIR
            / f"implementation44_a8_fold{outer_fold}.pt"
        )

        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "features": FEATURES,
                "groups": GROUPS,
                "group_indices": GROUP_INDEXES,
                "cheb_degree": CHEB_K,
                "embedding_dim": GROUP_EMBED_DIM,
                "learning_rate": LEARNING_RATE,
                "l2": L2,
                "kan_l1": KAN_L1,
                "gate_l1": GATE_L1,
                "best_epoch": best_epoch,
                "seed": SEED,
                "architecture": (
                    "A8 sparse clinically-grouped "
                    "Chebyshev-KAN with explicit "
                    "pairwise cross-group interaction"
                ),
            },
            model_path,
        )

        print(
            "Model saved:",
            model_path,
        )

        del model

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # -------------------------------------------------------------------------
    # Combine predictions
    # -------------------------------------------------------------------------

    prediction_df = (
        pd.concat(
            prediction_frames,
            ignore_index=True,
        )
        .sort_values(
            "row_index"
        )
        .reset_index(drop=True)
    )

    expected = len(dev_df)
    observed = len(prediction_df)
    unique_rows = prediction_df[
        "row_index"
    ].nunique()

    coverage_pass = (
        observed == expected
        and unique_rows == expected
        and set(
            prediction_df["row_index"]
        ) == set(range(expected))
    )

    print()
    print("=" * 80)
    print("3. OUTER-CV COVERAGE")
    print("=" * 80)

    print("Expected:", expected)
    print("Observed:", observed)
    print("Unique row indices:", unique_rows)
    print("Exact 0..48,999 coverage:", coverage_pass)

    if not coverage_pass:
        raise RuntimeError(
            "A8 outer-CV coverage failed."
        )

    # -------------------------------------------------------------------------
    # Pooled metrics
    # -------------------------------------------------------------------------

    pooled_metrics = calculate_metrics(
        prediction_df[
            "y_true"
        ].to_numpy(),
        prediction_df[
            "probability"
        ].to_numpy(),
    )

    outer_df = pd.DataFrame(
        outer_results
    )

    gate_df = pd.DataFrame(
        gate_rows
    )

    # -------------------------------------------------------------------------
    # Save predictions/results
    # -------------------------------------------------------------------------

    outer_path = (
        RESULTS_DIR
        / "implementation44_a8_outer_results.csv"
    )

    prediction_path = (
        RESULTS_DIR
        / "implementation44_a8_outer_predictions.csv"
    )

    gate_path = (
        RESULTS_DIR
        / "implementation44_a8_gate_stability.csv"
    )

    outer_df.to_csv(
        outer_path,
        index=False,
    )

    prediction_df.to_csv(
        prediction_path,
        index=False,
    )

    gate_df.to_csv(
        gate_path,
        index=False,
    )

    # -------------------------------------------------------------------------
    # Protocol
    # -------------------------------------------------------------------------

    protocol = {
        "implementation": "44",
        "experiment": "A8_cross_group_interaction_development_outer_cv",
        "model": (
            "Sparse Clinically-Grouped Chebyshev-KAN "
            "with explicit pairwise cross-group interaction"
        ),
        "development_rows": int(len(dev_df)),
        "features": FEATURES,
        "groups": GROUPS,
        "chebyshev_basis": "first_kind",
        "chebyshev_degree": CHEB_K,
        "group_embedding_dimension": GROUP_EMBED_DIM,
        "activation": "SiLU",
        "group_fusion": "softmax_weighted_group_sum",
        "cross_group_interaction": (
            "pairwise Hadamard products of three group embeddings, "
            "followed by linear projection and SiLU"
        ),
        "final_representation": (
            "concatenated gated group fusion and interaction embedding"
        ),
        "kan_regularization": "L1_on_Chebyshev_coefficients",
        "gate_regularization": "L1_on_pre_softmax_gate_logits",
        "loss": "BCE + lambda_KAN*KAN_L1 + lambda_gate*Gate_L1",
        "learning_rate": LEARNING_RATE,
        "l2": L2,
        "kan_l1": KAN_L1,
        "gate_l1": GATE_L1,
        "batch_size": BATCH_SIZE,
        "max_epochs": MAX_EPOCHS,
        "patience": PATIENCE,
        "outer_folds": OUTER_FOLDS,
        "random_state": SEED,
        "adasyn": False,
        "conformal_prediction": False,
        "calibration_used": False,
        "locked_test_used": False,
        "uci_used": False,
        "inner_hyperparameter_search": False,
        "hyperparameters_frozen_from": "A6_corrected_reduced_runtime",
        "note": (
            "Controlled architecture experiment. The A6-selected "
            "training configuration is frozen to isolate the effect "
            "of explicit cross-group interaction. This is exploratory "
            "development-CV evidence and is not a locked-test result."
        ),
    }

    protocol_path = (
        RESULTS_DIR
        / "implementation44_a8_protocol.json"
    )

    with open(
        protocol_path,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            protocol,
            f,
            indent=2,
        )

    # -------------------------------------------------------------------------
    # Summary JSON
    # -------------------------------------------------------------------------

    summary = {
        "implementation": "44",
        "status": "PASS_A8_DEVELOPMENT_OUTER_CV"
        if coverage_pass
        else "FAIL_A8_DEVELOPMENT_OUTER_CV",
        "n_development": int(len(dev_df)),
        "n_outer_folds": OUTER_FOLDS,
        "mean_outer_roc_auc": float(
            outer_df["roc_auc"].mean()
        ),
        "sd_outer_roc_auc": float(
            outer_df["roc_auc"].std(ddof=1)
        ),
        "pooled_roc_auc": float(
            pooled_metrics["roc_auc"]
        ),
        "pooled_pr_auc": float(
            pooled_metrics["pr_auc"]
        ),
        "pooled_brier": float(
            pooled_metrics["brier"]
        ),
        "pooled_ece": float(
            pooled_metrics["ece"]
        ),
        "parameter_count": int(parameter_count),
        "gate_means": {
            "demographic": float(
                gate_df["demographic"].mean()
            ),
            "physiological_anthropometric_metabolic": float(
                gate_df[
                    "physiological_anthropometric_metabolic"
                ].mean()
            ),
            "lifestyle": float(
                gate_df["lifestyle"].mean()
            ),
        },
        "coverage_pass": bool(coverage_pass),
        "locked_test_used": False,
        "calibration_used": False,
        "uci_used": False,
    }

    summary_path = (
        RESULTS_DIR
        / "implementation44_a8_summary.json"
    )

    with open(
        summary_path,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            summary,
            f,
            indent=2,
        )

    # -------------------------------------------------------------------------
    # Report
    # -------------------------------------------------------------------------

    elapsed_minutes = (
        time.time() - start_time
    ) / 60.0

    report_lines = [
        "=" * 80,
        "IMPLEMENTATION 44",
        "A8 CROSS-GROUP INTERACTION SPARSE GROUPED CHEBYSHEV-KAN",
        "DEVELOPMENT OUTER-CV ONLY",
        "=" * 80,
        "",
        "PROTECTION",
        "-" * 80,
        "Calibration used: NO",
        "Locked test used: NO",
        "UCI used: NO",
        "Retraining on locked test: NO",
        "",
        "ARCHITECTURE",
        "-" * 80,
        "Chebyshev first kind, K=5",
        "Three clinical groups",
        "16-dimensional group embeddings",
        "Softmax sparse group gates",
        "Pairwise cross-group Hadamard interactions",
        "Interaction projection + SiLU",
        "Final representation = gated fusion + interaction embedding",
        "",
        "RESULTS",
        "-" * 80,
        f"Development records: {len(dev_df):,}",
        f"Outer folds: {OUTER_FOLDS}",
        f"Mean outer ROC-AUC: {outer_df['roc_auc'].mean():.6f}",
        f"SD outer ROC-AUC: {outer_df['roc_auc'].std(ddof=1):.6f}",
        f"Pooled ROC-AUC: {pooled_metrics['roc_auc']:.6f}",
        f"Pooled PR-AUC: {pooled_metrics['pr_auc']:.6f}",
        f"Pooled Brier: {pooled_metrics['brier']:.6f}",
        f"Pooled ECE: {pooled_metrics['ece']:.6f}",
        f"Parameters: {parameter_count:,}",
        "",
        "FOLD RESULTS",
        "-" * 80,
        outer_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        ),
        "",
        "GATE STABILITY",
        "-" * 80,
        gate_df.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}",
        ),
        "",
        "OVERALL INTERPRETATION",
        "-" * 80,
        (
            "This is Development-CV evidence only. It must not be "
            "reported as locked-test performance. A8 should be compared "
            "against A6 and the verified baselines using the same "
            "49,000-record outer-CV cohort before any final model decision."
        ),
        "",
        f"Execution time: {elapsed_minutes:.2f} minutes",
        "",
        "FINAL STATUS",
        "-" * 80,
        "PASS_A8_DEVELOPMENT_OUTER_CV"
        if coverage_pass
        else "FAIL_A8_DEVELOPMENT_OUTER_CV",
    ]

    report_path = (
        RESULTS_DIR
        / "implementation44_a8_report.txt"
    )

    report_path.write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )

    # -------------------------------------------------------------------------
    # Console final
    # -------------------------------------------------------------------------

    print()
    print("=" * 80)
    print("4. A8 FINAL DEVELOPMENT-CV SUMMARY")
    print("=" * 80)

    print(
        "Mean outer ROC-AUC:",
        f"{outer_df['roc_auc'].mean():.6f}",
    )
    print(
        "SD outer ROC-AUC:",
        f"{outer_df['roc_auc'].std(ddof=1):.6f}",
    )
    print(
        "Pooled ROC-AUC:",
        f"{pooled_metrics['roc_auc']:.6f}",
    )
    print(
        "Pooled PR-AUC:",
        f"{pooled_metrics['pr_auc']:.6f}",
    )
    print(
        "Pooled Brier:",
        f"{pooled_metrics['brier']:.6f}",
    )
    print(
        "Pooled ECE:",
        f"{pooled_metrics['ece']:.6f}",
    )
    print(
        "Parameters:",
        f"{parameter_count:,}",
    )

    print()
    print("Gate means:")
    print(
        "  Demographic:",
        f"{gate_df['demographic'].mean():.6f}",
    )
    print(
        "  Physiological:",
        f"{gate_df['physiological_anthropometric_metabolic'].mean():.6f}",
    )
    print(
        "  Lifestyle:",
        f"{gate_df['lifestyle'].mean():.6f}",
    )

    print()
    print("=" * 80)
    print("IMPLEMENTATION 44 COMPLETE")
    print("=" * 80)

    print(
        "Final status:",
        "PASS_A8_DEVELOPMENT_OUTER_CV"
        if coverage_pass
        else "FAIL_A8_DEVELOPMENT_OUTER_CV",
    )

    print()
    print("Outputs:")
    print(outer_path)
    print(prediction_path)
    print(gate_path)
    print(protocol_path)
    print(summary_path)
    print(report_path)

    print()
    print(
        "IMPORTANT: A8 is Development-CV exploratory evidence only."
    )
    print(
        "The locked test, conformal calibration set, and UCI cohorts "
        "were not used."
    )


if __name__ == "__main__":
    main()
