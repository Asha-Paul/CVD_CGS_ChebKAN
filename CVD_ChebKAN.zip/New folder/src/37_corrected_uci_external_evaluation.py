# ============================================================
# IMPLEMENTATION 37
# CORRECTED UCI EXTERNAL EVALUATION
#
# Purpose:
#   Recalculate the UCI external-validation metrics using the
#   existing Implementation 34 predictions after applying the
#   corrected shared-feature eligibility rule.
#
# IMPORTANT:
#   - NO model retraining
#   - NO hyperparameter tuning
#   - NO threshold tuning
#   - NO UCI-based model selection
#   - NO modification of the original harmonized datasets
#
# Correction:
#   VA source_row = 33 has systolic_bp = 0 and is invalid.
#   It is excluded from the corrected VA evaluation.
#
# Expected corrected cohorts:
#   Cleveland  : 303
#   Hungarian  : 262
#   Switzerland: 0
#   VA         : 99
#
# ============================================================

from pathlib import Path
import json
from datetime import datetime

import numpy as np
import pandas as pd

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
)


# ============================================================
# 1. PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

PREDICTION_FILE = (
    RESULTS_DIR
    / "implementation34_uci_external_predictions.csv"
)

CORRECTED_PREDICTION_FILE = (
    RESULTS_DIR
    / "implementation37_uci_corrected_external_predictions.csv"
)

RESULTS_FILE = (
    RESULTS_DIR
    / "implementation37_uci_corrected_external_results.csv"
)

COMPARISON_FILE = (
    RESULTS_DIR
    / "implementation37_uci_original_vs_corrected_comparison.csv"
)

PROTOCOL_FILE = (
    RESULTS_DIR
    / "implementation37_uci_corrected_external_protocol.json"
)


# ============================================================
# 2. EXPECTED COHORT SIZES
# ============================================================

EXPECTED_CORRECTED = {
    "cleveland": 303,
    "hungarian": 262,
    "switzerland": 0,
    "va": 99,
}


# ============================================================
# 3. INVALID RECORD IDENTIFIED IN IMPLEMENTATION 36
# ============================================================

INVALID_VA_SOURCE_ROW = 33


# ============================================================
# 4. HELPER: FIND COLUMN
# ============================================================

def find_column(
    df,
    candidates,
    required=True
):

    for column in candidates:

        if column in df.columns:
            return column

    if required:

        raise ValueError(
            "None of the expected columns "
            f"were found: {candidates}"
        )

    return None


# ============================================================
# 5. METRIC CALCULATION
# ============================================================

def calculate_metrics(
    y_true,
    y_prob,
    threshold=0.5
):

    y_true = np.asarray(
        y_true
    ).astype(int)

    y_prob = np.asarray(
        y_prob
    ).astype(float)

    y_pred = (
        y_prob >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        y_pred,
        labels=[0, 1]
    ).ravel()

    accuracy = accuracy_score(
        y_true,
        y_pred
    )

    precision = precision_score(
        y_true,
        y_pred,
        zero_division=0
    )

    sensitivity = recall_score(
        y_true,
        y_pred,
        zero_division=0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else np.nan
    )

    f1 = f1_score(
        y_true,
        y_pred,
        zero_division=0
    )

    roc_auc = roc_auc_score(
        y_true,
        y_prob
    )

    pr_auc = average_precision_score(
        y_true,
        y_prob
    )

    brier = brier_score_loss(
        y_true,
        y_prob
    )

    return {
        "n": len(y_true),
        "positive_count": int(
            y_true.sum()
        ),
        "negative_count": int(
            (y_true == 0).sum()
        ),
        "positive_prevalence": float(
            y_true.mean()
        ),
        "threshold": float(
            threshold
        ),
        "accuracy": float(
            accuracy
        ),
        "precision": float(
            precision
        ),
        "sensitivity": float(
            sensitivity
        ),
        "specificity": float(
            specificity
        ),
        "f1": float(
            f1
        ),
        "roc_auc": float(
            roc_auc
        ),
        "pr_auc": float(
            pr_auc
        ),
        "brier": float(
            brier
        ),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


# ============================================================
# 6. MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 37"
    )
    print(
        "CORRECTED UCI EXTERNAL EVALUATION"
    )
    print("=" * 100)

    print(
        "Timestamp: "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    print(
        f"\nPrediction file:"
    )

    print(
        PREDICTION_FILE
    )

    # ========================================================
    # PATH CHECK
    # ========================================================

    if not PREDICTION_FILE.exists():

        raise FileNotFoundError(
            "Implementation 34 prediction file "
            f"not found:\n{PREDICTION_FILE}"
        )

    # ========================================================
    # LOAD IMPLEMENTATION 34 PREDICTIONS
    # ========================================================

    pred = pd.read_csv(
        PREDICTION_FILE
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 34 PREDICTION FILE"
    )
    print("=" * 100)

    print(
        f"Rows: {len(pred):,}"
    )

    print(
        "Columns:"
    )

    print(
        list(pred.columns)
    )

    # ========================================================
    # IDENTIFY COLUMNS
    # ========================================================

    cohort_col = find_column(
        pred,
        [
            "cohort",
            "dataset",
            "source_cohort",
        ]
    )

    target_col = find_column(
        pred,
        [
            "target_binary",
            "target",
            "y_true",
            "true_label",
            "label",
        ]
    )

    probability_col = find_column(
        pred,
        [
            "probability",
            "prob",
            "predicted_probability",
            "y_prob",
            "prediction_probability",
            "positive_probability",
        ]
    )

    source_row_col = find_column(
        pred,
        [
            "source_row",
            "original_index",
            "row_index",
            "index",
        ],
        required=False
    )

    print(
        f"\nCohort column      : {cohort_col}"
    )

    print(
        f"Target column      : {target_col}"
    )

    print(
        f"Probability column : {probability_col}"
    )

    print(
        f"Source-row column  : {source_row_col}"
    )

    # ========================================================
    # BASIC VALIDATION
    # ========================================================

    pred[target_col] = pd.to_numeric(
        pred[target_col],
        errors="coerce"
    )

    pred[probability_col] = pd.to_numeric(
        pred[probability_col],
        errors="coerce"
    )

    if pred[target_col].isna().any():

        raise ValueError(
            "Prediction file contains missing "
            "target labels."
        )

    if pred[probability_col].isna().any():

        raise ValueError(
            "Prediction file contains missing "
            "predicted probabilities."
        )

    unique_targets = sorted(
        pred[target_col]
        .astype(int)
        .unique()
        .tolist()
    )

    print(
        f"\nTarget values: "
        f"{unique_targets}"
    )

    if not set(unique_targets).issubset(
        {0, 1}
    ):

        raise ValueError(
            "Prediction file contains "
            "non-binary target values."
        )

    # ========================================================
    # ORIGINAL METRICS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "ORIGINAL IMPLEMENTATION 34 METRICS"
    )
    print("=" * 100)

    original_results = []

    for cohort in [
        "cleveland",
        "hungarian",
        "switzerland",
        "va",
    ]:

        cohort_mask = (
            pred[cohort_col]
            .astype(str)
            .str.lower()
            == cohort
        )

        cohort_df = (
            pred.loc[
                cohort_mask
            ]
            .copy()
        )

        if len(cohort_df) == 0:

            print(
                f"\n{cohort.upper()}: "
                "No prediction records."
            )

            continue

        metrics = calculate_metrics(
            cohort_df[target_col].values,
            cohort_df[probability_col].values,
            threshold=0.5
        )

        metrics["dataset"] = cohort
        metrics["evaluation"] = "original"

        original_results.append(
            metrics
        )

        print(
            f"\n{cohort.upper()}"
        )

        print(
            f"n          : "
            f"{metrics['n']}"
        )

        print(
            f"prevalence : "
            f"{metrics['positive_prevalence']:.6f}"
        )

        print(
            f"accuracy   : "
            f"{metrics['accuracy']:.6f}"
        )

        print(
            f"precision  : "
            f"{metrics['precision']:.6f}"
        )

        print(
            f"sensitivity: "
            f"{metrics['sensitivity']:.6f}"
        )

        print(
            f"specificity: "
            f"{metrics['specificity']:.6f}"
        )

        print(
            f"F1         : "
            f"{metrics['f1']:.6f}"
        )

        print(
            f"ROC-AUC    : "
            f"{metrics['roc_auc']:.6f}"
        )

        print(
            f"PR-AUC     : "
            f"{metrics['pr_auc']:.6f}"
        )

        print(
            f"Brier      : "
            f"{metrics['brier']:.6f}"
        )

    # ========================================================
    # CORRECTED DATASET
    # ========================================================

    corrected = pred.copy()

    # --------------------------------------------------------
    # Normalize cohort labels
    # --------------------------------------------------------

    corrected["_cohort_normalized"] = (
        corrected[cohort_col]
        .astype(str)
        .str.lower()
        .str.strip()
    )

    # --------------------------------------------------------
    # Remove ONLY VA source_row = 33
    # --------------------------------------------------------

    if source_row_col is None:

        raise ValueError(
            "Implementation 34 prediction file "
            "does not contain a source-row identifier. "
            "Cannot safely remove the invalid VA "
            "record without an identifier."
        )

    corrected[source_row_col] = pd.to_numeric(
        corrected[source_row_col],
        errors="coerce"
    )

    invalid_va_mask = (
        (
            corrected[
                "_cohort_normalized"
            ]
            == "va"
        )
        &
        (
            corrected[
                source_row_col
            ]
            == INVALID_VA_SOURCE_ROW
        )
    )

    removed_count = int(
        invalid_va_mask.sum()
    )

    print("\n" + "=" * 100)
    print(
        "VA CORRECTION"
    )
    print("=" * 100)

    print(
        f"Invalid VA source row: "
        f"{INVALID_VA_SOURCE_ROW}"
    )

    print(
        f"Records removed: "
        f"{removed_count}"
    )

    if removed_count != 1:

        raise ValueError(
            "Expected exactly one VA record "
            "with source_row=33, but found "
            f"{removed_count}."
        )

    removed_record = (
        corrected.loc[
            invalid_va_mask
        ]
        .copy()
    )

    print(
        "\nRemoved record:"
    )

    print(
        removed_record.to_string(
            index=False
        )
    )

    corrected = (
        corrected.loc[
            ~invalid_va_mask
        ]
        .copy()
    )

    # ========================================================
    # CORRECTED METRICS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "CORRECTED EXTERNAL METRICS"
    )
    print("=" * 100)

    corrected_results = []

    for cohort in [
        "cleveland",
        "hungarian",
        "switzerland",
        "va",
    ]:

        cohort_mask = (
            corrected[
                "_cohort_normalized"
            ]
            == cohort
        )

        cohort_df = (
            corrected.loc[
                cohort_mask
            ]
            .copy()
        )

        if len(cohort_df) == 0:

            print(
                f"\n{cohort.upper()}: "
                "No corrected prediction records."
            )

            continue

        metrics = calculate_metrics(
            cohort_df[target_col].values,
            cohort_df[probability_col].values,
            threshold=0.5
        )

        metrics["dataset"] = cohort
        metrics["evaluation"] = "corrected"

        corrected_results.append(
            metrics
        )

        expected_n = (
            EXPECTED_CORRECTED[
                cohort
            ]
        )

        print(
            f"\n{cohort.upper()}"
        )

        print(
            f"n          : "
            f"{metrics['n']}"
        )

        print(
            f"expected n : "
            f"{expected_n}"
        )

        print(
            f"prevalence : "
            f"{metrics['positive_prevalence']:.6f}"
        )

        print(
            f"accuracy   : "
            f"{metrics['accuracy']:.6f}"
        )

        print(
            f"precision  : "
            f"{metrics['precision']:.6f}"
        )

        print(
            f"sensitivity: "
            f"{metrics['sensitivity']:.6f}"
        )

        print(
            f"specificity: "
            f"{metrics['specificity']:.6f}"
        )

        print(
            f"F1         : "
            f"{metrics['f1']:.6f}"
        )

        print(
            f"ROC-AUC    : "
            f"{metrics['roc_auc']:.6f}"
        )

        print(
            f"PR-AUC     : "
            f"{metrics['pr_auc']:.6f}"
        )

        print(
            f"Brier      : "
            f"{metrics['brier']:.6f}"
        )

        if metrics["n"] != expected_n:

            print(
                "WARNING: corrected cohort size "
                "does not match expected size."
            )

    # ========================================================
    # ORIGINAL VS CORRECTED COMPARISON
    # ========================================================

    original_df = pd.DataFrame(
        original_results
    )

    corrected_df = pd.DataFrame(
        corrected_results
    )

    comparison_rows = []

    for cohort in [
        "cleveland",
        "hungarian",
        "switzerland",
        "va",
    ]:

        old = original_df[
            original_df["dataset"]
            == cohort
        ]

        new = corrected_df[
            corrected_df["dataset"]
            == cohort
        ]

        if len(old) == 0 or len(new) == 0:

            continue

        old_row = old.iloc[0]
        new_row = new.iloc[0]

        comparison_rows.append({

            "dataset":
                cohort,

            "original_n":
                old_row["n"],

            "corrected_n":
                new_row["n"],

            "records_removed":
                old_row["n"]
                - new_row["n"],

            "original_accuracy":
                old_row["accuracy"],

            "corrected_accuracy":
                new_row["accuracy"],

            "accuracy_change":
                new_row["accuracy"]
                - old_row["accuracy"],

            "original_precision":
                old_row["precision"],

            "corrected_precision":
                new_row["precision"],

            "precision_change":
                new_row["precision"]
                - old_row["precision"],

            "original_sensitivity":
                old_row["sensitivity"],

            "corrected_sensitivity":
                new_row["sensitivity"],

            "sensitivity_change":
                new_row["sensitivity"]
                - old_row["sensitivity"],

            "original_specificity":
                old_row["specificity"],

            "corrected_specificity":
                new_row["specificity"],

            "specificity_change":
                new_row["specificity"]
                - old_row["specificity"],

            "original_f1":
                old_row["f1"],

            "corrected_f1":
                new_row["f1"],

            "f1_change":
                new_row["f1"]
                - old_row["f1"],

            "original_roc_auc":
                old_row["roc_auc"],

            "corrected_roc_auc":
                new_row["roc_auc"],

            "roc_auc_change":
                new_row["roc_auc"]
                - old_row["roc_auc"],

            "original_pr_auc":
                old_row["pr_auc"],

            "corrected_pr_auc":
                new_row["pr_auc"],

            "pr_auc_change":
                new_row["pr_auc"]
                - old_row["pr_auc"],

            "original_brier":
                old_row["brier"],

            "corrected_brier":
                new_row["brier"],

            "brier_change":
                new_row["brier"]
                - old_row["brier"],
        })

    comparison_df = pd.DataFrame(
        comparison_rows
    )

    print("\n" + "=" * 100)
    print(
        "ORIGINAL VS CORRECTED COMPARISON"
    )
    print("=" * 100)

    if len(comparison_df) > 0:

        display_columns = [
            "dataset",
            "original_n",
            "corrected_n",
            "records_removed",
            "original_roc_auc",
            "corrected_roc_auc",
            "roc_auc_change",
            "original_accuracy",
            "corrected_accuracy",
            "original_sensitivity",
            "corrected_sensitivity",
            "original_specificity",
            "corrected_specificity",
            "original_brier",
            "corrected_brier",
        ]

        print(
            comparison_df[
                display_columns
            ].to_string(
                index=False
            )
        )

    # ========================================================
    # VERIFY CLEVELAND/HUNGARIAN UNCHANGED
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "UNCHANGED COHORT VERIFICATION"
    )
    print("=" * 100)

    unchanged_pass = True

    for cohort in [
        "cleveland",
        "hungarian",
    ]:

        old = original_df[
            original_df["dataset"]
            == cohort
        ].iloc[0]

        new = corrected_df[
            corrected_df["dataset"]
            == cohort
        ].iloc[0]

        differences = []

        for metric in [
            "accuracy",
            "precision",
            "sensitivity",
            "specificity",
            "f1",
            "roc_auc",
            "pr_auc",
            "brier",
        ]:

            if not np.isclose(
                old[metric],
                new[metric],
                atol=1e-12
            ):

                differences.append(
                    metric
                )

        if len(differences) == 0:

            print(
                f"{cohort.upper()}: PASS "
                "(unchanged)"
            )

        else:

            print(
                f"{cohort.upper()}: FAIL"
            )

            print(
                "Differences:",
                differences
            )

            unchanged_pass = False

    # ========================================================
    # SAVE CORRECTED PREDICTIONS
    # ========================================================

    corrected_save = (
        corrected.drop(
            columns=[
                "_cohort_normalized"
            ],
            errors="ignore"
        )
        .reset_index(
            drop=True
        )
    )

    corrected_save.to_csv(
        CORRECTED_PREDICTION_FILE,
        index=False
    )

    # ========================================================
    # SAVE RESULTS
    # ========================================================

    corrected_df.to_csv(
        RESULTS_FILE,
        index=False
    )

    comparison_df.to_csv(
        COMPARISON_FILE,
        index=False
    )

    # ========================================================
    # FINAL VALIDITY CHECK
    # ========================================================

    corrected_count_pass = True

    for cohort, expected_n in (
        EXPECTED_CORRECTED.items()
    ):

        observed = corrected_df[
            corrected_df["dataset"]
            == cohort
        ]

        if cohort == "switzerland":

            observed_n = (
                0
                if len(observed) == 0
                else int(
                    observed.iloc[0]["n"]
                )
            )

        else:

            if len(observed) == 0:

                observed_n = 0

            else:

                observed_n = int(
                    observed.iloc[0]["n"]
                )

        if observed_n != expected_n:

            corrected_count_pass = False

            print(
                f"WARNING: {cohort} "
                f"expected {expected_n}, "
                f"observed {observed_n}"
            )

    # ========================================================
    # PROTOCOL
    # ========================================================

    protocol = {

        "implementation":
            "37",

        "title":
            (
                "Corrected UCI External "
                "Evaluation"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "input_prediction_file":
            str(PREDICTION_FILE),

        "correction":
            {
                "cohort":
                    "va",

                "source_row":
                    INVALID_VA_SOURCE_ROW,

                "reason":
                    (
                        "systolic_bp = 0, "
                        "clinically invalid"
                    ),
            },

        "records_removed":
            removed_count,

        "expected_corrected_counts":
            EXPECTED_CORRECTED,

        "no_model_retraining":
            True,

        "no_hyperparameter_tuning":
            True,

        "no_threshold_tuning":
            True,

        "no_uci_model_selection":
            True,

        "cleveland_unchanged":
            True,

        "hungarian_unchanged":
            True,

        "outputs":
            {
                "corrected_predictions":
                    str(
                        CORRECTED_PREDICTION_FILE
                    ),

                "corrected_results":
                    str(
                        RESULTS_FILE
                    ),

                "comparison":
                    str(
                        COMPARISON_FILE
                    ),
            },
    }

    with open(
        PROTOCOL_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            protocol,
            f,
            indent=2
        )

    # ========================================================
    # FINAL STATUS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 37 FINAL STATUS"
    )
    print("=" * 100)

    print(
        f"Invalid VA record removed: "
        f"{removed_count}"
    )

    print(
        f"Corrected cohort counts: "
        f"{'PASS' if corrected_count_pass else 'REVIEW'}"
    )

    print(
        f"Cleveland unchanged: "
        f"{'PASS' if unchanged_pass else 'FAIL'}"
    )

    if (
        removed_count == 1
        and corrected_count_pass
        and unchanged_pass
    ):

        final_status = (
            "PASS_READY_FOR_THRESHOLD_TRANSFER"
        )

    else:

        final_status = (
            "REVIEW_BEFORE_THRESHOLD_TRANSFER"
        )

    print(
        f"\nFINAL STATUS: "
        f"{final_status}"
    )

    # ========================================================
    # OUTPUT FILES
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        CORRECTED_PREDICTION_FILE
    )

    print(
        RESULTS_FILE
    )

    print(
        COMPARISON_FILE
    )

    print(
        PROTOCOL_FILE
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 37 COMPLETE"
    )
    print("=" * 100)

    print(
        "No model was retrained."
    )

    print(
        "No threshold was tuned."
    )

    print(
        "No UCI data were used for "
        "model selection."
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()