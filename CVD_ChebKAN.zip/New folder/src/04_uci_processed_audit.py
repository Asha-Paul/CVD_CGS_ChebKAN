from pathlib import Path
import zipfile
import pandas as pd

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

FILES = {
    "Cleveland": "processed.cleveland.data",
    "Hungarian": "processed.hungarian.data",
    "Switzerland": "processed.switzerland.data",
    "VA Long Beach": "processed.va.data",
}

COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target",
]

print("=" * 80)
print("CVD CGS-ChebKAN — UCI PROCESSED DATA AUDIT")
print("=" * 80)

with zipfile.ZipFile(UCI_ZIP, "r") as z:

    for cohort, filename in FILES.items():

        print("\n" + "=" * 80)
        print(cohort)
        print("=" * 80)

        with z.open(filename) as f:

            df = pd.read_csv(
                f,
                header=None,
                names=COLUMNS,
                na_values=["?"],
            )

        print(f"Rows    : {len(df):,}")
        print(f"Columns : {len(df.columns)}")

        print("\n--- Data types ---")
        print(df.dtypes)

        print("\n--- Missing values ---")

        missing = df.isna().sum()

        missing_table = pd.DataFrame({
            "missing_n": missing,
            "missing_percent": (
                missing / len(df) * 100
            ).round(2)
        })

        print(
            missing_table[
                missing_table["missing_n"] > 0
            ]
        )

        print("\n--- Target distribution ---")
        print(df["target"].value_counts(dropna=False).sort_index())

        print("\nTarget proportions:")
        print(
            df["target"]
            .value_counts(
                normalize=True,
                dropna=False
            )
            .sort_index()
            .round(4)
        )

        print("\n--- Unique values ---")

        for col in df.columns:
            values = df[col].dropna().unique()

            if len(values) <= 15:
                print(
                    f"{col}: "
                    f"{sorted(values.tolist())}"
                )

        print("\n--- Descriptive statistics ---")
        print(df.describe().T)

print("\n" + "=" * 80)
print("UCI PROCESSED DATA AUDIT COMPLETED")
print("=" * 80)

print("\nNo files were extracted.")
print("No UCI data were modified.")