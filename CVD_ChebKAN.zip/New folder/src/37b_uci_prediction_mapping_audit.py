# ============================================================
# IMPLEMENTATION 37b
# UCI PREDICTION-TO-SOURCE ROW MAPPING AUDIT
#
# Purpose:
#   Determine whether Implementation 34's prediction file
#   preserves the exact row ordering / source-row correspondence
#   needed to safely remove the invalid VA record.
#
# IMPORTANT:
#   - No model training
#   - No retraining
#   - No threshold tuning
#   - No UCI model selection
#   - No prediction rows are deleted
#   - No original datasets are modified
#
# ============================================================

from pathlib import Path
import json
from datetime import datetime

import numpy as np
import pandas as pd


# ============================================================
# 1. PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

HARMONIZED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "uci_harmonized"
)

PREDICTION_FILE = (
    RESULTS_DIR
    / "implementation34_uci_external_predictions.csv"
)

VA_FILE = (
    HARMONIZED_DIR
    / "uci_va_harmonized_shared_features.csv"
)

OUTPUT_JSON = (
    RESULTS_DIR
    / "implementation37b_prediction_mapping_audit.json"
)

OUTPUT_CSV = (
    RESULTS_DIR
    / "implementation37b_va_mapping_comparison.csv"
)


# ============================================================
# 2. CONSTANTS
# ============================================================

INVALID_VA_SOURCE_ROW = 33


# ============================================================
# 3. HELPER
# ============================================================

def find_column(
    df,
    candidates
):

    for column in candidates:

        if column in df.columns:
            return column

    return None


# ============================================================
# 4. MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 37b"
    )
    print(
        "UCI PREDICTION-TO-SOURCE ROW "
        "MAPPING AUDIT"
    )
    print("=" * 100)

    print(
        "Timestamp: "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    # ========================================================
    # PATH CHECKS
    # ========================================================

    if not PREDICTION_FILE.exists():

        raise FileNotFoundError(
            f"Prediction file not found:\n"
            f"{PREDICTION_FILE}"
        )

    if not VA_FILE.exists():

        raise FileNotFoundError(
            f"VA harmonized file not found:\n"
            f"{VA_FILE}"
        )

    # ========================================================
    # LOAD FILES
    # ========================================================

    pred = pd.read_csv(
        PREDICTION_FILE
    )

    va = pd.read_csv(
        VA_FILE
    )

    print("\n" + "=" * 100)
    print(
        "FILE INFORMATION"
    )
    print("=" * 100)

    print(
        f"Prediction rows: "
        f"{len(pred):,}"
    )

    print(
        f"VA harmonized rows: "
        f"{len(va):,}"
    )

    print(
        "\nPrediction columns:"
    )

    print(
        list(pred.columns)
    )

    print(
        "\nVA columns:"
    )

    print(
        list(va.columns)
    )

    # ========================================================
    # IDENTIFY PREDICTION COLUMNS
    # ========================================================

    cohort_col = find_column(
        pred,
        [
            "cohort",
            "dataset",
            "source_cohort",
        ]
    )

    target_col = find_column(
        pred,
        [
            "target_binary",
            "target",
            "y_true",
            "true_label",
            "label",
        ]
    )

    probability_col = find_column(
        pred,
        [
            "probability",
            "prob",
            "predicted_probability",
            "y_prob",
            "prediction_probability",
            "positive_probability",
        ]
    )

    source_row_pred_col = find_column(
        pred,
        [
            "source_row",
            "original_index",
            "row_index",
            "source_index",
        ]
    )

    print("\n" + "=" * 100)
    print(
        "IDENTIFIED COLUMNS"
    )
    print("=" * 100)

    print(
        f"Cohort column: "
        f"{cohort_col}"
    )

    print(
        f"Target column: "
        f"{target_col}"
    )

    print(
        f"Probability column: "
        f"{probability_col}"
    )

    print(
        f"Prediction source-row column: "
        f"{source_row_pred_col}"
    )

    # ========================================================
    # FILTER VA PREDICTIONS
    # ========================================================

    if cohort_col is None:

        raise ValueError(
            "No cohort column was found "
            "in the prediction file."
        )

    va_pred = (
        pred.loc[
            pred[cohort_col]
            .astype(str)
            .str.lower()
            .str.strip()
            == "va"
        ]
        .copy()
        .reset_index(drop=True)
    )

    print("\n" + "=" * 100)
    print(
        "VA PREDICTION FILE"
    )
    print("=" * 100)

    print(
        f"VA prediction rows: "
        f"{len(va_pred):,}"
    )

    # ========================================================
    # LOAD VA SOURCE ROW
    # ========================================================

    if "source_row" not in va.columns:

        raise ValueError(
            "The VA harmonized file does not "
            "contain source_row."
        )

    va_source = pd.to_numeric(
        va["source_row"],
        errors="coerce"
    )

    va["source_row_numeric"] = (
        va_source
    )

    invalid_mask = (
        va["source_row_numeric"]
        == INVALID_VA_SOURCE_ROW
    )

    invalid_indices = (
        va.index[
            invalid_mask
        ]
        .tolist()
    )

    print("\n" + "=" * 100)
    print(
        "INVALID VA RECORD"
    )
    print("=" * 100)

    print(
        f"Invalid source_row: "
        f"{INVALID_VA_SOURCE_ROW}"
    )

    print(
        f"Matching VA rows: "
        f"{len(invalid_indices)}"
    )

    if len(invalid_indices) != 1:

        raise ValueError(
            "Expected exactly one VA record "
            f"with source_row={INVALID_VA_SOURCE_ROW}, "
            f"found {len(invalid_indices)}."
        )

    invalid_position = (
        invalid_indices[0]
    )

    invalid_record = (
        va.loc[
            invalid_position
        ]
    )

    print(
        "\nInvalid record:"
    )

    print(
        invalid_record.to_string()
    )

    print(
        f"\nInvalid record positional index: "
        f"{invalid_position}"
    )

    # ========================================================
    # CHECK 1
    # SAME NUMBER OF VA RECORDS
    # ========================================================

    same_count = (
        len(va)
        == len(va_pred)
    )

    print("\n" + "=" * 100)
    print(
        "CHECK 1: VA ROW COUNT"
    )
    print("=" * 100)

    print(
        f"VA source rows      : "
        f"{len(va):,}"
    )

    print(
        f"VA prediction rows  : "
        f"{len(va_pred):,}"
    )

    print(
        f"Same count: "
        f"{'PASS' if same_count else 'FAIL'}"
    )

    # ========================================================
    # CHECK 2
    # PREDICTION FILE SOURCE-ROW COLUMN
    # ========================================================

    direct_source_row_mapping = False

    if source_row_pred_col is not None:

        pred_source = pd.to_numeric(
            va_pred[
                source_row_pred_col
            ],
            errors="coerce"
        )

        source_match = (
            len(pred_source)
            == len(va_source)
            and
            np.array_equal(
                pred_source.values,
                va_source.values
            )
        )

        direct_source_row_mapping = (
            source_match
        )

        print("\n" + "=" * 100)
        print(
            "CHECK 2: DIRECT SOURCE-ROW MAPPING"
        )
        print("=" * 100)

        print(
            f"Prediction source-row column: "
            f"{source_row_pred_col}"
        )

        print(
            f"Exact row-by-row source mapping: "
            f"{'PASS' if source_match else 'FAIL'}"
        )

    else:

        print("\n" + "=" * 100)
        print(
            "CHECK 2: DIRECT SOURCE-ROW MAPPING"
        )
        print("=" * 100)

        print(
            "No source_row column exists "
            "in the prediction file."
        )

        print(
            "Direct mapping: NOT AVAILABLE"
        )

    # ========================================================
    # CHECK 3
    # TARGET ORDER COMPARISON
    # ========================================================

    target_order_match = False

    if (
        target_col is not None
        and target_col in va.columns
    ):

        pred_target = pd.to_numeric(
            va_pred[target_col],
            errors="coerce"
        )

        va_target = pd.to_numeric(
            va[target_col],
            errors="coerce"
        )

        if len(
            pred_target
        ) == len(
            va_target
        ):

            target_order_match = (
                np.array_equal(
                    pred_target.values,
                    va_target.values
                )
            )

        print("\n" + "=" * 100)
        print(
            "CHECK 3: TARGET ORDER"
        )
        print("=" * 100)

        print(
            f"Target column: "
            f"{target_col}"
        )

        print(
            f"Exact target sequence match: "
            f"{'PASS' if target_order_match else 'FAIL'}"
        )

    else:

        print("\n" + "=" * 100)
        print(
            "CHECK 3: TARGET ORDER"
        )
        print("=" * 100)

        print(
            "Target order cannot be checked."
        )

    # ========================================================
    # CHECK 4
    # COMPARE ALL PREDICTION-AVAILABLE COLUMNS
    # ========================================================

    common_columns = []

    for column in [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
        "target_binary",
        "source_row",
    ]:

        if (
            column in va.columns
            and column in va_pred.columns
        ):

            common_columns.append(
                column
            )

    print("\n" + "=" * 100)
    print(
        "CHECK 4: COMMON COLUMN ORDER"
    )
    print("=" * 100)

    print(
        f"Common identifying columns: "
        f"{common_columns}"
    )

    column_match_results = {}

    for column in common_columns:

        source_values = va[column].values
        pred_values = va_pred[column].values

        if len(
            source_values
        ) != len(
            pred_values
        ):

            match = False

        else:

            match = np.array_equal(
                source_values,
                pred_values
            )

        column_match_results[
            column
        ] = bool(match)

        print(
            f"{column:25s}: "
            f"{'PASS' if match else 'FAIL'}"
        )

    # ========================================================
    # CHECK 5
    # EXACT FEATURE ORDER MATCH
    # ========================================================

    feature_columns = [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
    ]

    feature_matches = {}

    print("\n" + "=" * 100)
    print(
        "CHECK 5: FEATURE ORDER"
    )
    print("=" * 100)

    for column in feature_columns:

        if column not in va_pred.columns:

            print(
                f"{column:25s}: "
                "NOT AVAILABLE IN PREDICTION FILE"
            )

            feature_matches[
                column
            ] = None

            continue

        source_values = pd.to_numeric(
            va[column],
            errors="coerce"
        ).values

        pred_values = pd.to_numeric(
            va_pred[column],
            errors="coerce"
        ).values

        if (
            len(source_values)
            != len(pred_values)
        ):

            match = False

        else:

            match = np.allclose(
                source_values,
                pred_values,
                equal_nan=True
            )

        feature_matches[
            column
        ] = bool(match)

        print(
            f"{column:25s}: "
            f"{'PASS' if match else 'FAIL'}"
        )

    # ========================================================
    # CHECK 6
    # POSITION OF INVALID VA RECORD
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "CHECK 6: INVALID RECORD POSITION"
    )
    print("=" * 100)

    print(
        f"Invalid source-row: "
        f"{INVALID_VA_SOURCE_ROW}"
    )

    print(
        f"Invalid source positional index: "
        f"{invalid_position}"
    )

    if (
        same_count
        and invalid_position
        < len(va_pred)
    ):

        candidate_prediction = (
            va_pred.iloc[
                invalid_position
            ]
        )

        print(
            "\nPrediction at the same "
            "positional index:"
        )

        print(
            candidate_prediction.to_string()
        )

    else:

        candidate_prediction = None

        print(
            "Cannot perform positional "
            "comparison."
        )

    # ========================================================
    # DECISION LOGIC
    # ========================================================

    exact_mapping = False

    if direct_source_row_mapping:

        exact_mapping = True

    elif (
        same_count
        and target_order_match
        and all(
            value is True
            for value in feature_matches.values()
            if value is not None
        )
    ):

        exact_mapping = True

    # ========================================================
    # SAVE COMPARISON TABLE
    # ========================================================

    comparison_rows = []

    max_rows = min(
        len(va),
        len(va_pred)
    )

    for i in range(
        max_rows
    ):

        row = {

            "prediction_position":
                i,

            "source_position":
                i,

            "source_row":
                va.iloc[
                    i
                ]["source_row"],

            "systolic_bp":
                va.iloc[
                    i
                ]["systolic_bp"],

            "target_source":
                va.iloc[
                    i
                ][
                    "target_binary"
                ],

            "prediction_target":
                (
                    va_pred.iloc[
                        i
                    ][target_col]
                    if target_col
                    in va_pred.columns
                    else np.nan
                ),

            "predicted_probability":
                (
                    va_pred.iloc[
                        i
                    ][probability_col]
                    if probability_col
                    in va_pred.columns
                    else np.nan
                ),

            "is_invalid_va_record":
                (
                    i
                    == invalid_position
                ),
        }

        comparison_rows.append(
            row
        )

    comparison_df = pd.DataFrame(
        comparison_rows
    )

    comparison_df.to_csv(
        OUTPUT_CSV,
        index=False
    )

    # ========================================================
    # SAFE CORRECTION DECISION
    # ========================================================

    safe_to_remove_by_position = (
        exact_mapping
        and same_count
        and invalid_position
        < len(va_pred)
    )

    print("\n" + "=" * 100)
    print(
        "FINAL MAPPING DECISION"
    )
    print("=" * 100)

    print(
        f"Exact mapping established: "
        f"{'YES' if exact_mapping else 'NO'}"
    )

    print(
        f"Safe to remove invalid VA "
        f"prediction by position: "
        f"{'YES' if safe_to_remove_by_position else 'NO'}"
    )

    if safe_to_remove_by_position:

        print(
            "\nThe prediction at positional "
            f"index {invalid_position} "
            "corresponds to the invalid "
            f"VA source_row={INVALID_VA_SOURCE_ROW}."
        )

        print(
            "It is methodologically safe "
            "to remove that prediction "
            "for the corrected VA analysis."
        )

    else:

        print(
            "\nDO NOT remove any prediction "
            "by position."
        )

        print(
            "The mapping cannot be proven "
            "from the available prediction file."
        )

        print(
            "The next step should be "
            "external inference using the "
            "saved Implementation 34 model."
        )

    # ========================================================
    # PROTOCOL JSON
    # ========================================================

    protocol = {

        "implementation":
            "37b",

        "title":
            (
                "UCI Prediction-to-Source "
                "Row Mapping Audit"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "prediction_file":
            str(PREDICTION_FILE),

        "va_harmonized_file":
            str(VA_FILE),

        "invalid_va_source_row":
            INVALID_VA_SOURCE_ROW,

        "va_prediction_rows":
            int(len(va_pred)),

        "va_source_rows":
            int(len(va)),

        "same_count":
            bool(same_count),

        "direct_source_row_mapping":
            bool(
                direct_source_row_mapping
            ),

        "target_order_match":
            bool(
                target_order_match
            ),

        "feature_matches":
            feature_matches,

        "invalid_source_position":
            int(
                invalid_position
            ),

        "exact_mapping":
            bool(
                exact_mapping
            ),

        "safe_to_remove_by_position":
            bool(
                safe_to_remove_by_position
            ),

        "no_model_training":
            True,

        "no_retraining":
            True,

        "no_threshold_tuning":
            True,

        "no_prediction_deletion":
            True,

        "output_comparison":
            str(OUTPUT_CSV),
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            protocol,
            f,
            indent=2
        )

    # ========================================================
    # OUTPUT
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        OUTPUT_CSV
    )

    print(
        OUTPUT_JSON
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 37b COMPLETE"
    )
    print("=" * 100)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()