"""
IMPLEMENTATION 43B-3
PAIRED STATISTICAL COMPARISON OF OUTER-CV PREDICTIONS

Purpose
-------
Compare sparse grouped Chebyshev-KAN (A6) against the five validated
49,000-record outer-CV baselines using paired bootstrap inference.

No retraining. No hyperparameter tuning. No locked-test or UCI data.

Comparisons
-----------
A6 vs Random Forest
A6 vs XGBoost
A6 vs MLP
A6 vs B-spline KAN
A6 vs Vanilla Chebyshev KAN

For each comparison:
- pooled out-of-fold ROC-AUC
- mean outer-fold ROC-AUC
- paired bootstrap 95% CI for AUC difference (A6 - baseline)
- two-sided paired bootstrap p-value
- Holm-adjusted p-value
- effect direction

Bootstrap resampling is performed at the patient/record level, preserving
pairing between models. The same bootstrap indices are used for both models.
"""

from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd

# -----------------------------------------------------------------------------
# PATHS
# -----------------------------------------------------------------------------
ROOT = Path(r"E:\CVD_CGS_ChebKAN")
RESULTS = ROOT / "results" / "tables"

A6_FILE = RESULTS / "implementation31b_reduced_corrected_a6_outer_predictions.csv"
BASELINES = {
    "Random_Forest": RESULTS / "implementation23_random_forest_outer_predictions.csv",
    "XGBoost": RESULTS / "implementation24_xgboost_outer_predictions.csv",
    "MLP": RESULTS / "implementation25_mlp_outer_predictions.csv",
    "B-spline_KAN": RESULTS / "implementation26_bspline_kan_outer_predictions.csv",
    "Vanilla_Chebyshev_KAN": RESULTS / "implementation27_chebyshev_outer_predictions.csv",
}

OUT_CSV = RESULTS / "implementation43B3_paired_statistical_comparison.csv"
OUT_JSON = RESULTS / "implementation43B3_paired_statistical_comparison.json"
OUT_REPORT = RESULTS / "implementation43B3_paired_statistical_comparison_report.txt"

# -----------------------------------------------------------------------------
# SETTINGS
# -----------------------------------------------------------------------------
SEED = 20261006
N_BOOTSTRAP = 5000
CI_LEVEL = 0.95
ALPHA = 0.05

# -----------------------------------------------------------------------------
# UTILITIES
# -----------------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def auc_fast(y, score):
    """Exact ROC-AUC via ranks, handling ties with average ranks."""
    y = np.asarray(y, dtype=np.int8)
    score = np.asarray(score, dtype=np.float64)
    n_pos = int(y.sum())
    n = len(y)
    n_neg = n - n_pos
    if n_pos == 0 or n_neg == 0:
        return np.nan

    order = np.argsort(score, kind="mergesort")
    sorted_scores = score[order]
    ranks_sorted = np.empty(n, dtype=np.float64)

    start = 0
    while start < n:
        end = start + 1
        while end < n and sorted_scores[end] == sorted_scores[start]:
            end += 1
        # ranks are 1-based; average rank for ties
        avg_rank = (start + 1 + end) / 2.0
        ranks_sorted[start:end] = avg_rank
        start = end

    ranks = np.empty(n, dtype=np.float64)
    ranks[order] = ranks_sorted
    sum_pos_ranks = ranks[y == 1].sum()
    return (sum_pos_ranks - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)


def mean_fold_auc(df, pred_col):
    vals = []
    for fold in sorted(df["outer_fold"].unique()):
        d = df[df["outer_fold"] == fold]
        vals.append(auc_fast(d["y_true"].to_numpy(), d[pred_col].to_numpy()))
    return np.asarray(vals, dtype=float)


def holm_adjust(pvalues):
    """Holm step-down adjusted p-values, returned in original order."""
    p = np.asarray(pvalues, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m, dtype=float)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running = max(running, val)
        adj[idx] = min(running, 1.0)
    return adj


def bootstrap_paired_auc(y, a6, base, rng, n_bootstrap):
    """Paired patient-level bootstrap for AUC difference A6 - baseline."""
    n = len(y)
    diffs = np.empty(n_bootstrap, dtype=np.float64)
    valid = 0

    # Stratified resampling maintains both classes in every replicate and avoids
    # undefined AUC. Pairing is preserved because one common index sample is used.
    pos_idx = np.flatnonzero(y == 1)
    neg_idx = np.flatnonzero(y == 0)

    for b in range(n_bootstrap):
        ii_pos = rng.choice(pos_idx, size=len(pos_idx), replace=True)
        ii_neg = rng.choice(neg_idx, size=len(neg_idx), replace=True)
        ii = np.concatenate([ii_pos, ii_neg])
        rng.shuffle(ii)
        d = auc_fast(y[ii], a6[ii]) - auc_fast(y[ii], base[ii])
        diffs[valid] = d
        valid += 1

    diffs = diffs[:valid]
    lo = float(np.quantile(diffs, (1 - CI_LEVEL) / 2))
    hi = float(np.quantile(diffs, 1 - (1 - CI_LEVEL) / 2))

    # Two-sided paired bootstrap p-value around the null difference of zero.
    p = 2.0 * min(float(np.mean(diffs <= 0.0)), float(np.mean(diffs >= 0.0)))
    # Finite-sample conservative adjustment.
    p = min(1.0, p)

    return diffs, lo, hi, p


def bootstrap_fold_mean_difference(df, baseline_col, rng, n_bootstrap=5000):
    """Secondary bootstrap over the five paired outer folds."""
    folds = sorted(df["outer_fold"].unique())
    fold_diffs = []
    for fold in folds:
        d = df[df["outer_fold"] == fold]
        fold_diffs.append(
            auc_fast(d["y_true"].to_numpy(), d["a6_probability"].to_numpy())
            - auc_fast(d["y_true"].to_numpy(), d[baseline_col].to_numpy())
        )
    fold_diffs = np.asarray(fold_diffs, dtype=float)
    boot = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        boot[b] = np.mean(rng.choice(fold_diffs, size=len(fold_diffs), replace=True))
    return float(np.mean(fold_diffs)), float(np.quantile(boot, .025)), float(np.quantile(boot, .975))


# -----------------------------------------------------------------------------
# MAIN
# -----------------------------------------------------------------------------
print("=" * 80)
print("IMPLEMENTATION 43B-3")
print("PAIRED STATISTICAL COMPARISON OF A6 OUTER-CV PREDICTIONS")
print("=" * 80)
print(f"Bootstrap replicates: {N_BOOTSTRAP}")
print(f"Seed: {SEED}")
print("No retraining | No tuning | No locked test | No UCI")

RESULTS.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# 1. LOAD A6
# -----------------------------------------------------------------------------
print("\n" + "=" * 80)
print("1. LOADING A6 PREDICTIONS")
print("=" * 80)
print(f"File: {A6_FILE}")

if not A6_FILE.exists():
    raise FileNotFoundError(f"A6 file not found: {A6_FILE}")

a6 = pd.read_csv(A6_FILE)
required_a6 = {"row_index", "outer_fold", "y_true", "probability"}
missing = required_a6 - set(a6.columns)
if missing:
    raise ValueError(f"A6 missing required columns: {sorted(missing)}")

if len(a6) != 49000:
    raise ValueError(f"Expected 49,000 A6 rows; found {len(a6)}")

if a6["row_index"].duplicated().any():
    raise ValueError("A6 row_index contains duplicates.")

if set(a6["row_index"].astype(int)) != set(range(49000)):
    raise ValueError("A6 row_index is not exactly 0..48,999.")

if a6["y_true"].isna().any() or a6["probability"].isna().any():
    raise ValueError("A6 contains missing y_true/probability values.")

print(f"Rows: {len(a6):,}")
print("PASS: A6 contains exactly 49,000 unique row indices.")

# -----------------------------------------------------------------------------
# 2. LOAD AND VALIDATE BASELINES
# -----------------------------------------------------------------------------
print("\n" + "=" * 80)
print("2. LOADING AND VALIDATING FIVE BASELINES")
print("=" * 80)

# Reconciliation established that the A6 row_index maps exactly to the
# development ID. We use the saved mapping to make the pairing explicit.
mapping_file = RESULTS / "implementation43B2_CORRECTED_A6_verified_row_index_to_kaggle_id.csv"
if not mapping_file.exists():
    raise FileNotFoundError(f"Verified A6 mapping not found: {mapping_file}")

mapping = pd.read_csv(mapping_file)
print(f"Verified mapping rows: {len(mapping):,}")
if len(mapping) != 49000:
    raise ValueError("Verified mapping does not contain 49,000 rows.")

# Build a common identity table keyed by verified ID.
# Expected mapping column names are checked flexibly because the reconciliation
# script may have used slightly different descriptive names.
print(f"Mapping columns: {mapping.columns.tolist()}")

# Identify ID column in mapping.
id_candidates = [c for c in mapping.columns if c.lower() == "id" or c.lower().endswith("_id")]
if not id_candidates:
    raise ValueError("Could not identify Kaggle ID column in verified mapping.")
map_id_col = id_candidates[0]

row_col_candidates = [c for c in mapping.columns if c.lower() == "row_index"]
if not row_col_candidates:
    raise ValueError("Could not identify row_index column in verified mapping.")
map_row_col = row_col_candidates[0]

map_small = mapping[[map_row_col, map_id_col]].copy()
map_small.columns = ["row_index", "id"]
map_small["row_index"] = map_small["row_index"].astype(int)
map_small["id"] = map_small["id"].astype(str)

if map_small["id"].duplicated().any():
    raise ValueError("Verified A6 mapping contains duplicate IDs.")

# Attach verified IDs to A6.
a6["row_index"] = a6["row_index"].astype(int)
a6 = a6.merge(map_small, on="row_index", how="left", validate="one_to_one")
if a6["id"].isna().any():
    raise ValueError("Some A6 row_index values could not be mapped to IDs.")

a6["id"] = a6["id"].astype(str)
a6["y_true"] = a6["y_true"].astype(int)
a6["probability"] = a6["probability"].astype(float)

base_frames = {}
for name, path in BASELINES.items():
    print(f"\n{name}: {path}")
    if not path.exists():
        raise FileNotFoundError(f"Baseline file not found: {path}")
    d = pd.read_csv(path)
    if len(d) != 49000:
        raise ValueError(f"{name}: expected 49,000 rows; found {len(d)}")

    print(f"Rows: {len(d):,}")
    print(f"Columns: {d.columns.tolist()}")

    # Known prediction schemas from 43B-2 audit.
    id_col = "id" if "id" in d.columns else None
    fold_col = "outer_fold" if "outer_fold" in d.columns else None
    y_col = "y_true" if "y_true" in d.columns else None

    if id_col is None or y_col is None:
        raise ValueError(f"{name}: required id/y_true columns not found.")

    prob_candidates = [c for c in d.columns if c.lower() in {"probability", "prob", "y_prob", "prediction_probability"}]
    if not prob_candidates:
        raise ValueError(f"{name}: could not identify probability column.")
    prob_col = prob_candidates[0]

    if d[id_col].astype(str).duplicated().any():
        raise ValueError(f"{name}: duplicate IDs detected.")

    frame = d[[id_col, y_col, prob_col] + ([fold_col] if fold_col else [])].copy()
    frame[id_col] = frame[id_col].astype(str)
    frame[y_col] = frame[y_col].astype(int)
    frame[prob_col] = frame[prob_col].astype(float)
    if frame[prob_col].isna().any():
        raise ValueError(f"{name}: missing probabilities detected.")

    rename = {id_col: "id", y_col: "baseline_y_true", prob_col: "baseline_probability"}
    if fold_col:
        rename[fold_col] = "baseline_outer_fold"
    frame = frame.rename(columns=rename)

    # Exact cohort reconciliation.
    common = set(a6["id"]) & set(frame["id"])
    if len(common) != 49000 or set(a6["id"]) != set(frame["id"]):
        raise ValueError(f"{name}: cohort does not exactly match A6.")

    merged = a6[["id", "row_index", "outer_fold", "y_true", "probability"]].merge(
        frame, on="id", how="inner", validate="one_to_one"
    )

    if len(merged) != 49000:
        raise ValueError(f"{name}: merged paired cohort is not 49,000 rows.")

    target_mismatch = int((merged["y_true"] != merged["baseline_y_true"]).sum())
    if target_mismatch != 0:
        raise ValueError(f"{name}: target mismatch count = {target_mismatch}")

    # Fold assignment is expected to be identical because all models were
    # generated on the validated common outer-CV cohort. If available, verify.
    if "baseline_outer_fold" in merged.columns:
        fold_mismatch = int((merged["outer_fold"] != merged["baseline_outer_fold"]).sum())
        if fold_mismatch != 0:
            raise ValueError(f"{name}: outer-fold mismatch count = {fold_mismatch}")

    merged = merged.sort_values("row_index").reset_index(drop=True)
    base_frames[name] = merged
    print(f"PASS: exact 49,000-ID paired cohort; target mismatches=0")

# -----------------------------------------------------------------------------
# 3. POOLED AND FOLD AUCs
# -----------------------------------------------------------------------------
print("\n" + "=" * 80)
print("3. AUC SUMMARY")
print("=" * 80)

summary_rows = []
for name, d in base_frames.items():
    a6_auc = auc_fast(d["y_true"].to_numpy(), d["probability"].to_numpy())
    base_auc = auc_fast(d["y_true"].to_numpy(), d["baseline_probability"].to_numpy())
    a6_folds = mean_fold_auc(d.rename(columns={"probability": "a6_probability"}), "a6_probability")
    base_folds = mean_fold_auc(d.rename(columns={"baseline_probability": "baseline_probability"}), "baseline_probability")

    # Mean fold AUC is same across each model's five outer validation folds.
    a6_mean = float(np.mean(a6_folds))
    base_mean = float(np.mean(base_folds))
    fold_diff = a6_folds - base_folds

    summary_rows.append({
        "comparison": f"A6_vs_{name}",
        "baseline": name,
        "n_records": len(d),
        "n_folds": d["outer_fold"].nunique(),
        "a6_pooled_auc": a6_auc,
        "baseline_pooled_auc": base_auc,
        "pooled_auc_difference_a6_minus_baseline": a6_auc - base_auc,
        "a6_mean_outer_fold_auc": a6_mean,
        "baseline_mean_outer_fold_auc": base_mean,
        "mean_outer_fold_auc_difference": float(np.mean(fold_diff)),
        "sd_outer_fold_auc_difference": float(np.std(fold_diff, ddof=1)),
    })

summary_df = pd.DataFrame(summary_rows)
print(summary_df.to_string(index=False))

# -----------------------------------------------------------------------------
# 4. PAIRED BOOTSTRAP
# -----------------------------------------------------------------------------
print("\n" + "=" * 80)
print("4. PAIRED PATIENT-LEVEL BOOTSTRAP")
print("=" * 80)
print("Stratified resampling by outcome; the same record indices are used for")
print("A6 and the comparator in every replicate, preserving pairing.")

rng = np.random.default_rng(SEED)
results = []
bootstrap_details = {}

for i, (name, d) in enumerate(base_frames.items(), start=1):
    print(f"\n[{i}/{len(base_frames)}] A6 vs {name}")
    y = d["y_true"].to_numpy(dtype=np.int8)
    a6_prob = d["probability"].to_numpy(dtype=float)
    base_prob = d["baseline_probability"].to_numpy(dtype=float)

    pooled_a6 = auc_fast(y, a6_prob)
    pooled_base = auc_fast(y, base_prob)
    pooled_diff = pooled_a6 - pooled_base

    diffs, lo, hi, p = bootstrap_paired_auc(
        y, a6_prob, base_prob, rng, N_BOOTSTRAP
    )

    fold_d = d.rename(columns={"probability": "a6_probability"})
    fold_mean_diff, fold_ci_lo, fold_ci_hi = bootstrap_fold_mean_difference(
        fold_d, "baseline_probability", rng, n_bootstrap=N_BOOTSTRAP
    )

    result = {
        "comparison": f"A6_vs_{name}",
        "baseline": name,
        "n_records": len(d),
        "n_positive": int(y.sum()),
        "n_negative": int((y == 0).sum()),
        "n_outer_folds": int(d["outer_fold"].nunique()),
        "a6_pooled_roc_auc": float(pooled_a6),
        "baseline_pooled_roc_auc": float(pooled_base),
        "pooled_roc_auc_difference": float(pooled_diff),
        "paired_bootstrap_ci_low": float(lo),
        "paired_bootstrap_ci_high": float(hi),
        "paired_bootstrap_p_value": float(p),
        "mean_outer_fold_auc_difference": float(fold_mean_diff),
        "fold_bootstrap_ci_low": float(fold_ci_lo),
        "fold_bootstrap_ci_high": float(fold_ci_hi),
        "bootstrap_replicates": N_BOOTSTRAP,
        "bootstrap_seed": SEED,
        "paired_bootstrap_method": "stratified patient-level bootstrap; common resampled indices",
    }
    results.append(result)
    bootstrap_details[name] = diffs

    print(f"Pooled A6 AUC:       {pooled_a6:.6f}")
    print(f"Pooled {name} AUC:   {pooled_base:.6f}")
    print(f"Difference:           {pooled_diff:+.6f}")
    print(f"95% CI:               [{lo:+.6f}, {hi:+.6f}]")
    print(f"p-value:              {p:.6f}")

# -----------------------------------------------------------------------------
# 5. HOLM MULTIPLE-COMPARISON CORRECTION
# -----------------------------------------------------------------------------
print("\n" + "=" * 80)
print("5. HOLM MULTIPLE-COMPARISON CORRECTION")
print("=" * 80)

raw_p = [r["paired_bootstrap_p_value"] for r in results]
adj_p = holm_adjust(raw_p)

for r, ap in zip(results, adj_p):
    r["holm_adjusted_p_value"] = float(ap)
    ci_lo = r["paired_bootstrap_ci_low"]
    ci_hi = r["paired_bootstrap_ci_high"]
    if ci_lo > 0:
        direction = "A6 significantly higher"
    elif ci_hi < 0:
        direction = "A6 significantly lower"
    else:
        direction = "No statistically clear difference"
    r["inference_at_alpha_0_05"] = direction
    r["holm_significant_alpha_0_05"] = bool(ap < ALPHA)
    print(f"{r['baseline']:<24} raw p={r['paired_bootstrap_p_value']:.6f}  Holm p={ap:.6f}  {direction}")

# -----------------------------------------------------------------------------
# 6. FINAL TABLE
# -----------------------------------------------------------------------------
results_df = pd.DataFrame(results)

preferred_cols = [
    "comparison", "baseline", "n_records", "n_positive", "n_negative",
    "n_outer_folds", "a6_pooled_roc_auc", "baseline_pooled_roc_auc",
    "pooled_roc_auc_difference", "paired_bootstrap_ci_low",
    "paired_bootstrap_ci_high", "paired_bootstrap_p_value",
    "holm_adjusted_p_value", "holm_significant_alpha_0_05",
    "inference_at_alpha_0_05", "mean_outer_fold_auc_difference",
    "fold_bootstrap_ci_low", "fold_bootstrap_ci_high",
    "bootstrap_replicates", "bootstrap_seed", "paired_bootstrap_method"
]
results_df = results_df[preferred_cols]
results_df.to_csv(OUT_CSV, index=False)

# -----------------------------------------------------------------------------
# 7. JSON + REPORT
# -----------------------------------------------------------------------------
json_payload = {
    "implementation": "43B-3",
    "status": "PASS_PAIRED_STATISTICAL_COMPARISON",
    "protocol": {
        "dataset": "Kaggle cardiovascular development outer-CV predictions",
        "n_records": 49000,
        "outer_folds": 5,
        "paired_cohort_verified_in_43B2": True,
        "locked_test_used": False,
        "uci_used": False,
        "retraining": False,
        "hyperparameter_tuning": False,
        "bootstrap_replicates": N_BOOTSTRAP,
        "bootstrap_seed": SEED,
        "bootstrap_type": "stratified patient-level paired bootstrap",
        "multiple_comparison_correction": "Holm",
        "alpha": ALPHA,
    },
    "input_files": {
        "a6": str(A6_FILE),
        **{k: str(v) for k, v in BASELINES.items()},
        "verified_mapping": str(mapping_file),
    },
    "input_sha256": {
        "a6": sha256_file(A6_FILE),
        **{k: sha256_file(v) for k, v in BASELINES.items()},
        "verified_mapping": sha256_file(mapping_file),
    },
    "results": results,
}

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(json_payload, f, indent=2)

lines = []
lines.append("IMPLEMENTATION 43B-3 — PAIRED STATISTICAL COMPARISON")
lines.append("=" * 80)
lines.append("Status: PASS_PAIRED_STATISTICAL_COMPARISON")
lines.append("")
lines.append("Protocol:")
lines.append("- 49,000-record validated outer-CV cohort")
lines.append("- A6 and five baselines have exact common IDs and target agreement")
lines.append("- No retraining, tuning, locked test, or UCI data")
lines.append("- Stratified patient-level paired bootstrap, 5,000 replicates")
lines.append("- Same sampled records used for both models in each replicate")
lines.append("- Holm correction across five comparisons")
lines.append("")
lines.append("Results:")
for r in results:
    lines.append(
        f"{r['baseline']}: A6 AUC={r['a6_pooled_roc_auc']:.6f}; "
        f"baseline AUC={r['baseline_pooled_roc_auc']:.6f}; "
        f"difference={r['pooled_roc_auc_difference']:+.6f}; "
        f"95% CI=[{r['paired_bootstrap_ci_low']:+.6f}, {r['paired_bootstrap_ci_high']:+.6f}]; "
        f"raw p={r['paired_bootstrap_p_value']:.6f}; "
        f"Holm p={r['holm_adjusted_p_value']:.6f}; "
        f"inference={r['inference_at_alpha_0_05']}"
    )
lines.append("")
lines.append("Interpretation rule:")
lines.append("- CI entirely above 0: A6 has higher ROC-AUC")
lines.append("- CI entirely below 0: A6 has lower ROC-AUC")
lines.append("- CI crosses 0: no statistically clear difference")
lines.append("")
lines.append("Important: statistical significance is not assumed. Results must be interpreted from the observed paired differences and confidence intervals.")

with open(OUT_REPORT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")

print("\n" + "=" * 80)
print("IMPLEMENTATION 43B-3 COMPLETE")
print("=" * 80)
print("Final status: PASS_PAIRED_STATISTICAL_COMPARISON")
print(f"CSV:    {OUT_CSV}")
print(f"JSON:   {OUT_JSON}")
print(f"Report: {OUT_REPORT}")
print("\nNo retraining performed.")
print("No locked-test data used.")
print("No UCI data used.")
