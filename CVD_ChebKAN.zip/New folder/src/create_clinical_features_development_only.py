# -*- coding: utf-8 -*-
"""
Clinical feature engineering for CGS-ChebKAN-CP cardiovascular prediction.

This script:
  1. Reads the DEVELOPMENT dataset only.
  2. Adds pulse pressure, approximate mean arterial pressure, and BMI.
  3. Preserves missing values in derived blood-pressure features when either
     source BP value is missing; do not impute here.
  4. Writes a new dataset and a small audit report without overwriting inputs.

Important:
  - Run this script only after confirming PROJECT_ROOT and DEV_FILE.
  - Do not use the locked test set for feature selection or model tuning.
  - Any imputation/scaling must be fitted inside each CV training fold.
  - This script does not repair implausible BP values. Define and document
    any clinical cleaning rules separately before evaluating them.
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DEV_FILE = PROJECT_ROOT / r"data\processed\kaggle_development_cv.csv"
OUTPUT_DIR = PROJECT_ROOT / r"data\processed"
OUTPUT_FILE = OUTPUT_DIR / "kaggle_development_clinical_features_v1.csv"
AUDIT_FILE = OUTPUT_DIR / "kaggle_development_clinical_features_v1_audit.json"

REQUIRED_COLUMNS = [
    "id", "age", "gender", "height", "weight",
    "ap_hi", "ap_lo", "cholesterol", "gluc",
    "smoke", "alco", "active", "cardio"
]

NEW_FEATURES = [
    "pulse_pressure",
    "mean_arterial_pressure",
    "bmi"
]

def main():
    if not DEV_FILE.exists():
        raise FileNotFoundError(
            f"Development dataset not found: {DEV_FILE}\n"
            "Check PROJECT_ROOT and DEV_FILE. This script must use the "
            "development dataset, not the locked test dataset."
        )

    df = pd.read_csv(DEV_FILE)
    missing_columns = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {missing_columns}")

    if df["id"].duplicated().any():
        raise ValueError("Duplicate IDs found in development data.")
    if df["cardio"].isna().any():
        raise ValueError("Missing target values found in development data.")

    # Keep source data unchanged; add only new columns to this in-memory copy.
    for col in ["ap_hi", "ap_lo", "height", "weight"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Derived BP values remain missing if either BP input is missing.
    df["pulse_pressure"] = df["ap_hi"] - df["ap_lo"]
    df["mean_arterial_pressure"] = (
        df["ap_hi"] + 2.0 * df["ap_lo"]
    ) / 3.0

    # Dataset units: height in centimetres, weight in kilograms.
    height_m = df["height"] / 100.0
    valid_height = height_m.notna() & np.isfinite(height_m) & (height_m > 0)
    df["bmi"] = np.nan
    df.loc[valid_height, "bmi"] = (
        df.loc[valid_height, "weight"] / (height_m.loc[valid_height] ** 2)
    )

    # Prevent non-finite derived values from silently entering later pipelines.
    for col in NEW_FEATURES:
        df[col] = df[col].replace([np.inf, -np.inf], np.nan)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)

    audit = {
        "purpose": "Development-only clinical feature engineering",
        "input_file": str(DEV_FILE),
        "output_file": str(OUTPUT_FILE),
        "rows": int(len(df)),
        "unique_ids": int(df["id"].nunique()),
        "new_features": {
            "pulse_pressure": "ap_hi - ap_lo",
            "mean_arterial_pressure": "(ap_hi + 2 * ap_lo) / 3",
            "bmi": "weight_kg / (height_cm / 100)^2",
        },
        "units_assumed": {
            "height": "centimetres",
            "weight": "kilograms",
            "blood_pressure": "same units as source dataset, conventionally mmHg",
            "age": "days in source dataset; unchanged",
        },
        "missing_counts": {
            col: int(df[col].isna().sum())
            for col in ["ap_hi", "ap_lo"] + NEW_FEATURES
        },
        "nonfinite_values_after_processing": {
            col: int((~np.isfinite(df[col].to_numpy(dtype=float))).sum())
            for col in NEW_FEATURES
        },
        "notes": [
            "No rows were removed.",
            "No missing values were imputed in this script.",
            "No implausible blood-pressure values were repaired or deleted.",
            "Imputation and scaling must be fitted within each CV training fold.",
            "Do not use the locked test set for feature/model selection.",
        ],
    }

    with open(AUDIT_FILE, "w", encoding="utf-8") as f:
        json.dump(audit, f, indent=2)

    print("Clinical feature engineering completed.")
    print(f"Rows preserved: {len(df):,}")
    print(f"Output dataset: {OUTPUT_FILE}")
    print(f"Audit report:   {AUDIT_FILE}")
    print("\nMissing values in new features:")
    print(df[NEW_FEATURES].isna().sum().to_string())
    print("\nNo training or model evaluation was performed by this script.")

if __name__ == "__main__":
    main()
