# ============================================================
# IMPLEMENTATION 31
# A6: SPARSE CLINICALLY-GROUPED CHEBYSHEV-KAN
# ============================================================

import sys
import json
import time
import random
import warnings
from pathlib import Path
from itertools import product

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

warnings.filterwarnings("ignore")


# ============================================================
# 1. PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
MODELS_DIR = RESULTS_DIR / "models"

TABLES_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 2026


def set_seed(seed=SEED):

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed()


# ============================================================
# 3. ENVIRONMENT
# ============================================================

print("=" * 80)
print("IMPLEMENTATION 31 — A6 SPARSE CLINICALLY-GROUPED CHEBYSHEV-KAN")
print("=" * 80)

print("\n[ENVIRONMENT]")
print("Python:", sys.version)
print("NumPy:", np.__version__)
print("Pandas:", pd.__version__)
print("PyTorch:", torch.__version__)
print("Project root:", PROJECT_ROOT)

if torch.cuda.is_available():

    DEVICE = torch.device("cuda")

    print("CUDA available: True")
    print(
        "GPU:",
        torch.cuda.get_device_name(0),
    )

    print(
        "GPU memory:",
        round(
            torch.cuda.get_device_properties(
                0
            ).total_memory
            / (1024 ** 3),
            2,
        ),
        "GB",
    )

else:

    DEVICE = torch.device("cpu")

    print("CUDA available: False")
    print("WARNING: Running on CPU.")

print("Device:", DEVICE)


# ============================================================
# 4. DATA FILES
# ============================================================

DEV_FILE = (
    DATA_DIR /
    "kaggle_development_cv.csv"
)

CAL_FILE = (
    DATA_DIR /
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    DATA_DIR /
    "kaggle_locked_test.csv"
)

print("\n[DATA FILE CHECK]")

for file_path in [
    DEV_FILE,
    CAL_FILE,
    TEST_FILE,
]:

    print(
        file_path,
        "->",
        file_path.exists(),
    )

    if not file_path.exists():

        raise FileNotFoundError(
            f"Required file not found: "
            f"{file_path}"
        )


# ============================================================
# 5. LOAD DATA
# ============================================================

dev = pd.read_csv(
    DEV_FILE
)

cal = pd.read_csv(
    CAL_FILE
)

test = pd.read_csv(
    TEST_FILE
)

print("\n[PARTITIONS]")
print(
    "Development:",
    dev.shape,
)

print(
    "Calibration:",
    cal.shape,
)

print(
    "Locked test:",
    test.shape,
)


# ============================================================
# 6. FROZEN FEATURES
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"


# ============================================================
# 7. FROZEN CLINICAL GROUPS
# ============================================================

CLINICAL_GROUPS = {

    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


print("\n[FROZEN CLINICAL GROUPS]")

for group_name, group_features in (
    CLINICAL_GROUPS.items()
):

    print(
        f"{group_name}: "
        f"{group_features}"
    )


# ============================================================
# 8. GROUP VALIDATION
# ============================================================

flattened_features = []

for group_features in (
    CLINICAL_GROUPS.values()
):

    flattened_features.extend(
        group_features
    )

if (
    sorted(flattened_features)
    !=
    sorted(FEATURES)
):

    raise ValueError(
        "Clinical grouping does not contain "
        "exactly the 11 frozen features."
    )

if (
    len(flattened_features)
    !=
    len(set(flattened_features))
):

    raise ValueError(
        "Duplicate feature assignment detected."
    )

print(
    "Clinical grouping validation: PASS"
)


# ============================================================
# 9. BASIC DATA VALIDATION
# ============================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    missing_features = [
        feature
        for feature in FEATURES
        if feature not in df.columns
    ]

    if TARGET not in df.columns:

        raise ValueError(
            f"{TARGET} missing from {name}"
        )

    if missing_features:

        raise ValueError(
            f"Missing features in {name}: "
            f"{missing_features}"
        )

    if (
        df[TARGET]
        .isna()
        .sum()
        > 0
    ):

        raise ValueError(
            f"Missing target in {name}"
        )

    target_values = sorted(
        df[TARGET]
        .unique()
        .tolist()
    )

    if target_values != [0, 1]:

        raise ValueError(
            f"Unexpected target values "
            f"in {name}: {target_values}"
        )

    print(
        f"{name}: rows={len(df)}, "
        f"target values={target_values}"
    )


# ============================================================
# 10. PARTITION INTEGRITY
# ============================================================

print("\n[PARTITION INTEGRITY]")

if all(
    "id" in df.columns
    for df in [
        dev,
        cal,
        test,
    ]
):

    dev_ids = set(
        dev["id"]
    )

    cal_ids = set(
        cal["id"]
    )

    test_ids = set(
        test["id"]
    )

    overlap_dev_cal = (
        dev_ids.intersection(
            cal_ids
        )
    )

    overlap_dev_test = (
        dev_ids.intersection(
            test_ids
        )
    )

    overlap_cal_test = (
        cal_ids.intersection(
            test_ids
        )
    )

    print(
        "Development-Calibration overlap:",
        len(overlap_dev_cal),
    )

    print(
        "Development-Test overlap:",
        len(overlap_dev_test),
    )

    print(
        "Calibration-Test overlap:",
        len(overlap_cal_test),
    )

    assert len(overlap_dev_cal) == 0
    assert len(overlap_dev_test) == 0
    assert len(overlap_cal_test) == 0

    print(
        "ID disjointness: PASS"
    )


# ============================================================
# 11. TARGET DISTRIBUTION
# ============================================================

print("\n[TARGET DISTRIBUTION]")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    counts = (
        df[TARGET]
        .value_counts()
        .sort_index()
    )

    print(
        f"{name}: "
        f"class 0={counts.get(0, 0)}, "
        f"class 1={counts.get(1, 0)}, "
        f"positive rate="
        f"{df[TARGET].mean():.6f}"
    )


# ============================================================
# 12. MISSINGNESS
# ============================================================

print("\n[MISSINGNESS AUDIT]")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    missing = (
        df[FEATURES]
        .isna()
        .sum()
    )

    print(f"\n{name}")

    for feature, count in (
        missing.items()
    ):

        if count > 0:

            print(
                f"  {feature}: "
                f"{count} "
                f"({100 * count / len(df):.4f}%)"
            )


# ============================================================
# 13. DATA ARRAYS
# ============================================================

X_dev = dev[
    FEATURES
].copy()

y_dev = (
    dev[TARGET]
    .astype(int)
    .values
)

X_cal = cal[
    FEATURES
].copy()

y_cal = (
    cal[TARGET]
    .astype(int)
    .values
)

X_test = test[
    FEATURES
].copy()

y_test = (
    test[TARGET]
    .astype(int)
    .values
)


# ============================================================
# 14. CROSS-VALIDATION
# ============================================================

OUTER_FOLDS = 5
INNER_FOLDS = 4

outer_cv = StratifiedKFold(
    n_splits=OUTER_FOLDS,
    shuffle=True,
    random_state=SEED,
)

inner_cv = StratifiedKFold(
    n_splits=INNER_FOLDS,
    shuffle=True,
    random_state=SEED,
)


# ============================================================
# 15. A6 ARCHITECTURE
# ============================================================

CHEB_K = 5

GROUP_EMBEDDING_DIM = 16

LEARNING_RATES = [
    1e-3,
    3e-4,
]

L2_VALUES = [
    1e-5,
    1e-4,
    1e-3,
]

# Sparse group-gate regularization.
#
# L1 is applied to the pre-softmax gate parameters q_g.
#
# This follows the frozen A6 definition:
#
# alpha_g =
# exp(q_g) / sum_j exp(q_j)
#
# h =
# sum_g alpha_g h_g
#
# The L1 coefficient itself is selected only inside
# the inner CV.

GATE_L1_VALUES = [
    1e-5,
    1e-4,
    1e-3,
]

HYPERPARAM_GRID = list(
    product(
        LEARNING_RATES,
        L2_VALUES,
        GATE_L1_VALUES,
    )
)

MAX_EPOCHS = 150

PATIENCE = 15

BATCH_SIZE = 512


print("\n[A6 ARCHITECTURE]")
print(
    "Chebyshev degree:",
    CHEB_K,
)

print(
    "Group embedding dimension:",
    GROUP_EMBEDDING_DIM,
)

print(
    "Clinical grouping: YES"
)

print(
    "Sparse group gates: YES"
)

print(
    "Gate activation: SOFTMAX"
)

print(
    "Gate L1 regularization: YES"
)

print(
    "ADASYN: NO"
)

print(
    "Conformal prediction: NO"
)

print(
    "Hyperparameter configurations:",
    len(HYPERPARAM_GRID),
)


# ============================================================
# 16. CHEBYSHEV-KAN LAYER
# ============================================================

class ChebyshevKANLayer(nn.Module):

    def __init__(
        self,
        input_dim,
        output_dim,
        degree=5,
    ):

        super().__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                output_dim,
                input_dim,
                degree + 1,
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(
                output_dim
            )
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02,
        )

    def forward(self, x):

        x = torch.clamp(
            x,
            -1.0,
            1.0,
        )

        basis = [
            torch.ones_like(x)
        ]

        if self.degree >= 1:

            basis.append(x)

        for _ in range(
            2,
            self.degree + 1,
        ):

            basis.append(
                2.0
                * x
                * basis[-1]
                - basis[-2]
            )

        basis_tensor = torch.stack(
            basis,
            dim=-1,
        )

        output = torch.einsum(
            "bik,oik->bo",
            basis_tensor,
            self.coefficients,
        )

        return (
            output
            + self.bias
        )


# ============================================================
# 17. CLINICAL GROUP BRANCH
# ============================================================

class ClinicalGroupBranch(
    nn.Module
):

    def __init__(
        self,
        input_dim,
        embedding_dim=16,
        degree=5,
    ):

        super().__init__()

        self.cheb = (
            ChebyshevKANLayer(
                input_dim=input_dim,
                output_dim=embedding_dim,
                degree=degree,
            )
        )

        self.activation = nn.SiLU()

    def forward(self, x):

        return self.activation(
            self.cheb(x)
        )


# ============================================================
# 18. A6 SPARSE MODEL
# ============================================================

class SparseClinicalGroupedChebKAN(
    nn.Module
):

    """
    A6:

        Group 1 -> ChebKAN -> 16
        Group 2 -> ChebKAN -> 16
        Group 3 -> ChebKAN -> 16

        Each group embedding is passed through
        a learnable scalar gate.

        alpha_g =
            softmax(q_g)

        h =
            sum_g alpha_g h_g

        Final:
            Linear(16 -> 1)

    The gate parameters q_g receive L1 regularization
    in the training loss.

    IMPORTANT:
    Softmax gates are strictly positive. Therefore,
    L1 on q_g encourages small gate logits but does
    not mathematically guarantee exact zero gates.
    """

    def __init__(
        self,
        group_dimensions,
        embedding_dim=16,
        degree=5,
    ):

        super().__init__()

        self.demographic_branch = (
            ClinicalGroupBranch(
                input_dim=group_dimensions[
                    "demographic"
                ],
                embedding_dim=embedding_dim,
                degree=degree,
            )
        )

        self.physiological_branch = (
            ClinicalGroupBranch(
                input_dim=group_dimensions[
                    "physiological_anthropometric_metabolic"
                ],
                embedding_dim=embedding_dim,
                degree=degree,
            )
        )

        self.lifestyle_branch = (
            ClinicalGroupBranch(
                input_dim=group_dimensions[
                    "lifestyle"
                ],
                embedding_dim=embedding_dim,
                degree=degree,
            )
        )

        # Pre-softmax group gate logits q_g.
        self.gate_logits = nn.Parameter(
            torch.zeros(3)
        )

        self.output = nn.Linear(
            embedding_dim,
            1,
        )

    def forward(
        self,
        demographic_x,
        physiological_x,
        lifestyle_x,
    ):

        demographic_embedding = (
            self.demographic_branch(
                demographic_x
            )
        )

        physiological_embedding = (
            self.physiological_branch(
                physiological_x
            )
        )

        lifestyle_embedding = (
            self.lifestyle_branch(
                lifestyle_x
            )
        )

        # ----------------------------------------------------
        # Softmax group gates
        # ----------------------------------------------------

        alpha = torch.softmax(
            self.gate_logits,
            dim=0,
        )

        fused = (
            alpha[0]
            * demographic_embedding
            +
            alpha[1]
            * physiological_embedding
            +
            alpha[2]
            * lifestyle_embedding
        )

        return self.output(
            fused
        ).squeeze(1)


# ============================================================
# 19. FEATURE INDICES
# ============================================================

feature_index = {
    feature: index
    for index, feature
    in enumerate(FEATURES)
}

GROUP_INDICES = {
    group_name: [
        feature_index[feature]
        for feature in group_features
    ]
    for group_name, group_features
    in CLINICAL_GROUPS.items()
}

print("\n[GROUP INDICES]")

for group_name, indices in (
    GROUP_INDICES.items()
):

    print(
        group_name,
        "->",
        indices,
    )


# ============================================================
# 20. GROUP SPLITTING
# ============================================================

def split_into_groups(X):

    demographic = X[
        :,
        GROUP_INDICES[
            "demographic"
        ]
    ]

    physiological = X[
        :,
        GROUP_INDICES[
            "physiological_anthropometric_metabolic"
        ]
    ]

    lifestyle = X[
        :,
        GROUP_INDICES[
            "lifestyle"
        ]
    ]

    return (
        demographic,
        physiological,
        lifestyle,
    )


# ============================================================
# 21. PREPROCESSING
# ============================================================

def fit_preprocessor(
    X_train
):

    imputer = SimpleImputer(
        strategy="median"
    )

    scaler = MinMaxScaler(
        feature_range=(-1, 1)
    )

    X_imputed = (
        imputer.fit_transform(
            X_train
        )
    )

    scaler.fit(
        X_imputed
    )

    return (
        imputer,
        scaler,
    )


def transform_preprocessor(
    X,
    imputer,
    scaler,
):

    X_imputed = (
        imputer.transform(X)
    )

    X_scaled = (
        scaler.transform(
            X_imputed
        )
    )

    return X_scaled.astype(
        np.float32
    )


# ============================================================
# 22. INTERNAL EARLY-STOPPING SPLIT
# ============================================================

def internal_split(
    X,
    y,
    seed,
):

    splitter = StratifiedKFold(
        n_splits=10,
        shuffle=True,
        random_state=seed,
    )

    train_idx, val_idx = next(
        splitter.split(
            X,
            y,
        )
    )

    return (
        train_idx,
        val_idx,
    )


# ============================================================
# 23. PARAMETER COUNT
# ============================================================

def count_parameters(
    model
):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ============================================================
# 24. GATE L1 PENALTY
# ============================================================

def gate_l1_penalty(
    model
):

    return torch.sum(
        torch.abs(
            model.gate_logits
        )
    )


# ============================================================
# 25. GET GATE VALUES
# ============================================================

def get_gate_values(
    model
):

    with torch.no_grad():

        alpha = torch.softmax(
            model.gate_logits,
            dim=0,
        )

        q = (
            model.gate_logits
            .detach()
            .cpu()
            .numpy()
        )

        alpha = (
            alpha
            .detach()
            .cpu()
            .numpy()
        )

    return q, alpha


# ============================================================
# 26. MODEL TRAINING
# ============================================================

def train_model(
    model,
    X_train_groups,
    y_train,
    X_val_groups,
    y_val,
    learning_rate,
    l2,
    gate_l1,
):

    model = model.to(
        DEVICE
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=l2,
    )

    criterion = (
        nn.BCEWithLogitsLoss()
    )

    train_tensors = [
        torch.tensor(
            group,
            dtype=torch.float32,
        )
        for group in X_train_groups
    ]

    y_tensor = torch.tensor(
        y_train,
        dtype=torch.float32,
    )

    train_dataset = TensorDataset(
        train_tensors[0],
        train_tensors[1],
        train_tensors[2],
        y_tensor,
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        drop_last=False,
    )

    val_tensors = [
        torch.tensor(
            group,
            dtype=torch.float32,
            device=DEVICE,
        )
        for group in X_val_groups
    ]

    best_auc = -np.inf

    best_state = None

    best_epoch = 0

    patience_counter = 0

    for epoch in range(
        1,
        MAX_EPOCHS + 1,
    ):

        model.train()

        for (
            batch_demographic,
            batch_physiological,
            batch_lifestyle,
            batch_y,
        ) in train_loader:

            batch_demographic = (
                batch_demographic.to(
                    DEVICE,
                    non_blocking=True,
                )
            )

            batch_physiological = (
                batch_physiological.to(
                    DEVICE,
                    non_blocking=True,
                )
            )

            batch_lifestyle = (
                batch_lifestyle.to(
                    DEVICE,
                    non_blocking=True,
                )
            )

            batch_y = batch_y.to(
                DEVICE,
                non_blocking=True,
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(
                batch_demographic,
                batch_physiological,
                batch_lifestyle,
            )

            prediction_loss = (
                criterion(
                    logits,
                    batch_y,
                )
            )

            sparsity_loss = (
                gate_l1
                * gate_l1_penalty(
                    model
                )
            )

            loss = (
                prediction_loss
                + sparsity_loss
            )

            loss.backward()

            optimizer.step()

        # ----------------------------------------------------
        # Validation
        # ----------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                val_tensors[0],
                val_tensors[1],
                val_tensors[2],
            )

            val_probability = (
                torch.sigmoid(
                    val_logits
                )
                .detach()
                .cpu()
                .numpy()
            )

        val_auc = roc_auc_score(
            y_val,
            val_probability,
        )

        if val_auc > best_auc:

            best_auc = val_auc

            best_state = {
                key: value.detach()
                .cpu()
                .clone()
                for key, value
                in model.state_dict().items()
            }

            best_epoch = epoch

            patience_counter = 0

        else:

            patience_counter += 1

        if (
            patience_counter
            >= PATIENCE
        ):

            break

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    return (
        model,
        best_auc,
        best_epoch,
    )


# ============================================================
# 27. PREDICTION
# ============================================================

def predict_probability(
    model,
    X_groups,
):

    model.eval()

    group_tensors = [
        torch.tensor(
            group,
            dtype=torch.float32,
            device=DEVICE,
        )
        for group in X_groups
    ]

    with torch.no_grad():

        logits = model(
            group_tensors[0],
            group_tensors[1],
            group_tensors[2],
        )

        probability = (
            torch.sigmoid(
                logits
            )
            .detach()
            .cpu()
            .numpy()
        )

    return probability


# ============================================================
# 28. METRICS
# ============================================================

def calculate_metrics(
    y_true,
    probability,
):

    prediction = (
        probability >= 0.5
    ).astype(int)

    tn, fp, fn, tp = (
        confusion_matrix(
            y_true,
            prediction,
            labels=[0, 1],
        ).ravel()
    )

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {

        "accuracy": accuracy_score(
            y_true,
            prediction,
        ),

        "precision": precision_score(
            y_true,
            prediction,
            zero_division=0,
        ),

        "sensitivity": sensitivity,

        "specificity": specificity,

        "f1": f1_score(
            y_true,
            prediction,
            zero_division=0,
        ),

        "roc_auc": roc_auc_score(
            y_true,
            probability,
        ),

        "pr_auc": average_precision_score(
            y_true,
            probability,
        ),

        "brier": brier_score_loss(
            y_true,
            probability,
        ),
    }


# ============================================================
# 29. EXPECTED CALIBRATION ERROR
# ============================================================

def expected_calibration_error(
    y_true,
    probability,
    n_bins=10,
):

    bins = np.linspace(
        0.0,
        1.0,
        n_bins + 1,
    )

    ece = 0.0

    for i in range(
        n_bins
    ):

        lower = bins[i]
        upper = bins[i + 1]

        if (
            i
            ==
            n_bins - 1
        ):

            mask = (
                (probability >= lower)
                &
                (probability <= upper)
            )

        else:

            mask = (
                (probability >= lower)
                &
                (probability < upper)
            )

        if np.sum(mask) == 0:
            continue

        mean_probability = np.mean(
            probability[mask]
        )

        observed_frequency = np.mean(
            y_true[mask]
        )

        fraction = (
            np.sum(mask)
            /
            len(y_true)
        )

        ece += (
            fraction
            *
            abs(
                mean_probability
                -
                observed_frequency
            )
        )

    return ece


# ============================================================
# 30. RESULT STORAGE
# ============================================================

fold_results = []

hyperparameter_results = []

selected_hyperparameters = []

outer_probabilities = []

outer_targets = []


# ============================================================
# 31. NESTED 5 x 4 CV
# ============================================================

print("\n")
print("=" * 80)
print("STARTING A6 NESTED 5 x 4 CROSS-VALIDATION")
print("=" * 80)

overall_start = time.time()


for outer_fold, (
    outer_train_idx,
    outer_val_idx,
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev,
    ),
    start=1,
):

    fold_start = time.time()

    print("\n")
    print("-" * 80)
    print(
        f"OUTER FOLD "
        f"{outer_fold}/{OUTER_FOLDS}"
    )
    print("-" * 80)

    X_outer_train = (
        X_dev.iloc[
            outer_train_idx
        ].copy()
    )

    y_outer_train = (
        y_dev[
            outer_train_idx
        ]
    )

    X_outer_val = (
        X_dev.iloc[
            outer_val_idx
        ].copy()
    )

    y_outer_val = (
        y_dev[
            outer_val_idx
        ]
    )

    print(
        "Outer training size:",
        len(X_outer_train),
    )

    print(
        "Outer validation size:",
        len(X_outer_val),
    )

    print(
        "Outer training positive rate:",
        f"{np.mean(y_outer_train):.6f}",
    )

    print(
        "Outer validation positive rate:",
        f"{np.mean(y_outer_val):.6f}",
    )


    # ========================================================
    # 32. INNER HYPERPARAMETER SEARCH
    # ========================================================

    config_scores = []

    for config_number, (
        learning_rate,
        l2,
        gate_l1,
    ) in enumerate(
        HYPERPARAM_GRID,
        start=1,
    ):

        inner_scores = []

        for inner_fold, (
            inner_train_idx,
            inner_val_idx,
        ) in enumerate(
            inner_cv.split(
                X_outer_train,
                y_outer_train,
            ),
            start=1,
        ):

            X_inner_train_raw = (
                X_outer_train.iloc[
                    inner_train_idx
                ]
            )

            y_inner_train = (
                y_outer_train[
                    inner_train_idx
                ]
            )

            X_inner_val_raw = (
                X_outer_train.iloc[
                    inner_val_idx
                ]
            )

            y_inner_val = (
                y_outer_train[
                    inner_val_idx
                ]
            )


            # ------------------------------------------------
            # Fold-specific preprocessing
            # ------------------------------------------------

            inner_imputer, inner_scaler = (
                fit_preprocessor(
                    X_inner_train_raw
                )
            )

            X_inner_train = (
                transform_preprocessor(
                    X_inner_train_raw,
                    inner_imputer,
                    inner_scaler,
                )
            )

            X_inner_val = (
                transform_preprocessor(
                    X_inner_val_raw,
                    inner_imputer,
                    inner_scaler,
                )
            )


            # ------------------------------------------------
            # Internal early stopping split
            # ------------------------------------------------

            (
                internal_train_idx,
                internal_val_idx,
            ) = internal_split(
                X_inner_train,
                y_inner_train,
                seed=(
                    SEED
                    + outer_fold * 100
                    + inner_fold
                ),
            )

            X_fit = X_inner_train[
                internal_train_idx
            ]

            y_fit = y_inner_train[
                internal_train_idx
            ]

            X_early = X_inner_train[
                internal_val_idx
            ]

            y_early = y_inner_train[
                internal_val_idx
            ]

            X_fit_groups = (
                split_into_groups(
                    X_fit
                )
            )

            X_early_groups = (
                split_into_groups(
                    X_early
                )
            )


            # ------------------------------------------------
            # Model
            # ------------------------------------------------

            set_seed(
                SEED
                + outer_fold * 1000
                + inner_fold * 100
                + config_number
            )

            group_dimensions = {
                group_name: len(
                    group_features
                )
                for (
                    group_name,
                    group_features
                ) in CLINICAL_GROUPS.items()
            }

            model = (
                SparseClinicalGroupedChebKAN(
                    group_dimensions=(
                        group_dimensions
                    ),
                    embedding_dim=(
                        GROUP_EMBEDDING_DIM
                    ),
                    degree=CHEB_K,
                )
            )

            model, _, _ = train_model(
                model=model,
                X_train_groups=(
                    X_fit_groups
                ),
                y_train=y_fit,
                X_val_groups=(
                    X_early_groups
                ),
                y_val=y_early,
                learning_rate=(
                    learning_rate
                ),
                l2=l2,
                gate_l1=gate_l1,
            )

            X_inner_val_groups = (
                split_into_groups(
                    X_inner_val
                )
            )

            inner_probability = (
                predict_probability(
                    model,
                    X_inner_val_groups,
                )
            )

            inner_auc = (
                roc_auc_score(
                    y_inner_val,
                    inner_probability,
                )
            )

            inner_scores.append(
                inner_auc
            )

            print(
                f"Outer {outer_fold} | "
                f"Config {config_number:02d}/"
                f"{len(HYPERPARAM_GRID)} | "
                f"Inner {inner_fold}/"
                f"{INNER_FOLDS} | "
                f"lr={learning_rate:.0e} | "
                f"l2={l2:.0e} | "
                f"gate_l1={gate_l1:.0e} | "
                f"AUC={inner_auc:.6f}"
            )

            del model

            if torch.cuda.is_available():
                torch.cuda.empty_cache()


        mean_inner_auc = float(
            np.mean(
                inner_scores
            )
        )

        std_inner_auc = float(
            np.std(
                inner_scores,
                ddof=1,
            )
        )

        config_scores.append(
            {
                "outer_fold": (
                    outer_fold
                ),
                "config_number": (
                    config_number
                ),
                "learning_rate": (
                    learning_rate
                ),
                "l2": l2,
                "gate_l1": gate_l1,
                "mean_inner_auc": (
                    mean_inner_auc
                ),
                "std_inner_auc": (
                    std_inner_auc
                ),
            }
        )


    # ========================================================
    # 33. BEST HYPERPARAMETERS
    # ========================================================

    config_scores_sorted = sorted(
        config_scores,
        key=lambda x: (
            -x["mean_inner_auc"],
            x["gate_l1"],
            x["l2"],
            -x["learning_rate"],
        ),
    )

    best_config = (
        config_scores_sorted[0]
    )

    best_lr = (
        best_config[
            "learning_rate"
        ]
    )

    best_l2 = (
        best_config["l2"]
    )

    best_gate_l1 = (
        best_config["gate_l1"]
    )

    print(
        "\nSelected hyperparameters:"
    )

    print(
        "Learning rate:",
        best_lr,
    )

    print(
        "L2:",
        best_l2,
    )

    print(
        "Gate L1:",
        best_gate_l1,
    )

    print(
        "Best hyperparameter-search "
        "inner-CV ROC-AUC:",
        f"{best_config['mean_inner_auc']:.6f}",
    )

    hyperparameter_results.extend(
        config_scores
    )

    selected_hyperparameters.append(
        {
            "outer_fold": outer_fold,
            "learning_rate": best_lr,
            "l2": best_l2,
            "gate_l1": best_gate_l1,
            "best_inner_cv_auc": (
                best_config[
                    "mean_inner_auc"
                ]
            ),
        }
    )


    # ========================================================
    # 34. OUTER PREPROCESSING
    # ========================================================

    outer_imputer, outer_scaler = (
        fit_preprocessor(
            X_outer_train
        )
    )

    X_outer_train_processed = (
        transform_preprocessor(
            X_outer_train,
            outer_imputer,
            outer_scaler,
        )
    )

    X_outer_val_processed = (
        transform_preprocessor(
            X_outer_val,
            outer_imputer,
            outer_scaler,
        )
    )


    # ========================================================
    # 35. INTERNAL EARLY STOPPING SPLIT
    # ========================================================

    (
        internal_train_idx,
        internal_val_idx,
    ) = internal_split(
        X_outer_train_processed,
        y_outer_train,
        seed=SEED + outer_fold,
    )

    X_fit = (
        X_outer_train_processed[
            internal_train_idx
        ]
    )

    y_fit = (
        y_outer_train[
            internal_train_idx
        ]
    )

    X_early = (
        X_outer_train_processed[
            internal_val_idx
        ]
    )

    y_early = (
        y_outer_train[
            internal_val_idx
        ]
    )

    X_fit_groups = (
        split_into_groups(
            X_fit
        )
    )

    X_early_groups = (
        split_into_groups(
            X_early
        )
    )


    # ========================================================
    # 36. FINAL OUTER MODEL
    # ========================================================

    set_seed(
        SEED
        + 5000
        + outer_fold
    )

    group_dimensions = {
        group_name: len(
            group_features
        )
        for (
            group_name,
            group_features
        ) in CLINICAL_GROUPS.items()
    }

    final_model = (
        SparseClinicalGroupedChebKAN(
            group_dimensions=(
                group_dimensions
            ),
            embedding_dim=(
                GROUP_EMBEDDING_DIM
            ),
            degree=CHEB_K,
        )
    )

    parameter_count = (
        count_parameters(
            final_model
        )
    )

    (
        final_model,
        final_internal_auc,
        best_epoch,
    ) = train_model(
        model=final_model,
        X_train_groups=(
            X_fit_groups
        ),
        y_train=y_fit,
        X_val_groups=(
            X_early_groups
        ),
        y_val=y_early,
        learning_rate=best_lr,
        l2=best_l2,
        gate_l1=best_gate_l1,
    )

    print(
        "Final selected-model "
        "internal validation ROC-AUC:",
        f"{final_internal_auc:.6f}",
    )

    print(
        "Best epoch:",
        best_epoch,
    )

    print(
        "Trainable parameters:",
        parameter_count,
    )


    # ========================================================
    # 37. FINAL GATE VALUES
    # ========================================================

    gate_q, gate_alpha = (
        get_gate_values(
            final_model
        )
    )

    print(
        "\nLearned pre-softmax gate logits:"
    )

    print(
        "  demographic:",
        f"{gate_q[0]:.6f}",
    )

    print(
        "  physiological:",
        f"{gate_q[1]:.6f}",
    )

    print(
        "  lifestyle:",
        f"{gate_q[2]:.6f}",
    )

    print(
        "Normalized group gates:"
    )

    print(
        "  demographic:",
        f"{gate_alpha[0]:.6f}",
    )

    print(
        "  physiological:",
        f"{gate_alpha[1]:.6f}",
    )

    print(
        "  lifestyle:",
        f"{gate_alpha[2]:.6f}",
    )

    print(
        "Gate sum:",
        f"{gate_alpha.sum():.6f}",
    )


    # ========================================================
    # 38. OUTER VALIDATION
    # ========================================================

    X_outer_val_groups = (
        split_into_groups(
            X_outer_val_processed
        )
    )

    outer_probability = (
        predict_probability(
            final_model,
            X_outer_val_groups,
        )
    )

    metrics = calculate_metrics(
        y_outer_val,
        outer_probability,
    )

    metrics["ece"] = (
        expected_calibration_error(
            y_outer_val,
            outer_probability,
        )
    )

    metrics["outer_fold"] = (
        outer_fold
    )

    metrics["learning_rate"] = (
        best_lr
    )

    metrics["l2"] = (
        best_l2
    )

    metrics["gate_l1"] = (
        best_gate_l1
    )

    metrics["best_epoch"] = (
        best_epoch
    )

    metrics["parameter_count"] = (
        parameter_count
    )

    metrics["gate_q_demographic"] = (
        gate_q[0]
    )

    metrics["gate_q_physiological"] = (
        gate_q[1]
    )

    metrics["gate_q_lifestyle"] = (
        gate_q[2]
    )

    metrics["gate_alpha_demographic"] = (
        gate_alpha[0]
    )

    metrics["gate_alpha_physiological"] = (
        gate_alpha[1]
    )

    metrics["gate_alpha_lifestyle"] = (
        gate_alpha[2]
    )

    fold_results.append(
        metrics
    )

    outer_probabilities.extend(
        outer_probability.tolist()
    )

    outer_targets.extend(
        y_outer_val.tolist()
    )

    print(
        "\nOuter validation results:"
    )

    for metric_name in [
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "brier",
        "ece",
    ]:

        print(
            f"{metric_name:15s}: "
            f"{metrics[metric_name]:.6f}"
        )


    # ========================================================
    # 39. SAVE FOLD MODEL
    # ========================================================

    model_path = (
        MODELS_DIR
        /
        (
            "implementation31_a6_"
            "sparse_grouped_chebkan_"
            f"fold{outer_fold}.pt"
        )
    )

    torch.save(
        {
            "model_state_dict": (
                final_model.state_dict()
            ),
            "clinical_groups": (
                CLINICAL_GROUPS
            ),
            "features": FEATURES,
            "target": TARGET,
            "chebyshev_degree": (
                CHEB_K
            ),
            "group_embedding_dim": (
                GROUP_EMBEDDING_DIM
            ),
            "learning_rate": (
                best_lr
            ),
            "l2": best_l2,
            "gate_l1": (
                best_gate_l1
            ),
            "parameter_count": (
                parameter_count
            ),
            "gate_logits": gate_q.tolist(),
            "gate_weights": (
                gate_alpha.tolist()
            ),
        },
        model_path,
    )

    print(
        "Model saved:",
        model_path,
    )

    fold_time = (
        time.time()
        - fold_start
    )

    print(
        f"Fold execution time: "
        f"{fold_time / 60:.2f} minutes"
    )

    del final_model

    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# ============================================================
# 40. OUTER CV SUMMARY
# ============================================================

results_df = pd.DataFrame(
    fold_results
)

outer_targets = np.asarray(
    outer_targets
)

outer_probabilities = np.asarray(
    outer_probabilities
)

print("\n")
print("=" * 80)
print("A6 OUTER CROSS-VALIDATION SUMMARY")
print("=" * 80)

metric_columns = [
    "accuracy",
    "precision",
    "sensitivity",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier",
    "ece",
]

summary_rows = []

for metric in metric_columns:

    mean_value = (
        results_df[
            metric
        ].mean()
    )

    std_value = (
        results_df[
            metric
        ].std(
            ddof=1
        )
    )

    summary_rows.append(
        {
            "metric": metric,
            "mean": mean_value,
            "std": std_value,
        }
    )

    print(
        f"{metric:15s}: "
        f"{mean_value:.6f} "
        f"+/- {std_value:.6f}"
    )


# ============================================================
# 41. POOLED OUTER METRICS
# ============================================================

pooled_metrics = (
    calculate_metrics(
        outer_targets,
        outer_probabilities,
    )
)

pooled_metrics["ece"] = (
    expected_calibration_error(
        outer_targets,
        outer_probabilities,
    )
)

print(
    "\n[POOLED OUTER VALIDATION]"
)

for metric_name, value in (
    pooled_metrics.items()
):

    print(
        f"{metric_name:15s}: "
        f"{value:.6f}"
    )


# ============================================================
# 42. HYPERPARAMETER STABILITY
# ============================================================

selected_df = pd.DataFrame(
    selected_hyperparameters
)

print("\n")
print("=" * 80)
print("A6 HYPERPARAMETER STABILITY")
print("=" * 80)

print(
    "\nLearning-rate selections:"
)

print(
    selected_df[
        "learning_rate"
    ].value_counts()
)

print(
    "\nL2 selections:"
)

print(
    selected_df[
        "l2"
    ].value_counts()
)

print(
    "\nGate-L1 selections:"
)

print(
    selected_df[
        "gate_l1"
    ].value_counts()
)


# ============================================================
# 43. GATE STABILITY
# ============================================================

print("\n")
print("=" * 80)
print("A6 GROUP-GATE STABILITY")
print("=" * 80)

gate_columns = [
    "gate_alpha_demographic",
    "gate_alpha_physiological",
    "gate_alpha_lifestyle",
]

for column in gate_columns:

    print(
        column,
        ": mean=",
        f"{results_df[column].mean():.6f}",
        "std=",
        f"{results_df[column].std(ddof=1):.6f}",
    )

print(
    "\nMean gate sum:",
    f"{results_df[gate_columns].sum(axis=1).mean():.6f}",
)


# ============================================================
# 44. PARAMETER COUNTS
# ============================================================

print("\n")
print("=" * 80)
print("PARAMETER COUNTS")
print("=" * 80)

print(
    results_df[
        [
            "outer_fold",
            "parameter_count",
        ]
    ].to_string(
        index=False
    )
)

print(
    "\nMean parameter count:",
    results_df[
        "parameter_count"
    ].mean(),
)


# ============================================================
# 45. OUTER VALIDATION COVERAGE
# ============================================================

print("\n")
print("=" * 80)
print("OUTER VALIDATION COVERAGE")
print("=" * 80)

outer_validation_ids = []

for _, (
    _,
    outer_val_idx,
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev,
    ),
    start=1,
):

    outer_validation_ids.extend(
        outer_val_idx.tolist()
    )

unique_validation_ids = set(
    outer_validation_ids
)

expected_ids = set(
    range(len(dev))
)

coverage_pass = (
    len(
        outer_validation_ids
    )
    ==
    len(dev)
    and
    unique_validation_ids
    ==
    expected_ids
)

print(
    "Total validation observations:",
    len(outer_validation_ids),
)

print(
    "Unique validation observations:",
    len(unique_validation_ids),
)

print(
    "Expected development observations:",
    len(dev),
)

print(
    "Each development observation "
    "used exactly once as outer validation:",
    coverage_pass,
)

assert coverage_pass


# ============================================================
# 46. CALIBRATION / TEST PROTECTION
# ============================================================

print("\n")
print("=" * 80)
print("CALIBRATION / LOCKED TEST PROTECTION")
print("=" * 80)

print(
    "Conformal calibration rows:",
    len(cal),
)

print(
    "Locked test rows:",
    len(test),
)

print(
    "Calibration used for training:",
    False,
)

print(
    "Calibration used for "
    "hyperparameter selection:",
    False,
)

print(
    "Calibration used for "
    "outer-fold model selection:",
    False,
)

print(
    "Locked test used during "
    "model development:",
    False,
)

print(
    "Locked test used for "
    "hyperparameter selection:",
    False,
)

print(
    "Locked test used for "
    "early stopping:",
    False,
)


# ============================================================
# 47. SAVE RESULTS
# ============================================================

fold_results_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "outer_fold_results.csv"
    )
)

summary_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "summary.csv"
    )
)

pooled_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "pooled_metrics.csv"
    )
)

hyperparameter_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "hyperparameter_search.csv"
    )
)

selected_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "selected_hyperparameters.csv"
    )
)

protocol_path = (
    TABLES_DIR
    /
    (
        "implementation31_a6_"
        "sparse_grouped_chebkan_"
        "protocol.json"
    )
)

results_df.to_csv(
    fold_results_path,
    index=False,
)

pd.DataFrame(
    summary_rows
).to_csv(
    summary_path,
    index=False,
)

pd.DataFrame(
    [pooled_metrics]
).to_csv(
    pooled_path,
    index=False,
)

pd.DataFrame(
    hyperparameter_results
).to_csv(
    hyperparameter_path,
    index=False,
)

selected_df.to_csv(
    selected_path,
    index=False,
)


# ============================================================
# 48. SAVE PROTOCOL
# ============================================================

protocol = {

    "implementation": "31",

    "ablation": "A6",

    "model":
        "Sparse Clinically-Grouped "
        "Chebyshev-KAN",

    "purpose":
        "Evaluate sparse gated fusion "
        "after clinical grouping",

    "project_root":
        str(PROJECT_ROOT),

    "features":
        FEATURES,

    "target":
        TARGET,

    "clinical_groups":
        CLINICAL_GROUPS,

    "chebyshev_basis":
        "Chebyshev first kind",

    "chebyshev_degree":
        CHEB_K,

    "group_embedding_dimension":
        GROUP_EMBEDDING_DIM,

    "architecture":
        "Three grouped ChebKAN branches "
        "-> 16-dimensional embeddings "
        "-> softmax gated weighted sum "
        "-> Linear(1)",

    "clinical_grouping":
        True,

    "sparse_gates":
        True,

    "gate_function":
        "softmax",

    "gate_regularization":
        "L1 on pre-softmax gate logits",

    "kan_l1_regularization":
        False,

    "adasyn":
        False,

    "conformal_prediction":
        False,

    "normalization":
        "MinMaxScaler [-1, 1]",

    "imputation":
        "Fold-specific "
        "training-data median",

    "outer_cv":
        OUTER_FOLDS,

    "inner_cv":
        INNER_FOLDS,

    "random_state":
        SEED,

    "early_stopping": {

        "internal_validation_fraction":
            0.10,

        "max_epochs":
            MAX_EPOCHS,

        "patience":
            PATIENCE,
    },

    "batch_size":
        BATCH_SIZE,

    "learning_rates":
        LEARNING_RATES,

    "l2_values":
        L2_VALUES,

    "gate_l1_values":
        GATE_L1_VALUES,

    "calibration_rows":
        len(cal),

    "locked_test_rows":
        len(test),

    "calibration_used_for_training":
        False,

    "calibration_used_for_model_selection":
        False,

    "locked_test_used_for_training":
        False,

    "locked_test_used_for_model_selection":
        False,

    "locked_test_used_for_early_stopping":
        False,
}

with open(
    protocol_path,
    "w",
    encoding="utf-8",
) as file:

    json.dump(
        protocol,
        file,
        indent=4,
    )


# ============================================================
# 49. FINAL SUMMARY
# ============================================================

total_time = (
    time.time()
    -
    overall_start
)

print("\n")
print("=" * 80)
print("IMPLEMENTATION 31 — FINAL SUMMARY")
print("=" * 80)

print(
    "Model: A6 Sparse "
    "Clinically-Grouped "
    "Chebyshev-KAN"
)

print(
    "Chebyshev degree:",
    CHEB_K,
)

print(
    "Group embedding dimension:",
    GROUP_EMBEDDING_DIM,
)

print(
    "Mean outer ROC-AUC:",
    f"{results_df['roc_auc'].mean():.6f}",
)

print(
    "Std outer ROC-AUC:",
    f"{results_df['roc_auc'].std(ddof=1):.6f}",
)

print(
    "Pooled outer ROC-AUC:",
    f"{pooled_metrics['roc_auc']:.6f}",
)

print(
    "Pooled outer PR-AUC:",
    f"{pooled_metrics['pr_auc']:.6f}",
)

print(
    "Pooled outer Brier:",
    f"{pooled_metrics['brier']:.6f}",
)

print(
    "Pooled outer ECE:",
    f"{pooled_metrics['ece']:.6f}",
)

print(
    "Clinical grouping: YES"
)

print(
    "Sparse gates: YES"
)

print(
    "Gate function: SOFTMAX"
)

print(
    "Gate L1: YES"
)

print(
    "ADASYN: NO"
)

print(
    "Conformal prediction: NO"
)

print(
    "Calibration protected: PASS"
)

print(
    "Locked test protected: PASS"
)

print(
    "Outer validation coverage: PASS"
)

print(
    "Total execution time:",
    f"{total_time / 60:.2f} minutes",
)

print("\nSaved files:")

print(
    fold_results_path
)

print(
    summary_path
)

print(
    pooled_path
)

print(
    hyperparameter_path
)

print(
    selected_path
)

print(
    protocol_path
)

print("\n")
print("=" * 80)
print(
    "IMPLEMENTATION 31 COMPLETE — STATUS: PASS"
)
print("=" * 80)