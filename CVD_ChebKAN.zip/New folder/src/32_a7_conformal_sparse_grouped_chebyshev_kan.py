# ================================================================
# A7: Sparse Clinically-Grouped Chebyshev-KAN + Conformal Prediction
# ================================================================
#
# Frozen methodology:
#   Development: 49,000
#   Conformal calibration: 7,000
#   Locked test: 14,000
#
# Model:
#   11 features
#   3 clinical groups
#   Chebyshev K=5
#   Group embedding = 16
#   SiLU activation
#   Softmax group gates
#   KAN coefficient L1
#   Group gate L1
#
# Conformal prediction:
#   Separate 7,000-record calibration set
#   No calibration data used for training/model selection
#   Locked 14,000-record test remains untouched
#
# Runtime-conscious A7:
#   Uses the selected A6 hyperparameters directly.
#   No additional nested hyperparameter search is performed.
#
# ================================================================

import os
import json
import time
import random
import warnings

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
)

warnings.filterwarnings("ignore")


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

DEV_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "kaggle_development_cv.csv"
)

CAL_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "kaggle_conformal_calibration.csv"
)

TEST_PATH = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "kaggle_locked_test.csv"
)

RESULTS_TABLES = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

RESULTS_MODELS = os.path.join(
    PROJECT_ROOT,
    "results",
    "models"
)

os.makedirs(RESULTS_TABLES, exist_ok=True)
os.makedirs(RESULTS_MODELS, exist_ok=True)


# ================================================================
# 2. REPRODUCIBILITY
# ================================================================

SEED = 2026

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


# ================================================================
# 3. DEVICE
# ================================================================

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("=" * 80)
print("A7 SPARSE CLINICALLY-GROUPED CHEBYSHEV-KAN")
print("WITH CONFORMAL PREDICTION")
print("=" * 80)

print()
print("Environment:")
print("  Python:", __import__("sys").version.split()[0])
print("  PyTorch:", torch.__version__)
print("  NumPy:", np.__version__)
print("  Pandas:", pd.__version__)
print("  Device:", DEVICE)

if torch.cuda.is_available():
    print("  CUDA:", torch.version.cuda)
    print("  GPU:", torch.cuda.get_device_name(0))


# ================================================================
# 4. FROZEN FEATURES AND GROUPS
# ================================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"

GROUPS = {
    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}

GROUP_NAMES = list(GROUPS.keys())

GROUP_INDICES = {
    name: [FEATURES.index(f) for f in feature_list]
    for name, feature_list in GROUPS.items()
}


# ================================================================
# 5. FROZEN A6 HYPERPARAMETERS
# ================================================================

CHEB_DEGREE = 5
GROUP_EMBEDDING = 16

LEARNING_RATE = 1e-3
L2 = 1e-4
KAN_L1 = 1e-5
GATE_L1 = 1e-4

BATCH_SIZE = 1024
MAX_EPOCHS = 100
PATIENCE = 10

# A7 final model training uses the complete 49,000-record
# development partition after model architecture/hyperparameters
# have already been fixed by the previous A6 development experiment.


# ================================================================
# 6. CONFORMAL SETTINGS
# ================================================================

# Significance level.
#
# alpha = 0.10 corresponds to nominal 90% marginal coverage.
#
# We will also report 95% coverage as a sensitivity analysis.
ALPHA_PRIMARY = 0.10
ALPHA_SECONDARY = 0.05


# ================================================================
# 7. LOAD DATA
# ================================================================

print()
print("Loading data...")

dev = pd.read_csv(DEV_PATH)
cal = pd.read_csv(CAL_PATH)
test = pd.read_csv(TEST_PATH)

print("Development:", dev.shape)
print("Calibration:", cal.shape)
print("Locked test:", test.shape)


# ================================================================
# 8. BASIC DATA VALIDATION
# ================================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test),
]:

    missing_features = [
        f for f in FEATURES
        if f not in df.columns
    ]

    if missing_features:
        raise ValueError(
            f"{name}: missing features: {missing_features}"
        )

    if TARGET not in df.columns:
        raise ValueError(
            f"{name}: target column '{TARGET}' missing."
        )

    if df[TARGET].isna().any():
        raise ValueError(
            f"{name}: missing target values found."
        )


# ================================================================
# 9. ID / PARTITION INTEGRITY
# ================================================================

if "id" in dev.columns and "id" in cal.columns and "id" in test.columns:

    dev_ids = set(dev["id"])
    cal_ids = set(cal["id"])
    test_ids = set(test["id"])

    print()
    print("Partition overlap:")
    print("  Development ∩ Calibration:", len(dev_ids & cal_ids))
    print("  Development ∩ Test:", len(dev_ids & test_ids))
    print("  Calibration ∩ Test:", len(cal_ids & test_ids))

    assert len(dev_ids & cal_ids) == 0
    assert len(dev_ids & test_ids) == 0
    assert len(cal_ids & test_ids) == 0

    print("  Partition disjointness: PASS")


# ================================================================
# 10. TARGET CHECK
# ================================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test),
]:

    unique_target = sorted(df[TARGET].unique().tolist())

    if unique_target != [0, 1]:
        raise ValueError(
            f"{name}: target is not binary: {unique_target}"
        )

    print(
        f"{name} target:",
        df[TARGET].value_counts().sort_index().to_dict()
    )


# ================================================================
# 11. ARCHITECTURE REPORT
# ================================================================

print()
print("=" * 80)
print("A7 ARCHITECTURE")
print("=" * 80)

print("Features:", len(FEATURES))
print("Chebyshev degree:", CHEB_DEGREE)
print("Group embedding:", GROUP_EMBEDDING)
print("KAN coefficient L1: YES")
print("Group gate L1: YES")
print("ADASYN: NO")
print("Conformal prediction: YES")
print("Batch size:", BATCH_SIZE)
print("Maximum epochs:", MAX_EPOCHS)
print("Patience:", PATIENCE)

print()
print("Clinical groups:")

for group_name, group_features in GROUPS.items():
    print(
        f"  {group_name}: {group_features}"
    )

print()
print("Frozen hyperparameters:")
print("  learning rate:", LEARNING_RATE)
print("  L2:", L2)
print("  KAN L1:", KAN_L1)
print("  gate L1:", GATE_L1)


# ================================================================
# 12. CHEBYSHEV BASIS
# ================================================================

def chebyshev_basis(x, degree):
    """
    Compute Chebyshev polynomials of the first kind:

        T0(x) = 1
        T1(x) = x
        Tk(x) = 2*x*T(k-1)(x) - T(k-2)(x)

    Returns:
        [batch, n_features, degree + 1]
    """

    if degree < 0:
        raise ValueError("degree must be >= 0")

    basis = [
        torch.ones_like(x)
    ]

    if degree >= 1:
        basis.append(x)

    for k in range(2, degree + 1):
        basis.append(
            2.0 * x * basis[-1] - basis[-2]
        )

    return torch.stack(
        basis,
        dim=-1
    )


# ================================================================
# 13. CHEBYSHEV KAN LAYER
# ================================================================

class ChebyshevKANLayer(nn.Module):

    def __init__(
        self,
        in_features,
        out_features,
        degree=5
    ):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                degree + 1
            )
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.05
        )

        self.bias = nn.Parameter(
            torch.zeros(out_features)
        )

    def forward(self, x):

        # x:
        # [batch, in_features]

        basis = chebyshev_basis(
            x,
            self.degree
        )

        # basis:
        # [batch, in_features, degree+1]

        output = torch.einsum(
            "bik,oik->bo",
            basis,
            self.coefficients
        )

        output = output + self.bias

        return output

    def l1_penalty(self):

        return torch.sum(
            torch.abs(self.coefficients)
        )


# ================================================================
# 14. GROUP BRANCH
# ================================================================

class GroupChebKANBranch(nn.Module):

    def __init__(
        self,
        input_dim,
        embedding_dim,
        degree
    ):
        super().__init__()

        self.kan = ChebyshevKANLayer(
            in_features=input_dim,
            out_features=embedding_dim,
            degree=degree
        )

        self.activation = nn.SiLU()

    def forward(self, x):

        return self.activation(
            self.kan(x)
        )

    def l1_penalty(self):

        return self.kan.l1_penalty()


# ================================================================
# 15. A7 MODEL
# ================================================================

class A7SparseGroupedChebKAN(nn.Module):

    def __init__(
        self,
        group_indices,
        degree=5,
        embedding_dim=16
    ):
        super().__init__()

        self.group_indices = group_indices

        self.demographic = GroupChebKANBranch(
            input_dim=len(group_indices["demographic"]),
            embedding_dim=embedding_dim,
            degree=degree
        )

        self.physiological = GroupChebKANBranch(
            input_dim=len(
                group_indices[
                    "physiological_anthropometric_metabolic"
                ]
            ),
            embedding_dim=embedding_dim,
            degree=degree
        )

        self.lifestyle = GroupChebKANBranch(
            input_dim=len(
                group_indices["lifestyle"]
            ),
            embedding_dim=embedding_dim,
            degree=degree
        )

        # Learnable group fusion logits.
        self.gate_logits = nn.Parameter(
            torch.zeros(3)
        )

        # Final projection after weighted group fusion.
        self.output_layer = nn.Linear(
            embedding_dim,
            1
        )

    def forward(self, x):

        demographic_x = x[
            :,
            self.group_indices["demographic"]
        ]

        physiological_x = x[
            :,
            self.group_indices[
                "physiological_anthropometric_metabolic"
            ]
        ]

        lifestyle_x = x[
            :,
            self.group_indices["lifestyle"]
        ]

        h_demographic = self.demographic(
            demographic_x
        )

        h_physiological = self.physiological(
            physiological_x
        )

        h_lifestyle = self.lifestyle(
            lifestyle_x
        )

        group_embeddings = torch.stack(
            [
                h_demographic,
                h_physiological,
                h_lifestyle,
            ],
            dim=1
        )

        # Positive normalized fusion weights.
        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        fused = torch.sum(
            group_embeddings *
            gates.view(1, 3, 1),
            dim=1
        )

        logits = self.output_layer(
            fused
        ).squeeze(1)

        return logits

    def kan_l1_penalty(self):

        return (
            self.demographic.l1_penalty()
            + self.physiological.l1_penalty()
            + self.lifestyle.l1_penalty()
        )

    def gate_l1_penalty(self):

        return torch.sum(
            torch.abs(self.gate_logits)
        )

    def get_group_gates(self):

        with torch.no_grad():

            gates = torch.softmax(
                self.gate_logits,
                dim=0
            ).detach().cpu().numpy()

        return {
            "demographic": float(gates[0]),
            "physiological_anthropometric_metabolic":
                float(gates[1]),
            "lifestyle": float(gates[2]),
        }


# ================================================================
# 16. PARAMETER COUNT
# ================================================================

def count_parameters(model):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ================================================================
# 17. PREPROCESSING
# ================================================================

def fit_preprocessor(df):

    imputer = SimpleImputer(
        strategy="median"
    )

    scaler = MinMaxScaler(
        feature_range=(-1, 1)
    )

    x = df[FEATURES].astype(
        np.float32
    )

    x_imp = imputer.fit_transform(x)

    x_scaled = scaler.fit_transform(
        x_imp
    )

    return imputer, scaler, x_scaled.astype(
        np.float32
    )


def transform_with_preprocessor(
    df,
    imputer,
    scaler
):

    x = df[FEATURES].astype(
        np.float32
    )

    x_imp = imputer.transform(x)

    x_scaled = scaler.transform(
        x_imp
    )

    return x_scaled.astype(
        np.float32
    )


# ================================================================
# 18. TRAINING FUNCTION
# ================================================================

def train_model(
    model,
    x_train,
    y_train,
    x_val,
    y_val,
    lr=LEARNING_RATE,
    l2=L2,
    kan_l1=KAN_L1,
    gate_l1=GATE_L1,
    max_epochs=MAX_EPOCHS,
    patience=PATIENCE
):

    model = model.to(DEVICE)

    x_train_t = torch.tensor(
        x_train,
        dtype=torch.float32,
        device=DEVICE
    )

    y_train_t = torch.tensor(
        y_train,
        dtype=torch.float32,
        device=DEVICE
    )

    x_val_t = torch.tensor(
        x_val,
        dtype=torch.float32,
        device=DEVICE
    )

    y_val_t = torch.tensor(
        y_val,
        dtype=torch.float32,
        device=DEVICE
    )

    dataset = TensorDataset(
        x_train_t,
        y_train_t
    )

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=False
    )

    criterion = nn.BCEWithLogitsLoss()

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=lr,
        weight_decay=l2
    )

    best_state = None
    best_val_auc = -np.inf
    best_epoch = 0
    patience_counter = 0

    for epoch in range(1, max_epochs + 1):

        model.train()

        for xb, yb in loader:

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(xb)

            bce = criterion(
                logits,
                yb
            )

            kan_penalty = (
                model.kan_l1_penalty()
            )

            gate_penalty = (
                model.gate_l1_penalty()
            )

            loss = (
                bce
                + kan_l1 * kan_penalty
                + gate_l1 * gate_penalty
            )

            loss.backward()

            optimizer.step()

        # --------------------------------------------------------
        # Validation
        # --------------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                x_val_t
            )

            val_prob = torch.sigmoid(
                val_logits
            ).detach().cpu().numpy()

        try:
            val_auc = roc_auc_score(
                y_val,
                val_prob
            )
        except Exception:
            val_auc = 0.5

        if val_auc > best_val_auc:

            best_val_auc = val_auc
            best_epoch = epoch

            best_state = {
                k: v.detach().cpu().clone()
                for k, v in model.state_dict().items()
            }

            patience_counter = 0

        else:

            patience_counter += 1

        if patience_counter >= patience:
            break

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    return model, best_epoch, best_val_auc


# ================================================================
# 19. PREDICTION FUNCTION
# ================================================================

def predict_probability(
    model,
    x
):

    model.eval()

    x_t = torch.tensor(
        x,
        dtype=torch.float32,
        device=DEVICE
    )

    with torch.no_grad():

        logits = model(
            x_t
        )

        probability = torch.sigmoid(
            logits
        ).detach().cpu().numpy()

    return probability


# ================================================================
# 20. PERFORMANCE METRICS
# ================================================================

def calculate_metrics(
    y_true,
    probability,
    threshold=0.5
):

    prediction = (
        probability >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        prediction,
        labels=[0, 1]
    ).ravel()

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "accuracy": accuracy_score(
            y_true,
            prediction
        ),

        "precision": precision_score(
            y_true,
            prediction,
            zero_division=0
        ),

        "sensitivity": sensitivity,

        "specificity": specificity,

        "f1": f1_score(
            y_true,
            prediction,
            zero_division=0
        ),

        "roc_auc": roc_auc_score(
            y_true,
            probability
        ),

        "pr_auc": average_precision_score(
            y_true,
            probability
        ),

        "brier": brier_score_loss(
            y_true,
            probability
        ),
    }


# ================================================================
# 21. CONFORMAL NONCONFORMITY SCORES
# ================================================================
#
# We use the standard classification nonconformity score:
#
#   score_i = 1 - p(true class | x_i)
#
# For binary classification:
#
#   if y=1:
#       score = 1-p
#
#   if y=0:
#       score = p
#
# The calibration distribution is then used to obtain
# class-conditional quantiles.
#
# We use finite-sample conformal quantiles:
#
#   k = ceil((n_cal + 1) * (1-alpha))
#
# and select the corresponding order statistic using the
# "higher" method.
#
# This avoids using the test set in any calibration calculation.
# ================================================================

def calibration_scores(
    y_cal,
    p_cal
):

    y_cal = np.asarray(
        y_cal
    ).astype(int)

    p_cal = np.asarray(
        p_cal
    )

    score_class_0 = p_cal[
        y_cal == 0
    ]

    score_class_1 = (
        1.0 - p_cal[
            y_cal == 1
        ]
    )

    return (
        score_class_0,
        score_class_1
    )


def conformal_quantile(
    scores,
    alpha
):

    scores = np.asarray(
        scores,
        dtype=np.float64
    )

    n = len(scores)

    if n == 0:
        raise ValueError(
            "No calibration observations available "
            "for one of the classes."
        )

    # Finite-sample conformal index.
    k = int(
        np.ceil(
            (n + 1) * (1.0 - alpha)
        )
    )

    # If k exceeds n, use the largest score.
    k = min(
        max(k, 1),
        n
    )

    sorted_scores = np.sort(
        scores
    )

    return float(
        sorted_scores[k - 1]
    )


def fit_conformal_classifier(
    y_cal,
    p_cal,
    alpha
):

    score_0, score_1 = calibration_scores(
        y_cal,
        p_cal
    )

    q0 = conformal_quantile(
        score_0,
        alpha
    )

    q1 = conformal_quantile(
        score_1,
        alpha
    )

    return {
        "alpha": float(alpha),
        "q0": float(q0),
        "q1": float(q1),
        "n_class0": int(len(score_0)),
        "n_class1": int(len(score_1)),
    }


# ================================================================
# 22. GENERATE CONFORMAL PREDICTION SETS
# ================================================================

def generate_prediction_sets(
    probabilities,
    q0,
    q1
):

    probabilities = np.asarray(
        probabilities,
        dtype=np.float64
    )

    prediction_sets = []

    for p in probabilities:

        # Nonconformity for candidate class 0:
        # 1 - P(Y=0|x) = p
        score_if_0 = p

        # Nonconformity for candidate class 1:
        # 1 - P(Y=1|x) = 1-p
        score_if_1 = 1.0 - p

        include_0 = (
            score_if_0 <= q0
        )

        include_1 = (
            score_if_1 <= q1
        )

        if include_0 and include_1:
            pred_set = (0, 1)

        elif include_0:
            pred_set = (0,)

        elif include_1:
            pred_set = (1,)

        else:
            pred_set = tuple()

        prediction_sets.append(
            pred_set
        )

    return prediction_sets


# ================================================================
# 23. CONFORMAL METRICS
# ================================================================

def evaluate_prediction_sets(
    y_true,
    prediction_sets
):

    y_true = np.asarray(
        y_true
    ).astype(int)

    n = len(y_true)

    covered = 0
    singleton = 0
    ambiguous = 0
    empty = 0

    set_sizes = []

    for y, pred_set in zip(
        y_true,
        prediction_sets
    ):

        set_size = len(
            pred_set
        )

        set_sizes.append(
            set_size
        )

        if y in pred_set:
            covered += 1

        if set_size == 1:
            singleton += 1

        elif set_size == 2:
            ambiguous += 1

        elif set_size == 0:
            empty += 1

    return {
        "coverage": covered / n,
        "average_set_size": float(
            np.mean(set_sizes)
        ),
        "singleton_rate": singleton / n,
        "ambiguous_rate": ambiguous / n,
        "empty_set_rate": empty / n,
        "n": n,
    }


# ================================================================
# 24. SAVE PREDICTION SETS
# ================================================================

def prediction_set_label(
    pred_set
):

    if pred_set == (0,):
        return "{0}"

    if pred_set == (1,):
        return "{1}"

    if pred_set == (0, 1):
        return "{0,1}"

    return "{}"


# ================================================================
# 25. FINAL MODEL TRAINING
# ================================================================
#
# IMPORTANT:
#
# We now train one final A7 model using all 49,000 Development
# observations.
#
# The 7,000 calibration observations are NOT used here.
#
# We use an internal 10% training-validation split only for
# early stopping. This split is created inside Development.
#
# It does not use Calibration or Locked Test.
# ================================================================

print()
print("=" * 80)
print("FINAL A7 MODEL TRAINING")
print("=" * 80)

from sklearn.model_selection import train_test_split

dev_train, dev_internal_val = train_test_split(
    dev,
    test_size=0.10,
    stratify=dev[TARGET],
    random_state=SEED
)

print(
    "Development training:",
    len(dev_train)
)

print(
    "Internal early-stopping validation:",
    len(dev_internal_val)
)

# ---------------------------------------------------------------
# Fit preprocessing ONLY on final development training data.
# ---------------------------------------------------------------

imputer_final, scaler_final, x_dev_train = (
    fit_preprocessor(
        dev_train
    )
)

x_dev_val = transform_with_preprocessor(
    dev_internal_val,
    imputer_final,
    scaler_final
)

y_dev_train = dev_train[
    TARGET
].astype(int).to_numpy()

y_dev_val = dev_internal_val[
    TARGET
].astype(int).to_numpy()


# ---------------------------------------------------------------
# Build model
# ---------------------------------------------------------------

final_model = A7SparseGroupedChebKAN(
    group_indices=GROUP_INDICES,
    degree=CHEB_DEGREE,
    embedding_dim=GROUP_EMBEDDING
)

print(
    "Final model parameters:",
    count_parameters(final_model)
)

start_time = time.time()

final_model, final_best_epoch, final_internal_auc = train_model(
    model=final_model,
    x_train=x_dev_train,
    y_train=y_dev_train,
    x_val=x_dev_val,
    y_val=y_dev_val,
    lr=LEARNING_RATE,
    l2=L2,
    kan_l1=KAN_L1,
    gate_l1=GATE_L1,
    max_epochs=MAX_EPOCHS,
    patience=PATIENCE
)

training_time = (
    time.time() - start_time
)

print()
print("Final model training complete.")
print(
    "Best epoch:",
    final_best_epoch
)

print(
    "Internal validation ROC-AUC:",
    f"{final_internal_auc:.6f}"
)

print(
    "Training time:",
    f"{training_time / 60:.2f} minutes"
)


# ================================================================
# 26. SAVE FINAL MODEL
# ================================================================

final_model_path = os.path.join(
    RESULTS_MODELS,
    "implementation32_a7_final_model.pt"
)

torch.save(
    {
        "model_state_dict":
            final_model.state_dict(),

        "features":
            FEATURES,

        "groups":
            GROUPS,

        "group_indices":
            GROUP_INDICES,

        "cheb_degree":
            CHEB_DEGREE,

        "embedding_dim":
            GROUP_EMBEDDING,

        "learning_rate":
            LEARNING_RATE,

        "l2":
            L2,

        "kan_l1":
            KAN_L1,

        "gate_l1":
            GATE_L1,

        "best_epoch":
            final_best_epoch,

        "seed":
            SEED,
    },
    final_model_path
)

print(
    "Final model saved:",
    final_model_path
)


# ================================================================
# 27. FINAL GROUP GATES
# ================================================================

final_gates = (
    final_model.get_group_gates()
)

print()
print("Final group gates:")

for name, value in final_gates.items():

    print(
        f"  {name}: {value:.6f}"
    )


# ================================================================
# 28. PREPARE CALIBRATION DATA
# ================================================================
#
# IMPORTANT:
#
# The preprocessing objects are already fitted on Development
# training data.
#
# Calibration data is transformed using those SAME objects.
#
# Calibration data is NOT used to refit imputation/scaling.
# ================================================================

x_cal = transform_with_preprocessor(
    cal,
    imputer_final,
    scaler_final
)

y_cal = cal[
    TARGET
].astype(int).to_numpy()


# ================================================================
# 29. CALIBRATION PREDICTIONS
# ================================================================

print()
print("=" * 80)
print("CONFORMAL CALIBRATION")
print("=" * 80)

p_cal = predict_probability(
    final_model,
    x_cal
)

calibration_probability_metrics = calculate_metrics(
    y_cal,
    p_cal
)

print(
    "Calibration ROC-AUC:",
    f"{calibration_probability_metrics['roc_auc']:.6f}"
)

print(
    "Calibration PR-AUC:",
    f"{calibration_probability_metrics['pr_auc']:.6f}"
)

print(
    "Calibration Brier:",
    f"{calibration_probability_metrics['brier']:.6f}"
)


# ================================================================
# 30. FIT PRIMARY 90% CONFORMAL PREDICTOR
# ================================================================

conformal_primary = fit_conformal_classifier(
    y_cal=y_cal,
    p_cal=p_cal,
    alpha=ALPHA_PRIMARY
)

print()
print("Primary conformal configuration:")
print(
    "  Nominal coverage:",
    f"{(1 - ALPHA_PRIMARY) * 100:.1f}%"
)

print(
    "  alpha:",
    conformal_primary["alpha"]
)

print(
    "  q0:",
    f"{conformal_primary['q0']:.6f}"
)

print(
    "  q1:",
    f"{conformal_primary['q1']:.6f}"
)

print(
    "  Calibration class 0:",
    conformal_primary["n_class0"]
)

print(
    "  Calibration class 1:",
    conformal_primary["n_class1"]
)


# ================================================================
# 31. FIT SECONDARY 95% CONFORMAL PREDICTOR
# ================================================================

conformal_secondary = fit_conformal_classifier(
    y_cal=y_cal,
    p_cal=p_cal,
    alpha=ALPHA_SECONDARY
)

print()
print("Secondary conformal configuration:")
print(
    "  Nominal coverage:",
    f"{(1 - ALPHA_SECONDARY) * 100:.1f}%"
)

print(
    "  alpha:",
    conformal_secondary["alpha"]
)

print(
    "  q0:",
    f"{conformal_secondary['q0']:.6f}"
)

print(
    "  q1:",
    f"{conformal_secondary['q1']:.6f}"
)


# ================================================================
# 32. PREPARE LOCKED TEST
# ================================================================

print()
print("=" * 80)
print("LOCKED TEST EVALUATION")
print("=" * 80)

x_test = transform_with_preprocessor(
    test,
    imputer_final,
    scaler_final
)

y_test = test[
    TARGET
].astype(int).to_numpy()


# ================================================================
# 33. TEST PROBABILITY PREDICTIONS
# ================================================================

p_test = predict_probability(
    final_model,
    x_test
)

test_probability_metrics = calculate_metrics(
    y_test,
    p_test
)

print()
print("Locked-test probabilistic metrics:")

for key, value in test_probability_metrics.items():

    print(
        f"  {key}: {value:.6f}"
    )


# ================================================================
# 34. PRIMARY 90% CONFORMAL PREDICTION SETS
# ================================================================

prediction_sets_90 = generate_prediction_sets(
    probabilities=p_test,
    q0=conformal_primary["q0"],
    q1=conformal_primary["q1"]
)

conformal_metrics_90 = evaluate_prediction_sets(
    y_test,
    prediction_sets_90
)

print()
print("=" * 80)
print("90% CONFORMAL TEST RESULTS")
print("=" * 80)

print(
    "Nominal coverage:",
    f"{(1 - ALPHA_PRIMARY) * 100:.1f}%"
)

print(
    "Observed coverage:",
    f"{conformal_metrics_90['coverage']:.6f}"
)

print(
    "Average prediction-set size:",
    f"{conformal_metrics_90['average_set_size']:.6f}"
)

print(
    "Singleton rate:",
    f"{conformal_metrics_90['singleton_rate']:.6f}"
)

print(
    "Ambiguous-set rate:",
    f"{conformal_metrics_90['ambiguous_rate']:.6f}"
)

print(
    "Empty-set rate:",
    f"{conformal_metrics_90['empty_set_rate']:.6f}"
)


# ================================================================
# 35. SECONDARY 95% CONFORMAL PREDICTION SETS
# ================================================================

prediction_sets_95 = generate_prediction_sets(
    probabilities=p_test,
    q0=conformal_secondary["q0"],
    q1=conformal_secondary["q1"]
)

conformal_metrics_95 = evaluate_prediction_sets(
    y_test,
    prediction_sets_95
)

print()
print("=" * 80)
print("95% CONFORMAL TEST RESULTS")
print("=" * 80)

print(
    "Nominal coverage:",
    f"{(1 - ALPHA_SECONDARY) * 100:.1f}%"
)

print(
    "Observed coverage:",
    f"{conformal_metrics_95['coverage']:.6f}"
)

print(
    "Average prediction-set size:",
    f"{conformal_metrics_95['average_set_size']:.6f}"
)

print(
    "Singleton rate:",
    f"{conformal_metrics_95['singleton_rate']:.6f}"
)

print(
    "Ambiguous-set rate:",
    f"{conformal_metrics_95['ambiguous_rate']:.6f}"
)

print(
    "Empty-set rate:",
    f"{conformal_metrics_95['empty_set_rate']:.6f}"
)


# ================================================================
# 36. SAVE TEST PREDICTIONS
# ================================================================

prediction_output = pd.DataFrame()

if "id" in test.columns:
    prediction_output["id"] = test["id"].to_numpy()

prediction_output["true_label"] = y_test

prediction_output["probability"] = p_test

prediction_output["binary_prediction"] = (
    p_test >= 0.5
).astype(int)

prediction_output["conformal_90_set"] = [
    prediction_set_label(x)
    for x in prediction_sets_90
]

prediction_output["conformal_95_set"] = [
    prediction_set_label(x)
    for x in prediction_sets_95
]

prediction_output["covered_90"] = [
    int(y in pred_set)
    for y, pred_set in zip(
        y_test,
        prediction_sets_90
    )
]

prediction_output["covered_95"] = [
    int(y in pred_set)
    for y, pred_set in zip(
        y_test,
        prediction_sets_95
    )
]

prediction_output_path = os.path.join(
    RESULTS_TABLES,
    "implementation32_a7_locked_test_predictions.csv"
)

prediction_output.to_csv(
    prediction_output_path,
    index=False
)

print()
print(
    "Test predictions saved:",
    prediction_output_path
)


# ================================================================
# 37. SAVE SUMMARY
# ================================================================

summary = {
    "model": "A7 Sparse Clinically-Grouped Chebyshev-KAN + Conformal Prediction",

    "features": FEATURES,

    "groups": GROUPS,

    "chebyshev_degree": CHEB_DEGREE,

    "group_embedding": GROUP_EMBEDDING,

    "parameters": count_parameters(
        final_model
    ),

    "learning_rate": LEARNING_RATE,

    "l2": L2,

    "kan_l1": KAN_L1,

    "gate_l1": GATE_L1,

    "batch_size": BATCH_SIZE,

    "maximum_epochs": MAX_EPOCHS,

    "patience": PATIENCE,

    "development_n": int(len(dev)),

    "calibration_n": int(len(cal)),

    "locked_test_n": int(len(test)),

    "internal_best_epoch": int(
        final_best_epoch
    ),

    "internal_validation_auc": float(
        final_internal_auc
    ),

    "final_group_gates": final_gates,

    "test_probability_metrics":
        test_probability_metrics,

    "conformal_90": {
        "alpha": ALPHA_PRIMARY,
        "nominal_coverage":
            1 - ALPHA_PRIMARY,
        "q0":
            conformal_primary["q0"],
        "q1":
            conformal_primary["q1"],
        **conformal_metrics_90,
    },

    "conformal_95": {
        "alpha": ALPHA_SECONDARY,
        "nominal_coverage":
            1 - ALPHA_SECONDARY,
        "q0":
            conformal_secondary["q0"],
        "q1":
            conformal_secondary["q1"],
        **conformal_metrics_95,
    },

    "calibration_protected": True,

    "locked_test_protected_until_final_evaluation": True,

    "adasyn_used": False,

    "seed": SEED,

    "protocol_note":
        "A7 uses the corrected A6 architecture with "
        "KAN coefficient L1 and group-gate L1. "
        "The A6-selected hyperparameters were fixed "
        "before conformal calibration. "
        "The 7,000-record calibration set was not used "
        "for model training or hyperparameter selection.",
}

summary_path = os.path.join(
    RESULTS_TABLES,
    "implementation32_a7_summary.json"
)

with open(
    summary_path,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        summary,
        f,
        indent=2
    )


# ================================================================
# 38. CONFORMAL SUMMARY CSV
# ================================================================

conformal_summary = pd.DataFrame(
    [
        {
            "nominal_coverage": 0.90,
            "alpha": ALPHA_PRIMARY,
            "q0": conformal_primary["q0"],
            "q1": conformal_primary["q1"],
            "observed_coverage":
                conformal_metrics_90["coverage"],
            "average_set_size":
                conformal_metrics_90[
                    "average_set_size"
                ],
            "singleton_rate":
                conformal_metrics_90[
                    "singleton_rate"
                ],
            "ambiguous_rate":
                conformal_metrics_90[
                    "ambiguous_rate"
                ],
            "empty_set_rate":
                conformal_metrics_90[
                    "empty_set_rate"
                ],
        },

        {
            "nominal_coverage": 0.95,
            "alpha": ALPHA_SECONDARY,
            "q0": conformal_secondary["q0"],
            "q1": conformal_secondary["q1"],
            "observed_coverage":
                conformal_metrics_95["coverage"],
            "average_set_size":
                conformal_metrics_95[
                    "average_set_size"
                ],
            "singleton_rate":
                conformal_metrics_95[
                    "singleton_rate"
                ],
            "ambiguous_rate":
                conformal_metrics_95[
                    "ambiguous_rate"
                ],
            "empty_set_rate":
                conformal_metrics_95[
                    "empty_set_rate"
                ],
        },
    ]
)

conformal_summary_path = os.path.join(
    RESULTS_TABLES,
    "implementation32_a7_conformal_summary.csv"
)

conformal_summary.to_csv(
    conformal_summary_path,
    index=False
)


# ================================================================
# 39. SAVE PREPROCESSING PARAMETERS
# ================================================================
#
# Save medians and scaling parameters so the final model is
# reproducible.
# ================================================================

preprocessing_summary = {
    "features": FEATURES,

    "imputation_strategy":
        "median",

    "imputation_statistics":
        imputer_final.statistics_.tolist(),

    "scaler_feature_min":
        scaler_final.data_min_.tolist(),

    "scaler_feature_max":
        scaler_final.data_max_.tolist(),

    "scaler_scale":
        scaler_final.scale_.tolist(),

    "scaler_min":
        scaler_final.min_.tolist(),

    "fit_source":
        "development_training_subset_only",

    "calibration_refit":
        False,

    "test_refit":
        False,
}

preprocessing_path = os.path.join(
    RESULTS_TABLES,
    "implementation32_a7_preprocessing.json"
)

with open(
    preprocessing_path,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        preprocessing_summary,
        f,
        indent=2
    )


# ================================================================
# 40. FINAL PROTECTION CHECKS
# ================================================================

print()
print("=" * 80)
print("A7 PROTECTION CHECKS")
print("=" * 80)

print(
    "Development size:",
    len(dev)
)

print(
    "Calibration size:",
    len(cal)
)

print(
    "Locked test size:",
    len(test)
)

if "id" in dev.columns:

    dev_ids = set(dev["id"])
    cal_ids = set(cal["id"])
    test_ids = set(test["id"])

    overlap_count = (
        len(dev_ids & cal_ids)
        + len(dev_ids & test_ids)
        + len(cal_ids & test_ids)
    )

    print(
        "Cross-partition ID overlap:",
        overlap_count
    )

    assert overlap_count == 0

print(
    "Calibration used for model training: NO"
)

print(
    "Calibration used for hyperparameter selection: NO"
)

print(
    "Locked test used for model training: NO"
)

print(
    "Locked test used for calibration: NO"
)

print(
    "ADASYN used: NO"
)

print(
    "Protection status: PASS"
)


# ================================================================
# 41. FINAL SUMMARY
# ================================================================

print()
print("=" * 80)
print("A7 FINAL SUMMARY")
print("=" * 80)

print(
    "Model: Sparse Clinically-Grouped "
    "Chebyshev-KAN + Conformal Prediction"
)

print(
    "Mean/outer CV source: corrected A6-selected "
    "architecture and hyperparameters"
)

print(
    "Final locked-test ROC-AUC:",
    f"{test_probability_metrics['roc_auc']:.6f}"
)

print(
    "Final locked-test PR-AUC:",
    f"{test_probability_metrics['pr_auc']:.6f}"
)

print(
    "Final locked-test Brier:",
    f"{test_probability_metrics['brier']:.6f}"
)

print()
print(
    "90% nominal conformal coverage:",
    f"{conformal_metrics_90['coverage']:.6f}"
)

print(
    "90% average prediction-set size:",
    f"{conformal_metrics_90['average_set_size']:.6f}"
)

print(
    "90% singleton rate:",
    f"{conformal_metrics_90['singleton_rate']:.6f}"
)

print(
    "90% ambiguous-set rate:",
    f"{conformal_metrics_90['ambiguous_rate']:.6f}"
)

print()
print(
    "95% nominal conformal coverage:",
    f"{conformal_metrics_95['coverage']:.6f}"
)

print(
    "95% average prediction-set size:",
    f"{conformal_metrics_95['average_set_size']:.6f}"
)

print(
    "95% singleton rate:",
    f"{conformal_metrics_95['singleton_rate']:.6f}"
)

print(
    "95% ambiguous-set rate:",
    f"{conformal_metrics_95['ambiguous_rate']:.6f}"
)

print()
print(
    "Final model:",
    final_model_path
)

print(
    "Summary:",
    summary_path
)

print(
    "Conformal summary:",
    conformal_summary_path
)

print(
    "Preprocessing:",
    preprocessing_path
)

print(
    "Test predictions:",
    prediction_output_path
)

print()
print("=" * 80)
print("A7 COMPLETE")
print("=" * 80)