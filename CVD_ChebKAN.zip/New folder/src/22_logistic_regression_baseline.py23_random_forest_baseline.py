# ============================================================
# IMPLEMENTATION 23
# RANDOM FOREST BASELINE
# ============================================================
# Project: CVD_CGS-ChebKAN
#
# Purpose:
#   Train and evaluate a Random Forest baseline using the
#   frozen nested-CV protocol.
#
# Data roles:
#   Development = model development + nested CV
#   Calibration = PROTECTED; not used here
#   Locked Test = PROTECTED; not used here
#
# Primary pipeline:
#   - All 11 Kaggle predictors
#   - Fold-specific median imputation
#   - No ADASYN
#   - Nested 5-fold outer / 4-fold inner CV
#   - Hyperparameter selection inside inner CV only
#
# Random Forest hyperparameters:
#   n_estimators
#   max_depth
#   min_samples_split
#   min_samples_leaf
#   max_features
#
# Metrics:
#   Accuracy
#   Precision
#   Sensitivity
#   Specificity
#   F1
#   ROC-AUC
#   PR-AUC
#   Brier score
#   ECE
#
# Random seed:
#   2026
# ============================================================

import os
import json
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix
)
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

DATA_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
RESULTS_DIR = os.path.join(PROJECT_ROOT, "results", "tables")

DEV_FILE = os.path.join(
    DATA_DIR,
    "kaggle_development_cv.csv"
)

CAL_FILE = os.path.join(
    DATA_DIR,
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = os.path.join(
    DATA_DIR,
    "kaggle_locked_test.csv"
)

SEED = 2026

N_OUTER = 5
N_INNER = 4

os.makedirs(RESULTS_DIR, exist_ok=True)

# ============================================================
# PREDICTORS
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active"
]

TARGET = "cardio"

# ============================================================
# RANDOM FOREST HYPERPARAMETER GRID
# ============================================================

PARAM_GRID = {
    "model__n_estimators": [300, 500],
    "model__max_depth": [None, 10, 20],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2],
    "model__max_features": ["sqrt", "log2"]
}

# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def print_header(title):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def calculate_ece(y_true, probabilities, n_bins=10):
    """
    Expected Calibration Error using equal-width probability bins.
    """

    y_true = np.asarray(y_true)
    probabilities = np.asarray(probabilities)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)

    ece = 0.0

    for i in range(n_bins):

        if i == n_bins - 1:
            mask = (
                (probabilities >= bin_edges[i]) &
                (probabilities <= bin_edges[i + 1])
            )
        else:
            mask = (
                (probabilities >= bin_edges[i]) &
                (probabilities < bin_edges[i + 1])
            )

        if np.sum(mask) == 0:
            continue

        bin_accuracy = np.mean(y_true[mask])
        bin_confidence = np.mean(probabilities[mask])

        bin_weight = np.mean(mask)

        ece += bin_weight * abs(
            bin_accuracy - bin_confidence
        )

    return float(ece)


def calculate_metrics(y_true, probabilities, threshold=0.5):

    predictions = (
        probabilities >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1]
    ).ravel()

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else np.nan
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else np.nan
    )

    metrics = {
        "accuracy": accuracy_score(
            y_true,
            predictions
        ),

        "precision": precision_score(
            y_true,
            predictions,
            zero_division=0
        ),

        "sensitivity": sensitivity,

        "specificity": specificity,

        "f1": f1_score(
            y_true,
            predictions,
            zero_division=0
        ),

        "roc_auc": roc_auc_score(
            y_true,
            probabilities
        ),

        "pr_auc": average_precision_score(
            y_true,
            probabilities
        ),

        "brier": brier_score_loss(
            y_true,
            probabilities
        ),

        "ece": calculate_ece(
            y_true,
            probabilities
        )
    }

    return metrics


# ============================================================
# ENVIRONMENT
# ============================================================

print_header("IMPLEMENTATION 23: RANDOM FOREST BASELINE")

print(f"Project root: {PROJECT_ROOT}")
print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

print("\nPython environment:")
print(f"NumPy:  {np.__version__}")
print(f"Pandas: {pd.__version__}")

# ============================================================
# CHECK FILES
# ============================================================

print_header("1. FILE VALIDATION")

required_files = [
    DEV_FILE,
    CAL_FILE,
    TEST_FILE
]

for path in required_files:

    exists = os.path.exists(path)

    print(
        f"{os.path.basename(path)}: "
        f"{'EXISTS' if exists else 'MISSING'}"
    )

    if not exists:
        raise FileNotFoundError(
            f"Required file not found: {path}"
        )

print("All required files exist.")

# ============================================================
# LOAD DATA
# ============================================================

print_header("2. LOAD DATA")

dev = pd.read_csv(DEV_FILE)
cal = pd.read_csv(CAL_FILE)
test = pd.read_csv(TEST_FILE)

print(f"Development: {dev.shape}")
print(f"Calibration: {cal.shape}")
print(f"Locked test: {test.shape}")

# ============================================================
# BASIC DATA VALIDATION
# ============================================================

print_header("3. DATA VALIDATION")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    missing_features = [
        col for col in FEATURES
        if col not in df.columns
    ]

    if missing_features:
        raise ValueError(
            f"{name} missing features: "
            f"{missing_features}"
        )

    if TARGET not in df.columns:
        raise ValueError(
            f"{name} missing target column."
        )

    unique_target = sorted(
        df[TARGET].dropna().unique().tolist()
    )

    print(
        f"{name}: target values = "
        f"{unique_target}"
    )

    if unique_target != [0, 1]:
        raise ValueError(
            f"{name} target is not binary."
        )

    if df[TARGET].isna().any():
        raise ValueError(
            f"{name} contains missing target values."
        )

print("Target validation PASS.")

# ============================================================
# PARTITION SIZE CHECK
# ============================================================

print_header("4. PARTITION VALIDATION")

expected_sizes = {
    "Development": 49000,
    "Calibration": 7000,
    "Locked Test": 14000
}

actual_sizes = {
    "Development": len(dev),
    "Calibration": len(cal),
    "Locked Test": len(test)
}

for name in expected_sizes:

    print(
        f"{name}: "
        f"{actual_sizes[name]} "
        f"(expected {expected_sizes[name]})"
    )

    if actual_sizes[name] != expected_sizes[name]:
        raise ValueError(
            f"{name} size mismatch."
        )

print("Partition sizes PASS.")

# ============================================================
# TARGET DISTRIBUTION
# ============================================================

print_header("5. TARGET DISTRIBUTION")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    counts = df[TARGET].value_counts().sort_index()

    print(
        f"{name}: "
        f"class 0 = {counts.get(0, 0)}, "
        f"class 1 = {counts.get(1, 0)}"
    )

# ============================================================
# ID DISJOINTNESS
# ============================================================

print_header("6. PARTITION DISJOINTNESS")

if "id" not in dev.columns:
    raise ValueError("ID column missing from Development.")

if "id" not in cal.columns:
    raise ValueError("ID column missing from Calibration.")

if "id" not in test.columns:
    raise ValueError("ID column missing from Locked Test.")

dev_ids = set(dev["id"])
cal_ids = set(cal["id"])
test_ids = set(test["id"])

overlap_dev_cal = dev_ids.intersection(cal_ids)
overlap_dev_test = dev_ids.intersection(test_ids)
overlap_cal_test = cal_ids.intersection(test_ids)

print(
    f"Development ∩ Calibration: "
    f"{len(overlap_dev_cal)}"
)

print(
    f"Development ∩ Locked Test: "
    f"{len(overlap_dev_test)}"
)

print(
    f"Calibration ∩ Locked Test: "
    f"{len(overlap_cal_test)}"
)

if (
    len(overlap_dev_cal) > 0 or
    len(overlap_dev_test) > 0 or
    len(overlap_cal_test) > 0
):
    raise ValueError(
        "Partition ID overlap detected."
    )

print("Partition disjointness PASS.")

# ============================================================
# DATA MATRICES
# ============================================================

X_dev = dev[FEATURES].copy()
y_dev = dev[TARGET].astype(int).copy()

X_cal = cal[FEATURES].copy()
y_cal = cal[TARGET].astype(int).copy()

X_test = test[FEATURES].copy()
y_test = test[TARGET].astype(int).copy()

# ============================================================
# PROTECTED DATA ASSERTIONS
# ============================================================

print_header("7. PROTECTED DATA ASSERTIONS")

print(
    "Calibration rows loaded but NOT used "
    "for model selection."
)

print(
    "Locked test rows loaded but NOT used "
    "for model selection or performance evaluation."
)

print("Calibration/test protection PASS.")

# ============================================================
# PIPELINE
# ============================================================

print_header("8. RANDOM FOREST PIPELINE")

print("Primary preprocessing:")
print("  - Median imputation")
print("  - Imputation fitted inside each CV training fold")
print("  - No global imputation")
print("  - No scaling required for Random Forest")
print("  - No ADASYN")

pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="median"
            )
        ),

        (
            "model",
            RandomForestClassifier(
                random_state=SEED,
                n_jobs=-1,
                class_weight=None
            )
        )
    ]
)

# ============================================================
# NESTED CV
# ============================================================

print_header("9. NESTED CROSS-VALIDATION")

outer_cv = StratifiedKFold(
    n_splits=N_OUTER,
    shuffle=True,
    random_state=SEED
)

inner_cv = StratifiedKFold(
    n_splits=N_INNER,
    shuffle=True,
    random_state=SEED
)

print(
    f"Outer folds: {N_OUTER}"
)

print(
    f"Inner folds: {N_INNER}"
)

print(
    "Random state:",
    SEED
)

print(
    "Calibration and locked test are excluded."
)

# ============================================================
# OUTER CV
# ============================================================

outer_results = []
outer_predictions = []
selected_hyperparameters = []

for fold_number, (train_idx, val_idx) in enumerate(
    outer_cv.split(X_dev, y_dev),
    start=1
):

    print_header(
        f"OUTER FOLD {fold_number}/{N_OUTER}"
    )

    X_train = X_dev.iloc[train_idx].copy()
    y_train = y_dev.iloc[train_idx].copy()

    X_val = X_dev.iloc[val_idx].copy()
    y_val = y_dev.iloc[val_idx].copy()

    print(
        f"Training rows:   {len(X_train)}"
    )

    print(
        f"Validation rows: {len(X_val)}"
    )

    print(
        f"Training class distribution: "
        f"{y_train.value_counts().sort_index().to_dict()}"
    )

    print(
        f"Validation class distribution: "
        f"{y_val.value_counts().sort_index().to_dict()}"
    )

    # --------------------------------------------------------
    # INNER CV HYPERPARAMETER SELECTION
    # --------------------------------------------------------

    print("\nRunning inner CV hyperparameter search...")

    grid_search = GridSearchCV(
        estimator=pipeline,
        param_grid=PARAM_GRID,
        scoring="roc_auc",
        cv=inner_cv,
        n_jobs=-1,
        refit=True,
        return_train_score=False
    )

    grid_search.fit(
        X_train,
        y_train
    )

    best_params = grid_search.best_params_
    best_inner_auc = grid_search.best_score_

    print(
        "\nBest inner-CV ROC-AUC:",
        f"{best_inner_auc:.6f}"
    )

    print("Selected hyperparameters:")

    for key, value in best_params.items():
        print(
            f"  {key}: {value}"
        )

    # --------------------------------------------------------
    # OUTER VALIDATION
    # --------------------------------------------------------

    best_model = grid_search.best_estimator_

    probabilities = best_model.predict_proba(
        X_val
    )[:, 1]

    metrics = calculate_metrics(
        y_val.to_numpy(),
        probabilities
    )

    print("\nOuter validation metrics:")

    for key, value in metrics.items():

        print(
            f"  {key}: {value:.6f}"
        )

    # --------------------------------------------------------
    # SAVE RESULTS
    # --------------------------------------------------------

    result_row = {
        "fold": fold_number,
        "n_train": len(X_train),
        "n_validation": len(X_val),
        "best_inner_roc_auc": best_inner_auc,
        **metrics
    }

    for key, value in best_params.items():

        clean_key = key.replace(
            "model__",
            ""
        )

        result_row[
            f"selected_{clean_key}"
        ] = value

    outer_results.append(
        result_row
    )

    selected_hyperparameters.append(
        {
            "fold": fold_number,
            "best_inner_roc_auc": best_inner_auc,
            **{
                key.replace(
                    "model__",
                    "selected_"
                ): value
                for key, value in best_params.items()
            }
        }
    )

    validation_ids = dev.iloc[
        val_idx
    ]["id"].to_numpy()

    fold_predictions = pd.DataFrame({
        "fold": fold_number,
        "id": validation_ids,
        "y_true": y_val.to_numpy(),
        "probability": probabilities,
        "prediction": (
            probabilities >= 0.5
        ).astype(int)
    })

    outer_predictions.append(
        fold_predictions
    )

# ============================================================
# OUTER RESULTS DATAFRAME
# ============================================================

outer_results_df = pd.DataFrame(
    outer_results
)

outer_predictions_df = pd.concat(
    outer_predictions,
    ignore_index=True
)

selected_params_df = pd.DataFrame(
    selected_hyperparameters
)

# ============================================================
# AGGREGATE RESULTS
# ============================================================

print_header(
    "10. AGGREGATE OUTER-CV RESULTS"
)

metric_columns = [
    "accuracy",
    "precision",
    "sensitivity",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier",
    "ece"
]

aggregate_rows = []

for metric in metric_columns:

    mean_value = (
        outer_results_df[metric]
        .mean()
    )

    std_value = (
        outer_results_df[metric]
        .std(ddof=1)
    )

    aggregate_rows.append({
        "metric": metric,
        "mean": mean_value,
        "std": std_value,
        "mean_plus_minus_std":
            f"{mean_value:.6f} ± {std_value:.6f}"
    })

    print(
        f"{metric:15s}: "
        f"{mean_value:.6f} ± "
        f"{std_value:.6f}"
    )

aggregate_df = pd.DataFrame(
    aggregate_rows
)

# ============================================================
# POOLED OUTER-CV PERFORMANCE
# ============================================================

print_header(
    "11. POOLED OUTER-CV PERFORMANCE"
)

pooled_metrics = calculate_metrics(
    outer_predictions_df["y_true"].to_numpy(),
    outer_predictions_df["probability"].to_numpy()
)

for key, value in pooled_metrics.items():

    print(
        f"{key:15s}: {value:.6f}"
    )

pooled_df = pd.DataFrame([
    pooled_metrics
])

# ============================================================
# OUTER CV COVERAGE CHECK
# ============================================================

print_header(
    "12. OUTER-CV VALIDATION COVERAGE"
)

prediction_ids = outer_predictions_df["id"]

unique_prediction_ids = (
    prediction_ids.nunique()
)

expected_prediction_ids = len(dev)

print(
    f"Unique Development IDs evaluated: "
    f"{unique_prediction_ids}"
)

print(
    f"Expected Development IDs: "
    f"{expected_prediction_ids}"
)

if unique_prediction_ids != expected_prediction_ids:
    raise RuntimeError(
        "Outer CV does not cover every "
        "Development record exactly once."
    )

prediction_counts = (
    outer_predictions_df["id"]
    .value_counts()
)

if not np.all(
    prediction_counts.values == 1
):
    raise RuntimeError(
        "Some Development IDs appear "
        "more than once in outer validation."
    )

print(
    "Every Development record appears "
    "exactly once as outer validation."
)

print("Outer CV coverage PASS.")

# ============================================================
# HYPERPARAMETER STABILITY
# ============================================================

print_header(
    "13. HYPERPARAMETER SELECTION STABILITY"
)

hyperparameter_columns = [
    col
    for col in selected_params_df.columns
    if col.startswith("selected_")
]

for column in hyperparameter_columns:

    counts = (
        selected_params_df[column]
        .value_counts(dropna=False)
    )

    print(f"\n{column}:")

    for value, count in counts.items():

        print(
            f"  {value}: "
            f"{count}/{N_OUTER}"
        )

# ============================================================
# CALIBRATION / TEST PROTECTION
# ============================================================

print_header(
    "14. CALIBRATION AND TEST PROTECTION"
)

evaluated_ids = set(
    outer_predictions_df["id"]
)

calibration_overlap = (
    evaluated_ids.intersection(cal_ids)
)

test_overlap = (
    evaluated_ids.intersection(test_ids)
)

print(
    f"Outer-CV IDs ∩ Calibration IDs: "
    f"{len(calibration_overlap)}"
)

print(
    f"Outer-CV IDs ∩ Locked Test IDs: "
    f"{len(test_overlap)}"
)

if (
    len(calibration_overlap) > 0 or
    len(test_overlap) > 0
):
    raise RuntimeError(
        "Protected partition overlap detected."
    )

print(
    "Calibration and locked test "
    "remain protected."
)

# ============================================================
# LEAKAGE ASSERTIONS
# ============================================================

print_header(
    "15. LEAKAGE CONTROL ASSERTIONS"
)

print("PASS: Hyperparameter selection performed inside inner CV.")
print("PASS: Imputation fitted within training folds.")
print("PASS: No global imputation.")
print("PASS: No ADASYN in primary pipeline.")
print("PASS: Calibration set excluded from model selection.")
print("PASS: Locked test excluded from model selection.")
print("PASS: Locked test excluded from evaluation.")
print("PASS: UCI data not used in Kaggle development.")
print("PASS: Outer validation records are held out from their training fold.")

# ============================================================
# SAVE RESULTS
# ============================================================

print_header(
    "16. SAVE RESULTS"
)

outer_results_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_outer_fold_results.csv"
)

aggregate_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_aggregate_results.csv"
)

selected_params_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_selected_hyperparameters.csv"
)

pooled_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_pooled_outer_cv.csv"
)

predictions_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_outer_predictions.csv"
)

experiment_file = os.path.join(
    RESULTS_DIR,
    "implementation23_random_forest_experiment_record.json"
)

outer_results_df.to_csv(
    outer_results_file,
    index=False
)

aggregate_df.to_csv(
    aggregate_file,
    index=False
)

selected_params_df.to_csv(
    selected_params_file,
    index=False
)

pooled_df.to_csv(
    pooled_file,
    index=False
)

outer_predictions_df.to_csv(
    predictions_file,
    index=False
)

# ============================================================
# EXPERIMENT RECORD
# ============================================================

experiment_record = {

    "implementation": "23",
    "model": "Random Forest",
    "experiment": "Random Forest baseline",

    "timestamp":
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        ),

    "random_seed": SEED,

    "data": {
        "development_rows": len(dev),
        "calibration_rows": len(cal),
        "locked_test_rows": len(test),
        "features": FEATURES,
        "target": TARGET
    },

    "evaluation": {
        "outer_folds": N_OUTER,
        "inner_folds": N_INNER,
        "selection_metric": "ROC-AUC",
        "threshold": 0.5
    },

    "preprocessing": {
        "imputation":
            "median, fold-specific",
        "scaling":
            "not used for Random Forest",
        "adasyn":
            False
    },

    "model": {
        "class":
            "sklearn.ensemble.RandomForestClassifier",
        "random_state": SEED,
        "n_jobs": -1,
        "class_weight": None,
        "parameter_grid": PARAM_GRID
    },

    "metrics": metric_columns,

    "protected_partitions": {
        "calibration_used":
            False,
        "locked_test_used":
            False
    },

    "pooled_outer_cv": pooled_metrics,

    "aggregate_outer_cv": aggregate_rows,

    "output_files": {
        "outer_fold_results":
            outer_results_file,
        "aggregate_results":
            aggregate_file,
        "selected_hyperparameters":
            selected_params_file,
        "pooled_outer_cv":
            pooled_file,
        "outer_predictions":
            predictions_file,
        "experiment_record":
            experiment_file
    },

    "status": "PASS"
}

with open(
    experiment_file,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        experiment_record,
        f,
        indent=2,
        default=str
    )

# ============================================================
# FINAL SUMMARY
# ============================================================

print_header(
    "IMPLEMENTATION 23 COMPLETE"
)

print(
    "Random Forest nested-CV baseline completed."
)

print(
    "\nDevelopment set: 49,000"
)

print(
    "Calibration set: 7,000 [PROTECTED]"
)

print(
    "Locked test set: 14,000 [PROTECTED]"
)

print(
    "\nOuter CV: 5-fold"
)

print(
    "Inner CV: 4-fold"
)

print(
    "ADASYN: NOT USED"
)

print(
    "Primary feature strategy: ALL 11 FEATURES"
)

print(
    "\nPrimary comparison metric: ROC-AUC"
)

print(
    f"Pooled outer-CV ROC-AUC: "
    f"{pooled_metrics['roc_auc']:.6f}"
)

print(
    f"Mean outer-CV ROC-AUC: "
    f"{outer_results_df['roc_auc'].mean():.6f} "
    f"± "
    f"{outer_results_df['roc_auc'].std(ddof=1):.6f}"
)

print(
    "\nCalibration and locked test remain untouched."
)

print(
    "\nOutput files saved to:"
)

print(RESULTS_DIR)

print(
    "\nOVERALL IMPLEMENTATION 23 STATUS: PASS"
)

print("=" * 78)