# ============================================================
# IMPLEMENTATION 43A
# Prediction-File Audit for Paired Statistical Comparison
#
# PURPOSE:
#   Identify and audit saved model prediction files before
#   performing paired statistical comparisons.
#
# IMPORTANT:
#   - NO model training
#   - NO hyperparameter tuning
#   - NO threshold selection
#   - NO modification of existing prediction files
#   - NO external/UCI model development
#
# PRIMARY EVALUATION:
#   Kaggle locked test set
#
# TARGET:
#   14,000 locked-test observations
#
# ============================================================

from pathlib import Path
import json
import re
import pandas as pd
import numpy as np


# ============================================================
# 1. PATHS
# ============================================================

BASE_DIR = Path(".")

RESULTS_DIR = (
    BASE_DIR
    / "results"
    / "tables"
)

OUTPUT_CSV = (
    RESULTS_DIR
    / "implementation43A_prediction_audit.csv"
)

OUTPUT_JSON = (
    RESULTS_DIR
    / "implementation43A_prediction_audit.json"
)

OUTPUT_REPORT = (
    RESULTS_DIR
    / "implementation43A_prediction_audit_report.txt"
)

EXPECTED_TEST_N = 14000


# ============================================================
# 2. START
# ============================================================

print("=" * 80)
print("IMPLEMENTATION 43A: PREDICTION-FILE AUDIT")
print("=" * 80)

print("\nResults directory:")
print(RESULTS_DIR)


if not RESULTS_DIR.exists():
    raise FileNotFoundError(
        f"\nResults directory not found:\n{RESULTS_DIR}"
    )


# ============================================================
# 3. LIST CSV FILES
# ============================================================

csv_files = sorted(
    RESULTS_DIR.glob("*.csv")
)

print(
    f"\nCSV files found: {len(csv_files)}"
)

for f in csv_files:
    print(" -", f.name)


# ============================================================
# 4. MODEL NAME IDENTIFICATION
# ============================================================

MODEL_PATTERNS = {

    "Logistic Regression": [
        "logistic",
        "lr",
        "logreg",
    ],

    "Random Forest": [
        "random_forest",
        "randomforest",
        "rf",
    ],

    "XGBoost": [
        "xgboost",
        "xgb",
    ],

    "MLP": [
        "mlp",
    ],

    "B-spline KAN": [
        "b_spline",
        "bspline",
        "b-spline",
        "bspline_kan",
    ],

    "Vanilla Chebyshev KAN": [
        "vanilla_cheb",
        "vanilla_chebyshev",
        "chebyshev_kan",
        "chebkan",
    ],

    "Fourier KAN": [
        "fourier",
        "fourier_kan",
    ],

    "Flat ChebKAN": [
        "flat_cheb",
        "flat_chebkan",
    ],

    "Grouped ChebKAN": [
        "grouped_cheb",
        "grouped_chebkan",
    ],

    "Sparse Grouped ChebKAN": [
        "sparse_grouped",
        "sparse_grouped_cheb",
        "a6",
    ],

    "CGS-ChebKAN": [
        "cgs",
        "a7",
        "implementation39_locked_test",
        "locked_test_predictions",
    ],
}


def identify_model(filename):

    name = filename.lower()

    # Check more specific models first
    ordered_models = [
        "CGS-ChebKAN",
        "Sparse Grouped ChebKAN",
        "Grouped ChebKAN",
        "Flat ChebKAN",
        "Vanilla Chebyshev KAN",
        "B-spline KAN",
        "Fourier KAN",
        "XGBoost",
        "Random Forest",
        "Logistic Regression",
        "MLP",
    ]

    for model in ordered_models:

        for pattern in MODEL_PATTERNS[model]:

            if pattern.lower() in name:
                return model

    return "UNIDENTIFIED"


# ============================================================
# 5. COLUMN DETECTION
# ============================================================

def detect_column(columns, candidates):

    lower_map = {
        str(c).strip().lower(): c
        for c in columns
    }

    # Exact match
    for candidate in candidates:

        if candidate.lower() in lower_map:
            return lower_map[
                candidate.lower()
            ]

    # Partial match
    for c in columns:

        lc = str(c).strip().lower()

        for candidate in candidates:

            if candidate.lower() in lc:
                return c

    return None


# ============================================================
# 6. AUDIT EACH CSV
# ============================================================

records = []

print("\n")
print("=" * 80)
print("FILE-LEVEL AUDIT")
print("=" * 80)


for file_path in csv_files:

    print("\n" + "-" * 80)
    print("FILE:", file_path.name)
    print("-" * 80)

    record = {

        "file": file_path.name,

        "model": identify_model(
            file_path.name
        ),

        "rows": None,

        "columns": None,

        "target_column": None,

        "probability_column": None,

        "prediction_column": None,

        "id_column": None,

        "dataset_column": None,

        "has_probability": False,

        "has_target": False,

        "has_prediction": False,

        "has_id": False,

        "unique_ids": None,

        "duplicate_ids": None,

        "target_values": None,

        "probability_min": None,

        "probability_max": None,

        "probability_missing": None,

        "target_missing": None,

        "looks_like_prediction_file": False,

        "exact_14000_rows": False,

        "status": "NOT_PREDICTION_FILE",
    }


    try:

        data = pd.read_csv(
            file_path,
            low_memory=False
        )

    except Exception as e:

        record["status"] = (
            "READ_ERROR: " + str(e)
        )

        records.append(record)

        print(
            "READ ERROR:",
            str(e)
        )

        continue


    # --------------------------------------------------------
    # Basic information
    # --------------------------------------------------------

    record["rows"] = int(
        data.shape[0]
    )

    record["columns"] = int(
        data.shape[1]
    )


    print(
        "Rows:",
        data.shape[0]
    )

    print(
        "Columns:",
        data.columns.tolist()
    )


    # --------------------------------------------------------
    # Detect columns
    # --------------------------------------------------------

    target_col = detect_column(
        data.columns,
        [
            "true_label",
            "target",
            "y_true",
            "label",
            "cardio",
            "actual",
        ]
    )

    probability_col = detect_column(
        data.columns,
        [
            "probability",
            "prob",
            "prob_1",
            "predicted_probability",
            "positive_probability",
            "y_prob",
            "score",
        ]
    )

    prediction_col = detect_column(
        data.columns,
        [
            "prediction",
            "pred",
            "predicted",
            "y_pred",
            "class_prediction",
        ]
    )

    id_col = detect_column(
        data.columns,
        [
            "id",
            "ID",
            "sample_id",
            "record_id",
            "row_id",
            "source_row",
        ]
    )

    dataset_col = detect_column(
        data.columns,
        [
            "dataset",
            "cohort",
            "split",
        ]
    )


    record["target_column"] = (
        str(target_col)
        if target_col is not None
        else None
    )

    record["probability_column"] = (
        str(probability_col)
        if probability_col is not None
        else None
    )

    record["prediction_column"] = (
        str(prediction_col)
        if prediction_col is not None
        else None
    )

    record["id_column"] = (
        str(id_col)
        if id_col is not None
        else None
    )

    record["dataset_column"] = (
        str(dataset_col)
        if dataset_col is not None
        else None
    )


    record["has_target"] = (
        target_col is not None
    )

    record["has_probability"] = (
        probability_col is not None
    )

    record["has_prediction"] = (
        prediction_col is not None
    )

    record["has_id"] = (
        id_col is not None
    )


    # --------------------------------------------------------
    # Determine whether this looks like prediction data
    # --------------------------------------------------------

    looks_like_prediction = (
        target_col is not None
        and probability_col is not None
    )

    record[
        "looks_like_prediction_file"
    ] = looks_like_prediction


    # --------------------------------------------------------
    # Probability audit
    # --------------------------------------------------------

    if probability_col is not None:

        probability = pd.to_numeric(
            data[probability_col],
            errors="coerce"
        )

        record["probability_min"] = float(
            probability.min()
        )

        record["probability_max"] = float(
            probability.max()
        )

        record["probability_missing"] = int(
            probability.isna().sum()
        )


    # --------------------------------------------------------
    # Target audit
    # --------------------------------------------------------

    if target_col is not None:

        target = pd.to_numeric(
            data[target_col],
            errors="coerce"
        )

        record["target_missing"] = int(
            target.isna().sum()
        )

        unique_target = sorted(
            target.dropna().unique().tolist()
        )

        record["target_values"] = str(
            unique_target
        )


    # --------------------------------------------------------
    # ID audit
    # --------------------------------------------------------

    if id_col is not None:

        ids = data[id_col]

        record["unique_ids"] = int(
            ids.nunique(dropna=True)
        )

        record["duplicate_ids"] = int(
            ids.duplicated().sum()
        )


    # --------------------------------------------------------
    # Determine status
    # --------------------------------------------------------

    if looks_like_prediction:

        if data.shape[0] == EXPECTED_TEST_N:

            record["exact_14000_rows"] = True

            record["status"] = (
                "PREDICTION_FILE_14000_ROWS"
            )

        else:

            record["status"] = (
                "PREDICTION_FILE_OTHER_SIZE"
            )


    # --------------------------------------------------------
    # Print audit
    # --------------------------------------------------------

    print(
        "Identified model:",
        record["model"]
    )

    print(
        "Target column:",
        record["target_column"]
    )

    print(
        "Probability column:",
        record["probability_column"]
    )

    print(
        "Prediction column:",
        record["prediction_column"]
    )

    print(
        "ID column:",
        record["id_column"]
    )

    print(
        "Looks like prediction file:",
        record["looks_like_prediction_file"]
    )

    print(
        "Status:",
        record["status"]
    )


    records.append(record)


# ============================================================
# 7. CREATE AUDIT DATAFRAME
# ============================================================

audit_df = pd.DataFrame(
    records
)


# ============================================================
# 8. SAVE INITIAL AUDIT
# ============================================================

audit_df.to_csv(
    OUTPUT_CSV,
    index=False
)


# ============================================================
# 9. IDENTIFY PREDICTION FILES
# ============================================================

prediction_df = audit_df[
    audit_df[
        "looks_like_prediction_file"
    ] == True
].copy()


print("\n")
print("=" * 80)
print("PREDICTION FILES IDENTIFIED")
print("=" * 80)

if len(prediction_df) == 0:

    print(
        "\nNo prediction files were identified."
    )

else:

    print(
        prediction_df[
            [
                "file",
                "model",
                "rows",
                "target_column",
                "probability_column",
                "prediction_column",
                "id_column",
                "status",
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 10. IDENTIFY CGS-CHEBKAN LOCKED TEST FILE
# ============================================================

cgs_candidates = prediction_df[
    prediction_df["model"]
    == "CGS-ChebKAN"
].copy()


print("\n")
print("=" * 80)
print("CGS-CHEBKAN CANDIDATES")
print("=" * 80)


if len(cgs_candidates) == 0:

    print(
        "\nNo CGS-ChebKAN prediction file was "
        "automatically identified."
    )

else:

    print(
        cgs_candidates[
            [
                "file",
                "rows",
                "target_column",
                "probability_column",
                "id_column",
                "status",
            ]
        ].to_string(
            index=False
        )
    )


# ============================================================
# 11. FIND BEST CGS-CHEBKAN FILE
# ============================================================

cgs_locked = cgs_candidates[
    cgs_candidates["rows"]
    == EXPECTED_TEST_N
].copy()


if len(cgs_locked) == 0:

    print(
        "\nWARNING: No CGS-ChebKAN prediction file "
        f"with exactly {EXPECTED_TEST_N} rows was found."
    )

    cgs_file = None

else:

    # Prefer implementation39 locked-test file
    preferred = cgs_locked[
        cgs_locked["file"].str.contains(
            "implementation39",
            case=False,
            na=False
        )
    ]

    if len(preferred) > 0:

        cgs_file = preferred.iloc[0]["file"]

    else:

        cgs_file = cgs_locked.iloc[0]["file"]


    print(
        "\nSelected CGS-ChebKAN locked-test file:"
    )

    print(cgs_file)


# ============================================================
# 12. LOAD CGS TEST DATA
# ============================================================

cgs_data = None

if cgs_file is not None:

    cgs_path = RESULTS_DIR / cgs_file

    cgs_data = pd.read_csv(
        cgs_path,
        low_memory=False
    )

    cgs_target_col = detect_column(
        cgs_data.columns,
        [
            "true_label",
            "target",
            "y_true",
            "label",
            "cardio",
            "actual",
        ]
    )

    cgs_prob_col = detect_column(
        cgs_data.columns,
        [
            "probability",
            "prob",
            "prob_1",
            "predicted_probability",
            "positive_probability",
            "y_prob",
            "score",
        ]
    )

    cgs_id_col = detect_column(
        cgs_data.columns,
        [
            "id",
            "sample_id",
            "record_id",
            "row_id",
        ]
    )

    print("\nCGS-ChebKAN test rows:")
    print(len(cgs_data))

    print(
        "CGS target column:",
        cgs_target_col
    )

    print(
        "CGS probability column:",
        cgs_prob_col
    )

    print(
        "CGS ID column:",
        cgs_id_col
    )


# ============================================================
# 13. PAIRED-COMPATIBILITY AUDIT
# ============================================================

pair_records = []


if cgs_data is not None:

    print("\n")
    print("=" * 80)
    print("PAIRED COMPATIBILITY AUDIT")
    print("=" * 80)


    for _, row in prediction_df.iterrows():

        model = row["model"]
        filename = row["file"]

        # Skip CGS itself
        if model == "CGS-ChebKAN":
            continue

        # Only exact 14k files are candidates
        if int(row["rows"]) != EXPECTED_TEST_N:

            pair_records.append({

                "comparison_model": model,

                "comparison_file": filename,

                "comparison_rows":
                    row["rows"],

                "same_row_count":
                    False,

                "same_ids":
                    None,

                "missing_ids":
                    None,

                "extra_ids":
                    None,

                "duplicate_ids_comparison":
                    row["duplicate_ids"],

                "paired_comparison_ready":
                    False,

                "reason":
                    "Not exactly 14,000 rows",
            })

            continue


        comparison_path = (
            RESULTS_DIR
            / filename
        )

        try:

            comparison_data = pd.read_csv(
                comparison_path,
                low_memory=False
            )

        except Exception as e:

            pair_records.append({

                "comparison_model": model,

                "comparison_file": filename,

                "comparison_rows":
                    row["rows"],

                "same_row_count":
                    False,

                "same_ids":
                    None,

                "missing_ids":
                    None,

                "extra_ids":
                    None,

                "duplicate_ids_comparison":
                    row["duplicate_ids"],

                "paired_comparison_ready":
                    False,

                "reason":
                    "Read error: " + str(e),
            })

            continue


        comparison_id_col = detect_column(
            comparison_data.columns,
            [
                "id",
                "sample_id",
                "record_id",
                "row_id",
            ]
        )


        # ----------------------------------------------------
        # If both files have IDs, compare exact ID sets
        # ----------------------------------------------------

        if (
            cgs_id_col is not None
            and comparison_id_col is not None
        ):

            cgs_ids = set(
                cgs_data[
                    cgs_id_col
                ].dropna().tolist()
            )

            comparison_ids = set(
                comparison_data[
                    comparison_id_col
                ].dropna().tolist()
            )

            missing_ids = (
                cgs_ids
                - comparison_ids
            )

            extra_ids = (
                comparison_ids
                - cgs_ids
            )

            same_ids = (
                len(missing_ids) == 0
                and
                len(extra_ids) == 0
                and
                len(cgs_ids)
                == len(comparison_ids)
            )

            pair_ready = same_ids


            pair_records.append({

                "comparison_model": model,

                "comparison_file": filename,

                "comparison_rows":
                    len(comparison_data),

                "same_row_count":
                    len(comparison_data)
                    == EXPECTED_TEST_N,

                "same_ids":
                    same_ids,

                "missing_ids":
                    len(missing_ids),

                "extra_ids":
                    len(extra_ids),

                "duplicate_ids_comparison":
                    int(
                        comparison_data[
                            comparison_id_col
                        ].duplicated().sum()
                    ),

                "paired_comparison_ready":
                    pair_ready,

                "reason":
                    (
                        "Exact ID-set match"
                        if pair_ready
                        else
                        "ID-set mismatch"
                    ),
            })


        else:

            # ------------------------------------------------
            # No IDs: cannot claim exact pairing
            # ------------------------------------------------

            pair_records.append({

                "comparison_model": model,

                "comparison_file": filename,

                "comparison_rows":
                    len(comparison_data),

                "same_row_count":
                    len(comparison_data)
                    == EXPECTED_TEST_N,

                "same_ids":
                    None,

                "missing_ids":
                    None,

                "extra_ids":
                    None,

                "duplicate_ids_comparison":
                    row["duplicate_ids"],

                "paired_comparison_ready":
                    False,

                "reason":
                    "Missing ID column in one or both files",
            })


# ============================================================
# 14. SAVE PAIRED AUDIT
# ============================================================

pair_df = pd.DataFrame(
    pair_records
)


if len(pair_df) > 0:

    pair_df.to_csv(
        OUTPUT_CSV,
        index=False
    )


# ============================================================
# 15. PRINT PAIRING RESULTS
# ============================================================

print("\n")
print("=" * 80)
print("PAIRING RESULTS")
print("=" * 80)


if len(pair_df) == 0:

    print(
        "\nNo candidate paired prediction files "
        "were identified."
    )

else:

    print(
        pair_df.to_string(
            index=False
        )
    )


# ============================================================
# 16. DETERMINE MODELS READY FOR STATISTICS
# ============================================================

if len(pair_df) > 0:

    ready_models = pair_df[
        pair_df[
            "paired_comparison_ready"
        ] == True
    ][
        "comparison_model"
    ].tolist()

else:

    ready_models = []


print("\n")
print("=" * 80)
print("MODELS READY FOR PAIRED STATISTICAL COMPARISON")
print("=" * 80)

if len(ready_models) == 0:

    print(
        "\nNONE"
    )

else:

    for model in ready_models:

        print(
            " -",
            model
        )


# ============================================================
# 17. CHECK REQUIRED TARGET CONSISTENCY
# ============================================================

target_consistency_records = []


if cgs_data is not None:

    cgs_target = pd.to_numeric(
        cgs_data[
            cgs_target_col
        ],
        errors="coerce"
    )

    cgs_target_values = (
        cgs_target.tolist()
    )


    for model in ready_models:

        row = pair_df[
            pair_df[
                "comparison_model"
            ] == model
        ].iloc[0]

        comparison_file = row[
            "comparison_file"
        ]

        comparison_data = pd.read_csv(
            RESULTS_DIR
            / comparison_file,
            low_memory=False
        )

        comparison_target_col = detect_column(
            comparison_data.columns,
            [
                "true_label",
                "target",
                "y_true",
                "label",
                "cardio",
                "actual",
            ]
        )

        if comparison_target_col is None:

            target_consistency_records.append({

                "model": model,

                "target_column":
                    None,

                "same_target":
                    False,

                "reason":
                    "Target column missing",
            })

            continue


        comparison_target = pd.to_numeric(
            comparison_data[
                comparison_target_col
            ],
            errors="coerce"
        )

        same_length = (
            len(cgs_target)
            == len(comparison_target)
        )

        same_target = False

        if same_length:

            same_target = np.array_equal(
                cgs_target.to_numpy(),
                comparison_target.to_numpy()
            )

        target_consistency_records.append({

            "model": model,

            "target_column":
                comparison_target_col,

            "same_target":
                same_target,

            "reason":
                (
                    "Target arrays identical in file order"
                    if same_target
                    else
                    "Target arrays differ or row ordering differs"
                ),
        })


target_df = pd.DataFrame(
    target_consistency_records
)


# ============================================================
# 18. SAVE TARGET CONSISTENCY
# ============================================================

if len(target_df) > 0:

    target_file = (
        RESULTS_DIR
        / "implementation43A_target_consistency.csv"
    )

    target_df.to_csv(
        target_file,
        index=False
    )

    print("\nTarget consistency:")
    print(
        target_df.to_string(
            index=False
        )
    )

    print(
        "\nSaved:",
        target_file
    )


# ============================================================
# 19. FINAL STATUS
# ============================================================

paired_ready_count = len(
    ready_models
)

status = (
    "PASS_PREDICTION_AUDIT"
    if paired_ready_count > 0
    else
    "PARTIAL_PREDICTION_AUDIT"
)


# ============================================================
# 20. JSON OUTPUT
# ============================================================

json_output = {

    "implementation":
        "Implementation 43A",

    "status":
        status,

    "expected_locked_test_n":
        EXPECTED_TEST_N,

    "prediction_files_found":
        int(len(prediction_df)),

    "models_ready_for_paired_comparison":
        ready_models,

    "n_models_ready":
        int(paired_ready_count),

    "cgs_chebkan_file":
        cgs_file,

    "paired_audit":
        pair_df.to_dict(
            orient="records"
        )
        if len(pair_df) > 0
        else [],

    "target_consistency":
        target_df.to_dict(
            orient="records"
        )
        if len(target_df) > 0
        else [],
}


def clean_for_json(obj):

    if isinstance(obj, dict):

        return {
            k: clean_for_json(v)
            for k, v in obj.items()
        }

    if isinstance(obj, list):

        return [
            clean_for_json(v)
            for v in obj
        ]

    if isinstance(obj, (np.integer,)):

        return int(obj)

    if isinstance(obj, (np.floating,)):

        if np.isnan(obj):
            return None

        return float(obj)

    if pd.isna(obj):

        return None

    return obj


json_output = clean_for_json(
    json_output
)


with open(
    OUTPUT_JSON,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        json_output,
        f,
        indent=2
    )


# ============================================================
# 21. MANUSCRIPT AUDIT REPORT
# ============================================================

report = []

report.append(
    "IMPLEMENTATION 43A – PREDICTION-FILE AUDIT"
)

report.append(
    "=" * 75
)

report.append("")

report.append(
    f"Expected locked-test sample size: "
    f"{EXPECTED_TEST_N}"
)

report.append(
    f"Prediction files identified: "
    f"{len(prediction_df)}"
)

report.append(
    f"Models ready for paired statistical comparison: "
    f"{len(ready_models)}"
)

report.append("")

if cgs_file is not None:

    report.append(
        "CGS-ChebKAN locked-test prediction file: "
        + str(cgs_file)
    )

else:

    report.append(
        "CGS-ChebKAN locked-test prediction file: "
        "NOT IDENTIFIED"
    )

report.append("")

if ready_models:

    report.append(
        "Models with exact locked-test pairing:"
    )

    for model in ready_models:

        report.append(
            " - " + model
        )

else:

    report.append(
        "No model was confirmed as exactly paired "
        "with CGS-ChebKAN."
    )

report.append("")

report.append(
    "No models were retrained during this audit."
)

report.append(
    "No hyperparameters were tuned during this audit."
)

report.append(
    "No external/UCI data were used for model development."
)

report.append("")

report.append(
    "Statistical comparison should only proceed for "
    "models confirmed to use the same locked-test "
    "observations with identical target labels."
)


with open(
    OUTPUT_REPORT,
    "w",
    encoding="utf-8"
) as f:

    f.write(
        "\n".join(report)
    )


# ============================================================
# 22. FINAL OUTPUT
# ============================================================

print("\n")
print("=" * 80)
print("IMPLEMENTATION 43A COMPLETED")
print("=" * 80)

print("\nStatus:")
print(status)

print("\nOutput files:")
print(OUTPUT_CSV)
print(OUTPUT_JSON)
print(OUTPUT_REPORT)

print("\nModels ready for paired statistical comparison:")

if ready_models:

    for model in ready_models:
        print(" -", model)

else:

    print(" NONE")

print("\nNo model was retrained.")
print("No hyperparameters were changed.")
print("No UCI external data were used.")

print("\nNext process:")
print(
    "Implementation 43B – Paired ROC-AUC statistical comparison."
)

print("=" * 80)