# ================================================================
# AUDIT 19: CLINICAL GROUP DEFINITION AND FEATURE MAPPING
# ================================================================
#
# Project:
# Clinically-Grouped Sparse Chebyshev-KAN for Cardiovascular
# Disease Prediction with Conformal Prediction
#
# Purpose:
#   1. Verify the frozen 11-feature Kaggle representation.
#   2. Define clinically meaningful feature groups.
#   3. Verify that every predictor belongs to exactly one group.
#   4. Verify that the target is excluded from all groups.
#   5. Report feature-level and group-level missingness.
#   6. Verify Development / Calibration / Locked-Test separation.
#   7. Save the frozen clinical grouping configuration.
#
# IMPORTANT:
#   - No model training is performed.
#   - No feature selection is performed.
#   - No imputation is performed.
#   - No ADASYN is performed.
#   - No conformal calibration is performed.
#   - No locked-test evaluation is performed.
#   - This audit only defines and verifies the clinical grouping.
#
# Frozen primary Kaggle representation:
#   age, gender, height, weight, ap_hi, ap_lo,
#   cholesterol, gluc, smoke, alco, active
#
# Frozen clinical groups:
#   1. Demographic
#   2. Physiological / Anthropometric / Metabolic
#   3. Lifestyle
#
# ================================================================


from pathlib import Path
from datetime import datetime
import json
import sys

import numpy as np
import pandas as pd


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_PROCESSED = PROJECT_ROOT / "data" / "processed"
RESULTS_TABLES = PROJECT_ROOT / "results" / "tables"
RESULTS_LOGS = PROJECT_ROOT / "logs"

RESULTS_TABLES.mkdir(parents=True, exist_ok=True)
RESULTS_LOGS.mkdir(parents=True, exist_ok=True)


# ================================================================
# 2. INPUT FILES
# ================================================================

DEV_FILE = DATA_PROCESSED / "kaggle_development_cv.csv"

CAL_FILE = DATA_PROCESSED / "kaggle_conformal_calibration.csv"

TEST_FILE = DATA_PROCESSED / "kaggle_locked_test.csv"


# ================================================================
# 3. FROZEN 11-FEATURE PRIMARY REPRESENTATION
# ================================================================
#
# Audit 18 established that the PRIMARY Kaggle strategy remains
# the complete 11-feature representation.
#
# Feature selection is retained only as an ablation/sensitivity
# analysis and is NOT used to define these clinical groups.
# ================================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"


# ================================================================
# 4. FROZEN CLINICAL GROUP DEFINITION
# ================================================================
#
# IMPORTANT:
#
# The Kaggle cardiovascular dataset does not contain genuine
# symptomatic/diagnostic variables such as:
#
#   - chest pain
#   - resting ECG
#   - ST depression
#   - exercise-induced angina
#   - maximum heart rate
#   - coronary angiography findings
#
# Therefore, a symptomatic/diagnostic group is NOT invented for
# the Kaggle primary representation.
#
# Instead, the 11 predictors are divided into three groups.
# ================================================================

CLINICAL_GROUPS = {

    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


# ================================================================
# 5. HUMAN-READABLE GROUP LABELS
# ================================================================

GROUP_LABELS = {

    "demographic":
        "Demographic",

    "physiological_anthropometric_metabolic":
        "Physiological / Anthropometric / Metabolic",

    "lifestyle":
        "Lifestyle",
}


# ================================================================
# 6. EXPECTED PARTITION SIZES
# ================================================================

EXPECTED_PARTITION_SIZES = {

    "development_cv": 49_000,

    "conformal_calibration": 7_000,

    "locked_test": 14_000,
}


# ================================================================
# 7. HELPER FUNCTIONS
# ================================================================

def print_section(title):

    print()
    print("=" * 72)
    print(title)
    print("=" * 72)


def fail(message):

    print()
    print("!" * 72)
    print("AUDIT FAILURE")
    print("!" * 72)
    print(message)
    print("!" * 72)

    sys.exit(1)


def load_dataset(path, dataset_name):

    if not path.exists():

        fail(
            f"{dataset_name} file was not found:\n"
            f"{path}"
        )

    try:

        df = pd.read_csv(path)

    except Exception as exc:

        fail(
            f"Could not read {dataset_name}:\n"
            f"{path}\n\n"
            f"Error: {exc}"
        )

    print(
        f"{dataset_name:<25}: "
        f"{len(df):,} rows × {len(df.columns)} columns"
    )

    return df


# ================================================================
# 8. START AUDIT
# ================================================================

print_section(
    "AUDIT 19: CLINICAL GROUP DEFINITION AND FEATURE MAPPING"
)

print(
    f"Project root : {PROJECT_ROOT}"
)

print(
    f"Timestamp    : "
    f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
)


# ================================================================
# 9. VERIFY PROJECT DIRECTORY
# ================================================================

print_section("1. Project Directory Verification")

if not PROJECT_ROOT.exists():

    fail(
        f"Project root does not exist:\n"
        f"{PROJECT_ROOT}"
    )

if not DATA_PROCESSED.exists():

    fail(
        f"Processed-data directory does not exist:\n"
        f"{DATA_PROCESSED}"
    )

print(
    f"Project root exists: {PROJECT_ROOT}"
)

print(
    f"Processed-data directory exists: {DATA_PROCESSED}"
)

print("PASS: Project directories are available.")


# ================================================================
# 10. LOAD FROZEN PARTITIONS
# ================================================================

print_section("2. Loading Frozen Partitions")

dev = load_dataset(
    DEV_FILE,
    "Development/CV"
)

cal = load_dataset(
    CAL_FILE,
    "Conformal Calibration"
)

test = load_dataset(
    TEST_FILE,
    "Locked Test"
)


# ================================================================
# 11. VERIFY PARTITION SIZES
# ================================================================

print_section("3. Partition Size Verification")

actual_partition_sizes = {

    "development_cv":
        len(dev),

    "conformal_calibration":
        len(cal),

    "locked_test":
        len(test),
}


for partition_name, expected_size in \
        EXPECTED_PARTITION_SIZES.items():

    actual_size = actual_partition_sizes[
        partition_name
    ]

    print(
        f"{partition_name:<25}: "
        f"expected = {expected_size:,}, "
        f"actual = {actual_size:,}"
    )

    if actual_size != expected_size:

        fail(
            f"Unexpected partition size for "
            f"{partition_name}.\n"
            f"Expected: {expected_size:,}\n"
            f"Actual:   {actual_size:,}"
        )


print(
    "PASS: Development, calibration, and test "
    "partition sizes are correct."
)


# ================================================================
# 12. VERIFY REQUIRED FEATURES AND TARGET
# ================================================================

print_section(
    "4. Required Feature and Target Verification"
)


for dataset_name, df in [

    ("Development/CV", dev),

    ("Conformal Calibration", cal),

    ("Locked Test", test),

]:

    missing_features = [

        feature
        for feature in FEATURES
        if feature not in df.columns

    ]

    if missing_features:

        fail(
            f"{dataset_name} is missing required "
            f"predictors:\n"
            + "\n".join(
                f"  - {feature}"
                for feature in missing_features
            )
        )

    if TARGET not in df.columns:

        fail(
            f"{dataset_name} is missing target "
            f"column '{TARGET}'."
        )

    print(
        f"{dataset_name:<25}: "
        f"all 11 predictors + target present"
    )


print(
    "PASS: Required predictors and target are present "
    "in all partitions."
)


# ================================================================
# 13. VERIFY EXACT PRIMARY FEATURE SET
# ================================================================

print_section(
    "5. Frozen 11-Feature Primary Representation"
)

print(
    f"Number of frozen predictors: {len(FEATURES)}"
)

for index, feature in enumerate(
    FEATURES,
    start=1
):

    print(
        f"{index:2d}. {feature}"
    )


if len(FEATURES) != 11:

    fail(
        "The frozen primary representation does not "
        "contain exactly 11 predictors."
    )


if len(set(FEATURES)) != len(FEATURES):

    fail(
        "Duplicate feature names exist in the frozen "
        "11-feature representation."
    )


print()
print(
    "PASS: Exactly 11 unique predictors are defined."
)


# ================================================================
# 14. VERIFY CLINICAL GROUP NAMES
# ================================================================

print_section(
    "6. Clinical Group Definition"
)

for group_name, group_features in \
        CLINICAL_GROUPS.items():

    print()
    print(
        f"{GROUP_LABELS[group_name]}"
    )

    print(
        "-" * 55
    )

    for feature in group_features:

        print(
            f"  - {feature}"
        )


# ================================================================
# 15. VERIFY GROUP COUNT
# ================================================================

print_section(
    "7. Clinical Group Count Verification"
)

expected_group_count = 3

actual_group_count = len(
    CLINICAL_GROUPS
)

print(
    f"Expected clinical groups: {expected_group_count}"
)

print(
    f"Actual clinical groups:   {actual_group_count}"
)

if actual_group_count != expected_group_count:

    fail(
        "The number of clinical groups does not "
        "match the frozen design."
    )


print(
    "PASS: Three clinical groups are defined."
)


# ================================================================
# 16. COLLECT ALL GROUP FEATURES
# ================================================================

all_group_features = []

for group_name, group_features in \
        CLINICAL_GROUPS.items():

    all_group_features.extend(
        group_features
    )


# ================================================================
# 17. CHECK DUPLICATE FEATURE ASSIGNMENT
# ================================================================

print_section(
    "8. Duplicate Feature Assignment Check"
)

feature_counts = (
    pd.Series(all_group_features)
    .value_counts()
)

duplicated_features = (
    feature_counts[
        feature_counts > 1
    ]
    .index
    .tolist()
)


if duplicated_features:

    fail(
        "The following predictors appear in "
        "more than one clinical group:\n"
        + "\n".join(
            f"  - {feature}"
            for feature in duplicated_features
        )
    )


print(
    "PASS: No predictor belongs to more than one group."
)


# ================================================================
# 18. CHECK FOR MISSING GROUP ASSIGNMENTS
# ================================================================

print_section(
    "9. Missing Clinical Group Assignment Check"
)

feature_set = set(FEATURES)

group_feature_set = set(
    all_group_features
)


missing_from_groups = sorted(
    feature_set - group_feature_set
)

unexpected_group_features = sorted(
    group_feature_set - feature_set
)


if missing_from_groups:

    fail(
        "The following frozen predictors were not "
        "assigned to a clinical group:\n"
        + "\n".join(
            f"  - {feature}"
            for feature in missing_from_groups
        )
    )


if unexpected_group_features:

    fail(
        "The following unexpected predictors appear "
        "inside clinical groups:\n"
        + "\n".join(
            f"  - {feature}"
            for feature in unexpected_group_features
        )
    )


print(
    "PASS: Every frozen predictor is assigned to a "
    "clinical group."
)


# ================================================================
# 19. VERIFY ONE-TO-ONE FEATURE COVERAGE
# ================================================================

print_section(
    "10. One-to-One Feature Coverage"
)

if len(all_group_features) != len(FEATURES):

    fail(
        "The total number of group assignments does "
        "not equal the number of frozen predictors."
    )


if len(set(all_group_features)) != len(all_group_features):

    fail(
        "Duplicate group assignments detected."
    )


if set(all_group_features) != set(FEATURES):

    fail(
        "Clinical group features do not exactly match "
        "the frozen predictor set."
    )


print(
    f"Total frozen predictors : {len(FEATURES)}"
)

print(
    f"Total group assignments : {len(all_group_features)}"
)

print(
    "PASS: Every predictor is assigned exactly once."
)


# ================================================================
# 20. TARGET EXCLUSION CHECK
# ================================================================

print_section(
    "11. Target Exclusion / Leakage Check"
)

print(
    f"Target variable: {TARGET}"
)


for group_name, group_features in \
        CLINICAL_GROUPS.items():

    if TARGET in group_features:

        fail(
            f"Target '{TARGET}' is incorrectly included "
            f"in clinical group '{group_name}'."
        )


print(
    "PASS: Target is excluded from all clinical groups."
)


# ================================================================
# 21. VERIFY TARGET IS NOT IN FROZEN FEATURE LIST
# ================================================================

if TARGET in FEATURES:

    fail(
        f"Target '{TARGET}' is incorrectly included "
        f"in the predictor list."
    )


print(
    "PASS: Target is not part of the predictor representation."
)


# ================================================================
# 22. GROUP SIZE SUMMARY
# ================================================================

print_section(
    "12. Clinical Group Size Summary"
)

group_summary_rows = []


for group_order, (
    group_name,
    group_features
) in enumerate(
    CLINICAL_GROUPS.items(),
    start=1
):

    group_summary_rows.append({

        "group_order":
            group_order,

        "group":
            group_name,

        "group_label":
            GROUP_LABELS[group_name],

        "n_features":
            len(group_features),

        "features":
            ", ".join(group_features),

    })


group_summary_df = pd.DataFrame(
    group_summary_rows
)


print(
    group_summary_df.to_string(
        index=False
    )
)


# ================================================================
# 23. FEATURE-TO-GROUP MAPPING TABLE
# ================================================================

print_section(
    "13. Feature-to-Group Mapping"
)

feature_mapping_rows = []


for group_order, (
    group_name,
    group_features
) in enumerate(
    CLINICAL_GROUPS.items(),
    start=1
):

    for within_group_position, feature in \
            enumerate(
                group_features,
                start=1
            ):

        feature_mapping_rows.append({

            "feature":
                feature,

            "group_order":
                group_order,

            "group":
                group_name,

            "group_label":
                GROUP_LABELS[group_name],

            "within_group_position":
                within_group_position,

        })


feature_mapping_df = pd.DataFrame(
    feature_mapping_rows
)


print(
    feature_mapping_df.to_string(
        index=False
    )
)


# ================================================================
# 24. VERIFY MAPPING TABLE
# ================================================================

print_section(
    "14. Mapping Table Validation"
)

mapping_features = (
    feature_mapping_df[
        "feature"
    ]
    .tolist()
)


if mapping_features != all_group_features:

    fail(
        "The generated feature-to-group mapping table "
        "does not match the clinical group definition."
    )


if len(mapping_features) != len(
    set(mapping_features)
):

    fail(
        "Duplicate feature assignments exist in the "
        "feature-to-group mapping table."
    )


if set(mapping_features) != set(FEATURES):

    fail(
        "Feature mapping does not exactly match the "
        "frozen 11-feature representation."
    )


print(
    "PASS: Feature-to-group mapping is complete, "
    "unique, and exact."
)


# ================================================================
# 25. FEATURE DATA TYPES
# ================================================================

print_section(
    "15. Predictor Data-Type Verification"
)

dtype_rows = []


for feature in FEATURES:

    dtype_rows.append({

        "feature":
            feature,

        "development_dtype":
            str(dev[feature].dtype),

        "calibration_dtype":
            str(cal[feature].dtype),

        "test_dtype":
            str(test[feature].dtype),

    })


dtype_df = pd.DataFrame(
    dtype_rows
)


print(
    dtype_df.to_string(
        index=False
    )
)


# ================================================================
# 26. CHECK TYPE CONSISTENCY ACROSS PARTITIONS
# ================================================================

print_section(
    "16. Cross-Partition Data-Type Consistency"
)

for feature in FEATURES:

    dtypes = [

        str(dev[feature].dtype),

        str(cal[feature].dtype),

        str(test[feature].dtype),

    ]

    if len(set(dtypes)) != 1:

        fail(
            f"Data type mismatch for feature "
            f"'{feature}': {dtypes}"
        )


print(
    "PASS: Predictor data types are consistent "
    "across all partitions."
)


# ================================================================
# 27. MISSINGNESS BY FEATURE AND GROUP
# ================================================================

print_section(
    "17. Feature-Level Missingness by Clinical Group"
)

missingness_rows = []


partition_data = [

    (
        "Development_CV",
        dev
    ),

    (
        "Conformal_Calibration",
        cal
    ),

    (
        "Locked_Test",
        test
    ),

]


for dataset_name, df in partition_data:

    for group_name, group_features in \
            CLINICAL_GROUPS.items():

        for feature in group_features:

            missing_count = int(
                df[feature]
                .isna()
                .sum()
            )

            missing_percentage = (
                missing_count
                /
                len(df)
                *
                100.0
            )

            missingness_rows.append({

                "dataset":
                    dataset_name,

                "group":
                    group_name,

                "group_label":
                    GROUP_LABELS[group_name],

                "feature":
                    feature,

                "n_rows":
                    len(df),

                "missing_count":
                    missing_count,

                "missing_percent":
                    missing_percentage,

            })


missingness_df = pd.DataFrame(
    missingness_rows
)


print(
    missingness_df[
        [
            "dataset",
            "group",
            "feature",
            "missing_count",
            "missing_percent",
        ]
    ].to_string(
        index=False
    )
)


# ================================================================
# 28. GROUP-LEVEL MISSINGNESS
# ================================================================

print_section(
    "18. Group-Level Missingness Summary"
)

group_missingness_df = (

    missingness_df

    .groupby(
        [
            "dataset",
            "group",
            "group_label",
        ],
        as_index=False
    )

    .agg(

        total_missing=(
            "missing_count",
            "sum"
        ),

        features_with_missing=(
            "missing_count",
            lambda x:
                int((x > 0).sum())
        ),

        total_features=(
            "feature",
            "count"
        ),

    )
)


group_missingness_df[
    "any_missing"
] = (
    group_missingness_df[
        "features_with_missing"
    ] > 0
)


print(
    group_missingness_df.to_string(
        index=False
    )
)


# ================================================================
# 29. CHECK COMPLETELY MISSING FEATURES
# ================================================================

print_section(
    "19. Completely Missing Predictor Check"
)

for dataset_name, df in partition_data:

    completely_missing = [

        feature

        for feature in FEATURES

        if df[feature].isna().all()

    ]

    if completely_missing:

        fail(
            f"{dataset_name} contains completely "
            f"missing predictor(s):\n"
            + "\n".join(
                f"  - {feature}"
                for feature in completely_missing
            )
        )

    print(
        f"{dataset_name:<25}: "
        f"no completely missing predictors"
    )


print(
    "PASS: No predictor is completely missing "
    "in any partition."
)


# ================================================================
# 30. TARGET DISTRIBUTION
# ================================================================

print_section(
    "20. Target Distribution by Partition"
)

target_rows = []


for dataset_name, df in partition_data:

    target_counts = (
        df[TARGET]
        .value_counts()
        .sort_index()
    )

    for target_value, count in \
            target_counts.items():

        target_rows.append({

            "dataset":
                dataset_name,

            "target":
                int(target_value),

            "count":
                int(count),

            "percentage":
                float(
                    count
                    /
                    len(df)
                    *
                    100.0
                ),

        })


target_summary_df = pd.DataFrame(
    target_rows
)


print(
    target_summary_df.to_string(
        index=False
    )
)


# ================================================================
# 31. VERIFY BINARY TARGET
# ================================================================

print_section(
    "21. Binary Target Verification"
)

for dataset_name, df in partition_data:

    unique_targets = sorted(

        df[TARGET]
        .dropna()
        .unique()
        .tolist()

    )

    print(
        f"{dataset_name:<25}: "
        f"{unique_targets}"
    )

    if unique_targets != [0, 1]:

        fail(
            f"{dataset_name} does not contain the "
            f"expected binary target values [0, 1]."
        )


print(
    "PASS: Target is binary [0, 1] in all partitions."
)


# ================================================================
# 32. VERIFY TARGET HAS NO MISSING VALUES
# ================================================================

print_section(
    "22. Target Missingness Verification"
)

for dataset_name, df in partition_data:

    missing_target = int(
        df[TARGET].isna().sum()
    )

    print(
        f"{dataset_name:<25}: "
        f"{missing_target} missing target values"
    )

    if missing_target != 0:

        fail(
            f"{dataset_name} contains missing target values."
        )


print(
    "PASS: No target values are missing."
)


# ================================================================
# 33. VERIFY ID COLUMN
# ================================================================

print_section(
    "23. ID Column Verification"
)

for dataset_name, df in partition_data:

    if "id" not in df.columns:

        fail(
            f"ID column is missing from "
            f"{dataset_name}."
        )

    duplicate_ids = int(
        df["id"]
        .duplicated()
        .sum()
    )

    print(
        f"{dataset_name:<25}: "
        f"duplicate IDs = {duplicate_ids}"
    )

    if duplicate_ids != 0:

        fail(
            f"Duplicate IDs detected inside "
            f"{dataset_name}."
        )


print(
    "PASS: No duplicate IDs within any partition."
)


# ================================================================
# 34. VERIFY PARTITION DISJOINTNESS
# ================================================================

print_section(
    "24. Partition ID Disjointness"
)

dev_ids = set(
    dev["id"]
)

cal_ids = set(
    cal["id"]
)

test_ids = set(
    test["id"]
)


dev_cal_overlap = len(
    dev_ids.intersection(cal_ids)
)

dev_test_overlap = len(
    dev_ids.intersection(test_ids)
)

cal_test_overlap = len(
    cal_ids.intersection(test_ids)
)


print(
    f"Development ∩ Calibration : "
    f"{dev_cal_overlap}"
)

print(
    f"Development ∩ Test        : "
    f"{dev_test_overlap}"
)

print(
    f"Calibration ∩ Test         : "
    f"{cal_test_overlap}"
)


if dev_cal_overlap != 0:

    fail(
        "Development and calibration partitions "
        "share IDs."
    )


if dev_test_overlap != 0:

    fail(
        "Development and locked-test partitions "
        "share IDs."
    )


if cal_test_overlap != 0:

    fail(
        "Calibration and locked-test partitions "
        "share IDs."
    )


print(
    "PASS: All three partitions are ID-disjoint."
)


# ================================================================
# 35. VERIFY TOTAL PARTITION COVERAGE
# ================================================================

print_section(
    "25. Partition Coverage"
)

all_partition_ids = (
    dev_ids
    |
    cal_ids
    |
    test_ids
)


total_partition_rows = (
    len(dev)
    +
    len(cal)
    +
    len(test)
)


print(
    f"Development rows       : {len(dev):,}"
)

print(
    f"Calibration rows        : {len(cal):,}"
)

print(
    f"Locked-test rows        : {len(test):,}"
)

print(
    f"Total partition rows   : {total_partition_rows:,}"
)

print(
    f"Unique partition IDs    : {len(all_partition_ids):,}"
)


expected_total = sum(
    EXPECTED_PARTITION_SIZES.values()
)


if total_partition_rows != expected_total:

    fail(
        f"Total partition rows "
        f"({total_partition_rows:,}) do not equal "
        f"expected total ({expected_total:,})."
    )


if len(all_partition_ids) != expected_total:

    fail(
        "Unique partition IDs do not equal the "
        "expected total number of records."
    )


print(
    "PASS: Partition coverage is complete and disjoint."
)


# ================================================================
# 36. VERIFY GROUPS DO NOT USE TARGET
# ================================================================

print_section(
    "26. Final Leakage Audit"
)

leakage_checks = {

    "target_in_predictor_list":
        TARGET in FEATURES,

    "target_in_clinical_groups":
        any(
            TARGET in group_features
            for group_features
            in CLINICAL_GROUPS.values()
        ),

    "calibration_used_for_group_definition":
        False,

    "locked_test_used_for_group_definition":
        False,

    "feature_selection_used_for_group_definition":
        False,

    "ADASYN_used_for_group_definition":
        False,

    "model_training_performed":
        False,

}


for check_name, check_value in \
        leakage_checks.items():

    print(
        f"{check_name:<45}: "
        f"{check_value}"
    )


if leakage_checks[
    "target_in_predictor_list"
]:

    fail(
        "Target appears in predictor list."
    )


if leakage_checks[
    "target_in_clinical_groups"
]:

    fail(
        "Target appears in clinical groups."
    )


if leakage_checks[
    "calibration_used_for_group_definition"
]:

    fail(
        "Calibration data were used to define groups."
    )


if leakage_checks[
    "locked_test_used_for_group_definition"
]:

    fail(
        "Locked-test data were used to define groups."
    )


if leakage_checks[
    "feature_selection_used_for_group_definition"
]:

    fail(
        "Feature selection was used to define groups."
    )


if leakage_checks[
    "ADASYN_used_for_group_definition"
]:

    fail(
        "ADASYN was used during group definition."
    )


if leakage_checks[
    "model_training_performed"
]:

    fail(
        "Model training was unexpectedly performed."
    )


print(
    "PASS: No leakage pathway was introduced by Audit 19."
)


# ================================================================
# 37. SAVE GROUP SUMMARY
# ================================================================

print_section(
    "27. Saving Audit Tables"
)

GROUP_SUMMARY_FILE = (
    RESULTS_TABLES
    /
    "audit19_clinical_group_summary.csv"
)

FEATURE_MAPPING_FILE = (
    RESULTS_TABLES
    /
    "audit19_feature_to_clinical_group_mapping.csv"
)

MISSINGNESS_FILE = (
    RESULTS_TABLES
    /
    "audit19_group_feature_missingness.csv"
)

GROUP_MISSINGNESS_FILE = (
    RESULTS_TABLES
    /
    "audit19_group_level_missingness.csv"
)

TARGET_FILE = (
    RESULTS_TABLES
    /
    "audit19_target_distribution.csv"
)

DTYPE_FILE = (
    RESULTS_TABLES
    /
    "audit19_feature_dtypes.csv"
)


group_summary_df.to_csv(
    GROUP_SUMMARY_FILE,
    index=False
)

feature_mapping_df.to_csv(
    FEATURE_MAPPING_FILE,
    index=False
)

missingness_df.to_csv(
    MISSINGNESS_FILE,
    index=False
)

group_missingness_df.to_csv(
    GROUP_MISSINGNESS_FILE,
    index=False
)

target_summary_df.to_csv(
    TARGET_FILE,
    index=False
)

dtype_df.to_csv(
    DTYPE_FILE,
    index=False
)


print(
    f"Saved: {GROUP_SUMMARY_FILE}"
)

print(
    f"Saved: {FEATURE_MAPPING_FILE}"
)

print(
    f"Saved: {MISSINGNESS_FILE}"
)

print(
    f"Saved: {GROUP_MISSINGNESS_FILE}"
)

print(
    f"Saved: {TARGET_FILE}"
)

print(
    f"Saved: {DTYPE_FILE}"
)


# ================================================================
# 38. SAVE FROZEN CONFIGURATION
# ================================================================

print_section(
    "28. Saving Frozen Clinical Group Configuration"
)


frozen_configuration = {

    "audit":
        "Audit 19",

    "audit_status":
        "PASS",

    "project":
        "CVD_CGS_ChebKAN",

    "timestamp":
        datetime.now().isoformat(),

    "primary_feature_strategy":
        "FULL_11_FEATURE_REPRESENTATION",

    "target":
        TARGET,

    "predictors":
        FEATURES,

    "n_predictors":
        len(FEATURES),

    "clinical_groups":
        CLINICAL_GROUPS,

    "group_labels":
        GROUP_LABELS,

    "group_sizes": {

        group_name:
            len(group_features)

        for group_name, group_features
        in CLINICAL_GROUPS.items()

    },

    "partition_sizes":
        EXPECTED_PARTITION_SIZES,

    "methodological_notes": [

        "The primary Kaggle representation uses all 11 predictors.",

        "Clinical grouping is defined independently of model-based "
        "feature selection.",

        "Feature selection remains a controlled ablation/sensitivity "
        "analysis.",

        "Every primary predictor belongs to exactly one clinical group.",

        "The target variable is excluded from all clinical groups.",

        "No symptomatic/diagnostic group is invented for the Kaggle "
        "dataset because the required variables are not present.",

        "No ADASYN is used in the primary pipeline.",

        "No model training is performed during this audit.",

        "The conformal calibration partition remains untouched.",

        "The locked test partition remains untouched.",

    ],

    "leakage_checks":
        leakage_checks,

    "status":
        "FROZEN_FOR_ARCHITECTURE_DESIGN",

}


CONFIG_FILE = (
    RESULTS_TABLES
    /
    "audit19_frozen_clinical_group_configuration.json"
)


with open(
    CONFIG_FILE,
    "w",
    encoding="utf-8"
) as config_handle:

    json.dump(
        frozen_configuration,
        config_handle,
        indent=4
    )


print(
    f"Saved: {CONFIG_FILE}"
)


# ================================================================
# 39. SAVE HUMAN-READABLE AUDIT LOG
# ================================================================

AUDIT_LOG_FILE = (
    RESULTS_LOGS
    /
    "audit19_clinical_group_mapping_audit.txt"
)


with open(
    AUDIT_LOG_FILE,
    "w",
    encoding="utf-8"
) as log_handle:

    log_handle.write(
        "AUDIT 19: CLINICAL GROUP DEFINITION AND "
        "FEATURE MAPPING\n"
    )

    log_handle.write(
        "=" * 72
        + "\n"
    )

    log_handle.write(
        f"Timestamp: "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    )

    log_handle.write(
        "Frozen predictors:\n"
    )

    for feature in FEATURES:

        log_handle.write(
            f"  - {feature}\n"
        )

    log_handle.write(
        "\nClinical groups:\n"
    )

    for group_name, group_features in \
            CLINICAL_GROUPS.items():

        log_handle.write(
            f"\n{GROUP_LABELS[group_name]}:\n"
        )

        for feature in group_features:

            log_handle.write(
                f"  - {feature}\n"
            )

    log_handle.write(
        "\nTarget:\n"
    )

    log_handle.write(
        f"  {TARGET}\n"
    )

    log_handle.write(
        "\nPartition sizes:\n"
    )

    for partition_name, size in \
            EXPECTED_PARTITION_SIZES.items():

        log_handle.write(
            f"  {partition_name}: "
            f"{size:,}\n"
        )

    log_handle.write(
        "\nLeakage checks:\n"
    )

    for check_name, check_value in \
            leakage_checks.items():

        log_handle.write(
            f"  {check_name}: "
            f"{check_value}\n"
        )

    log_handle.write(
        "\nFINAL STATUS: AUDIT 19 PASS\n"
    )


print(
    f"Saved: {AUDIT_LOG_FILE}"
)


# ================================================================
# 40. FINAL AUDIT REPORT
# ================================================================

print_section(
    "AUDIT 19 FINAL RESULT"
)

print()
print(
    "FROZEN PRIMARY FEATURE REPRESENTATION"
)

print(
    "-" * 72
)

for index, feature in enumerate(
    FEATURES,
    start=1
):

    print(
        f"{index:2d}. {feature}"
    )


print()
print(
    "FROZEN CLINICAL GROUPS"
)

print(
    "-" * 72
)


for group_name, group_features in \
        CLINICAL_GROUPS.items():

    print(
        f"\n{GROUP_LABELS[group_name]}"
        f" ({len(group_features)} features)"
    )

    print(
        "  "
        + ", ".join(group_features)
    )


print()
print(
    "AUDIT CHECKS"
)

print(
    "-" * 72
)

print(
    "PASS: Exactly 11 predictors defined."
)

print(
    "PASS: Every predictor assigned exactly once."
)

print(
    "PASS: No duplicate group assignments."
)

print(
    "PASS: Target excluded from predictor list."
)

print(
    "PASS: Target excluded from clinical groups."
)

print(
    "PASS: No completely missing predictors."
)

print(
    "PASS: Binary target verified."
)

print(
    "PASS: No duplicate IDs within partitions."
)

print(
    "PASS: Development/calibration/test IDs are disjoint."
)

print(
    "PASS: Partition coverage verified."
)

print(
    "PASS: Calibration data protected."
)

print(
    "PASS: Locked-test data protected."
)

print(
    "PASS: Feature selection not used to define grouping."
)

print(
    "PASS: ADASYN not used."
)

print(
    "PASS: No model training performed."
)

print()
print(
    "=" * 72
)

print(
    "AUDIT 19 PASS"
)

print(
    "=" * 72
)

print()
print(
    "Clinical grouping is now frozen for the CGS-ChebKAN "
    "architecture design."
)

print()
print(
    "Next step:"
)

print(
    "Define the exact CGS-ChebKAN architecture, "
    "data flow, equations, sparse fusion mechanism, "
    "and Chebyshev basis implementation before training."
)

print()