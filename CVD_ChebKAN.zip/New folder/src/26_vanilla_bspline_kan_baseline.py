# ================================================================
# IMPLEMENTATION 26
# VANILLA B-SPLINE KAN BASELINE
# ================================================================

from pathlib import Path
import copy
import json
import platform
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ----------------------------------------------------------------
# PyTorch
# ----------------------------------------------------------------
try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except ImportError as exc:
    raise ImportError(
        "PyTorch is required. Install it with: pip install torch"
    ) from exc

# ----------------------------------------------------------------
# Scikit-learn
# ----------------------------------------------------------------
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
)


# ================================================================
# 1. PROJECT CONFIGURATION
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)

DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
CAL_FILE = DATA_DIR / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"

TARGET = "cardio"

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

N_FEATURES = len(FEATURES)

RANDOM_STATE = 2026

N_OUTER_SPLITS = 5
N_INNER_SPLITS = 4

# Vanilla KAN architecture
HIDDEN_DIM = 16

# Cubic B-spline
SPLINE_DEGREE = 3

# Candidate hyperparameters
GRID_SIZES = [5, 8]
LEARNING_RATES = [1e-3, 3e-4]
L2_VALUES = [1e-5, 1e-4, 1e-3]

# Training
MAX_EPOCHS = 150
BATCH_SIZE = 512
PATIENCE = 15
MIN_DELTA = 1e-5

# Internal validation used only for early stopping inside
# each individual model fit.
INTERNAL_VALIDATION_FRACTION = 0.10

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# ================================================================
# 2. OUTPUT FILES
# ================================================================

OUTER_RESULTS_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_outer_fold_results.csv"
)

AGGREGATE_RESULTS_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_aggregate_results.csv"
)

HYPERPARAMETER_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_selected_hyperparameters.csv"
)

POOLED_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_pooled_outer_cv.csv"
)

PREDICTIONS_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_outer_predictions.csv"
)

EXPERIMENT_FILE = (
    RESULTS_DIR /
    "implementation26_bspline_kan_experiment_record.json"
)


# ================================================================
# 3. RANDOM SEED
# ================================================================

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(RANDOM_STATE)


# ================================================================
# 4. UTILITY FUNCTIONS
# ================================================================

def print_header(title):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def calculate_ece(y_true, y_prob, n_bins=10):
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)

    bin_edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    for i in range(n_bins):

        lower = bin_edges[i]
        upper = bin_edges[i + 1]

        if i == n_bins - 1:
            mask = (
                (y_prob >= lower) &
                (y_prob <= upper)
            )
        else:
            mask = (
                (y_prob >= lower) &
                (y_prob < upper)
            )

        if not np.any(mask):
            continue

        bin_accuracy = np.mean(
            y_true[mask]
        )

        bin_confidence = np.mean(
            y_prob[mask]
        )

        bin_fraction = np.mean(mask)

        ece += (
            bin_fraction *
            abs(
                bin_accuracy -
                bin_confidence
            )
        )

    return float(ece)


def calculate_metrics(y_true, y_prob):
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)

    y_pred = (
        y_prob >= 0.50
    ).astype(int)

    accuracy = accuracy_score(
        y_true,
        y_pred
    )

    precision = precision_score(
        y_true,
        y_pred,
        zero_division=0
    )

    sensitivity = recall_score(
        y_true,
        y_pred,
        zero_division=0
    )

    tn = np.sum(
        (y_true == 0) &
        (y_pred == 0)
    )

    fp = np.sum(
        (y_true == 0) &
        (y_pred == 1)
    )

    if (tn + fp) > 0:
        specificity = tn / (tn + fp)
    else:
        specificity = 0.0

    f1 = f1_score(
        y_true,
        y_pred,
        zero_division=0
    )

    roc_auc = roc_auc_score(
        y_true,
        y_prob
    )

    pr_auc = average_precision_score(
        y_true,
        y_prob
    )

    brier = brier_score_loss(
        y_true,
        y_prob
    )

    ece = calculate_ece(
        y_true,
        y_prob
    )

    return {
        "Accuracy": accuracy,
        "Precision": precision,
        "Sensitivity": sensitivity,
        "Specificity": specificity,
        "F1": f1,
        "ROC-AUC": roc_auc,
        "PR-AUC": pr_auc,
        "Brier": brier,
        "ECE": ece,
    }


# ================================================================
# 5. B-SPLINE BASIS
# ================================================================

class BSplineBasis(nn.Module):
    """
    Cubic B-spline basis using the Cox-de Boor recursion.

    Input:
        [batch, n_features]

    Output:
        [batch, n_features, n_basis]
    """

    def __init__(
        self,
        grid_size=5,
        degree=3,
        xmin=-1.0,
        xmax=1.0,
    ):
        super().__init__()

        self.grid_size = grid_size
        self.degree = degree
        self.xmin = xmin
        self.xmax = xmax

        internal_knots = torch.linspace(
            xmin,
            xmax,
            grid_size + 1
        )

        left_extension = torch.full(
            (degree,),
            xmin
        )

        right_extension = torch.full(
            (degree,),
            xmax
        )

        knots = torch.cat(
            [
                left_extension,
                internal_knots,
                right_extension,
            ]
        )

        self.register_buffer(
            "knots",
            knots
        )

        self.n_basis = (
            len(knots) -
            degree -
            1
        )

    def forward(self, x):

        x = torch.clamp(
            x,
            self.xmin,
            self.xmax
        )

        knots = self.knots
        degree = self.degree

        # Degree 0 basis
        basis = (
            (
                x.unsqueeze(-1) >= knots[:-1]
            )
            &
            (
                x.unsqueeze(-1) < knots[1:]
            )
        ).to(x.dtype)

        # Include right endpoint x = xmax
        right_boundary = (
            x == self.xmax
        )

        if torch.any(right_boundary):
            basis[..., -1] = torch.where(
                right_boundary,
                torch.ones_like(x),
                basis[..., -1]
            )

        # Cox-de Boor recursion
        for d in range(1, degree + 1):

            n_current = (
                basis.shape[-1] - 1
            )

            left_den = (
                knots[d:d + n_current]
                -
                knots[:n_current]
            )

            right_den = (
                knots[d + 1:d + 1 + n_current]
                -
                knots[1:1 + n_current]
            )

            left_num = (
                x.unsqueeze(-1)
                -
                knots[:n_current]
            )

            right_num = (
                knots[d + 1:d + 1 + n_current]
                -
                x.unsqueeze(-1)
            )

            left_den_safe = torch.where(
                left_den != 0,
                left_den,
                torch.ones_like(left_den)
            )

            right_den_safe = torch.where(
                right_den != 0,
                right_den,
                torch.ones_like(right_den)
            )

            left_term = (
                left_num /
                left_den_safe
            )

            right_term = (
                right_num /
                right_den_safe
            )

            left_term = torch.where(
                left_den != 0,
                left_term,
                torch.zeros_like(left_term)
            )

            right_term = torch.where(
                right_den != 0,
                right_term,
                torch.zeros_like(right_term)
            )

            basis = (
                left_term * basis[..., :-1]
                +
                right_term * basis[..., 1:]
            )

        return basis


# ================================================================
# 6. B-SPLINE KAN LAYER
# ================================================================

class BSplineKANLayer(nn.Module):
    """
    Dense B-spline KAN layer.

    Each input-output edge contains a univariate B-spline:

        phi_ij(x_i) =
            sum_k c_ijk B_k(x_i)

    Output:

        y_j =
            sum_i phi_ij(x_i)
            + bias_j
    """

    def __init__(
        self,
        in_features,
        out_features,
        grid_size=5,
        degree=3,
    ):
        super().__init__()

        self.in_features = in_features
        self.out_features = out_features

        self.basis = BSplineBasis(
            grid_size=grid_size,
            degree=degree
        )

        n_basis = self.basis.n_basis

        self.coefficients = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                n_basis
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(out_features)
        )

        self.reset_parameters()

    def reset_parameters(self):

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02
        )

        nn.init.zeros_(
            self.bias
        )

    def forward(self, x):

        basis = self.basis(x)

        output = torch.einsum(
            "bik,oik->bo",
            basis,
            self.coefficients
        )

        output = (
            output +
            self.bias
        )

        return output


# ================================================================
# 7. VANILLA B-SPLINE KAN
# ================================================================

class VanillaBSplineKAN(nn.Module):
    """
    Vanilla B-spline KAN.

    Architecture:

        11 input features
              |
              v
        B-spline KAN
            11 -> 16
              |
            SiLU
              |
              v
        B-spline KAN
             16 -> 1
              |
              v
           logit
    """

    def __init__(
        self,
        input_dim,
        hidden_dim,
        grid_size,
        degree,
    ):
        super().__init__()

        self.layer1 = BSplineKANLayer(
            in_features=input_dim,
            out_features=hidden_dim,
            grid_size=grid_size,
            degree=degree
        )

        self.layer2 = BSplineKANLayer(
            in_features=hidden_dim,
            out_features=1,
            grid_size=grid_size,
            degree=degree
        )

    def forward(self, x):

        x = self.layer1(x)

        x = F.silu(x)

        x = self.layer2(x)

        return x.squeeze(-1)


def count_parameters(model):
    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ================================================================
# 8. PREPROCESSING
# ================================================================

def fit_preprocessor(X_train):

    imputer = SimpleImputer(
        strategy="median"
    )

    X_train_imputed = (
        imputer.fit_transform(
            X_train
        )
    )

    scaler = MinMaxScaler(
        feature_range=(-1.0, 1.0)
    )

    X_train_scaled = (
        scaler.fit_transform(
            X_train_imputed
        )
    )

    return (
        imputer,
        scaler,
        X_train_scaled.astype(
            np.float32
        )
    )


def transform_data(
    X,
    imputer,
    scaler
):

    X_imputed = (
        imputer.transform(X)
    )

    X_scaled = (
        scaler.transform(
            X_imputed
        )
    )

    X_scaled = np.clip(
        X_scaled,
        -1.0,
        1.0
    )

    return X_scaled.astype(
        np.float32
    )


# ================================================================
# 9. TRAIN ONE KAN MODEL
# ================================================================

def train_model(
    X_train,
    y_train,
    grid_size,
    learning_rate,
    l2,
    seed,
):
    set_seed(seed)

    model = VanillaBSplineKAN(
        input_dim=N_FEATURES,
        hidden_dim=HIDDEN_DIM,
        grid_size=grid_size,
        degree=SPLINE_DEGREE,
    ).to(DEVICE)

    n_samples = len(X_train)

    # ------------------------------------------------------------
    # Stratified internal validation split for early stopping
    # ------------------------------------------------------------

    rng = np.random.RandomState(seed)

    indices = np.arange(
        n_samples
    )

    class0_idx = indices[
        y_train == 0
    ]

    class1_idx = indices[
        y_train == 1
    ]

    rng.shuffle(class0_idx)
    rng.shuffle(class1_idx)

    val_n0 = max(
        1,
        int(
            len(class0_idx) *
            INTERNAL_VALIDATION_FRACTION
        )
    )

    val_n1 = max(
        1,
        int(
            len(class1_idx) *
            INTERNAL_VALIDATION_FRACTION
        )
    )

    val_idx = np.concatenate(
        [
            class0_idx[:val_n0],
            class1_idx[:val_n1],
        ]
    )

    train_idx = np.setdiff1d(
        indices,
        val_idx
    )

    X_fit = X_train[
        train_idx
    ]

    y_fit = y_train[
        train_idx
    ]

    X_val = X_train[
        val_idx
    ]

    y_val = y_train[
        val_idx
    ]

    X_fit_tensor = torch.tensor(
        X_fit,
        dtype=torch.float32,
        device=DEVICE
    )

    y_fit_tensor = torch.tensor(
        y_fit,
        dtype=torch.float32,
        device=DEVICE
    )

    X_val_tensor = torch.tensor(
        X_val,
        dtype=torch.float32,
        device=DEVICE
    )

    y_val_tensor = torch.tensor(
        y_val,
        dtype=torch.float32,
        device=DEVICE
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=l2
    )

    criterion = nn.BCEWithLogitsLoss()

    best_state = None
    best_val_loss = np.inf
    best_epoch = 1
    patience_counter = 0

    n_fit = len(X_fit)

    # ------------------------------------------------------------
    # Training
    # ------------------------------------------------------------

    for epoch in range(
        1,
        MAX_EPOCHS + 1
    ):

        model.train()

        permutation = torch.randperm(
            n_fit,
            device=DEVICE
        )

        for start in range(
            0,
            n_fit,
            BATCH_SIZE
        ):

            batch_idx = permutation[
                start:start + BATCH_SIZE
            ]

            xb = X_fit_tensor[
                batch_idx
            ]

            yb = y_fit_tensor[
                batch_idx
            ]

            optimizer.zero_grad()

            logits = model(xb)

            loss = criterion(
                logits,
                yb
            )

            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=5.0
            )

            optimizer.step()

        # --------------------------------------------------------
        # Internal validation
        # --------------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                X_val_tensor
            )

            val_loss = criterion(
                val_logits,
                y_val_tensor
            ).item()

        improvement = (
            best_val_loss -
            val_loss
        )

        if improvement > MIN_DELTA:

            best_val_loss = val_loss

            best_state = copy.deepcopy(
                model.state_dict()
            )

            best_epoch = epoch

            patience_counter = 0

        else:

            patience_counter += 1

        if patience_counter >= PATIENCE:
            break

    # ------------------------------------------------------------
    # Restore best model
    # ------------------------------------------------------------

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    model.eval()

    return (
        model,
        best_epoch,
        best_val_loss
    )


# ================================================================
# 10. PREDICTION
# ================================================================

def predict_probability(
    model,
    X
):

    X_tensor = torch.tensor(
        X,
        dtype=torch.float32,
        device=DEVICE
    )

    model.eval()

    with torch.no_grad():

        logits = model(
            X_tensor
        )

        probabilities = torch.sigmoid(
            logits
        )

    return (
        probabilities
        .detach()
        .cpu()
        .numpy()
    )


# ================================================================
# 11. INNER-CV HYPERPARAMETER SEARCH
# ================================================================

def inner_cv_search(
    X_outer_train,
    y_outer_train,
    outer_fold
):

    best_auc = -np.inf
    best_params = None

    search_records = []

    configurations = []

    for grid_size in GRID_SIZES:

        for learning_rate in LEARNING_RATES:

            for l2 in L2_VALUES:

                configurations.append(
                    {
                        "grid_size": grid_size,
                        "learning_rate": learning_rate,
                        "l2": l2,
                    }
                )

    total_configs = len(
        configurations
    )

    for config_number, params in enumerate(
        configurations,
        start=1
    ):

        fold_auc = []

        for inner_fold, (
            inner_train_idx,
            inner_val_idx
        ) in enumerate(
            inner_cv.split(
                X_outer_train,
                y_outer_train
            ),
            start=1
        ):

            X_inner_train_raw = (
                X_outer_train.iloc[
                    inner_train_idx
                ]
            )

            X_inner_val_raw = (
                X_outer_train.iloc[
                    inner_val_idx
                ]
            )

            y_inner_train = (
                y_outer_train[
                    inner_train_idx
                ]
            )

            y_inner_val = (
                y_outer_train[
                    inner_val_idx
                ]
            )

            # ----------------------------------------------------
            # Fold-specific preprocessing
            # ----------------------------------------------------

            (
                imputer,
                scaler,
                X_inner_train
            ) = fit_preprocessor(
                X_inner_train_raw
            )

            X_inner_val = transform_data(
                X_inner_val_raw,
                imputer,
                scaler
            )

            # ----------------------------------------------------
            # Train
            # ----------------------------------------------------

            model, _, _ = train_model(
                X_inner_train,
                y_inner_train,
                grid_size=params[
                    "grid_size"
                ],
                learning_rate=params[
                    "learning_rate"
                ],
                l2=params["l2"],
                seed=(
                    RANDOM_STATE
                    + outer_fold * 100
                    + config_number * 10
                    + inner_fold
                )
            )

            # ----------------------------------------------------
            # Validate
            # ----------------------------------------------------

            y_prob = predict_probability(
                model,
                X_inner_val
            )

            auc = roc_auc_score(
                y_inner_val,
                y_prob
            )

            fold_auc.append(
                auc
            )

        mean_auc = float(
            np.mean(fold_auc)
        )

        sd_auc = float(
            np.std(
                fold_auc,
                ddof=1
            )
        )

        search_records.append(
            {
                "outer_fold": outer_fold,
                "grid_size": params[
                    "grid_size"
                ],
                "learning_rate": params[
                    "learning_rate"
                ],
                "l2": params["l2"],
                "mean_inner_auc": mean_auc,
                "sd_inner_auc": sd_auc,
            }
        )

        print(
            f"      Config "
            f"{config_number}/{total_configs}: "
            f"grid={params['grid_size']}, "
            f"lr={params['learning_rate']}, "
            f"L2={params['l2']}, "
            f"AUC={mean_auc:.6f}"
        )

        if mean_auc > best_auc:

            best_auc = mean_auc

            best_params = params.copy()

    return (
        best_params,
        best_auc,
        search_records
    )


# ================================================================
# 12. ENVIRONMENT
# ================================================================

print_header(
    "IMPLEMENTATION 26 — "
    "VANILLA B-SPLINE KAN BASELINE"
)

print("Environment")
print("-" * 72)

print(
    "Python:",
    sys.version
)

print(
    "Platform:",
    platform.platform()
)

print(
    "NumPy:",
    np.__version__
)

print(
    "Pandas:",
    pd.__version__
)

print(
    "PyTorch:",
    torch.__version__
)

print(
    "Device:",
    DEVICE
)

if torch.cuda.is_available():

    print(
        "GPU:",
        torch.cuda.get_device_name(0)
    )


# ================================================================
# 13. INPUT FILE VERIFICATION
# ================================================================

print_header(
    "1. INPUT FILE VERIFICATION"
)

for path in [
    DEV_FILE,
    CAL_FILE,
    TEST_FILE
]:

    if not path.exists():

        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )

    print(
        "EXISTS:",
        path
    )


# ================================================================
# 14. LOAD DATA
# ================================================================

print_header(
    "2. LOAD DATA"
)

dev = pd.read_csv(
    DEV_FILE
)

cal = pd.read_csv(
    CAL_FILE
)

test = pd.read_csv(
    TEST_FILE
)

print(
    "Development:",
    dev.shape
)

print(
    "Calibration:",
    cal.shape
)

print(
    "Locked test:",
    test.shape
)


# ================================================================
# 15. DATA VALIDATION
# ================================================================

print_header(
    "3. DATA VALIDATION"
)

expected_sizes = {
    "Development": 49000,
    "Calibration": 7000,
    "Locked test": 14000,
}

actual_sizes = {
    "Development": len(dev),
    "Calibration": len(cal),
    "Locked test": len(test),
}

for name in expected_sizes:

    if (
        actual_sizes[name]
        !=
        expected_sizes[name]
    ):

        raise AssertionError(
            f"{name} size mismatch."
        )

    print(
        f"{name}: "
        f"{actual_sizes[name]} rows -> PASS"
    )


for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test),
]:

    if TARGET not in df.columns:

        raise AssertionError(
            f"Target missing in {name}"
        )

    if df[TARGET].isna().any():

        raise AssertionError(
            f"Missing target in {name}"
        )

    target_values = sorted(
        df[TARGET].unique().tolist()
    )

    if target_values != [0, 1]:

        raise AssertionError(
            f"Unexpected target values "
            f"in {name}: {target_values}"
        )

    for feature in FEATURES:

        if feature not in df.columns:

            raise AssertionError(
                f"{feature} missing in {name}"
            )

print(
    f"All {N_FEATURES} predictors available -> PASS"
)

print(
    "Binary target -> PASS"
)


# ================================================================
# 16. TARGET DISTRIBUTION
# ================================================================

print_header(
    "4. TARGET DISTRIBUTION"
)

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test),
]:

    counts = (
        df[TARGET]
        .value_counts()
        .sort_index()
    )

    print(
        f"{name}: "
        f"class 0 = {counts.get(0, 0)}, "
        f"class 1 = {counts.get(1, 0)}"
    )


# ================================================================
# 17. PARTITION DISJOINTNESS
# ================================================================

print_header(
    "5. PARTITION DISJOINTNESS"
)

if "id" not in dev.columns:

    raise AssertionError(
        "ID column is required."
    )

dev_ids = set(
    dev["id"]
)

cal_ids = set(
    cal["id"]
)

test_ids = set(
    test["id"]
)

overlap_dev_cal = len(
    dev_ids.intersection(
        cal_ids
    )
)

overlap_dev_test = len(
    dev_ids.intersection(
        test_ids
    )
)

overlap_cal_test = len(
    cal_ids.intersection(
        test_ids
    )
)

print(
    "Development × Calibration:",
    overlap_dev_cal
)

print(
    "Development × Test:",
    overlap_dev_test
)

print(
    "Calibration × Test:",
    overlap_cal_test
)

if any(
    [
        overlap_dev_cal,
        overlap_dev_test,
        overlap_cal_test,
    ]
):

    raise AssertionError(
        "Partition overlap detected."
    )

print(
    "Partition disjointness -> PASS"
)


# ================================================================
# 18. MISSINGNESS
# ================================================================

print_header(
    "6. MISSINGNESS AUDIT"
)

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test),
]:

    missing = (
        df[FEATURES]
        .isna()
        .sum()
    )

    print(f"\n{name}")

    for feature, count in missing.items():

        if count > 0:

            percentage = (
                100.0 *
                count /
                len(df)
            )

            print(
                f"  {feature}: "
                f"{count} "
                f"({percentage:.4f}%)"
            )


# ================================================================
# 19. PROTOCOL
# ================================================================

print_header(
    "7. FROZEN B-SPLINE KAN PROTOCOL"
)

print(
    "Features:",
    N_FEATURES
)

print(
    "Architecture:",
    f"{N_FEATURES} -> "
    f"{HIDDEN_DIM} -> 1"
)

print(
    "Basis: Cubic B-spline"
)

print(
    "Clinical grouping: NO"
)

print(
    "Sparse group gates: NO"
)

print(
    "ADASYN: NO"
)

print(
    "Conformal prediction: NO"
)

print(
    "Median imputation: fold-specific"
)

print(
    "Normalization: fold-specific MinMax "
    "to [-1, 1]"
)

print(
    "Outer CV: 5 folds"
)

print(
    "Inner CV: 4 folds"
)

print(
    "Calibration set: PROTECTED"
)

print(
    "Locked test: PROTECTED"
)


# ================================================================
# 20. DEVELOPMENT DATA
# ================================================================

X_dev = dev[
    FEATURES
].copy()

y_dev = dev[
    TARGET
].astype(int).copy()


# ================================================================
# 21. CV OBJECTS
# ================================================================

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)

inner_cv = StratifiedKFold(
    n_splits=N_INNER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)


# ================================================================
# 22. OUTER CV
# ================================================================

print_header(
    "8. NESTED 5 × 4 CROSS-VALIDATION"
)

outer_results = []
hyperparameter_results = []
prediction_frames = []
inner_search_results = []

for outer_fold, (
    outer_train_idx,
    outer_val_idx
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev
    ),
    start=1
):

    print("\n" + "-" * 72)

    print(
        f"OUTER FOLD "
        f"{outer_fold}/{N_OUTER_SPLITS}"
    )

    print("-" * 72)

    X_outer_train = (
        X_dev.iloc[
            outer_train_idx
        ].copy()
    )

    X_outer_val = (
        X_dev.iloc[
            outer_val_idx
        ].copy()
    )

    y_outer_train = (
        y_dev.iloc[
            outer_train_idx
        ].to_numpy()
    )

    y_outer_val = (
        y_dev.iloc[
            outer_val_idx
        ].to_numpy()
    )

    print(
        "Training rows:",
        len(X_outer_train)
    )

    print(
        "Validation rows:",
        len(X_outer_val)
    )

    # ------------------------------------------------------------
    # Inner CV
    # ------------------------------------------------------------

    print(
        "\nInner-CV hyperparameter search:"
    )

    (
        best_params,
        best_inner_auc,
        search_records,
    ) = inner_cv_search(
        X_outer_train,
        y_outer_train,
        outer_fold
    )

    inner_search_results.extend(
        search_records
    )

    print(
        "\nBest inner-CV ROC-AUC:",
        f"{best_inner_auc:.6f}"
    )

    print(
        "Selected hyperparameters:"
    )

    print(
        "  grid_size:",
        best_params["grid_size"]
    )

    print(
        "  learning_rate:",
        best_params["learning_rate"]
    )

    print(
        "  l2:",
        best_params["l2"]
    )

    # ------------------------------------------------------------
    # Outer training preprocessing
    # ------------------------------------------------------------

    (
        outer_imputer,
        outer_scaler,
        X_outer_train_processed
    ) = fit_preprocessor(
        X_outer_train
    )

    X_outer_val_processed = (
        transform_data(
            X_outer_val,
            outer_imputer,
            outer_scaler
        )
    )

    # ------------------------------------------------------------
    # Train selected configuration
    # ------------------------------------------------------------

    model, best_epoch, best_val_loss = (
        train_model(
            X_outer_train_processed,
            y_outer_train,
            grid_size=best_params[
                "grid_size"
            ],
            learning_rate=best_params[
                "learning_rate"
            ],
            l2=best_params["l2"],
            seed=(
                RANDOM_STATE +
                outer_fold
            ),
        )
    )

    parameter_count = count_parameters(
        model
    )

    print(
        "Best internal-validation epoch:",
        best_epoch
    )

    print(
        "Trainable parameters:",
        parameter_count
    )

    # ------------------------------------------------------------
    # Outer validation
    # ------------------------------------------------------------

    y_prob = predict_probability(
        model,
        X_outer_val_processed
    )

    metrics = calculate_metrics(
        y_outer_val,
        y_prob
    )

    print(
        "\nOuter validation metrics:"
    )

    for metric_name, value in metrics.items():

        print(
            f"  {metric_name}: "
            f"{value:.6f}"
        )

    # ------------------------------------------------------------
    # Store fold results
    # ------------------------------------------------------------

    outer_results.append(
        {
            "fold": outer_fold,
            "inner_best_roc_auc": best_inner_auc,
            "best_epoch": best_epoch,
            "parameter_count": parameter_count,
            "grid_size": best_params[
                "grid_size"
            ],
            "learning_rate": best_params[
                "learning_rate"
            ],
            "l2": best_params["l2"],
            **metrics,
        }
    )

    hyperparameter_results.append(
        {
            "fold": outer_fold,
            "inner_best_roc_auc": best_inner_auc,
            "best_epoch": best_epoch,
            "parameter_count": parameter_count,
            "grid_size": best_params[
                "grid_size"
            ],
            "learning_rate": best_params[
                "learning_rate"
            ],
            "l2": best_params["l2"],
        }
    )

    # ------------------------------------------------------------
    # Store predictions
    # ------------------------------------------------------------

    prediction_frames.append(
        pd.DataFrame(
            {
                "fold": outer_fold,
                "id": dev.iloc[
                    outer_val_idx
                ]["id"].to_numpy(),
                "y_true": y_outer_val,
                "y_prob": y_prob,
            }
        )
    )


# ================================================================
# 23. CREATE RESULT DATAFRAMES
# ================================================================

outer_results_df = pd.DataFrame(
    outer_results
)

hyperparameters_df = pd.DataFrame(
    hyperparameter_results
)

predictions_df = pd.concat(
    prediction_frames,
    ignore_index=True
)

inner_search_df = pd.DataFrame(
    inner_search_results
)


# ================================================================
# 24. OUTER COVERAGE
# ================================================================

print_header(
    "9. OUTER-CV COVERAGE CHECK"
)

print(
    "Expected Development predictions:",
    len(dev)
)

print(
    "Actual outer-CV predictions:",
    len(predictions_df)
)

if len(predictions_df) != len(dev):

    raise AssertionError(
        "Outer prediction count mismatch."
    )

unique_prediction_ids = (
    predictions_df["id"].nunique()
)

print(
    "Unique prediction IDs:",
    unique_prediction_ids
)

if unique_prediction_ids != len(dev):

    raise AssertionError(
        "Development IDs were not "
        "predicted exactly once."
    )

print(
    "Every Development record appears "
    "exactly once -> PASS"
)


# ================================================================
# 25. AGGREGATE METRICS
# ================================================================

print_header(
    "10. AGGREGATE OUTER-CV RESULTS"
)

METRICS = [
    "Accuracy",
    "Precision",
    "Sensitivity",
    "Specificity",
    "F1",
    "ROC-AUC",
    "PR-AUC",
    "Brier",
    "ECE",
]

aggregate_rows = []

for metric in METRICS:

    values = (
        outer_results_df[
            metric
        ].astype(float)
    )

    aggregate_rows.append(
        {
            "Metric": metric,
            "Mean": values.mean(),
            "SD": values.std(
                ddof=1
            ),
        }
    )

aggregate_df = pd.DataFrame(
    aggregate_rows
)

for _, row in aggregate_df.iterrows():

    print(
        f"{row['Metric']}: "
        f"{row['Mean']:.6f} ± "
        f"{row['SD']:.6f}"
    )


# ================================================================
# 26. POOLED OUTER CV
# ================================================================

print_header(
    "11. POOLED OUTER-CV RESULTS"
)

pooled_metrics = calculate_metrics(
    predictions_df[
        "y_true"
    ].to_numpy(),
    predictions_df[
        "y_prob"
    ].to_numpy()
)

for metric_name, value in pooled_metrics.items():

    print(
        f"{metric_name}: "
        f"{value:.6f}"
    )


# ================================================================
# 27. HYPERPARAMETER STABILITY
# ================================================================

print_header(
    "12. HYPERPARAMETER STABILITY"
)

for column in [
    "grid_size",
    "learning_rate",
    "l2",
]:

    print(
        f"\n{column}"
    )

    counts = (
        hyperparameters_df[
            column
        ]
        .astype(str)
        .value_counts()
    )

    for value, count in counts.items():

        print(
            f"  {value}: "
            f"{count}/{N_OUTER_SPLITS}"
        )


# ================================================================
# 28. MODEL SIZE
# ================================================================

print_header(
    "13. MODEL SIZE"
)

parameter_counts = (
    hyperparameters_df[
        "parameter_count"
    ]
)

print(
    "Parameter count by fold:"
)

for value in parameter_counts:

    print(
        f"  {int(value)}"
    )

print(
    "Mean parameter count:",
    f"{parameter_counts.mean():.0f}"
)


# ================================================================
# 29. CALIBRATION / TEST PROTECTION
# ================================================================

print_header(
    "14. CALIBRATION / TEST PROTECTION"
)

prediction_ids = set(
    predictions_df["id"]
)

calibration_overlap = len(
    prediction_ids.intersection(
        cal_ids
    )
)

test_overlap = len(
    prediction_ids.intersection(
        test_ids
    )
)

print(
    "Outer-CV predictions × Calibration:",
    calibration_overlap
)

print(
    "Outer-CV predictions × Locked Test:",
    test_overlap
)

if calibration_overlap != 0:

    raise AssertionError(
        "Calibration contamination detected."
    )

if test_overlap != 0:

    raise AssertionError(
        "Locked-test contamination detected."
    )

print(
    "Calibration protection -> PASS"
)

print(
    "Locked-test protection -> PASS"
)


# ================================================================
# 30. SAVE RESULTS
# ================================================================

print_header(
    "15. SAVE RESULTS"
)

outer_results_df.to_csv(
    OUTER_RESULTS_FILE,
    index=False
)

aggregate_df.to_csv(
    AGGREGATE_RESULTS_FILE,
    index=False
)

hyperparameters_df.to_csv(
    HYPERPARAMETER_FILE,
    index=False
)

predictions_df.to_csv(
    PREDICTIONS_FILE,
    index=False
)

pooled_df = pd.DataFrame(
    [
        {
            "Metric": metric,
            "Pooled_Value": value,
        }
        for metric, value
        in pooled_metrics.items()
    ]
)

pooled_df.to_csv(
    POOLED_FILE,
    index=False
)


# ================================================================
# 31. EXPERIMENT RECORD
# ================================================================

experiment_record = {
    "implementation": "26",

    "model": "Vanilla B-spline KAN",

    "architecture": {
        "input_dimension": N_FEATURES,
        "hidden_dimension": HIDDEN_DIM,
        "output_dimension": 1,
        "layers": [
            f"{N_FEATURES} -> {HIDDEN_DIM}",
            f"{HIDDEN_DIM} -> 1",
        ],
        "basis": "Cubic B-spline",
        "degree": SPLINE_DEGREE,
        "grid_sizes": GRID_SIZES,
        "input_range": [-1.0, 1.0],
    },

    "features": FEATURES,

    "clinical_grouping": False,

    "sparse_group_gating": False,

    "conformal_prediction": False,

    "adasyn_primary": False,

    "random_state": RANDOM_STATE,

    "data": {
        "development_rows": len(dev),
        "calibration_rows": len(cal),
        "locked_test_rows": len(test),
    },

    "preprocessing": {
        "imputation": (
            "Median imputation fitted independently "
            "inside each training fold."
        ),
        "normalization": (
            "MinMaxScaler fitted independently "
            "inside each training fold and mapped "
            "to [-1, 1]."
        ),
        "global_imputation": False,
        "global_scaling": False,
    },

    "cross_validation": {
        "outer_folds": N_OUTER_SPLITS,
        "inner_folds": N_INNER_SPLITS,
        "outer_type": "StratifiedKFold",
        "inner_type": "StratifiedKFold",
        "shuffle": True,
        "random_state": RANDOM_STATE,
    },

    "training": {
        "optimizer": "Adam",
        "loss": "BCEWithLogitsLoss",
        "batch_size": BATCH_SIZE,
        "max_epochs": MAX_EPOCHS,
        "early_stopping": True,
        "internal_validation_fraction":
            INTERNAL_VALIDATION_FRACTION,
        "patience": PATIENCE,
    },

    "hyperparameter_grid": {
        "grid_size": GRID_SIZES,
        "learning_rate": LEARNING_RATES,
        "l2": L2_VALUES,
    },

    "model_selection_metric": "ROC-AUC",

    "metrics": METRICS,

    "calibration_set_used": False,

    "locked_test_used": False,

    "outer_cv_prediction_rows": len(
        predictions_df
    ),

    "pooled_outer_cv_metrics": {
        key: float(value)
        for key, value in pooled_metrics.items()
    },

    "aggregate_outer_cv": {
        row["Metric"]: {
            "mean": float(row["Mean"]),
            "sd": float(row["SD"]),
        }
        for _, row in aggregate_df.iterrows()
    },

    "status": "PASS",
}

with open(
    EXPERIMENT_FILE,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        experiment_record,
        file,
        indent=2
    )


# ================================================================
# 32. FINAL SUMMARY
# ================================================================

print_header(
    "IMPLEMENTATION 26 FINAL SUMMARY"
)

roc_mean = aggregate_df.loc[
    aggregate_df["Metric"] == "ROC-AUC",
    "Mean",
].iloc[0]

roc_sd = aggregate_df.loc[
    aggregate_df["Metric"] == "ROC-AUC",
    "SD",
].iloc[0]

print(
    "Vanilla B-spline KAN "
    "pooled outer-CV ROC-AUC:",
    f"{pooled_metrics['ROC-AUC']:.6f}"
)

print(
    "Vanilla B-spline KAN "
    "mean outer-CV ROC-AUC:",
    f"{roc_mean:.6f} ± {roc_sd:.6f}"
)

print(
    "Calibration set touched:",
    False
)

print(
    "Locked test touched:",
    False
)

print(
    "ADASYN used:",
    False
)

print(
    "Clinical grouping used:",
    False
)

print(
    "Sparse group gating used:",
    False
)

print(
    "Conformal prediction used:",
    False
)

print(
    "Status: PASS"
)

print("\nSaved files:")

print(
    OUTER_RESULTS_FILE
)

print(
    AGGREGATE_RESULTS_FILE
)

print(
    HYPERPARAMETER_FILE
)

print(
    POOLED_FILE
)

print(
    PREDICTIONS_FILE
)

print(
    EXPERIMENT_FILE
)

print(
    "\nImplementation 26 completed successfully."
)