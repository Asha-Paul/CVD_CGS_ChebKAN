# ================================================================
# AUDIT 09: KAGGLE BLOOD PRESSURE VALIDITY AUDIT
# ================================================================
# Purpose:
#   Quantify BP validity under predefined clinical plausibility rules.
#
# IMPORTANT:
#   - This script DOES NOT modify the dataset.
#   - This script DOES NOT delete records.
#   - This script DOES NOT impute missing values.
#   - This script only audits and reports.
#
# Proposed validity rules:
#   SBP: 70 <= ap_hi <= 250 mmHg
#   DBP: 40 <= ap_lo <= 150 mmHg
#   Valid BP pair additionally requires:
#       SBP > DBP
#
# Output categories:
#   1. Completely valid BP
#   2. Valid SBP + invalid DBP
#   3. Invalid SBP + valid DBP
#   4. Both SBP and DBP invalid
#   5. Valid individual BP values but reversed SBP <= DBP
#   6. Overall BP validity
#
# ================================================================

from pathlib import Path
import pandas as pd
import numpy as np


# ------------------------------------------------
# 1. Paths
# ------------------------------------------------

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_PATH = PROJECT_ROOT / "data" / "raw" / "kaggle" / "cardio_train 70k.csv"

RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_CSV = RESULTS_DIR / "audit09_bp_validity_summary.csv"


# ------------------------------------------------
# 2. Load dataset
# ------------------------------------------------

print("=" * 80)
print("AUDIT 09: KAGGLE BLOOD PRESSURE VALIDITY AUDIT")
print("=" * 80)

print("\nLoading dataset...")
print(DATA_PATH)

df = pd.read_csv(DATA_PATH, sep=",")

print(f"\nRows    : {len(df):,}")
print(f"Columns : {len(df.columns)}")


# ------------------------------------------------
# 3. Check required columns
# ------------------------------------------------

required_columns = ["ap_hi", "ap_lo"]

missing_columns = [
    col for col in required_columns
    if col not in df.columns
]

if missing_columns:
    raise ValueError(
        f"Required columns are missing: {missing_columns}"
    )


# ------------------------------------------------
# 4. Convert BP columns to numeric
# ------------------------------------------------

sbp = pd.to_numeric(df["ap_hi"], errors="coerce")
dbp = pd.to_numeric(df["ap_lo"], errors="coerce")


# ------------------------------------------------
# 5. Define proposed clinical validity ranges
# ------------------------------------------------

SBP_MIN = 70
SBP_MAX = 250

DBP_MIN = 40
DBP_MAX = 150


# ------------------------------------------------
# 6. Individual SBP / DBP validity
# ------------------------------------------------

sbp_missing = sbp.isna()
dbp_missing = dbp.isna()

sbp_valid = (
    sbp.notna()
    & (sbp >= SBP_MIN)
    & (sbp <= SBP_MAX)
)

dbp_valid = (
    dbp.notna()
    & (dbp >= DBP_MIN)
    & (dbp <= DBP_MAX)
)


# ------------------------------------------------
# 7. Basic BP validity categories
# ------------------------------------------------

valid_sbp_invalid_dbp = (
    sbp_valid
    & ~dbp_valid
)

invalid_sbp_valid_dbp = (
    ~sbp_valid
    & dbp_valid
)

both_invalid = (
    ~sbp_valid
    & ~dbp_valid
)

both_individually_valid = (
    sbp_valid
    & dbp_valid
)


# ------------------------------------------------
# 8. Check SBP > DBP
# ------------------------------------------------

bp_reversed = (
    both_individually_valid
    & (sbp <= dbp)
)

bp_correct_order = (
    both_individually_valid
    & (sbp > dbp)
)


# ------------------------------------------------
# 9. Final BP validity
# ------------------------------------------------

completely_valid_bp = bp_correct_order

overall_invalid_bp = ~completely_valid_bp


# ------------------------------------------------
# 10. Print summary
# ------------------------------------------------

N = len(df)


def print_count(label, mask):
    count = int(mask.sum())
    pct = 100 * count / N

    print(
        f"{label:<50} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


print("\n" + "=" * 80)
print("PROPOSED BP VALIDITY RULES")
print("=" * 80)

print(f"SBP valid range : {SBP_MIN} <= SBP <= {SBP_MAX} mmHg")
print(f"DBP valid range : {DBP_MIN} <= DBP <= {DBP_MAX} mmHg")
print("Pair requirement: SBP > DBP")


print("\n" + "=" * 80)
print("INDIVIDUAL BP VALIDITY")
print("=" * 80)

print_count("Valid SBP", sbp_valid)
print_count("Invalid SBP", ~sbp_valid)

print()
print_count("Valid DBP", dbp_valid)
print_count("Invalid DBP", ~dbp_valid)


print("\n" + "=" * 80)
print("COMBINATION OF SBP AND DBP VALIDITY")
print("=" * 80)

print_count(
    "Valid SBP + valid DBP",
    both_individually_valid
)

print_count(
    "Valid SBP + invalid DBP",
    valid_sbp_invalid_dbp
)

print_count(
    "Invalid SBP + valid DBP",
    invalid_sbp_valid_dbp
)

print_count(
    "Both SBP and DBP invalid",
    both_invalid
)


print("\n" + "=" * 80)
print("SBP / DBP ORDERING")
print("=" * 80)

print_count(
    "Both valid + SBP > DBP",
    bp_correct_order
)

print_count(
    "Both valid + SBP <= DBP",
    bp_reversed
)


print("\n" + "=" * 80)
print("FINAL BP VALIDITY")
print("=" * 80)

print_count(
    "Completely valid BP",
    completely_valid_bp
)

print_count(
    "Any BP validity problem",
    overall_invalid_bp
)


# ------------------------------------------------
# 11. Detailed mutually exclusive categories
# ------------------------------------------------
#
# These categories allow every record to be placed into
# exactly one BP-status category.

def classify_bp(row):
    s = row["ap_hi"]
    d = row["ap_lo"]

    s_valid = (
        pd.notna(s)
        and SBP_MIN <= s <= SBP_MAX
    )

    d_valid = (
        pd.notna(d)
        and DBP_MIN <= d <= DBP_MAX
    )

    if s_valid and d_valid:
        if s > d:
            return "Valid BP"
        else:
            return "Valid values but reversed SBP<=DBP"

    elif s_valid and not d_valid:
        return "Valid SBP + invalid DBP"

    elif not s_valid and d_valid:
        return "Invalid SBP + valid DBP"

    else:
        return "Both SBP and DBP invalid"


df["bp_audit_category"] = df.apply(
    classify_bp,
    axis=1
)


print("\n" + "=" * 80)
print("MUTUALLY EXCLUSIVE BP CATEGORIES")
print("=" * 80)

category_counts = (
    df["bp_audit_category"]
    .value_counts()
)

for category, count in category_counts.items():
    pct = 100 * count / N

    print(
        f"{category:<50} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ------------------------------------------------
# 12. Verify categories cover every record
# ------------------------------------------------

category_total = category_counts.sum()

print("\nCategory total:", f"{category_total:,}")
print("Dataset total :", f"{N:,}")

if category_total == N:
    print("PASS: Every record belongs to exactly one BP category.")
else:
    print("ERROR: Category counts do not sum to dataset size.")


# ------------------------------------------------
# 13. Examine reversed BP records
# ------------------------------------------------

print("\n" + "=" * 80)
print("REVERSED BP RECORDS: SBP <= DBP")
print("=" * 80)

reversed_df = df.loc[
    bp_reversed,
    ["id", "age", "gender", "ap_hi", "ap_lo", "cardio"]
].copy()

print(
    f"Number of reversed records: "
    f"{len(reversed_df):,}"
)

if len(reversed_df) > 0:
    print("\nFirst 20 examples:")
    print(
        reversed_df
        .head(20)
        .to_string(index=False)
    )


# ------------------------------------------------
# 14. Valid SBP + invalid DBP examples
# ------------------------------------------------

print("\n" + "=" * 80)
print("VALID SBP + INVALID DBP: EXAMPLES")
print("=" * 80)

examples_1 = df.loc[
    valid_sbp_invalid_dbp,
    ["id", "age", "gender", "ap_hi", "ap_lo", "cardio"]
].copy()

print(
    examples_1
    .head(20)
    .to_string(index=False)
)


# ------------------------------------------------
# 15. Invalid SBP + valid DBP examples
# ------------------------------------------------

print("\n" + "=" * 80)
print("INVALID SBP + VALID DBP: EXAMPLES")
print("=" * 80)

examples_2 = df.loc[
    invalid_sbp_valid_dbp,
    ["id", "age", "gender", "ap_hi", "ap_lo", "cardio"]
].copy()

print(
    examples_2
    .head(20)
    .to_string(index=False)
)


# ------------------------------------------------
# 16. Both invalid examples
# ------------------------------------------------

print("\n" + "=" * 80)
print("BOTH SBP AND DBP INVALID: EXAMPLES")
print("=" * 80)

examples_3 = df.loc[
    both_invalid,
    ["id", "age", "gender", "ap_hi", "ap_lo", "cardio"]
].copy()

print(
    examples_3
    .head(20)
    .to_string(index=False)
)


# ------------------------------------------------
# 17. Extreme BP values
# ------------------------------------------------

print("\n" + "=" * 80)
print("EXTREME SBP VALUES")
print("=" * 80)

print(
    df[
        ["id", "ap_hi", "ap_lo", "cardio"]
    ]
    .sort_values("ap_hi")
    .head(20)
    .to_string(index=False)
)

print("\nHighest SBP values:")

print(
    df[
        ["id", "ap_hi", "ap_lo", "cardio"]
    ]
    .sort_values("ap_hi", ascending=False)
    .head(20)
    .to_string(index=False)
)


print("\n" + "=" * 80)
print("EXTREME DBP VALUES")
print("=" * 80)

print(
    df[
        ["id", "ap_hi", "ap_lo", "cardio"]
    ]
    .sort_values("ap_lo")
    .head(20)
    .to_string(index=False)
)

print("\nHighest DBP values:")

print(
    df[
        ["id", "ap_hi", "ap_lo", "cardio"]
    ]
    .sort_values("ap_lo", ascending=False)
    .head(20)
    .to_string(index=False)
)


# ------------------------------------------------
# 18. Create summary table
# ------------------------------------------------

summary_rows = [
    {
        "category": "Valid SBP",
        "count": int(sbp_valid.sum()),
        "percentage": 100 * sbp_valid.sum() / N
    },
    {
        "category": "Invalid SBP",
        "count": int((~sbp_valid).sum()),
        "percentage": 100 * (~sbp_valid).sum() / N
    },
    {
        "category": "Valid DBP",
        "count": int(dbp_valid.sum()),
        "percentage": 100 * dbp_valid.sum() / N
    },
    {
        "category": "Invalid DBP",
        "count": int((~dbp_valid).sum()),
        "percentage": 100 * (~dbp_valid).sum() / N
    },
    {
        "category": "Valid SBP + invalid DBP",
        "count": int(valid_sbp_invalid_dbp.sum()),
        "percentage": 100 * valid_sbp_invalid_dbp.sum() / N
    },
    {
        "category": "Invalid SBP + valid DBP",
        "count": int(invalid_sbp_valid_dbp.sum()),
        "percentage": 100 * invalid_sbp_valid_dbp.sum() / N
    },
    {
        "category": "Both SBP and DBP invalid",
        "count": int(both_invalid.sum()),
        "percentage": 100 * both_invalid.sum() / N
    },
    {
        "category": "Valid values but SBP <= DBP",
        "count": int(bp_reversed.sum()),
        "percentage": 100 * bp_reversed.sum() / N
    },
    {
        "category": "Completely valid BP",
        "count": int(completely_valid_bp.sum()),
        "percentage": 100 * completely_valid_bp.sum() / N
    },
    {
        "category": "Any BP validity problem",
        "count": int(overall_invalid_bp.sum()),
        "percentage": 100 * overall_invalid_bp.sum() / N
    }
]

summary_df = pd.DataFrame(summary_rows)

summary_df.to_csv(
    OUTPUT_CSV,
    index=False
)


# ------------------------------------------------
# 19. Save detailed audit category file
# ------------------------------------------------

DETAIL_OUTPUT = RESULTS_DIR / "audit09_bp_record_categories.csv"

df[
    [
        "id",
        "age",
        "gender",
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
        "smoke",
        "alco",
        "active",
        "cardio",
        "bp_audit_category"
    ]
].to_csv(
    DETAIL_OUTPUT,
    index=False
)


# ------------------------------------------------
# 20. Final message
# ------------------------------------------------

print("\n" + "=" * 80)
print("AUDIT 09 COMPLETE")
print("=" * 80)

print("\nSummary saved to:")
print(OUTPUT_CSV)

print("\nDetailed record-level categories saved to:")
print(DETAIL_OUTPUT)

print("\nIMPORTANT:")
print("No records were deleted.")
print("No BP values were corrected.")
print("No imputation was performed.")
print("This audit only quantifies BP validity.")