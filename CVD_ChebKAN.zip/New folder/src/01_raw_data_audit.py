from pathlib import Path
import zipfile
import pandas as pd

# ============================================================
# CVD CGS-ChebKAN
# Audit 01: Raw Dataset Inspection
# READ-ONLY — DOES NOT MODIFY RAW DATA
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

KAGGLE_FILE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

print("=" * 70)
print("CVD CGS-ChebKAN — RAW DATA AUDIT")
print("=" * 70)

# ============================================================
# 1. KAGGLE DATASET
# ============================================================

print("\n" + "=" * 70)
print("1. KAGGLE CARDIOVASCULAR DATASET")
print("=" * 70)

print(f"\nFile: {KAGGLE_FILE}")
print(f"Exists: {KAGGLE_FILE.exists()}")

if not KAGGLE_FILE.exists():
    raise FileNotFoundError(
        f"Kaggle file not found:\n{KAGGLE_FILE}"
    )

df = pd.read_csv(KAGGLE_FILE, sep=",")

print("\n--- Dataset shape ---")
print(f"Rows    : {df.shape[0]:,}")
print(f"Columns : {df.shape[1]}")

print("\n--- Column names ---")
for i, col in enumerate(df.columns, start=1):
    print(f"{i:2d}. {col}")

print("\n--- Data types ---")
print(df.dtypes)

print("\n--- Missing values ---")
missing = df.isna().sum()
missing = missing[missing > 0]

if len(missing) == 0:
    print("No standard NaN missing values detected.")
else:
    print(missing)

print("\n--- Duplicate rows ---")
print(f"Duplicate rows: {df.duplicated().sum():,}")

print("\n--- Duplicate IDs ---")
if "id" in df.columns:
    print(f"Duplicate IDs: {df['id'].duplicated().sum():,}")

print("\n--- Target distribution ---")
if "cardio" in df.columns:
    print(df["cardio"].value_counts(dropna=False).sort_index())

    print("\nTarget proportions:")
    print(
        df["cardio"]
        .value_counts(normalize=True, dropna=False)
        .sort_index()
    )

print("\n--- Unique values ---")

candidate_columns = [
    "gender",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
    "cardio",
]

for col in candidate_columns:
    if col in df.columns:
        print(
            f"{col}: "
            f"{sorted(df[col].dropna().unique().tolist())}"
        )

print("\n--- Numerical summary ---")
print(df.describe(include="all").T)

print("\n--- First 5 rows ---")
print(df.head())

print("\n--- Last 5 rows ---")
print(df.tail())

# ============================================================
# 2. UCI ZIP ARCHIVE
# ============================================================

print("\n" + "=" * 70)
print("2. UCI HEART DISEASE ZIP ARCHIVE")
print("=" * 70)

print(f"\nFile: {UCI_ZIP}")
print(f"Exists: {UCI_ZIP.exists()}")

if not UCI_ZIP.exists():
    raise FileNotFoundError(
        f"UCI ZIP not found:\n{UCI_ZIP}"
    )

with zipfile.ZipFile(UCI_ZIP, "r") as z:

    files = z.namelist()

    print("\n--- Files inside ZIP ---")

    for f in files:
        print(f)

    print(f"\nTotal entries in ZIP: {len(files)}")

# ============================================================
# END
# ============================================================

print("\n" + "=" * 70)
print("AUDIT 01 COMPLETED")
print("=" * 70)

print("\nIMPORTANT:")
print("No raw dataset was modified.")
print("No rows were removed.")
print("No missing values were imputed.")
print("No outliers were removed.")
print("No datasets were merged.")
print("No modeling was performed.")

print("=" * 70)