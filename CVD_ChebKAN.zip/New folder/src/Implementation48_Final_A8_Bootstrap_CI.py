
# ============================================================
# Implementation48_Final_A8_Bootstrap_CI.py
# Final locked-test bootstrap 95% CIs for A8 CGS-ChebKAN
#
# PURPOSE
#   Compute manuscript-ready bootstrap 95% confidence intervals
#   for the FINAL A8 locked-test predictions.
#
# IMPORTANT PROTECTION RULES
#   - Does NOT retrain the model.
#   - Does NOT tune hyperparameters.
#   - Does NOT use the calibration cohort.
#   - Does NOT change the locked-test threshold.
#   - Uses ONLY the already generated final A8 locked-test
#     prediction file from Implementation46.
#
# Expected final metrics from Implementation46:
#   ROC-AUC  ~ 0.802196
#   PR-AUC   ~ 0.783409
#   Accuracy ~ 0.735643
#   Precision ~ 0.744909
#   Sensitivity ~ 0.716266
#   Specificity ~ 0.754997
#   F1 ~ 0.730307
#   Brier ~ 0.180263
#
# Bootstrap:
#   stratified bootstrap by outcome class
#   default B=5000
#   percentile 95% CIs
#
# Outputs:
#   results/tables/implementation48_a8_bootstrap_summary.csv
#   results/tables/implementation48_a8_bootstrap_summary.json
#   results/tables/implementation48_a8_bootstrap_protocol.json
#
# ============================================================

from pathlib import Path
import json
import math
import time
import warnings

import numpy as np
import pandas as pd
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    brier_score_loss,
)

warnings.filterwarnings("ignore")

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

ROOT = Path.cwd()

# Search common locations first.
CANDIDATE_FILES = [
    ROOT / "results" / "tables" / "implementation46_a8_locked_test_predictions.csv",
    ROOT / "results" / "tables" / "implementation46_final_a8_locked_test_predictions.csv",
    ROOT / "results" / "tables" / "implementation46_locked_test_predictions.csv",
    ROOT / "results" / "implementation46_a8_locked_test_predictions.csv",
    ROOT / "implementation46_a8_locked_test_predictions.csv",
]

OUTPUT_DIR = ROOT / "results" / "tables"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

N_BOOTSTRAP = 5000
CI_LEVEL = 0.95
SEED = 20261006
THRESHOLD = 0.50

# ------------------------------------------------------------
# 2. FIND PREDICTION FILE
# ------------------------------------------------------------

prediction_file = None

for p in CANDIDATE_FILES:
    if p.exists():
        prediction_file = p
        break

if prediction_file is None:
    # Recursive search, restricted to CSVs with useful names.
    recursive_candidates = []
    for p in ROOT.rglob("*.csv"):
        name = p.name.lower()
        if (
            "implementation46" in name
            and "prediction" in name
        ):
            recursive_candidates.append(p)

    if len(recursive_candidates) == 1:
        prediction_file = recursive_candidates[0]
    elif len(recursive_candidates) > 1:
        # Prefer a filename containing locked/test/a8.
        ranked = sorted(
            recursive_candidates,
            key=lambda x: (
                "a8" not in x.name.lower(),
                "locked" not in x.name.lower(),
                "test" not in x.name.lower(),
            )
        )
        prediction_file = ranked[0]

if prediction_file is None:
    raise FileNotFoundError(
        "\nCould not find the final A8 locked-test prediction CSV.\n"
        "Expected a file such as:\n"
        "results/tables/implementation46_a8_locked_test_predictions.csv\n"
        "Please place the Implementation46 prediction CSV in the "
        "results/tables folder and rerun this script.\n"
    )

print("=" * 78)
print("IMPLEMENTATION48 — FINAL A8 LOCKED-TEST BOOTSTRAP 95% CIs")
print("=" * 78)
print(f"Prediction file: {prediction_file}")

# ------------------------------------------------------------
# 3. LOAD DATA
# ------------------------------------------------------------

df = pd.read_csv(prediction_file)

print(f"Rows loaded: {len(df):,}")
print(f"Columns: {list(df.columns)}")

# ------------------------------------------------------------
# 4. ROBUST COLUMN DETECTION
# ------------------------------------------------------------

def find_column(df, candidates, description):
    lower_map = {c.lower(): c for c in df.columns}

    # Exact lower-case candidate match.
    for cand in candidates:
        if cand.lower() in lower_map:
            return lower_map[cand.lower()]

    # Partial match.
    for c in df.columns:
        cl = c.lower()
        for cand in candidates:
            if cand.lower() in cl:
                return c

    raise KeyError(
        f"Could not identify {description}. "
        f"Available columns: {list(df.columns)}"
    )

TARGET_COL = find_column(
    df,
    [
        "y_true",
        "target",
        "cardio",
        "y",
        "true_label",
        "label",
    ],
    "true target column",
)

PROB_COL = find_column(
    df,
    [
        "probability",
        "prob",
        "predicted_probability",
        "pred_prob",
        "p1",
        "prob_1",
        "y_prob",
        "score",
    ],
    "positive-class probability column",
)

# Predicted class is preferably read from the file.
PRED_COL = None
for candidates in [
    ["y_pred", "predicted", "prediction", "pred_class"],
    ["predicted_class"],
]:
    try:
        PRED_COL = find_column(df, candidates, "predicted class")
        break
    except KeyError:
        pass

print(f"Target column: {TARGET_COL}")
print(f"Probability column: {PROB_COL}")
print(f"Predicted-class column: {PRED_COL}")

# ------------------------------------------------------------
# 5. PREPARE / VALIDATE LOCKED TEST DATA
# ------------------------------------------------------------

y = pd.to_numeric(df[TARGET_COL], errors="coerce").to_numpy()
p = pd.to_numeric(df[PROB_COL], errors="coerce").to_numpy()

if np.isnan(y).any():
    raise ValueError("Target contains missing/non-numeric values.")

if np.isnan(p).any():
    raise ValueError("Predicted probabilities contain missing values.")

# Binary target validation.
unique_y = np.unique(y)
if not np.all(np.isin(unique_y, [0, 1])):
    raise ValueError(
        f"Target must be binary 0/1. Found values: {unique_y}"
    )

# Probability validation.
if np.any(p < 0) or np.any(p > 1):
    raise ValueError("Predicted probabilities must lie in [0, 1].")

# Locked threshold is exactly 0.50.
if PRED_COL is not None:
    supplied_pred = pd.to_numeric(
        df[PRED_COL], errors="coerce"
    ).to_numpy()

    if np.isnan(supplied_pred).any():
        raise ValueError(
            "Predicted-class column contains missing/non-numeric values."
        )

    supplied_pred = supplied_pred.astype(int)

    expected_pred = (p >= THRESHOLD).astype(int)

    mismatch = int(np.sum(supplied_pred != expected_pred))

    if mismatch > 0:
        raise ValueError(
            f"Prediction mismatch: {mismatch:,} rows in the supplied "
            f"predicted-class column do not match threshold={THRESHOLD:.2f}."
        )

    pred = supplied_pred
else:
    pred = (p >= THRESHOLD).astype(int)

n = len(y)

if n != 14000:
    print(
        f"WARNING: Expected 14,000 locked-test records, but found {n:,}."
    )

# ------------------------------------------------------------
# 6. IDENTITY / DUPLICATE AUDIT IF ID EXISTS
# ------------------------------------------------------------

id_col = None
for candidate in ["id", "ID", "row_id", "patient_id"]:
    if candidate in df.columns:
        id_col = candidate
        break

if id_col is not None:
    id_values = df[id_col]
    duplicate_ids = int(id_values.duplicated().sum())
    print(f"ID column: {id_col}")
    print(f"Duplicate IDs: {duplicate_ids:,}")

    if duplicate_ids > 0:
        raise ValueError(
            "Duplicate IDs detected in locked-test prediction file."
        )
else:
    print("ID column: not present; proceeding with row-level audit.")

# ------------------------------------------------------------
# 7. ORIGINAL POINT ESTIMATES
# ------------------------------------------------------------

def compute_metrics(y_true, prob, threshold=0.50):
    y_pred = (prob >= threshold).astype(int)

    return {
        "ROC_AUC": roc_auc_score(y_true, prob),
        "PR_AUC": average_precision_score(y_true, prob),
        "Accuracy": accuracy_score(y_true, y_pred),
        "Precision": precision_score(
            y_true, y_pred, zero_division=0
        ),
        "Sensitivity": recall_score(
            y_true, y_pred, zero_division=0
        ),
        "Specificity": (
            np.sum((y_true == 0) & (y_pred == 0))
            / np.sum(y_true == 0)
        ),
        "F1": f1_score(
            y_true, y_pred, zero_division=0
        ),
        "Brier": brier_score_loss(y_true, prob),
    }

point_metrics = compute_metrics(y, p, THRESHOLD)

print("\nLOCKED-TEST POINT ESTIMATES")
print("-" * 78)
for name, value in point_metrics.items():
    print(f"{name:15s}: {value:.6f}")

# ------------------------------------------------------------
# 8. STRATIFIED BOOTSTRAP
# ------------------------------------------------------------
#
# Stratification preserves the observed number of positive and
# negative observations in every bootstrap sample.
#
# This is appropriate for a fixed locked-test evaluation because
# the class distribution is part of the evaluation sample.
#
# The original test data are not modified.
# ------------------------------------------------------------

rng = np.random.default_rng(SEED)

idx0 = np.flatnonzero(y == 0)
idx1 = np.flatnonzero(y == 1)

n0 = len(idx0)
n1 = len(idx1)

print("\nCLASS COUNTS")
print("-" * 78)
print(f"Negative class (0): {n0:,}")
print(f"Positive class (1): {n1:,}")
print(f"Total:               {n:,}")
print(f"Prevalence:          {n1 / n:.6f}")

bootstrap_values = {
    metric: np.empty(N_BOOTSTRAP, dtype=np.float64)
    for metric in point_metrics
}

start = time.time()

for b in range(N_BOOTSTRAP):

    sample0 = rng.choice(
        idx0,
        size=n0,
        replace=True,
    )

    sample1 = rng.choice(
        idx1,
        size=n1,
        replace=True,
    )

    sample_idx = np.concatenate([sample0, sample1])

    y_b = y[sample_idx]
    p_b = p[sample_idx]

    # A stratified bootstrap retains both classes, so ROC-AUC is
    # defined for every replicate.
    metrics_b = compute_metrics(
        y_b,
        p_b,
        threshold=THRESHOLD,
    )

    for metric, value in metrics_b.items():
        bootstrap_values[metric][b] = value

    if (b + 1) % 500 == 0:
        elapsed = time.time() - start
        print(
            f"Bootstrap {b + 1:,}/{N_BOOTSTRAP:,} "
            f"({elapsed:.1f} s)"
        )

elapsed = time.time() - start

# ------------------------------------------------------------
# 9. PERCENTILE 95% CONFIDENCE INTERVALS
# ------------------------------------------------------------

alpha = 1.0 - CI_LEVEL

rows = []

for metric, estimate in point_metrics.items():

    values = bootstrap_values[metric]

    lower = float(np.quantile(values, alpha / 2.0))
    upper = float(np.quantile(values, 1.0 - alpha / 2.0))

    rows.append(
        {
            "Model": "A8 CGS-ChebKAN",
            "Evaluation": "Kaggle locked test",
            "N": n,
            "Metric": metric,
            "Estimate": float(estimate),
            "CI_lower": lower,
            "CI_upper": upper,
            "CI_level": CI_LEVEL,
            "Bootstrap_replicates": N_BOOTSTRAP,
            "Bootstrap_method": "Stratified percentile bootstrap",
            "Threshold": THRESHOLD,
        }
    )

summary = pd.DataFrame(rows)

# ------------------------------------------------------------
# 10. ADD REPRODUCIBILITY / AUDIT INFORMATION
# ------------------------------------------------------------

protocol = {
    "implementation": "Implementation48",
    "purpose": (
        "Final A8 locked-test bootstrap 95% confidence intervals"
    ),
    "model": "A8 CGS-ChebKAN",
    "prediction_file": str(prediction_file),
    "n_locked_test": int(n),
    "positive_count": int(n1),
    "negative_count": int(n0),
    "prevalence": float(n1 / n),
    "threshold": THRESHOLD,
    "bootstrap_replicates": N_BOOTSTRAP,
    "confidence_level": CI_LEVEL,
    "bootstrap_method": "stratified percentile bootstrap",
    "random_seed": SEED,
    "retraining": False,
    "hyperparameter_tuning": False,
    "calibration_cohort_used": False,
    "locked_test_used_for_model_selection": False,
    "locked_test_used_only_for_final_evaluation": True,
    "runtime_seconds": float(elapsed),
}

# ------------------------------------------------------------
# 11. SAVE OUTPUTS
# ------------------------------------------------------------

summary_csv = (
    OUTPUT_DIR /
    "implementation48_a8_bootstrap_summary.csv"
)

summary_json = (
    OUTPUT_DIR /
    "implementation48_a8_bootstrap_summary.json"
)

protocol_json = (
    OUTPUT_DIR /
    "implementation48_a8_bootstrap_protocol.json"
)

summary.to_csv(summary_csv, index=False)

with open(summary_json, "w", encoding="utf-8") as f:
    json.dump(
        {
            "model": "A8 CGS-ChebKAN",
            "evaluation": "Kaggle locked test",
            "metrics": summary.to_dict(orient="records"),
        },
        f,
        indent=2,
    )

with open(protocol_json, "w", encoding="utf-8") as f:
    json.dump(protocol, f, indent=2)

# ------------------------------------------------------------
# 12. MANUSCRIPT-READY TABLE
# ------------------------------------------------------------

print("\n" + "=" * 78)
print("FINAL MANUSCRIPT-READY BOOTSTRAP RESULTS")
print("=" * 78)

for _, row in summary.iterrows():
    print(
        f"{row['Metric']:15s} "
        f"{row['Estimate']:.6f} "
        f"({row['CI_lower']:.6f}, {row['CI_upper']:.6f})"
    )

print("\n" + "=" * 78)
print("AUDIT STATUS")
print("=" * 78)
print("PASS_FINAL_A8_BOOTSTRAP_CI")
print(f"Bootstrap replicates: {N_BOOTSTRAP:,}")
print(f"Confidence level: {CI_LEVEL:.0%}")
print(f"Threshold: {THRESHOLD:.2f}")
print("Retraining: NO")
print("Hyperparameter tuning: NO")
print("Calibration cohort used: NO")
print("Locked test used for final evaluation only: YES")
print(f"Runtime: {elapsed:.2f} seconds")

print("\nOUTPUT FILES")
print("-" * 78)
print(summary_csv)
print(summary_json)
print(protocol_json)
