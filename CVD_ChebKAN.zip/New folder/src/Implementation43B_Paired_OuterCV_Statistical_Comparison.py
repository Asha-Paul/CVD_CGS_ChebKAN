# ============================================================
# IMPLEMENTATION 43B
# PAIRED OUTER-CV STATISTICAL COMPARISON
# COMPLETE REPLACEMENT VERSION
# ============================================================

import os
import json
import hashlib
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.metrics import roc_auc_score


# ============================================================
# CONFIGURATION
# ============================================================

RESULTS_DIR = Path("results") / "tables"

OUTPUT_RESULTS = (
    RESULTS_DIR /
    "implementation43B_paired_auc_comparison.csv"
)

OUTPUT_JSON = (
    RESULTS_DIR /
    "implementation43B_paired_auc_comparison.json"
)

OUTPUT_AUDIT = (
    RESULTS_DIR /
    "implementation43B_pairing_audit.csv"
)

OUTPUT_AUDIT_JSON = (
    RESULTS_DIR /
    "implementation43B_pairing_audit.json"
)

OUTPUT_REPORT = (
    RESULTS_DIR /
    "implementation43B_report.txt"
)

RANDOM_SEED = 20261006

# Verification run.
# For final manuscript results, this can later be increased
# to 5000 after the pairing protocol is confirmed.
N_BOOTSTRAP = 2000

ALPHA = 0.05


# ============================================================
# OUTER-CV PREDICTION FILES
# ============================================================

MODEL_FILES = {

    "CGS-ChebKAN_A6":
        "implementation31b_reduced_corrected_a6_outer_predictions.csv",

    "Logistic_Regression":
        "implementation22_logistic_outer_predictions.csv",

    "Random_Forest":
        "implementation23_random_forest_outer_predictions.csv",

    "XGBoost":
        "implementation24_xgboost_outer_predictions.csv",

    "MLP":
        "implementation25_mlp_outer_predictions.csv",

    "B-spline_KAN":
        "implementation26_bspline_kan_outer_predictions.csv",

    "Vanilla_Chebyshev_KAN":
        "implementation27_chebyshev_outer_predictions.csv",

    "Fourier_KAN":
        "implementation28_fourier_kan_outer_predictions.csv",
}


# ============================================================
# HASH
# ============================================================

def sha256_file(path):

    h = hashlib.sha256()

    with open(path, "rb") as f:

        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b""
        ):

            h.update(chunk)

    return h.hexdigest()


# ============================================================
# AUC
# ============================================================

def safe_auc(y_true, probability):

    y_true = np.asarray(y_true)
    probability = np.asarray(probability)

    if len(np.unique(y_true)) < 2:
        return np.nan

    return float(
        roc_auc_score(
            y_true,
            probability
        )
    )


# ============================================================
# HOLM CORRECTION
# ============================================================

def holm_adjust(p_values):

    p_values = np.asarray(
        p_values,
        dtype=float
    )

    m = len(p_values)

    order = np.argsort(p_values)

    adjusted = np.empty(m)

    running_max = 0.0

    for rank, idx in enumerate(order):

        value = (
            (m - rank)
            *
            p_values[idx]
        )

        running_max = max(
            running_max,
            value
        )

        adjusted[idx] = min(
            running_max,
            1.0
        )

    return adjusted


# ============================================================
# PAIRED BOOTSTRAP
# ============================================================

def bootstrap_paired_auc_difference(
    y_true,
    probability_reference,
    probability_comparator,
    n_bootstrap,
    seed
):

    y_true = np.asarray(
        y_true
    ).astype(int)

    probability_reference = np.asarray(
        probability_reference
    ).astype(float)

    probability_comparator = np.asarray(
        probability_comparator
    ).astype(float)

    n = len(y_true)

    auc_reference = safe_auc(
        y_true,
        probability_reference
    )

    auc_comparator = safe_auc(
        y_true,
        probability_comparator
    )

    observed_difference = (
        auc_reference
        -
        auc_comparator
    )

    rng = np.random.default_rng(
        seed
    )

    bootstrap_differences = []

    for _ in range(n_bootstrap):

        indices = rng.integers(
            0,
            n,
            size=n
        )

        y_b = y_true[
            indices
        ]

        if len(
            np.unique(y_b)
        ) < 2:

            continue

        ref_b = (
            probability_reference[
                indices
            ]
        )

        comp_b = (
            probability_comparator[
                indices
            ]
        )

        auc_ref_b = safe_auc(
            y_b,
            ref_b
        )

        auc_comp_b = safe_auc(
            y_b,
            comp_b
        )

        if (
            np.isfinite(auc_ref_b)
            and
            np.isfinite(auc_comp_b)
        ):

            bootstrap_differences.append(
                auc_ref_b
                -
                auc_comp_b
            )

    bootstrap_differences = np.asarray(
        bootstrap_differences
    )

    if len(
        bootstrap_differences
    ) < 100:

        raise RuntimeError(
            "Too few valid bootstrap replicates."
        )

    ci_low = float(
        np.percentile(
            bootstrap_differences,
            2.5
        )
    )

    ci_high = float(
        np.percentile(
            bootstrap_differences,
            97.5
        )
    )

    # Two-sided bootstrap p-value
    if observed_difference >= 0:

        extreme = np.sum(
            bootstrap_differences <= 0
        )

    else:

        extreme = np.sum(
            bootstrap_differences >= 0
        )

    p_value = float(
        (
            extreme + 1
        )
        /
        (
            len(
                bootstrap_differences
            )
            + 1
        )
    )

    return {
        "reference_auc":
            auc_reference,

        "comparator_auc":
            auc_comparator,

        "auc_difference":
            observed_difference,

        "ci_low":
            ci_low,

        "ci_high":
            ci_high,

        "p_value":
            p_value,

        "n_bootstrap_valid":
            len(
                bootstrap_differences
            ),
    }


# ============================================================
# COLUMN IDENTIFICATION
# ============================================================

def identify_columns(
    df,
    model_name
):

    columns = list(
        df.columns
    )

    # --------------------------------------------------------
    # TARGET
    # --------------------------------------------------------

    target_candidates = [

        "y_true",

        "true_label",

        "cardio",

        "target",

        "target_binary",
    ]

    target_col = None

    for c in target_candidates:

        if c in columns:

            target_col = c
            break

    if target_col is None:

        raise ValueError(
            f"[{model_name}] "
            f"Target column not found.\n"
            f"Columns: {columns}"
        )

    # --------------------------------------------------------
    # PROBABILITY
    # --------------------------------------------------------

    probability_candidates = [

        "probability",

        "predicted_probability",

        "positive_probability",

        "proba",

        "y_prob",
    ]

    probability_col = None

    for c in probability_candidates:

        if c in columns:

            probability_col = c
            break

    if probability_col is None:

        raise ValueError(
            f"[{model_name}] "
            f"Probability column not found.\n"
            f"Columns: {columns}"
        )

    # --------------------------------------------------------
    # IDENTITY
    # --------------------------------------------------------

    identity_candidates = [

        "id",

        "sample_index",

        "row_index",
    ]

    identity_col = None

    for c in identity_candidates:

        if c in columns:

            identity_col = c
            break

    return (
        target_col,
        probability_col,
        identity_col
    )


# ============================================================
# LOAD MODEL FILE
# ============================================================

def load_model_file(
    model_name,
    filename
):

    path = (
        RESULTS_DIR
        /
        filename
    )

    if not path.exists():

        raise FileNotFoundError(
            f"Missing file:\n{path}"
        )

    df = pd.read_csv(
        path
    )

    (
        target_col,
        probability_col,
        identity_col
    ) = identify_columns(
        df,
        model_name
    )

    # --------------------------------------------------------
    # Row count
    # --------------------------------------------------------

    if len(df) != 49000:

        raise ValueError(
            f"{model_name}: "
            f"{len(df)} rows found. "
            f"Expected 49,000."
        )

    # --------------------------------------------------------
    # Target
    # --------------------------------------------------------

    y = pd.to_numeric(
        df[target_col],
        errors="coerce"
    )

    if y.isna().any():

        raise ValueError(
            f"{model_name}: "
            f"target contains missing values."
        )

    y = y.astype(int)

    if not set(
        y.unique()
    ).issubset({0, 1}):

        raise ValueError(
            f"{model_name}: "
            f"target is not binary."
        )

    # --------------------------------------------------------
    # Probability
    # --------------------------------------------------------

    p = pd.to_numeric(
        df[probability_col],
        errors="coerce"
    )

    if p.isna().any():

        raise ValueError(
            f"{model_name}: "
            f"probability contains NaN."
        )

    p = p.astype(float)

    if (
        (p < 0)
        |
        (p > 1)
    ).any():

        raise ValueError(
            f"{model_name}: "
            f"probabilities outside [0,1]."
        )

    # --------------------------------------------------------
    # Identity
    # --------------------------------------------------------

    identity = None

    if identity_col is not None:

        identity = pd.to_numeric(
            df[identity_col],
            errors="coerce"
        )

        if identity.isna().any():

            raise ValueError(
                f"{model_name}: "
                f"identity contains missing values."
            )

        identity = identity.astype(int)

    # --------------------------------------------------------
    # Standardized dataframe
    # --------------------------------------------------------

    output = pd.DataFrame({

        "target":
            y,

        "probability":
            p,
    })

    if identity is not None:

        output[
            "identity"
        ] = identity

    else:

        output[
            "identity"
        ] = np.nan

    return {

        "name":
            model_name,

        "filename":
            filename,

        "path":
            str(path),

        "data":
            output,

        "target_column":
            target_col,

        "probability_column":
            probability_col,

        "identity_column":
            identity_col,

        "sha256":
            sha256_file(path),
    }


# ============================================================
# LOAD ALL
# ============================================================

def load_all_models():

    print(
        "\n============================================================"
    )

    print(
        "IMPLEMENTATION 43B"
    )

    print(
        "PAIRED OUTER-CV STATISTICAL COMPARISON"
    )

    print(
        "============================================================"
    )

    print(
        "\nLoading 49,000-row outer-CV prediction files...\n"
    )

    loaded = {}

    for model_name, filename in (
        MODEL_FILES.items()
    ):

        result = load_model_file(
            model_name,
            filename
        )

        loaded[
            model_name
        ] = result

        print(
            f"{model_name:30s} "
            f"rows={len(result['data']):5d} | "
            f"target={result['target_column']:20s} | "
            f"prob={result['probability_column']:25s} | "
            f"identity={str(result['identity_column']):15s}"
        )

    return loaded


# ============================================================
# TARGET AUDIT
# ============================================================

def target_audit(
    loaded
):

    print(
        "\n============================================================"
    )

    print(
        "TARGET CONSISTENCY AUDIT"
    )

    print(
        "============================================================"
    )

    reference = (
        loaded[
            "CGS-ChebKAN_A6"
        ]["data"]["target"]
        .to_numpy()
    )

    rows = []

    for model_name, result in (
        loaded.items()
    ):

        y = (
            result["data"]["target"]
            .to_numpy()
        )

        matches = np.array_equal(
            reference,
            y
        )

        rows.append({

            "model":
                model_name,

            "n":
                len(y),

            "positive_rate":
                float(
                    np.mean(y)
                ),

            "target_matches_cgs":
                bool(matches),
        })

        print(
            f"{model_name:30s} "
            f"target_match={matches}"
        )

    return pd.DataFrame(
        rows
    )


# ============================================================
# ID SET AUDIT
# ============================================================

def identity_audit(
    loaded
):

    print(
        "\n============================================================"
    )

    print(
        "IDENTITY AUDIT"
    )

    print(
        "============================================================"
    )

    reference_name = (
        "CGS-ChebKAN_A6"
    )

    reference = loaded[
        reference_name
    ]

    ref_identity = (
        reference[
            "data"
        ]["identity"]
    )

    rows = []

    for model_name, result in (
        loaded.items()
    ):

        if model_name == reference_name:
            continue

        comp_identity = (
            result[
                "data"
            ]["identity"]
        )

        # ----------------------------------------------------
        # Both identities available
        # ----------------------------------------------------

        if (
            ref_identity.notna().all()
            and
            comp_identity.notna().all()
        ):

            ref_ids = (
                ref_identity
                .astype(int)
                .to_numpy()
            )

            comp_ids = (
                comp_identity
                .astype(int)
                .to_numpy()
            )

            ref_unique = (
                len(
                    np.unique(
                        ref_ids
                    )
                )
                ==
                len(ref_ids)
            )

            comp_unique = (
                len(
                    np.unique(
                        comp_ids
                    )
                )
                ==
                len(comp_ids)
            )

            same_set = (
                set(ref_ids)
                ==
                set(comp_ids)
            )

            # ------------------------------------------------
            # If sets match, compare target after sorting
            # ------------------------------------------------

            target_match_after_id = False

            if (
                ref_unique
                and
                comp_unique
                and
                same_set
            ):

                ref_temp = pd.DataFrame({

                    "id":
                        ref_ids,

                    "target_ref":
                        reference[
                            "data"
                        ]["target"]
                        .to_numpy()
                })

                comp_temp = pd.DataFrame({

                    "id":
                        comp_ids,

                    "target_comp":
                        result[
                            "data"
                        ]["target"]
                        .to_numpy()
                })

                merged = pd.merge(
                    ref_temp,
                    comp_temp,
                    on="id",
                    how="inner",
                    validate="one_to_one"
                )

                target_match_after_id = np.array_equal(
                    merged[
                        "target_ref"
                    ].to_numpy(),

                    merged[
                        "target_comp"
                    ].to_numpy()
                )

            if (
                ref_unique
                and
                comp_unique
                and
                same_set
                and
                target_match_after_id
            ):

                status = "PASS"

                reason = (
                    "Exact identity-set match and "
                    "target-label match established."
                )

            else:

                status = "FAIL"

                reason = (
                    "Identity columns exist but exact "
                    "identity/target agreement failed."
                )

        # ----------------------------------------------------
        # No comparator identity
        # ----------------------------------------------------

        elif (
            comp_identity.isna().all()
        ):

            status = "UNVERIFIED"

            reason = (
                "Comparator has no explicit observation "
                "identity column."
            )

            ref_unique = np.nan
            comp_unique = np.nan
            same_set = False
            target_match_after_id = False

        # ----------------------------------------------------
        # Mixed identity
        # ----------------------------------------------------

        else:

            status = "UNVERIFIED"

            reason = (
                "Observation identity could not be "
                "established for both files."
            )

            ref_unique = np.nan
            comp_unique = np.nan
            same_set = False
            target_match_after_id = False

        rows.append({

            "reference_model":
                reference_name,

            "comparator_model":
                model_name,

            "reference_identity_column":
                reference[
                    "identity_column"
                ],

            "comparator_identity_column":
                result[
                    "identity_column"
                ],

            "reference_identity_unique":
                ref_unique,

            "comparator_identity_unique":
                comp_unique,

            "identity_sets_equal":
                same_set,

            "target_matches_after_identity_alignment":
                target_match_after_id,

            "pairing_status":
                status,

            "reason":
                reason,
        })

        print(
            f"{model_name:30s} "
            f"status={status:10s} | "
            f"{reason}"
        )

    return pd.DataFrame(
        rows
    )


# ============================================================
# ALIGN EXACTLY BY IDENTITY
# ============================================================

def align_by_identity(
    reference,
    comparator
):

    ref = (
        reference[
            "data"
        ][
            [
                "identity",
                "target",
                "probability"
            ]
        ]
        .rename(
            columns={
                "target":
                    "target_ref",

                "probability":
                    "prob_ref",
            }
        )
    )

    comp = (
        comparator[
            "data"
        ][
            [
                "identity",
                "target",
                "probability"
            ]
        ]
        .rename(
            columns={
                "target":
                    "target_comp",

                "probability":
                    "prob_comp",
            }
        )
    )

    merged = pd.merge(

        ref,

        comp,

        on="identity",

        how="inner",

        validate="one_to_one"
    )

    if len(merged) != 49000:

        raise RuntimeError(
            "Exact identity merge did not produce "
            "49,000 observations."
        )

    if not np.array_equal(

        merged[
            "target_ref"
        ].to_numpy(),

        merged[
            "target_comp"
        ].to_numpy()
    ):

        raise RuntimeError(
            "Targets differ after identity alignment."
        )

    return merged


# ============================================================
# RUN COMPARISONS
# ============================================================

def run_comparisons(
    loaded,
    identity_results
):

    print(
        "\n============================================================"
    )

    print(
        "PAIRED AUC STATISTICAL TESTING"
    )

    print(
        "============================================================"
    )

    reference_name = (
        "CGS-ChebKAN_A6"
    )

    reference = loaded[
        reference_name
    ]

    results = []

    for _, audit in (
        identity_results.iterrows()
    ):

        comparator_name = (
            audit[
                "comparator_model"
            ]
        )

        status = (
            audit[
                "pairing_status"
            ]
        )

        if status != "PASS":

            print(
                f"\nSKIPPED: "
                f"CGS-ChebKAN vs "
                f"{comparator_name}"
            )

            print(
                f"Reason: "
                f"{audit['reason']}"
            )

            results.append({

                "reference_model":
                    reference_name,

                "comparator_model":
                    comparator_name,

                "status":
                    "NOT_TESTED",

                "reason":
                    audit[
                        "reason"
                    ],
            })

            continue

        comparator = loaded[
            comparator_name
        ]

        merged = align_by_identity(
            reference,
            comparator
        )

        y = (
            merged[
                "target_ref"
            ].to_numpy()
        )

        p_ref = (
            merged[
                "prob_ref"
            ].to_numpy()
        )

        p_comp = (
            merged[
                "prob_comp"
            ].to_numpy()
        )

        # Deterministic seed based on model position
        comparator_index = list(
            MODEL_FILES.keys()
        ).index(
            comparator_name
        )

        seed = (
            RANDOM_SEED
            +
            comparator_index
        )

        stats = (
            bootstrap_paired_auc_difference(

                y_true=y,

                probability_reference=p_ref,

                probability_comparator=p_comp,

                n_bootstrap=N_BOOTSTRAP,

                seed=seed
            )
        )

        print(
            f"\nCGS-ChebKAN vs "
            f"{comparator_name}"
        )

        print(
            f"  CGS-ChebKAN AUC = "
            f"{stats['reference_auc']:.6f}"
        )

        print(
            f"  Comparator AUC = "
            f"{stats['comparator_auc']:.6f}"
        )

        print(
            f"  ΔAUC = "
            f"{stats['auc_difference']:+.6f}"
        )

        print(
            f"  95% CI = "
            f"[{stats['ci_low']:.6f}, "
            f"{stats['ci_high']:.6f}]"
        )

        print(
            f"  Raw p = "
            f"{stats['p_value']:.6f}"
        )

        results.append({

            "reference_model":
                reference_name,

            "comparator_model":
                comparator_name,

            "status":
                "TESTED",

            "reason":
                "Exact paired identity established.",

            "n":
                49000,

            "reference_auc":
                stats[
                    "reference_auc"
                ],

            "comparator_auc":
                stats[
                    "comparator_auc"
                ],

            "auc_difference":
                stats[
                    "auc_difference"
                ],

            "auc_difference_ci_low":
                stats[
                    "ci_low"
                ],

            "auc_difference_ci_high":
                stats[
                    "ci_high"
                ],

            "p_value_raw":
                stats[
                    "p_value"
                ],

            "n_bootstrap_valid":
                stats[
                    "n_bootstrap_valid"
                ],
        })

    return pd.DataFrame(
        results
    )


# ============================================================
# APPLY HOLM
# ============================================================

def apply_holm(
    results
):

    results[
        "p_value_holm"
    ] = np.nan

    results[
        "significant_holm"
    ] = False

    tested_mask = (
        results[
            "status"
        ]
        ==
        "TESTED"
    )

    if not tested_mask.any():

        return results

    p = (
        results.loc[
            tested_mask,
            "p_value_raw"
        ]
        .astype(float)
        .to_numpy()
    )

    adjusted = holm_adjust(
        p
    )

    results.loc[
        tested_mask,
        "p_value_holm"
    ] = adjusted

    results.loc[
        tested_mask,
        "significant_holm"
    ] = (
        adjusted < ALPHA
    )

    return results


# ============================================================
# INTERPRETATION
# ============================================================

def add_interpretation(
    results
):

    interpretations = []

    for _, row in (
        results.iterrows()
    ):

        if row[
            "status"
        ] != "TESTED":

            interpretations.append(
                "Not tested because exact paired "
                "observation identity was not established."
            )

            continue

        low = row[
            "auc_difference_ci_low"
        ]

        high = row[
            "auc_difference_ci_high"
        ]

        p = row[
            "p_value_holm"
        ]

        if (
            low > 0
            and
            p < ALPHA
        ):

            text = (
                "CGS-ChebKAN has significantly higher "
                "paired ROC-AUC than the comparator "
                "after Holm correction."
            )

        elif (
            high < 0
            and
            p < ALPHA
        ):

            text = (
                "CGS-ChebKAN has significantly lower "
                "paired ROC-AUC than the comparator "
                "after Holm correction."
            )

        else:

            text = (
                "No statistically significant paired "
                "ROC-AUC difference was established "
                "after Holm correction."
            )

        interpretations.append(
            text
        )

    results[
        "interpretation"
    ] = interpretations

    return results


# ============================================================
# REPORT
# ============================================================

def create_report(
    loaded,
    target_results,
    identity_results,
    results
):

    lines = []

    lines.append(
        "IMPLEMENTATION 43B"
    )

    lines.append(
        "PAIRED OUTER-CV STATISTICAL COMPARISON"
    )

    lines.append(
        "=" * 70
    )

    lines.append("")

    lines.append(
        "Evaluation population:"
    )

    lines.append(
        "49,000 development observations under outer CV."
    )

    lines.append("")

    lines.append(
        "Locked 14,000-row test set used:"
    )

    lines.append(
        "NO"
    )

    lines.append("")

    lines.append(
        "UCI external data used:"
    )

    lines.append(
        "NO"
    )

    lines.append("")

    lines.append(
        "Model retraining:"
    )

    lines.append(
        "NO"
    )

    lines.append("")

    lines.append(
        f"Bootstrap repetitions: {N_BOOTSTRAP}"
    )

    lines.append(
        "Confidence interval: 95%"
    )

    lines.append(
        "Multiple-comparison correction: Holm"
    )

    lines.append("")

    lines.append(
        "TARGET AUDIT"
    )

    lines.append(
        "-" * 70
    )

    for _, row in (
        target_results.iterrows()
    ):

        lines.append(
            f"{row['model']}: "
            f"target_match="
            f"{row['target_matches_cgs']}, "
            f"positive_rate="
            f"{row['positive_rate']:.6f}"
        )

    lines.append("")

    lines.append(
        "PAIRING AUDIT"
    )

    lines.append(
        "-" * 70
    )

    for _, row in (
        identity_results.iterrows()
    ):

        lines.append(
            f"{row['comparator_model']}: "
            f"{row['pairing_status']} - "
            f"{row['reason']}"
        )

    lines.append("")

    lines.append(
        "STATISTICAL RESULTS"
    )

    lines.append(
        "-" * 70
    )

    tested = results[
        results[
            "status"
        ]
        ==
        "TESTED"
    ]

    if len(tested) == 0:

        lines.append(
            "No exact paired comparisons were available."
        )

    else:

        for _, row in (
            tested.iterrows()
        ):

            lines.append(
                f"\nCGS-ChebKAN vs "
                f"{row['comparator_model']}"
            )

            lines.append(
                f"  CGS-ChebKAN AUC: "
                f"{row['reference_auc']:.6f}"
            )

            lines.append(
                f"  Comparator AUC: "
                f"{row['comparator_auc']:.6f}"
            )

            lines.append(
                f"  ΔAUC: "
                f"{row['auc_difference']:+.6f}"
            )

            lines.append(
                f"  95% CI: "
                f"[{row['auc_difference_ci_low']:.6f}, "
                f"{row['auc_difference_ci_high']:.6f}]"
            )

            lines.append(
                f"  Raw p: "
                f"{row['p_value_raw']:.6f}"
            )

            lines.append(
                f"  Holm p: "
                f"{row['p_value_holm']:.6f}"
            )

            lines.append(
                f"  Significant: "
                f"{row['significant_holm']}"
            )

            lines.append(
                f"  Interpretation: "
                f"{row['interpretation']}"
            )

    lines.append("")

    lines.append(
        "MANUSCRIPT PROTOCOL NOTE"
    )

    lines.append(
        "-" * 70
    )

    lines.append(
        "These paired comparisons are intended for "
        "development-stage model comparison."
    )

    lines.append(
        "The locked 14,000-row test set remains "
        "the primary final internal evaluation."
    )

    lines.append(
        "No statistical comparison is reported when "
        "exact observation pairing cannot be established."
    )

    if len(tested) > 0:

        lines.append("")

        lines.append(
            "STATUS: "
            "PASS_PAIRED_OUTER_CV_COMPARISONS_COMPLETED"
        )

    else:

        lines.append("")

        lines.append(
            "STATUS: "
            "PARTIAL_NO_EXACT_PAIRING_ESTABLISHED"
        )

    with open(
        OUTPUT_REPORT,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "\n".join(lines)
        )


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    target_results,
    identity_results,
    results
):

    payload = {

        "implementation":
            "43B",

        "evaluation_population":
            49000,

        "locked_test_used":
            False,

        "uci_external_used":
            False,

        "retraining":
            False,

        "bootstrap_repetitions":
            N_BOOTSTRAP,

        "confidence_interval":
            0.95,

        "alpha":
            ALPHA,

        "target_audit":
            target_results.to_dict(
                orient="records"
            ),

        "identity_audit":
            identity_results.to_dict(
                orient="records"
            ),

        "results":
            results.replace(
                {np.nan: None}
            ).to_dict(
                orient="records"
            ),
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            payload,
            f,
            indent=2,
            default=str
        )

    audit_payload = {

        "implementation":
            "43B",

        "identity_audit":
            identity_results.replace(
                {np.nan: None}
            ).to_dict(
                orient="records"
            ),
    }

    with open(
        OUTPUT_AUDIT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            audit_payload,
            f,
            indent=2,
            default=str
        )


# ============================================================
# MAIN
# ============================================================

def main():

    warnings.filterwarnings(
        "ignore"
    )

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # 1. LOAD
    # --------------------------------------------------------

    loaded = load_all_models()

    # --------------------------------------------------------
    # 2. TARGET AUDIT
    # --------------------------------------------------------

    target_results = (
        target_audit(
            loaded
        )
    )

    if not target_results[
        "target_matches_cgs"
    ].all():

        raise RuntimeError(
            "TARGET AUDIT FAILED. "
            "Do not perform paired comparisons."
        )

    # --------------------------------------------------------
    # 3. IDENTITY AUDIT
    # --------------------------------------------------------

    identity_results = (
        identity_audit(
            loaded
        )
    )

    # --------------------------------------------------------
    # 4. SAVE IDENTITY AUDIT
    # --------------------------------------------------------

    identity_results.to_csv(
        OUTPUT_AUDIT,
        index=False
    )

    # --------------------------------------------------------
    # 5. STATISTICAL COMPARISON
    # --------------------------------------------------------

    results = (
        run_comparisons(
            loaded,
            identity_results
        )
    )

    # --------------------------------------------------------
    # 6. HOLM
    # --------------------------------------------------------

    results = apply_holm(
        results
    )

    # --------------------------------------------------------
    # 7. INTERPRETATION
    # --------------------------------------------------------

    results = add_interpretation(
        results
    )

    # --------------------------------------------------------
    # 8. SAVE CSV
    # --------------------------------------------------------

    results.to_csv(
        OUTPUT_RESULTS,
        index=False
    )

    # --------------------------------------------------------
    # 9. JSON
    # --------------------------------------------------------

    save_json(
        target_results,
        identity_results,
        results
    )

    # --------------------------------------------------------
    # 10. REPORT
    # --------------------------------------------------------

    create_report(
        loaded,
        target_results,
        identity_results,
        results
    )

    # --------------------------------------------------------
    # 11. FINAL OUTPUT
    # --------------------------------------------------------

    print(
        "\n============================================================"
    )

    print(
        "IMPLEMENTATION 43B COMPLETE"
    )

    print(
        "============================================================"
    )

    print(
        "\nResults:"
    )

    print(
        OUTPUT_RESULTS
    )

    print(
        "\nPairing audit:"
    )

    print(
        OUTPUT_AUDIT
    )

    print(
        "\nJSON:"
    )

    print(
        OUTPUT_JSON
    )

    print(
        "\nReport:"
    )

    print(
        OUTPUT_REPORT
    )

    tested = results[
        results[
            "status"
        ]
        ==
        "TESTED"
    ]

    print(
        f"\nExact paired comparisons tested: "
        f"{len(tested)}"
    )

    if len(tested) > 0:

        print(
            "\nFINAL PAIRED RESULTS"
        )

        print(
            "-" * 70
        )

        for _, row in (
            tested.iterrows()
        ):

            print(
                f"{row['comparator_model']:30s} "
                f"ΔAUC="
                f"{row['auc_difference']:+.6f} "
                f"95%CI=["
                f"{row['auc_difference_ci_low']:.6f}, "
                f"{row['auc_difference_ci_high']:.6f}] "
                f"Holm-p="
                f"{row['p_value_holm']:.6f}"
            )

        print(
            "\nSTATUS: "
            "PASS_PAIRED_OUTER_CV_COMPARISONS_COMPLETED"
        )

    else:

        print(
            "\nSTATUS: "
            "PARTIAL_NO_EXACT_PAIRING_ESTABLISHED"
        )

    print(
        "\nProtocol protection:"
    )

    print(
        "  Locked test used: FALSE"
    )

    print(
        "  UCI external data used: FALSE"
    )

    print(
        "  Model retraining: FALSE"
    )


if __name__ == "__main__":

    main()