"""
Implementation 47: A8 vs A8 + clinical feature engineering
Development-only five-fold outer CV. Does not load calibration or locked test data.

Models:
  A: Original A8, 11 predictors.
  B: A8 + BMI, pulse pressure, mean arterial pressure, 14 predictors.

Clinical features are calculated from the development CSV only. Imputation and
scaling are fitted on the inner fitting subset (not the early-stopping subset),
then applied to stopping and outer-validation subsets.

Outputs use implementation47_* names and do not overwrite prior results.
"""

import os
import json
import time
import random
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, brier_score_loss,
)
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

warnings.filterwarnings("ignore")

SEED = 2026
PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
MODELS_DIR = PROJECT_ROOT / "results" / "models"
DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

TARGET = "cardio"
ID_COL = "id"
BASE_FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]
CLINICAL_FEATURES = ["bmi", "pulse_pressure", "mean_arterial_pressure"]

BASE_GROUPS = {
    "demographic": ["age", "gender"],
    "physiological_anthropometric_metabolic": [
        "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc"
    ],
    "lifestyle": ["smoke", "alco", "active"],
}
FEATURE_SETUPS = {
    "A8_original": {
        "features": BASE_FEATURES,
        "groups": BASE_GROUPS,
    },
    "A8_plus_clinical": {
        "features": BASE_FEATURES + CLINICAL_FEATURES,
        "groups": {
            "demographic": ["age", "gender"],
            "physiological_anthropometric_metabolic": [
                "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc",
                "bmi", "pulse_pressure", "mean_arterial_pressure"
            ],
            "lifestyle": ["smoke", "alco", "active"],
        },
    },
}

CHEB_K = 5
GROUP_EMBED_DIM = 16
LEARNING_RATE = 1e-3
L2 = 1e-4
KAN_L1 = 1e-5
GATE_L1 = 1e-4
BATCH_SIZE = 1024
MAX_EPOCHS = 100
PATIENCE = 10
OUTER_FOLDS = 5
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
GROUP_ORDER = list(BASE_GROUPS.keys())


def seed_everything(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class ChebyshevKAN(nn.Module):
    def __init__(self, input_dim, output_dim, degree):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.degree = degree
        self.coefficients = nn.Parameter(
            torch.empty(output_dim, input_dim, degree + 1)
        )
        self.bias = nn.Parameter(torch.zeros(output_dim))
        nn.init.normal_(self.coefficients, mean=0.0, std=0.02)

    def forward(self, x):
        x = torch.clamp(x, -1.0, 1.0)
        terms = [torch.ones_like(x)]
        if self.degree >= 1:
            terms.append(x)
        for _k in range(2, self.degree + 1):
            terms.append(2.0 * x * terms[-1] - terms[-2])
        basis = torch.stack(terms, dim=-1)
        return torch.einsum("bid,oid->bo", basis, self.coefficients) + self.bias


class A8CrossGroupInteractionChebKAN(nn.Module):
    def __init__(self, group_sizes, embedding_dim=16, degree=5):
        super().__init__()
        self.demographic_kan = ChebyshevKAN(
            group_sizes["demographic"], embedding_dim, degree
        )
        self.physiological_kan = ChebyshevKAN(
            group_sizes["physiological_anthropometric_metabolic"],
            embedding_dim, degree
        )
        self.lifestyle_kan = ChebyshevKAN(
            group_sizes["lifestyle"], embedding_dim, degree
        )
        self.interaction_projection = nn.Linear(embedding_dim * 3, embedding_dim)
        self.output_layer = nn.Linear(embedding_dim * 2, 1)
        self.gate_logits = nn.Parameter(torch.zeros(3))
        self.activation = nn.SiLU()

    def forward(self, group_inputs):
        h_demo = self.activation(self.demographic_kan(group_inputs["demographic"]))
        h_phys = self.activation(self.physiological_kan(
            group_inputs["physiological_anthropometric_metabolic"]
        ))
        h_life = self.activation(self.lifestyle_kan(group_inputs["lifestyle"]))
        gates = torch.softmax(self.gate_logits, dim=0)
        h_gate = gates[0] * h_demo + gates[1] * h_phys + gates[2] * h_life
        interactions = torch.cat(
            [h_demo * h_phys, h_demo * h_life, h_phys * h_life], dim=1
        )
        h_interaction = self.activation(self.interaction_projection(interactions))
        return self.output_layer(torch.cat([h_gate, h_interaction], dim=1)).squeeze(1)

    def coefficient_l1(self):
        return (
            self.demographic_kan.coefficients.abs().sum()
            + self.physiological_kan.coefficients.abs().sum()
            + self.lifestyle_kan.coefficients.abs().sum()
        )

    def gate_l1(self):
        return self.gate_logits.abs().sum()

    def gate_values(self):
        return torch.softmax(self.gate_logits, dim=0).detach().cpu().numpy()


def fit_preprocessor(X_raw):
    imputer = SimpleImputer(strategy="median")
    X_imp = imputer.fit_transform(X_raw)
    scaler = MinMaxScaler(feature_range=(-1.0, 1.0))
    X_scaled = scaler.fit_transform(X_imp).astype(np.float32)
    return imputer, scaler, X_scaled


def transform_preprocessor(X_raw, imputer, scaler):
    return scaler.transform(imputer.transform(X_raw)).astype(np.float32)


def get_group_indexes(features, groups):
    return {name: [features.index(f) for f in groups[name]] for name in GROUP_ORDER}


def create_loader(X, y, group_indexes):
    tensors = [
        torch.tensor(X[:, group_indexes[name]], dtype=torch.float32)
        for name in GROUP_ORDER
    ]
    tensors.append(torch.tensor(y.astype(np.float32), dtype=torch.float32))
    ds = TensorDataset(*tensors)
    generator = torch.Generator()
    generator.manual_seed(SEED)
    return DataLoader(
        ds, batch_size=BATCH_SIZE, shuffle=True, generator=generator,
        drop_last=False, pin_memory=torch.cuda.is_available()
    )


def to_group_tensors(X, group_indexes):
    return {
        name: torch.tensor(
            X[:, group_indexes[name]], dtype=torch.float32, device=DEVICE
        )
        for name in GROUP_ORDER
    }


def calculate_metrics(y_true, probabilities):
    pred = (probabilities >= 0.5).astype(int)
    tn = np.sum((y_true == 0) & (pred == 0))
    fp = np.sum((y_true == 0) & (pred == 1))
    return {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "sensitivity": recall_score(y_true, pred, zero_division=0),
        "specificity": tn / (tn + fp) if tn + fp else np.nan,
        "f1": f1_score(y_true, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, probabilities),
        "pr_auc": average_precision_score(y_true, probabilities),
        "brier": brier_score_loss(y_true, probabilities),
    }


def fit_model(X_fit, y_fit, X_stop, y_stop, group_indexes, group_sizes, seed):
    seed_everything(seed)
    model = A8CrossGroupInteractionChebKAN(
        group_sizes=group_sizes, embedding_dim=GROUP_EMBED_DIM, degree=CHEB_K
    ).to(DEVICE)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=LEARNING_RATE, weight_decay=L2
    )
    criterion = nn.BCEWithLogitsLoss()
    loader = create_loader(X_fit, y_fit, group_indexes)
    stop_groups = to_group_tensors(X_stop, group_indexes)
    stop_y = torch.tensor(y_stop.astype(np.float32), device=DEVICE)
    best_state, best_loss, best_epoch, patience_count = None, np.inf, 0, 0

    for epoch in range(1, MAX_EPOCHS + 1):
        model.train()
        for batch in loader:
            inputs = {
                name: batch[i].to(DEVICE, non_blocking=True)
                for i, name in enumerate(GROUP_ORDER)
            }
            batch_y = batch[len(GROUP_ORDER)].to(DEVICE, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            logits = model(inputs)
            loss = (
                criterion(logits, batch_y)
                + KAN_L1 * model.coefficient_l1()
                + GATE_L1 * model.gate_l1()
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

        model.eval()
        with torch.no_grad():
            stop_loss = criterion(model(stop_groups), stop_y).item()
        if stop_loss < best_loss - 1e-6:
            best_loss = stop_loss
            best_state = {
                k: v.detach().cpu().clone()
                for k, v in model.state_dict().items()
            }
            best_epoch = epoch
            patience_count = 0
        else:
            patience_count += 1
        if patience_count >= PATIENCE:
            break

    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return model, best_epoch, best_loss


def predict(model, X, group_indexes):
    with torch.no_grad():
        logits = model(to_group_tensors(X, group_indexes))
        return torch.sigmoid(logits).detach().cpu().numpy()


def derive_features(df):
    out = df.copy()
    # Keep all original source values; missing/implausible BP values are not repaired.
    height_m = pd.to_numeric(out["height"], errors="coerce") / 100.0
    weight = pd.to_numeric(out["weight"], errors="coerce")
    out["bmi"] = weight / (height_m ** 2)
    systolic = pd.to_numeric(out["ap_hi"], errors="coerce")
    diastolic = pd.to_numeric(out["ap_lo"], errors="coerce")
    out["pulse_pressure"] = systolic - diastolic
    out["mean_arterial_pressure"] = (systolic + 2.0 * diastolic) / 3.0
    new_cols = CLINICAL_FEATURES
    out[new_cols] = out[new_cols].replace([np.inf, -np.inf], np.nan)
    # Invalid/non-positive height cannot yield a meaningful BMI.
    out.loc[~np.isfinite(height_m) | (height_m <= 0), "bmi"] = np.nan
    return out


def main():
    start = time.time()
    print("=" * 78)
    print("IMPLEMENTATION 47: A8 vs A8 + CLINICAL FEATURES")
    print("Development-only outer CV; locked test and calibration data are not loaded.")
    print("Device:", DEVICE)
    print("=" * 78)

    if not DEV_FILE.exists():
        raise FileNotFoundError(f"Development CSV not found: {DEV_FILE}")
    df = pd.read_csv(DEV_FILE)
    required = [ID_COL] + BASE_FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Required columns missing from development CSV: {missing}")
    if len(df) != 49000 or df[ID_COL].duplicated().any():
        raise RuntimeError(
            f"Expected 49,000 rows and unique IDs; rows={len(df)}, "
            f"duplicate IDs={df[ID_COL].duplicated().sum()}"
        )
    df = derive_features(df)
    y = df[TARGET].to_numpy(dtype=np.int64)
    print(f"Development rows: {len(df):,}; unique IDs: {df[ID_COL].nunique():,}")
    print("Derived-feature missing counts:")
    print(df[CLINICAL_FEATURES].isna().sum().to_string())
    print("No locked-test or calibration files are read by this script.")

    outer = StratifiedKFold(n_splits=OUTER_FOLDS, shuffle=True, random_state=SEED)
    splits = list(outer.split(np.zeros(len(df)), y))
    all_predictions, fold_results, audit = [], [], []

    for model_name, setup in FEATURE_SETUPS.items():
        features, groups = setup["features"], setup["groups"]
        group_indexes = get_group_indexes(features, groups)
        group_sizes = {name: len(groups[name]) for name in GROUP_ORDER}
        X = df[features].to_numpy(dtype=np.float32)
        print("\n" + "=" * 78)
        print(f"MODEL: {model_name} | features={len(features)}")
        print("Groups:", group_sizes)

        model_predictions = []
        for fold, (outer_train_idx, val_idx) in enumerate(splits, start=1):
            # Inner stopping split is made only inside the outer-training partition.
            y_outer_train = y[outer_train_idx]
            inner = StratifiedKFold(
                n_splits=10, shuffle=True, random_state=SEED + fold
            )
            fit_rel, stop_rel = next(
                inner.split(np.zeros(len(y_outer_train)), y_outer_train)
            )
            fit_idx = outer_train_idx[fit_rel]
            stop_idx = outer_train_idx[stop_rel]

            # Critical leakage prevention: fit imputer/scaler on fitting subset only.
            imputer, scaler, X_fit = fit_preprocessor(X[fit_idx])
            X_stop = transform_preprocessor(X[stop_idx], imputer, scaler)
            X_val = transform_preprocessor(X[val_idx], imputer, scaler)

            model, best_epoch, best_stop_loss = fit_model(
                X_fit, y[fit_idx], X_stop, y[stop_idx],
                group_indexes, group_sizes, seed=SEED + 10000 + fold
            )
            prob = predict(model, X_val, group_indexes)
            metrics = calculate_metrics(y[val_idx], prob)
            fold_row = {
                "model": model_name, "outer_fold": fold,
                **metrics, "best_epoch": best_epoch,
                "best_stop_loss": best_stop_loss,
                "n_features": len(features),
                "n_parameters": sum(p.numel() for p in model.parameters()),
                "fit_rows": len(fit_idx), "stop_rows": len(stop_idx),
                "validation_rows": len(val_idx),
            }
            fold_results.append(fold_row)
            pred_frame = pd.DataFrame({
                "model": model_name,
                "row_index": val_idx,
                "id": df.iloc[val_idx][ID_COL].to_numpy(),
                "outer_fold": fold,
                "y_true": y[val_idx],
                "probability": prob,
                "prediction_050": (prob >= 0.5).astype(int),
            })
            model_predictions.append(pred_frame)
            all_predictions.append(pred_frame)
            audit.append({
                "model": model_name, "fold": fold,
                "n_validation": len(val_idx),
                "unique_validation_rows": int(pd.Series(val_idx).nunique()),
                "validation_row_min": int(np.min(val_idx)),
                "validation_row_max": int(np.max(val_idx)),
                "best_epoch": best_epoch,
                "best_stop_loss": best_stop_loss,
            })
            print(
                f"Fold {fold}/5: AUC={metrics['roc_auc']:.6f}, "
                f"PR-AUC={metrics['pr_auc']:.6f}, "
                f"Brier={metrics['brier']:.6f}, epoch={best_epoch}"
            )
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        pred_all = pd.concat(model_predictions, ignore_index=True).sort_values(
            "row_index"
        )
        if len(pred_all) != len(df) or pred_all["row_index"].nunique() != len(df):
            raise RuntimeError(f"Outer-CV prediction coverage failed for {model_name}")
        pooled = calculate_metrics(
            pred_all["y_true"].to_numpy(),
            pred_all["probability"].to_numpy()
        )
        print(
            f"{model_name} pooled OOF: ROC-AUC={pooled['roc_auc']:.6f}, "
            f"PR-AUC={pooled['pr_auc']:.6f}, Brier={pooled['brier']:.6f}"
        )

    folds_df = pd.DataFrame(fold_results)
    preds_df = pd.concat(all_predictions, ignore_index=True)
    folds_path = RESULTS_DIR / "implementation47_clinical_feature_cv_fold_results.csv"
    preds_path = RESULTS_DIR / "implementation47_clinical_feature_cv_oof_predictions.csv"
    summary_path = RESULTS_DIR / "implementation47_clinical_feature_cv_summary.json"
    audit_path = RESULTS_DIR / "implementation47_clinical_feature_cv_audit.json"

    folds_df.to_csv(folds_path, index=False)
    preds_df.to_csv(preds_path, index=False)

    summaries = {}
    for model_name in FEATURE_SETUPS:
        p = preds_df[preds_df["model"] == model_name].sort_values("row_index")
        pooled = calculate_metrics(p["y_true"].to_numpy(), p["probability"].to_numpy())
        fold = folds_df[folds_df["model"] == model_name]
        summaries[model_name] = {
            "n_features": len(FEATURE_SETUPS[model_name]["features"]),
            "pooled_oof_metrics": {k: float(v) for k, v in pooled.items()},
            "mean_fold_roc_auc": float(fold["roc_auc"].mean()),
            "sd_fold_roc_auc": float(fold["roc_auc"].std(ddof=1)),
            "fold_best_epochs": [int(v) for v in fold["best_epoch"].tolist()],
            "all_49000_rows_predicted_once": bool(
                len(p) == 49000 and p["row_index"].nunique() == 49000
            ),
        }
    summary = {
        "implementation": 47,
        "purpose": "Development-only comparison of original A8 vs A8 with three derived clinical features",
        "development_rows": len(df),
        "unique_ids": int(df[ID_COL].nunique()),
        "outer_folds": OUTER_FOLDS,
        "outer_split_seed": SEED,
        "inner_early_stopping_split": "10-fold StratifiedKFold, first split, seed=2026+outer_fold",
        "preprocessing_fit_scope": "inner fitting subset only; applied to stopping and outer validation subsets",
        "clinical_features": {
            "bmi": "weight_kg / (height_cm / 100)^2",
            "pulse_pressure": "ap_hi - ap_lo",
            "mean_arterial_pressure": "(ap_hi + 2*ap_lo)/3",
        },
        "imputation": "median fitted separately within each fitting subset",
        "scaling": "MinMaxScaler(-1,1) fitted separately within each fitting subset",
        "locked_test_used": False,
        "calibration_data_used": False,
        "model_summaries": summaries,
        "elapsed_minutes": round((time.time() - start) / 60.0, 2),
        "caution": "Exploratory development-CV comparison only; do not use locked-test results to select between models.",
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    audit_payload = {
        "development_rows": len(df),
        "unique_ids": int(df[ID_COL].nunique()),
        "expected_predictions_per_model": len(df),
        "fold_audit": audit,
        "locked_test_loaded": False,
        "calibration_file_loaded": False,
    }
    audit_path.write_text(json.dumps(audit_payload, indent=2), encoding="utf-8")

    print("\n" + "=" * 78)
    print("IMPLEMENTATION 47 COMPLETE")
    print("Fold results:", folds_path)
    print("OOF predictions:", preds_path)
    print("Summary:", summary_path)
    print("Audit:", audit_path)
    print("Elapsed minutes:", round((time.time() - start) / 60.0, 2))
    print("IMPORTANT: These are development-CV results, not locked-test results.")


if __name__ == "__main__":
    main()
