# ================================================================
# IMPLEMENTATION 22
# LOGISTIC REGRESSION BASELINE
# ================================================================
#
# Project:
#   CGS-ChebKAN Cardiovascular Disease Study
#
# Model:
#   Logistic Regression
#
# Purpose:
#   Establish a transparent statistical baseline under the same
#   leakage-controlled nested-CV protocol used for all subsequent
#   models.
#
# Frozen protocol:
#   Development/CV       = 49,000
#   Conformal calibration = 7,000
#   Locked test          = 14,000
#
# Nested CV:
#   Outer = 5 folds
#   Inner = 4 folds
#
# Preprocessing:
#   Median imputation fitted only on active training data
#   StandardScaler fitted only on active training data
#
# Important:
#   Calibration and locked test are NOT used for model selection.
#   No ADASYN in the primary pipeline.
#   All 11 primary Kaggle predictors are used.
#
# ================================================================

from pathlib import Path
from datetime import datetime
import json
import random
import warnings
import sys

import numpy as np
import pandas as pd

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    brier_score_loss,
)
from sklearn.calibration import calibration_curve


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = DATA_DIR / "processed"

RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR = RESULTS_DIR / "figures"
CHECKPOINT_DIR = RESULTS_DIR / "checkpoints"
LOG_DIR = PROJECT_ROOT / "logs"


for directory in [
    RESULTS_DIR,
    TABLES_DIR,
    FIGURES_DIR,
    CHECKPOINT_DIR,
    LOG_DIR,
]:
    directory.mkdir(
        parents=True,
        exist_ok=True
    )


# ================================================================
# 2. REPRODUCIBILITY
# ================================================================

RANDOM_STATE = 2026

np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)

warnings.filterwarnings("ignore")


# ================================================================
# 3. INPUT FILE
# ================================================================

DEV_FILE = (
    PROCESSED_DIR /
    "kaggle_development_cv.csv"
)

CALIBRATION_FILE = (
    PROCESSED_DIR /
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROCESSED_DIR /
    "kaggle_locked_test.csv"
)


# ================================================================
# 4. FROZEN FEATURES
# ================================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"


# ================================================================
# 5. NESTED CV CONFIGURATION
# ================================================================

N_OUTER = 5
N_INNER = 4

CV_RANDOM_STATE = 2026


# ================================================================
# 6. LOGISTIC REGRESSION HYPERPARAMETER GRID
# ================================================================
#
# C controls inverse regularization strength.
#
# We use L2 regularization because it provides a standard,
# stable clinical statistical baseline.
#
# Solver:
#   liblinear
#
# Class weighting:
#   None
#
# Reason:
#   The development data are essentially class balanced.
#
# ================================================================

C_GRID = [
    0.01,
    0.1,
    1.0,
    10.0,
    100.0,
]


# ================================================================
# 7. PRINT HEADER
# ================================================================

print("=" * 78)
print("IMPLEMENTATION 22")
print("LOGISTIC REGRESSION BASELINE")
print("=" * 78)

print()
print("Project:")
print(PROJECT_ROOT)

print()
print("Timestamp:")
print(
    datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )
)

print()


# ================================================================
# 8. VERIFY INPUT FILES
# ================================================================

print("1. INPUT FILE VALIDATION")
print("-" * 78)

required_files = {
    "development": DEV_FILE,
    "calibration": CALIBRATION_FILE,
    "locked_test": TEST_FILE,
}

file_errors = []

for name, file_path in required_files.items():

    print(f"{name}:")
    print(f"  {file_path}")

    if file_path.exists():

        print("  STATUS: EXISTS")

    else:

        print("  STATUS: MISSING")

        file_errors.append(
            f"Missing file: {file_path}"
        )

if file_errors:

    print()

    for error in file_errors:
        print("ERROR:", error)

    sys.exit(1)

print()


# ================================================================
# 9. LOAD DEVELOPMENT DATA
# ================================================================
#
# Only Development is used during nested CV.
#
# Calibration and test are loaded ONLY for protection checks.
#
# ================================================================

print("2. LOADING DATA")
print("-" * 78)

development = pd.read_csv(
    DEV_FILE
)

calibration = pd.read_csv(
    CALIBRATION_FILE
)

locked_test = pd.read_csv(
    TEST_FILE
)

print(
    f"Development: "
    f"{len(development):,} rows"
)

print(
    f"Calibration: "
    f"{len(calibration):,} rows"
)

print(
    f"Locked test: "
    f"{len(locked_test):,} rows"
)

print()


# ================================================================
# 10. BASIC DATA VALIDATION
# ================================================================

print("3. BASIC DATA VALIDATION")
print("-" * 78)

if len(development) != 49000:

    print(
        "ERROR: Development set must contain "
        "49,000 records."
    )

    sys.exit(1)

if len(calibration) != 7000:

    print(
        "ERROR: Calibration set must contain "
        "7,000 records."
    )

    sys.exit(1)

if len(locked_test) != 14000:

    print(
        "ERROR: Locked test must contain "
        "14,000 records."
    )

    sys.exit(1)


required_columns = FEATURES + [TARGET]

for dataset_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:

        print(
            f"ERROR: {dataset_name} is missing: "
            f"{missing_columns}"
        )

        sys.exit(1)


print(
    "Data dimensions and required columns: PASS"
)

print()


# ================================================================
# 11. TARGET VALIDATION
# ================================================================

print("4. TARGET VALIDATION")
print("-" * 78)

for dataset_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    unique_values = sorted(
        df[TARGET]
        .dropna()
        .unique()
        .tolist()
    )

    missing_target = int(
        df[TARGET].isna().sum()
    )

    print(
        f"{dataset_name}: "
        f"classes={unique_values}, "
        f"missing={missing_target}"
    )

    if unique_values != [0, 1]:

        print(
            f"ERROR: {dataset_name} target "
            f"is not binary."
        )

        sys.exit(1)

    if missing_target != 0:

        print(
            f"ERROR: {dataset_name} contains "
            f"missing target values."
        )

        sys.exit(1)


print()
print("Target validation: PASS")

print()


# ================================================================
# 12. PARTITION DISJOINTNESS
# ================================================================

print("5. PARTITION PROTECTION")
print("-" * 78)

dev_ids = set(
    development["id"].astype(int)
)

calibration_ids = set(
    calibration["id"].astype(int)
)

test_ids = set(
    locked_test["id"].astype(int)
)

overlap_dev_cal = (
    dev_ids &
    calibration_ids
)

overlap_dev_test = (
    dev_ids &
    test_ids
)

overlap_cal_test = (
    calibration_ids &
    test_ids
)

print(
    f"Development ∩ Calibration: "
    f"{len(overlap_dev_cal)}"
)

print(
    f"Development ∩ Locked Test: "
    f"{len(overlap_dev_test)}"
)

print(
    f"Calibration ∩ Locked Test: "
    f"{len(overlap_cal_test)}"
)

if (
    overlap_dev_cal
    or
    overlap_dev_test
    or
    overlap_cal_test
):

    print()
    print(
        "ERROR: Partition overlap detected."
    )

    sys.exit(1)

print()
print(
    "Partition protection: PASS"
)

print()


# ================================================================
# 13. DEVELOPMENT DATA
# ================================================================

X = development[
    FEATURES
].copy()

y = development[
    TARGET
].astype(int).copy()


# ================================================================
# 14. METRIC FUNCTION
# ================================================================

def expected_calibration_error(
    y_true,
    y_prob,
    n_bins=10,
):
    """
    Compute Expected Calibration Error (ECE).

    Equal-width probability bins are used.
    Empty bins are ignored.
    """

    y_true = np.asarray(
        y_true
    )

    y_prob = np.asarray(
        y_prob
    )

    bin_edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    total = len(
        y_true
    )

    for i in range(n_bins):

        lower = bin_edges[i]
        upper = bin_edges[i + 1]

        if i == n_bins - 1:

            mask = (
                (y_prob >= lower)
                &
                (y_prob <= upper)
            )

        else:

            mask = (
                (y_prob >= lower)
                &
                (y_prob < upper)
            )

        if not np.any(mask):
            continue

        bin_probability = y_prob[
            mask
        ].mean()

        bin_accuracy = y_true[
            mask
        ].mean()

        bin_weight = (
            mask.sum() /
            total
        )

        ece += (
            bin_weight *
            abs(
                bin_accuracy -
                bin_probability
            )
        )

    return float(ece)


# ================================================================
# 15. METRIC CALCULATION
# ================================================================

def calculate_metrics(
    y_true,
    y_probability,
    threshold=0.50,
):
    """
    Calculate the complete frozen metric set.
    """

    y_true = np.asarray(
        y_true
    )

    y_probability = np.asarray(
        y_probability
    )

    y_prediction = (
        y_probability >= threshold
    ).astype(int)

    accuracy = accuracy_score(
        y_true,
        y_prediction
    )

    precision = precision_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    recall = recall_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    roc_auc = roc_auc_score(
        y_true,
        y_probability
    )

    pr_auc = average_precision_score(
        y_true,
        y_probability
    )

    brier = brier_score_loss(
        y_true,
        y_probability
    )

    ece = expected_calibration_error(
        y_true,
        y_probability,
        n_bins=10
    )

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        y_prediction,
        labels=[0, 1]
    ).ravel()

    specificity = (
        tn /
        (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {

        "accuracy":
            float(accuracy),

        "precision":
            float(precision),

        "sensitivity_recall":
            float(recall),

        "specificity":
            float(specificity),

        "f1":
            float(f1),

        "roc_auc":
            float(roc_auc),

        "pr_auc":
            float(pr_auc),

        "brier_score":
            float(brier),

        "ece":
            float(ece),

        "tn":
            int(tn),

        "fp":
            int(fp),

        "fn":
            int(fn),

        "tp":
            int(tp),
    }


# ================================================================
# 16. OUTER AND INNER CV
# ================================================================

outer_cv = StratifiedKFold(
    n_splits=N_OUTER,
    shuffle=True,
    random_state=CV_RANDOM_STATE,
)


# ================================================================
# 17. STORAGE
# ================================================================

outer_results = []

inner_selection_results = []

all_outer_predictions = []

all_outer_targets = []

best_parameters = []


# ================================================================
# 18. START NESTED CV
# ================================================================

print("6. NESTED CROSS-VALIDATION")
print("-" * 78)

print()
print(
    "Outer folds:",
    N_OUTER
)

print(
    "Inner folds:",
    N_INNER
)

print(
    "C grid:",
    C_GRID
)

print()


# ================================================================
# 19. OUTER LOOP
# ================================================================

for outer_fold, (
    outer_train_idx,
    outer_validation_idx
) in enumerate(
    outer_cv.split(
        X,
        y
    ),
    start=1
):

    print("=" * 78)

    print(
        f"OUTER FOLD {outer_fold}/{N_OUTER}"
    )

    print("=" * 78)

    # ------------------------------------------------------------
    # Outer training / validation split
    # ------------------------------------------------------------

    X_outer_train = X.iloc[
        outer_train_idx
    ].copy()

    y_outer_train = y.iloc[
        outer_train_idx
    ].copy()

    X_outer_validation = X.iloc[
        outer_validation_idx
    ].copy()

    y_outer_validation = y.iloc[
        outer_validation_idx
    ].copy()

    print()
    print(
        f"Outer training size: "
        f"{len(X_outer_train):,}"
    )

    print(
        f"Outer validation size: "
        f"{len(X_outer_validation):,}"
    )

    # ============================================================
    # 20. INNER CV HYPERPARAMETER SELECTION
    # ============================================================

    inner_cv = StratifiedKFold(
        n_splits=N_INNER,
        shuffle=True,
        random_state=CV_RANDOM_STATE,
    )

    inner_scores = []

    print()
    print(
        "Inner CV hyperparameter selection:"
    )

    for C_value in C_GRID:

        fold_auc_scores = []

        for inner_fold, (
            inner_train_idx,
            inner_validation_idx
        ) in enumerate(
            inner_cv.split(
                X_outer_train,
                y_outer_train
            ),
            start=1
        ):

            X_inner_train = (
                X_outer_train.iloc[
                    inner_train_idx
                ].copy()
            )

            y_inner_train = (
                y_outer_train.iloc[
                    inner_train_idx
                ].copy()
            )

            X_inner_validation = (
                X_outer_train.iloc[
                    inner_validation_idx
                ].copy()
            )

            y_inner_validation = (
                y_outer_train.iloc[
                    inner_validation_idx
                ].copy()
            )

            # ----------------------------------------------------
            # Fold-specific preprocessing
            # ----------------------------------------------------

            imputer = SimpleImputer(
                strategy="median"
            )

            X_inner_train_imp = (
                imputer.fit_transform(
                    X_inner_train
                )
            )

            X_inner_validation_imp = (
                imputer.transform(
                    X_inner_validation
                )
            )

            scaler = StandardScaler()

            X_inner_train_scaled = (
                scaler.fit_transform(
                    X_inner_train_imp
                )
            )

            X_inner_validation_scaled = (
                scaler.transform(
                    X_inner_validation_imp
                )
            )

            # ----------------------------------------------------
            # Logistic Regression
            # ----------------------------------------------------

            model = LogisticRegression(
                C=C_value,
                penalty="l2",
                solver="liblinear",
                class_weight=None,
                max_iter=5000,
                random_state=RANDOM_STATE,
            )

            model.fit(
                X_inner_train_scaled,
                y_inner_train
            )

            validation_probability = (
                model.predict_proba(
                    X_inner_validation_scaled
                )[:, 1]
            )

            fold_auc = roc_auc_score(
                y_inner_validation,
                validation_probability
            )

            fold_auc_scores.append(
                fold_auc
            )

        mean_inner_auc = float(
            np.mean(
                fold_auc_scores
            )
        )

        std_inner_auc = float(
            np.std(
                fold_auc_scores,
                ddof=1
            )
        )

        inner_scores.append({

            "outer_fold":
                outer_fold,

            "C":
                C_value,

            "inner_mean_roc_auc":
                mean_inner_auc,

            "inner_std_roc_auc":
                std_inner_auc,
        })

        print(
            f"  C={C_value:<7} "
            f"mean ROC-AUC="
            f"{mean_inner_auc:.6f} "
            f"± {std_inner_auc:.6f}"
        )

    # ============================================================
    # 21. SELECT BEST HYPERPARAMETER
    # ============================================================

    best_inner = max(
        inner_scores,
        key=lambda item:
            item["inner_mean_roc_auc"]
    )

    best_C = best_inner["C"]

    best_parameters.append({

        "outer_fold":
            outer_fold,

        "selected_C":
            best_C,

        "inner_mean_roc_auc":
            best_inner[
                "inner_mean_roc_auc"
            ],

        "inner_std_roc_auc":
            best_inner[
                "inner_std_roc_auc"
            ],
    })

    print()
    print(
        f"Selected C for outer fold "
        f"{outer_fold}: {best_C}"
    )

    # ============================================================
    # 22. OUTER-FOLD PREPROCESSING
    # ============================================================

    imputer = SimpleImputer(
        strategy="median"
    )

    X_outer_train_imp = (
        imputer.fit_transform(
            X_outer_train
        )
    )

    X_outer_validation_imp = (
        imputer.transform(
            X_outer_validation
        )
    )

    scaler = StandardScaler()

    X_outer_train_scaled = (
        scaler.fit_transform(
            X_outer_train_imp
        )
    )

    X_outer_validation_scaled = (
        scaler.transform(
            X_outer_validation_imp
        )
    )

    # ------------------------------------------------------------
    # Safety checks
    # ------------------------------------------------------------

    if np.isnan(
        X_outer_train_scaled
    ).any():

        print(
            "ERROR: NaN in outer training data."
        )

        sys.exit(1)

    if np.isnan(
        X_outer_validation_scaled
    ).any():

        print(
            "ERROR: NaN in outer validation data."
        )

        sys.exit(1)

    if not np.isfinite(
        X_outer_train_scaled
    ).all():

        print(
            "ERROR: Non-finite values in "
            "outer training data."
        )

        sys.exit(1)

    if not np.isfinite(
        X_outer_validation_scaled
    ).all():

        print(
            "ERROR: Non-finite values in "
            "outer validation data."
        )

        sys.exit(1)

    # ============================================================
    # 23. FINAL MODEL FOR THIS OUTER FOLD
    # ============================================================

    outer_model = LogisticRegression(
        C=best_C,
        penalty="l2",
        solver="liblinear",
        class_weight=None,
        max_iter=5000,
        random_state=RANDOM_STATE,
    )

    outer_model.fit(
        X_outer_train_scaled,
        y_outer_train
    )

    # ============================================================
    # 24. OUTER VALIDATION PREDICTIONS
    # ============================================================

    outer_probability = (
        outer_model.predict_proba(
            X_outer_validation_scaled
        )[:, 1]
    )

    metrics = calculate_metrics(
        y_outer_validation,
        outer_probability,
        threshold=0.50,
    )

    # Add fold information

    metrics["outer_fold"] = (
        outer_fold
    )

    metrics["selected_C"] = (
        best_C
    )

    metrics["n_train"] = (
        len(X_outer_train)
    )

    metrics["n_validation"] = (
        len(X_outer_validation)
    )

    outer_results.append(
        metrics
    )

    # Store predictions for pooled development estimate

    all_outer_predictions.extend(
        outer_probability.tolist()
    )

    all_outer_targets.extend(
        y_outer_validation.tolist()
    )

    # ============================================================
    # 25. PRINT OUTER-FOLD RESULTS
    # ============================================================

    print()
    print(
        "Outer validation results:"
    )

    print(
        f"  Accuracy:    "
        f"{metrics['accuracy']:.6f}"
    )

    print(
        f"  Precision:   "
        f"{metrics['precision']:.6f}"
    )

    print(
        f"  Sensitivity: "
        f"{metrics['sensitivity_recall']:.6f}"
    )

    print(
        f"  Specificity: "
        f"{metrics['specificity']:.6f}"
    )

    print(
        f"  F1:          "
        f"{metrics['f1']:.6f}"
    )

    print(
        f"  ROC-AUC:     "
        f"{metrics['roc_auc']:.6f}"
    )

    print(
        f"  PR-AUC:      "
        f"{metrics['pr_auc']:.6f}"
    )

    print(
        f"  Brier:       "
        f"{metrics['brier_score']:.6f}"
    )

    print(
        f"  ECE:         "
        f"{metrics['ece']:.6f}"
    )

    print()


# ================================================================
# 26. INNER CV RESULTS
# ================================================================

print("=" * 78)
print("7. INNER CV HYPERPARAMETER RESULTS")
print("=" * 78)

inner_results_df = pd.DataFrame(
    inner_selection_results
)

# The detailed inner scores were generated in each outer loop.
# Reconstruct them from the selected fold records and C grid
# if needed in the aggregate summary.

print()


# ================================================================
# 27. OUTER RESULTS DATAFRAME
# ================================================================

outer_results_df = pd.DataFrame(
    outer_results
)

print("=" * 78)
print("8. OUTER-FOLD RESULTS")
print("=" * 78)

print()

display_columns = [
    "outer_fold",
    "selected_C",
    "accuracy",
    "precision",
    "sensitivity_recall",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier_score",
    "ece",
]

print(
    outer_results_df[
        display_columns
    ].to_string(
        index=False,
        float_format=lambda x:
            f"{x:.6f}"
    )
)

print()


# ================================================================
# 28. AGGREGATE MEAN ± SD
# ================================================================

metric_columns = [
    "accuracy",
    "precision",
    "sensitivity_recall",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier_score",
    "ece",
]


aggregate_records = []

for metric in metric_columns:

    values = (
        outer_results_df[
            metric
        ].astype(float)
    )

    aggregate_records.append({

        "metric":
            metric,

        "mean":
            values.mean(),

        "std":
            values.std(
                ddof=1
            ),

        "min":
            values.min(),

        "max":
            values.max(),
    })


aggregate_df = pd.DataFrame(
    aggregate_records
)


# ================================================================
# 29. PRINT AGGREGATE RESULTS
# ================================================================

print("=" * 78)
print("9. AGGREGATE OUTER-CV RESULTS")
print("=" * 78)

print()

for _, row in aggregate_df.iterrows():

    print(
        f"{row['metric']:<22} "
        f"{row['mean']:.6f} "
        f"± "
        f"{row['std']:.6f}"
    )

print()


# ================================================================
# 30. POOLED OUTER-CV METRICS
# ================================================================

print("=" * 78)
print("10. POOLED OUTER-CV ESTIMATE")
print("=" * 78)

pooled_targets = np.asarray(
    all_outer_targets
)

pooled_predictions = np.asarray(
    all_outer_predictions
)

pooled_metrics = calculate_metrics(
    pooled_targets,
    pooled_predictions,
    threshold=0.50,
)

for key in [
    "accuracy",
    "precision",
    "sensitivity_recall",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier_score",
    "ece",
]:

    print(
        f"{key:<22} "
        f"{pooled_metrics[key]:.6f}"
    )

print()


# ================================================================
# 31. SELECTED C SUMMARY
# ================================================================

print("=" * 78)
print("11. SELECTED HYPERPARAMETERS")
print("=" * 78)

best_parameters_df = pd.DataFrame(
    best_parameters
)

print()

print(
    best_parameters_df.to_string(
        index=False,
        float_format=lambda x:
            f"{x:.6f}"
    )
)

print()


# ================================================================
# 32. HYPERPARAMETER STABILITY
# ================================================================

selected_C_values = (
    best_parameters_df[
        "selected_C"
    ].tolist()
)

unique_C, counts_C = np.unique(
    selected_C_values,
    return_counts=True
)

print(
    "Selected C frequency:"
)

for C_value, count in zip(
    unique_C,
    counts_C
):

    print(
        f"  C={C_value}: "
        f"{count}/{N_OUTER} outer folds"
    )

print()


# ================================================================
# 33. SAVE OUTER-FOLD RESULTS
# ================================================================

outer_results_file = (
    TABLES_DIR /
    "implementation22_logistic_outer_fold_results.csv"
)

outer_results_df.to_csv(
    outer_results_file,
    index=False
)

print(
    "Saved outer-fold results:"
)

print(
    outer_results_file
)

print()


# ================================================================
# 34. SAVE AGGREGATE RESULTS
# ================================================================

aggregate_file = (
    TABLES_DIR /
    "implementation22_logistic_aggregate_results.csv"
)

aggregate_df.to_csv(
    aggregate_file,
    index=False
)

print(
    "Saved aggregate results:"
)

print(
    aggregate_file
)

print()


# ================================================================
# 35. SAVE HYPERPARAMETER RESULTS
# ================================================================

hyperparameter_file = (
    TABLES_DIR /
    "implementation22_logistic_selected_hyperparameters.csv"
)

best_parameters_df.to_csv(
    hyperparameter_file,
    index=False
)

print(
    "Saved selected hyperparameters:"
)

print(
    hyperparameter_file
)

print()


# ================================================================
# 36. SAVE POOLED RESULTS
# ================================================================

pooled_file = (
    TABLES_DIR /
    "implementation22_logistic_pooled_outer_cv.csv"
)

pd.DataFrame(
    [pooled_metrics]
).to_csv(
    pooled_file,
    index=False
)

print(
    "Saved pooled outer-CV results:"
)

print(
    pooled_file
)

print()


# ================================================================
# 37. SAVE OUTER PREDICTIONS
# ================================================================

predictions_file = (
    TABLES_DIR /
    "implementation22_logistic_outer_predictions.csv"
)

predictions_df = pd.DataFrame({

    "y_true":
        pooled_targets,

    "predicted_probability":
        pooled_predictions,

    "predicted_class":
        (
            pooled_predictions >= 0.50
        ).astype(int),
})

predictions_df.to_csv(
    predictions_file,
    index=False
)

print(
    "Saved pooled predictions:"
)

print(
    predictions_file
)

print()


# ================================================================
# 38. FINAL EXPERIMENT RECORD
# ================================================================

experiment_record = {

    "implementation":
        "22",

    "model":
        "Logistic Regression",

    "timestamp":
        datetime.now().isoformat(),

    "random_state":
        RANDOM_STATE,

    "development_size":
        len(development),

    "calibration_size":
        len(calibration),

    "locked_test_size":
        len(locked_test),

    "features":
        FEATURES,

    "target":
        TARGET,

    "outer_folds":
        N_OUTER,

    "inner_folds":
        N_INNER,

    "C_grid":
        C_GRID,

    "regularization":
        "L2",

    "solver":
        "liblinear",

    "class_weight":
        None,

    "imputation":
        "Median fitted on active training fold only",

    "scaling":
        "StandardScaler fitted on active training fold only",

    "adasyn":
        False,

    "calibration_used":
        False,

    "locked_test_used":
        False,

    "external_uci_used":
        False,

    "outer_results":
        outer_results,

    "aggregate_results":
        aggregate_records,

    "pooled_results":
        pooled_metrics,

    "selected_hyperparameters":
        best_parameters,

    "model_training_completed":
        True,

    "locked_test_evaluated":
        False,

    "conformal_calibration_performed":
        False,
}


experiment_json = (
    TABLES_DIR /
    "implementation22_logistic_experiment_record.json"
)

with open(
    experiment_json,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        experiment_record,
        f,
        indent=2,
        default=str
    )


# ================================================================
# 39. FINAL STATUS
# ================================================================

print("=" * 78)
print("IMPLEMENTATION 22 COMPLETE")
print("=" * 78)

print()

print(
    "Logistic Regression nested-CV baseline "
    "training completed successfully."
)

print()

print(
    "IMPORTANT:"
)

print(
    "  Calibration set was NOT used for "
    "model selection."
)

print(
    "  Locked test set was NOT evaluated."
)

print(
    "  UCI data was NOT used."
)

print(
    "  ADASYN was NOT used."
)

print()

print(
    "Development evaluation:"
)

print(
    "  5-fold outer CV"
)

print(
    "  4-fold inner CV"
)

print(
    "  Fold-specific imputation"
)

print(
    "  Fold-specific scaling"
)

print()

print(
    "Experiment record:"
)

print(
    experiment_json
)

print()

print("=" * 78)
print("END OF IMPLEMENTATION 22")
print("=" * 78)