# ============================================================
# Implementation 43B-2 CORRECTED
# Exact reconciliation of A6 row_index -> Kaggle development ID
#
# PURPOSE:
#   A6 Implementation 31B saved row_index = val_idx, where val_idx
#   is the positional index within kaggle_development_cv.csv.
#
#   This script verifies:
#     A6 row_index
#       -> kaggle_development_cv.csv.iloc[row_index]
#       -> Kaggle ID
#       -> common baseline cohort
#
# NO model is retrained.
# NO hyperparameters are changed.
# NO locked test or UCI data are used.
# NO statistical testing is performed.
# ============================================================

from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DEV_FILE = PROJECT_ROOT / "data" / "processed" / "kaggle_development_cv.csv"
A6_FILE = PROJECT_ROOT / "results" / "tables" / (
    "implementation31b_reduced_corrected_a6_outer_predictions.csv"
)
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"

BASELINE_FILES = {
    "Random_Forest":
        RESULTS_DIR / "implementation23_random_forest_outer_predictions.csv",
    "XGBoost":
        RESULTS_DIR / "implementation24_xgboost_outer_predictions.csv",
    "MLP":
        RESULTS_DIR / "implementation25_mlp_outer_predictions.csv",
    "B-spline_KAN":
        RESULTS_DIR / "implementation26_bspline_kan_outer_predictions.csv",
    "Vanilla_Chebyshev_KAN":
        RESULTS_DIR / "implementation27_chebyshev_outer_predictions.csv",
}

OUTPUT_AUDIT = RESULTS_DIR / (
    "implementation43B2_CORRECTED_A6_row_index_reconciliation.csv"
)
OUTPUT_JSON = RESULTS_DIR / (
    "implementation43B2_CORRECTED_A6_row_index_reconciliation.json"
)
OUTPUT_MAPPING = RESULTS_DIR / (
    "implementation43B2_CORRECTED_A6_verified_row_index_to_kaggle_id.csv"
)
OUTPUT_REPORT = RESULTS_DIR / (
    "implementation43B2_CORRECTED_A6_reconciliation_report.txt"
)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalize_id_series(s):
    # Preserve integer IDs as integers where possible.
    return pd.to_numeric(s, errors="raise").astype(np.int64)


def load_baseline(path):
    df = pd.read_csv(path)

    required = {"id", "y_true"}
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(
            f"{path.name}: missing required columns {sorted(missing)}"
        )

    prob_col = None
    for c in ["probability", "y_prob", "predicted_probability"]:
        if c in df.columns:
            prob_col = c
            break

    if prob_col is None:
        raise RuntimeError(
            f"{path.name}: no probability column found."
        )

    out = df.copy()
    out["id"] = normalize_id_series(out["id"])
    out["y_true"] = pd.to_numeric(out["y_true"], errors="raise").astype(int)

    if out["id"].duplicated().any():
        raise RuntimeError(
            f"{path.name}: duplicate IDs detected."
        )

    return out


def main():

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("IMPLEMENTATION 43B-2 CORRECTED")
    print("EXACT A6 ROW_INDEX -> KAGGLE DEVELOPMENT ID RECONCILIATION")
    print("=" * 80)

    # ------------------------------------------------------------
    # 1. LOAD DEVELOPMENT FILE
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("1. LOADING KAGGLE DEVELOPMENT FILE")
    print("=" * 80)

    if not DEV_FILE.exists():
        raise FileNotFoundError(f"Development file not found:\n{DEV_FILE}")

    dev = pd.read_csv(DEV_FILE)

    if "id" not in dev.columns or "cardio" not in dev.columns:
        raise RuntimeError(
            "Development file must contain 'id' and 'cardio'."
        )

    dev["id"] = normalize_id_series(dev["id"])
    dev["cardio"] = pd.to_numeric(
        dev["cardio"], errors="raise"
    ).astype(int)

    print("File:", DEV_FILE)
    print("Rows:", f"{len(dev):,}")
    print("Columns:", list(dev.columns))

    dev_sha = sha256_file(DEV_FILE)
    print("SHA256:", dev_sha)

    if len(dev) != 49_000:
        raise RuntimeError(
            f"Expected 49,000 development rows; found {len(dev):,}."
        )

    if dev["id"].duplicated().any():
        raise RuntimeError("Development file contains duplicate IDs.")

    print("PASS: Development file contains exactly 49,000 unique IDs.")

    # ------------------------------------------------------------
    # 2. LOAD A6
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("2. LOADING A6 PREDICTIONS")
    print("=" * 80)

    if not A6_FILE.exists():
        raise FileNotFoundError(f"A6 prediction file not found:\n{A6_FILE}")

    a6 = pd.read_csv(A6_FILE)

    required_a6 = {
        "row_index",
        "outer_fold",
        "y_true",
        "probability",
    }
    missing = required_a6 - set(a6.columns)
    if missing:
        raise RuntimeError(
            f"A6 file missing required columns: {sorted(missing)}"
        )

    a6["row_index"] = pd.to_numeric(
        a6["row_index"], errors="raise"
    ).astype(int)
    a6["outer_fold"] = pd.to_numeric(
        a6["outer_fold"], errors="raise"
    ).astype(int)
    a6["y_true"] = pd.to_numeric(
        a6["y_true"], errors="raise"
    ).astype(int)
    a6["probability"] = pd.to_numeric(
        a6["probability"], errors="raise"
    ).astype(float)

    print("File:", A6_FILE)
    print("Rows:", f"{len(a6):,}")
    print("Columns:", list(a6.columns))
    print(
        "row_index range:",
        int(a6["row_index"].min()),
        "-",
        int(a6["row_index"].max()),
    )
    print("Unique row_index:", a6["row_index"].nunique())

    expected_indices = np.arange(len(dev))
    actual_indices = np.sort(a6["row_index"].to_numpy())

    index_range_pass = np.array_equal(
        actual_indices,
        expected_indices
    )

    print(
        "Exact row_index set 0..48999:",
        index_range_pass
    )

    if not index_range_pass:
        raise RuntimeError(
            "A6 row_index is not exactly 0..48,999."
        )

    # ------------------------------------------------------------
    # 3. DIRECT RECONCILIATION
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("3. RECONCILING A6 ROW_INDEX TO DEVELOPMENT ROWS")
    print("=" * 80)

    # This is the mapping dictated by Implementation 31B:
    # "row_index": val_idx
    # where val_idx indexes X_dev/y_dev constructed from dev_df.
    mapped = dev.iloc[a6["row_index"].to_numpy()].copy()
    mapped = mapped.reset_index(drop=False)
    mapped.rename(columns={"index": "development_position"}, inplace=True)

    if not np.array_equal(
        mapped["development_position"].to_numpy(),
        a6["row_index"].to_numpy()
    ):
        raise RuntimeError(
            "Internal mapping construction failed."
        )

    a6["kaggle_id"] = mapped["id"].to_numpy()
    a6["source_cardio"] = mapped["cardio"].to_numpy()

    id_unique = a6["kaggle_id"].nunique() == len(a6)

    target_mismatches = int(
        np.sum(a6["y_true"].to_numpy() != a6["source_cardio"].to_numpy())
    )

    print("Mapped rows:", f"{len(mapped):,}")
    print("Unique mapped IDs:", a6["kaggle_id"].nunique())
    print("Target mismatches:", target_mismatches)

    if not id_unique:
        raise RuntimeError("Mapped A6 IDs are not unique.")

    if target_mismatches != 0:
        raise RuntimeError(
            "A6 y_true does not match development cardio after exact mapping."
        )

    print("PASS: Every A6 prediction maps to exactly one development ID.")
    print("PASS: A6 targets exactly match development targets.")

    # ------------------------------------------------------------
    # 4. OUTER-FOLD COVERAGE
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("4. OUTER-FOLD COVERAGE CHECK")
    print("=" * 80)

    fold_counts = (
        a6.groupby("outer_fold")["row_index"]
        .agg(["count", "nunique", "min", "max"])
        .sort_index()
    )

    print(fold_counts.to_string())

    fold_count_pass = (
        len(fold_counts) == 5
        and (fold_counts["count"] == 9800).all()
        and (fold_counts["nunique"] == 9800).all()
    )

    print("Five-fold 9,800-row coverage:", fold_count_pass)

    # Each development observation must occur exactly once.
    row_frequency = a6["row_index"].value_counts()
    exact_once_pass = (
        len(row_frequency) == 49_000
        and (row_frequency == 1).all()
    )

    print("Every development row appears exactly once:", exact_once_pass)

    # ------------------------------------------------------------
    # 5. LOAD BASELINES AND ESTABLISH COMMON COHORT
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("5. VALIDATED BASELINE COHORT")
    print("=" * 80)

    baselines = {}
    baseline_id_sets = {}

    for name, path in BASELINE_FILES.items():
        if not path.exists():
            raise FileNotFoundError(
                f"Baseline file not found:\n{path}"
            )

        df = load_baseline(path)
        baselines[name] = df
        baseline_id_sets[name] = set(df["id"])

        print(
            f"{name:30s}",
            f"rows={len(df):,}",
            f"unique_ids={df['id'].nunique():,}"
        )

        if len(df) != 49_000:
            raise RuntimeError(
                f"{name} does not contain 49,000 rows."
            )

    common_ids = set(a6["kaggle_id"])

    for name, ids in baseline_id_sets.items():
        common_ids &= ids

    print("\nCommon IDs including A6:", f"{len(common_ids):,}")

    common_49k_pass = len(common_ids) == 49_000

    if common_49k_pass:
        print("PASS: A6 and all five baselines share exactly 49,000 IDs.")
    else:
        print("FAIL: A6 does not share all 49,000 IDs with the baselines.")

    # ------------------------------------------------------------
    # 6. TARGET AGREEMENT WITH EVERY BASELINE
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("6. TARGET AGREEMENT")
    print("=" * 80)

    target_audit_rows = []

    a6_id_target = (
        a6[["kaggle_id", "y_true"]]
        .rename(columns={"kaggle_id": "id", "y_true": "a6_y_true"})
        .set_index("id")
        .sort_index()
    )

    all_baseline_targets_pass = True

    for name, df in baselines.items():

        b = (
            df[["id", "y_true"]]
            .drop_duplicates("id")
            .set_index("id")
            .sort_index()
            .rename(columns={"y_true": "baseline_y_true"})
        )

        joined = a6_id_target.join(b, how="outer")

        missing_a6 = int(joined["a6_y_true"].isna().sum())
        missing_baseline = int(joined["baseline_y_true"].isna().sum())

        comparable = joined.dropna()

        mismatches = int(
            np.sum(
                comparable["a6_y_true"].astype(int)
                != comparable["baseline_y_true"].astype(int)
            )
        )

        passed = (
            len(joined) == 49_000
            and missing_a6 == 0
            and missing_baseline == 0
            and mismatches == 0
        )

        if not passed:
            all_baseline_targets_pass = False

        target_audit_rows.append(
            {
                "comparison": name,
                "a6_rows": len(a6),
                "baseline_rows": len(df),
                "union_ids": len(joined),
                "missing_a6_targets": missing_a6,
                "missing_baseline_targets": missing_baseline,
                "target_mismatches": mismatches,
                "target_agreement_pass": passed,
            }
        )

        print(
            f"{name:30s}",
            f"union={len(joined):,}",
            f"missing_A6={missing_a6}",
            f"missing_baseline={missing_baseline}",
            f"target_mismatches={mismatches}",
            f"PASS={passed}"
        )

    # ------------------------------------------------------------
    # 7. CREATE VERIFIED MAPPING FILE
    # ------------------------------------------------------------
    print("\n" + "=" * 80)
    print("7. SAVING VERIFIED A6 MAPPING")
    print("=" * 80)

    mapping = a6[
        [
            "row_index",
            "outer_fold",
            "kaggle_id",
            "y_true",
            "probability",
        ]
    ].copy()

    mapping["source_cardio"] = a6["source_cardio"].to_numpy()
    mapping["target_match"] = (
        mapping["y_true"] == mapping["source_cardio"]
    )

    mapping.to_csv(
        OUTPUT_MAPPING,
        index=False
    )

    print("Mapping:", OUTPUT_MAPPING)

    # ------------------------------------------------------------
    # 8. FINAL STATUS
    # ------------------------------------------------------------
    final_pass = all(
        [
            len(dev) == 49_000,
            len(a6) == 49_000,
            index_range_pass,
            id_unique,
            target_mismatches == 0,
            fold_count_pass,
            exact_once_pass,
            common_49k_pass,
            all_baseline_targets_pass,
        ]
    )

    audit_rows = [
        {
            "check": "development_rows",
            "value": len(dev),
            "pass": len(dev) == 49_000,
        },
        {
            "check": "a6_rows",
            "value": len(a6),
            "pass": len(a6) == 49_000,
        },
        {
            "check": "a6_row_index_exact_0_to_48999",
            "value": index_range_pass,
            "pass": index_range_pass,
        },
        {
            "check": "a6_mapped_unique_ids",
            "value": int(a6["kaggle_id"].nunique()),
            "pass": id_unique,
        },
        {
            "check": "a6_vs_source_target_mismatches",
            "value": target_mismatches,
            "pass": target_mismatches == 0,
        },
        {
            "check": "five_outer_folds_9800_each",
            "value": fold_count_pass,
            "pass": fold_count_pass,
        },
        {
            "check": "every_development_row_exactly_once",
            "value": exact_once_pass,
            "pass": exact_once_pass,
        },
        {
            "check": "a6_and_baselines_common_49000_ids",
            "value": len(common_ids),
            "pass": common_49k_pass,
        },
        {
            "check": "all_baseline_target_agreement",
            "value": all_baseline_targets_pass,
            "pass": all_baseline_targets_pass,
        },
    ]

    audit_df = pd.DataFrame(audit_rows)
    audit_df.to_csv(OUTPUT_AUDIT, index=False)

    summary = {
        "status":
            "PASS_A6_ROW_INDEX_RECONCILED"
            if final_pass
            else "A6_ROW_INDEX_RECONCILIATION_FAILED",
        "development_file": str(DEV_FILE),
        "development_rows": int(len(dev)),
        "development_sha256": dev_sha,
        "a6_file": str(A6_FILE),
        "a6_rows": int(len(a6)),
        "a6_row_index_range": [
            int(a6["row_index"].min()),
            int(a6["row_index"].max()),
        ],
        "a6_unique_mapped_ids":
            int(a6["kaggle_id"].nunique()),
        "a6_source_target_mismatches":
            target_mismatches,
        "outer_fold_counts":
            {
                str(k): int(v)
                for k, v in
                a6["outer_fold"].value_counts().sort_index().items()
            },
        "common_ids_with_all_baselines":
            int(len(common_ids)),
        "all_baseline_target_agreement":
            bool(all_baseline_targets_pass),
        "mapping_definition":
            "kaggle_development_cv.csv.iloc[row_index].id",
        "statistical_testing_performed": False,
        "model_retrained": False,
        "locked_test_used": False,
        "uci_used": False,
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2
        )

    report_lines = [
        "=" * 80,
        "IMPLEMENTATION 43B-2 CORRECTED REPORT",
        "=" * 80,
        "",
        "Mapping definition:",
        "A6 row_index -> kaggle_development_cv.csv.iloc[row_index].id",
        "",
        f"Development rows: {len(dev):,}",
        f"A6 rows: {len(a6):,}",
        f"A6 unique mapped IDs: {a6['kaggle_id'].nunique():,}",
        f"A6/source target mismatches: {target_mismatches}",
        f"Common IDs with all five baselines: {len(common_ids):,}",
        f"Five folds 9,800 each: {fold_count_pass}",
        f"Every development row exactly once: {exact_once_pass}",
        f"All baseline target agreement: {all_baseline_targets_pass}",
        "",
        "FINAL STATUS:",
        (
            "PASS_A6_ROW_INDEX_RECONCILED"
            if final_pass
            else "A6_ROW_INDEX_RECONCILIATION_FAILED"
        ),
        "",
        "No statistical testing performed.",
        "No model retrained.",
        "Locked test not used.",
        "UCI not used.",
    ]

    with open(
        OUTPUT_REPORT,
        "w",
        encoding="utf-8"
    ) as f:
        f.write("\n".join(report_lines))

    print("\n" + "=" * 80)
    print("IMPLEMENTATION 43B-2 CORRECTED COMPLETE")
    print("=" * 80)

    print("\nFinal status:")
    print(
        "PASS_A6_ROW_INDEX_RECONCILED"
        if final_pass
        else "A6_ROW_INDEX_RECONCILIATION_FAILED"
    )

    print("\nOutputs:")
    print(OUTPUT_AUDIT)
    print(OUTPUT_JSON)
    print(OUTPUT_MAPPING)
    print(OUTPUT_REPORT)

    if final_pass:
        print("\nNEXT STEP:")
        print(
            "Proceed to Implementation 43B-3 paired statistical comparison."
        )
    else:
        print("\nDO NOT perform paired statistical testing.")
        print("Inspect the failed reconciliation checks first.")


if __name__ == "__main__":
    main()
