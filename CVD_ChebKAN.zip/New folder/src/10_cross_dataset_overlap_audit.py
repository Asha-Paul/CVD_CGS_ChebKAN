# ================================================================
# AUDIT 10: KAGGLE BP CLEANING IMPACT AUDIT
# ================================================================
#
# Purpose:
#   Quantify the effect of the frozen BP quality-control rules
#   before train/test splitting and before any imputation.
#
# Frozen BP rules:
#   SBP valid: 70 <= ap_hi <= 250 mmHg
#   DBP valid: 40 <= ap_lo <= 150 mmHg
#   Valid BP pair additionally requires SBP > DBP
#
# Handling:
#   - Invalid SBP -> NaN
#   - Invalid DBP -> NaN
#   - Reversed valid BP pair (SBP <= DBP):
#         both measurements are treated as invalid for the pair
#         and therefore set to NaN
#   - Patient/row is RETAINED
#   - No imputation
#   - No train/test split
#   - No supervised feature selection
#
# IMPORTANT:
#   This script is an AUDIT.
#   It does not perform model training.
#
# ================================================================

from pathlib import Path
import pandas as pd
import numpy as np


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


SUMMARY_OUTPUT = (
    RESULTS_DIR
    / "audit10_bp_cleaning_impact_summary.csv"
)

MISSINGNESS_OUTPUT = (
    RESULTS_DIR
    / "audit10_missingness_before_after.csv"
)

BP_CATEGORY_OUTPUT = (
    RESULTS_DIR
    / "audit10_bp_cleaning_categories.csv"
)

CLEANED_DATA_OUTPUT = (
    PROCESSED_DIR
    / "kaggle_bp_quality_controlled.csv"
)


# ================================================================
# 2. LOAD DATA
# ================================================================

print("=" * 80)
print("AUDIT 10: KAGGLE BP CLEANING IMPACT AUDIT")
print("=" * 80)

print("\nLoading dataset:")
print(DATA_PATH)

df = pd.read_csv(DATA_PATH, sep=",")

N = len(df)

print("\nDataset:")
print(f"Rows    : {N:,}")
print(f"Columns : {len(df.columns)}")


# ================================================================
# 3. REQUIRED COLUMNS
# ================================================================

required_columns = [
    "id",
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
    "cardio"
]

missing_columns = [
    col for col in required_columns
    if col not in df.columns
]

if missing_columns:
    raise ValueError(
        f"Missing required columns: {missing_columns}"
    )


# ================================================================
# 4. ORIGINAL DATA SNAPSHOT
# ================================================================

original_df = df.copy()

original_missing = original_df.isna().sum()

print("\n" + "=" * 80)
print("ORIGINAL MISSINGNESS")
print("=" * 80)

for col in original_df.columns:

    count = int(original_missing[col])
    pct = 100 * count / N

    print(
        f"{col:<15} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 5. CONVERT BP TO NUMERIC
# ================================================================

df["ap_hi"] = pd.to_numeric(
    df["ap_hi"],
    errors="coerce"
)

df["ap_lo"] = pd.to_numeric(
    df["ap_lo"],
    errors="coerce"
)


# ================================================================
# 6. FROZEN BP VALIDITY RULES
# ================================================================

SBP_MIN = 70
SBP_MAX = 250

DBP_MIN = 40
DBP_MAX = 150


sbp_valid = (
    df["ap_hi"].notna()
    & (df["ap_hi"] >= SBP_MIN)
    & (df["ap_hi"] <= SBP_MAX)
)

dbp_valid = (
    df["ap_lo"].notna()
    & (df["ap_lo"] >= DBP_MIN)
    & (df["ap_lo"] <= DBP_MAX)
)


# ================================================================
# 7. IDENTIFY ORIGINAL BP PROBLEM TYPES
# ================================================================

original_sbp = df["ap_hi"].copy()
original_dbp = df["ap_lo"].copy()


valid_sbp_invalid_dbp = (
    sbp_valid
    & ~dbp_valid
)

invalid_sbp_valid_dbp = (
    ~sbp_valid
    & dbp_valid
)

both_invalid = (
    ~sbp_valid
    & ~dbp_valid
)

both_valid = (
    sbp_valid
    & dbp_valid
)

reversed_bp = (
    both_valid
    & (df["ap_hi"] <= df["ap_lo"])
)

correct_bp = (
    both_valid
    & (df["ap_hi"] > df["ap_lo"])
)


# ================================================================
# 8. ASSIGN EXCLUSIVE AUDIT CATEGORY
# ================================================================

def classify_bp(row):

    sbp = row["ap_hi"]
    dbp = row["ap_lo"]

    sbp_ok = (
        pd.notna(sbp)
        and SBP_MIN <= sbp <= SBP_MAX
    )

    dbp_ok = (
        pd.notna(dbp)
        and DBP_MIN <= dbp <= DBP_MAX
    )

    if sbp_ok and dbp_ok:

        if sbp > dbp:
            return "Valid BP"

        return "Valid values but reversed SBP<=DBP"

    if sbp_ok and not dbp_ok:
        return "Valid SBP + invalid DBP"

    if not sbp_ok and dbp_ok:
        return "Invalid SBP + valid DBP"

    return "Both SBP and DBP invalid"


df["bp_cleaning_category"] = df.apply(
    classify_bp,
    axis=1
)


# ================================================================
# 9. PRINT ORIGINAL BP CATEGORIES
# ================================================================

print("\n" + "=" * 80)
print("ORIGINAL BP CATEGORIES")
print("=" * 80)

category_counts = (
    df["bp_cleaning_category"]
    .value_counts()
)

for category, count in category_counts.items():

    pct = 100 * count / N

    print(
        f"{category:<50} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 10. APPLY BP CLEANING
# ================================================================
#
# Important:
#   We DO NOT modify other variables.
#
#   Invalid SBP -> NaN
#   Invalid DBP -> NaN
#
#   For reversed pairs:
#       SBP <= DBP despite both values individually being
#       plausible. Because the pair fails the frozen
#       physiological ordering rule, BOTH BP values are
#       treated as unreliable and set to NaN.
#
# ================================================================

cleaned_df = df.copy()

# Remove temporary audit column before final cleaning
cleaned_df = cleaned_df.drop(
    columns=["bp_cleaning_category"]
)


# ------------------------------------------------
# Invalid individual measurements
# ------------------------------------------------

cleaned_df.loc[
    ~sbp_valid,
    "ap_hi"
] = np.nan

cleaned_df.loc[
    ~dbp_valid,
    "ap_lo"
] = np.nan


# ------------------------------------------------
# Reversed valid BP pairs
# ------------------------------------------------
#
# Because these records have individually plausible values
# but violate SBP > DBP, treat both measurements as missing.
#

cleaned_df.loc[
    reversed_bp,
    ["ap_hi", "ap_lo"]
] = np.nan


# ================================================================
# 11. VERIFY OTHER VARIABLES WERE NOT MODIFIED
# ================================================================

print("\n" + "=" * 80)
print("CHECK: NON-BP VARIABLES")
print("=" * 80)

non_bp_columns = [
    col for col in original_df.columns
    if col not in ["ap_hi", "ap_lo"]
]

modification_detected = False

for col in non_bp_columns:

    original = original_df[col]
    cleaned = cleaned_df[col]

    same = original.equals(cleaned)

    print(
        f"{col:<15} : "
        f"{'UNCHANGED' if same else 'CHANGED'}"
    )

    if not same:
        modification_detected = True


if modification_detected:
    print(
        "\nWARNING: At least one non-BP variable changed."
    )
else:
    print(
        "\nPASS: No non-BP variables were modified."
    )


# ================================================================
# 12. MISSINGNESS AFTER BP CLEANING
# ================================================================

cleaned_missing = cleaned_df.isna().sum()

print("\n" + "=" * 80)
print("MISSINGNESS AFTER BP CLEANING")
print("=" * 80)

for col in cleaned_df.columns:

    count = int(cleaned_missing[col])
    pct = 100 * count / N

    print(
        f"{col:<15} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 13. BP-SPECIFIC MISSINGNESS PATTERNS
# ================================================================

sbp_missing_after = cleaned_df["ap_hi"].isna()
dbp_missing_after = cleaned_df["ap_lo"].isna()

both_bp_present = (
    ~sbp_missing_after
    & ~dbp_missing_after
)

sbp_missing_only = (
    sbp_missing_after
    & ~dbp_missing_after
)

dbp_missing_only = (
    ~sbp_missing_after
    & dbp_missing_after
)

both_bp_missing = (
    sbp_missing_after
    & dbp_missing_after
)


print("\n" + "=" * 80)
print("BP MISSINGNESS PATTERN AFTER CLEANING")
print("=" * 80)


def report(label, mask):

    count = int(mask.sum())
    pct = 100 * count / N

    print(
        f"{label:<45} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


report(
    "Both SBP and DBP present",
    both_bp_present
)

report(
    "SBP missing only",
    sbp_missing_only
)

report(
    "DBP missing only",
    dbp_missing_only
)

report(
    "Both SBP and DBP missing",
    both_bp_missing
)


# ================================================================
# 14. VERIFY BP ORDER AFTER CLEANING
# ================================================================

complete_bp_order_correct = (
    both_bp_present
    & (
        cleaned_df["ap_hi"]
        > cleaned_df["ap_lo"]
    )
)

complete_bp_order_invalid = (
    both_bp_present
    & (
        cleaned_df["ap_hi"]
        <= cleaned_df["ap_lo"]
    )
)

print("\n" + "=" * 80)
print("BP ORDER AFTER CLEANING")
print("=" * 80)

report(
    "Complete BP pairs with SBP > DBP",
    complete_bp_order_correct
)

report(
    "Complete BP pairs with SBP <= DBP",
    complete_bp_order_invalid
)


# ================================================================
# 15. VERIFY REMAINING BP RANGES
# ================================================================

print("\n" + "=" * 80)
print("REMAINING VALID BP RANGES")
print("=" * 80)

print(
    f"SBP minimum : "
    f"{cleaned_df['ap_hi'].min()}"
)

print(
    f"SBP maximum : "
    f"{cleaned_df['ap_hi'].max()}"
)

print(
    f"DBP minimum : "
    f"{cleaned_df['ap_lo'].min()}"
)

print(
    f"DBP maximum : "
    f"{cleaned_df['ap_lo'].max()}"
)


# ================================================================
# 16. CHECK FOR ANY REMAINING INVALID BP VALUES
# ================================================================

remaining_invalid_sbp = (
    cleaned_df["ap_hi"].notna()
    & (
        (cleaned_df["ap_hi"] < SBP_MIN)
        | (cleaned_df["ap_hi"] > SBP_MAX)
    )
)

remaining_invalid_dbp = (
    cleaned_df["ap_lo"].notna()
    & (
        (cleaned_df["ap_lo"] < DBP_MIN)
        | (cleaned_df["ap_lo"] > DBP_MAX)
    )
)

remaining_reversed = (
    both_bp_present
    & (
        cleaned_df["ap_hi"]
        <= cleaned_df["ap_lo"]
    )
)


print("\n" + "=" * 80)
print("FINAL BP QUALITY CHECK")
print("=" * 80)

report(
    "Remaining invalid SBP",
    remaining_invalid_sbp
)

report(
    "Remaining invalid DBP",
    remaining_invalid_dbp
)

report(
    "Remaining reversed BP pairs",
    remaining_reversed
)


# ================================================================
# 17. TARGET DISTRIBUTION BEFORE CLEANING
# ================================================================

print("\n" + "=" * 80)
print("TARGET DISTRIBUTION BEFORE CLEANING")
print("=" * 80)

target_before = (
    original_df["cardio"]
    .value_counts()
    .sort_index()
)

for target, count in target_before.items():

    pct = 100 * count / N

    print(
        f"cardio={target} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 18. TARGET DISTRIBUTION AFTER CLEANING
# ================================================================

print("\n" + "=" * 80)
print("TARGET DISTRIBUTION AFTER CLEANING")
print("=" * 80)

target_after = (
    cleaned_df["cardio"]
    .value_counts()
    .sort_index()
)

for target, count in target_after.items():

    pct = 100 * count / N

    print(
        f"cardio={target} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 19. COMPLETE-CASE BP TARGET DISTRIBUTION
# ================================================================

print("\n" + "=" * 80)
print("TARGET DISTRIBUTION AMONG COMPLETE BP RECORDS")
print("=" * 80)

complete_bp_df = cleaned_df.loc[
    both_bp_present
]

complete_target = (
    complete_bp_df["cardio"]
    .value_counts()
    .sort_index()
)

complete_N = len(complete_bp_df)

for target, count in complete_target.items():

    pct = 100 * count / complete_N

    print(
        f"cardio={target} : "
        f"{count:>7,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 20. CHECK OTHER FEATURE MISSINGNESS
# ================================================================

print("\n" + "=" * 80)
print("NON-BP MISSINGNESS AFTER CLEANING")
print("=" * 80)

for col in cleaned_df.columns:

    if col in ["ap_hi", "ap_lo"]:
        continue

    count = int(cleaned_df[col].isna().sum())

    if count > 0:

        pct = 100 * count / N

        print(
            f"{col:<15} : "
            f"{count:>7,} "
            f"({pct:>7.3f}%)"
        )

    else:

        print(
            f"{col:<15} : "
            f"{0:>7,} "
            f"(  0.000%)"
        )


# ================================================================
# 21. CREATE MISSINGNESS COMPARISON TABLE
# ================================================================

missingness_rows = []

for col in original_df.columns:

    before_count = int(
        original_df[col].isna().sum()
    )

    after_count = int(
        cleaned_df[col].isna().sum()
    )

    missingness_rows.append({

        "feature": col,

        "missing_before": before_count,

        "missing_before_pct":
            100 * before_count / N,

        "missing_after": after_count,

        "missing_after_pct":
            100 * after_count / N,

        "increase_in_missing":
            after_count - before_count
    })


missingness_df = pd.DataFrame(
    missingness_rows
)

missingness_df.to_csv(
    MISSINGNESS_OUTPUT,
    index=False
)


# ================================================================
# 22. BP CATEGORY SUMMARY
# ================================================================

bp_category_rows = []

for category, count in category_counts.items():

    bp_category_rows.append({

        "bp_category": category,

        "count": int(count),

        "percentage":
            100 * count / N
    })


bp_category_df = pd.DataFrame(
    bp_category_rows
)

bp_category_df.to_csv(
    BP_CATEGORY_OUTPUT,
    index=False
)


# ================================================================
# 23. OVERALL SUMMARY TABLE
# ================================================================

summary_rows = [

    {
        "metric":
            "Total records",

        "value":
            N,

        "percentage":
            100.0
    },

    {
        "metric":
            "Completely valid BP before cleaning",

        "value":
            int(correct_bp.sum()),

        "percentage":
            100 * correct_bp.sum() / N
    },

    {
        "metric":
            "Valid SBP + invalid DBP",

        "value":
            int(valid_sbp_invalid_dbp.sum()),

        "percentage":
            100 * valid_sbp_invalid_dbp.sum() / N
    },

    {
        "metric":
            "Invalid SBP + valid DBP",

        "value":
            int(invalid_sbp_valid_dbp.sum()),

        "percentage":
            100 * invalid_sbp_valid_dbp.sum() / N
    },

    {
        "metric":
            "Both SBP and DBP invalid",

        "value":
            int(both_invalid.sum()),

        "percentage":
            100 * both_invalid.sum() / N
    },

    {
        "metric":
            "Valid values but reversed SBP<=DBP",

        "value":
            int(reversed_bp.sum()),

        "percentage":
            100 * reversed_bp.sum() / N
    },

    {
        "metric":
            "SBP missing after cleaning",

        "value":
            int(sbp_missing_after.sum()),

        "percentage":
            100 * sbp_missing_after.sum() / N
    },

    {
        "metric":
            "DBP missing after cleaning",

        "value":
            int(dbp_missing_after.sum()),

        "percentage":
            100 * dbp_missing_after.sum() / N
    },

    {
        "metric":
            "Both BP measurements missing",

        "value":
            int(both_bp_missing.sum()),

        "percentage":
            100 * both_bp_missing.sum() / N
    },

    {
        "metric":
            "Complete BP after cleaning",

        "value":
            int(both_bp_present.sum()),

        "percentage":
            100 * both_bp_present.sum() / N
    },

    {
        "metric":
            "Complete BP with SBP>DBP",

        "value":
            int(complete_bp_order_correct.sum()),

        "percentage":
            100 * complete_bp_order_correct.sum() / N
    }
]

summary_df = pd.DataFrame(
    summary_rows
)

summary_df.to_csv(
    SUMMARY_OUTPUT,
    index=False
)


# ================================================================
# 24. SAVE BP-QUALITY-CONTROLLED DATASET
# ================================================================
#
# IMPORTANT:
#   This file is NOT yet the modeling dataset.
#
#   It contains:
#       - all 70,000 records
#       - BP quality control applied
#       - invalid BP values represented as NaN
#       - no imputation
#       - no feature selection
#       - no train/test split
#
# ================================================================

cleaned_df.to_csv(
    CLEANED_DATA_OUTPUT,
    index=False
)


# ================================================================
# 25. FINAL VERIFICATION
# ================================================================

print("\n" + "=" * 80)
print("FINAL VERIFICATION")
print("=" * 80)

print(
    f"Original rows : {len(original_df):,}"
)

print(
    f"Cleaned rows  : {len(cleaned_df):,}"
)

if len(original_df) == len(cleaned_df):
    print(
        "PASS: No patient records were deleted."
    )
else:
    print(
        "ERROR: Row count changed!"
    )


if (
    remaining_invalid_sbp.sum() == 0
    and remaining_invalid_dbp.sum() == 0
    and remaining_reversed.sum() == 0
):

    print(
        "PASS: No invalid complete BP values remain."
    )

else:

    print(
        "WARNING: Invalid BP values remain."
    )


# ================================================================
# 26. OUTPUT LOCATIONS
# ================================================================

print("\n" + "=" * 80)
print("AUDIT 10 COMPLETE")
print("=" * 80)

print("\nSummary:")
print(SUMMARY_OUTPUT)

print("\nMissingness comparison:")
print(MISSINGNESS_OUTPUT)

print("\nBP category summary:")
print(BP_CATEGORY_OUTPUT)

print("\nBP-quality-controlled dataset:")
print(CLEANED_DATA_OUTPUT)

print("\nIMPORTANT:")
print("No imputation was performed.")
print("No train/test split was performed.")
print("No feature selection was performed.")
print("No records were deleted.")
print("Only BP quality control was applied.")