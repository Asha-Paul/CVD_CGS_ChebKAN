"""Inference-only evaluation of the five saved Implementation 29 Flat ChebKAN fold models.
Does NOT train models or overwrite original results. This evaluates a newly defined
five-fold probability-averaging ensemble, not the original single-model CV result.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import roc_auc_score, average_precision_score, accuracy_score, precision_score, recall_score, f1_score, brier_score_loss, confusion_matrix

ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DATA = ROOT / "data" / "processed"
MODELS = ROOT / "results" / "models"
TABLES = ROOT / "results" / "tables"
DEV_PATH = DATA / "kaggle_development_cv.csv"
TEST_PATH = DATA / "kaggle_locked_test.csv"
A8_PATH = TABLES / "implementation46_final_a8_locked_test_predictions.csv"
OUT_PATH = TABLES / "implementation29_flat_chebkan_5fold_ensemble_locked_test_predictions.csv"
METRICS_PATH = TABLES / "implementation29_flat_chebkan_5fold_ensemble_locked_test_metrics.csv"
SEED = 2026
FEATURES = ["age", "gender", "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc", "smoke", "alco", "active"]

class ChebyshevKANLayer(nn.Module):
    def __init__(self, input_dim, output_dim, degree=5):
        super().__init__()
        self.input_dim, self.output_dim, self.degree = input_dim, output_dim, degree
        self.coefficients = nn.Parameter(torch.empty(output_dim, input_dim, degree + 1))
        self.bias = nn.Parameter(torch.zeros(output_dim))
        nn.init.normal_(self.coefficients, mean=0.0, std=0.02)
    def forward(self, x):
        x = torch.clamp(x, min=-1.0, max=1.0)
        basis = [torch.ones_like(x)]
        if self.degree >= 1:
            basis.append(x)
            for _ in range(2, self.degree + 1):
                basis.append(2.0 * x * basis[-1] - basis[-2])
        return torch.einsum("bik,oik->bo", torch.stack(basis, dim=-1), self.coefficients) + self.bias

class FlatChebKAN(nn.Module):
    def __init__(self, input_dim=11, hidden_dim=16, degree=5):
        super().__init__()
        self.cheb = ChebyshevKANLayer(input_dim, hidden_dim, degree)
        self.activation = nn.SiLU()
        self.output = nn.Linear(hidden_dim, 1)
    def forward(self, x):
        return self.output(self.activation(self.cheb(x))).squeeze(1)

def find_col(df, options, label):
    for c in options:
        if c in df.columns: return c
    raise ValueError(f"Could not identify {label} column. Columns: {list(df.columns)}")

def main():
    for p in [DEV_PATH, TEST_PATH, A8_PATH]:
        if not p.exists(): raise FileNotFoundError(f"Required file not found: {p}")
    dev = pd.read_csv(DEV_PATH); test = pd.read_csv(TEST_PATH); a8 = pd.read_csv(A8_PATH)
    ycol_dev = find_col(dev, ["cardio", "target", "true_label", "label"], "development label")
    ycol_test = find_col(test, ["cardio", "target", "true_label", "label"], "test label")
    idcol_test = find_col(test, ["id"], "test ID")
    idcol_a8 = find_col(a8, ["id"], "A8 prediction ID")
    ycol_a8 = find_col(a8, ["true_label", "cardio", "target", "label"], "A8 true label")
    pcol_a8 = find_col(a8, ["probability", "predicted_probability", "y_prob", "prob"], "A8 probability")
    for c in FEATURES:
        if c not in dev.columns or c not in test.columns: raise ValueError(f"Missing feature column: {c}")
    if len(test) != 14000: raise ValueError(f"Expected 14,000 locked-test rows; found {len(test)}")
    if dev[idcol_test if idcol_test in dev.columns else "id"].duplicated().any(): raise ValueError("Duplicate IDs in development data")
    if test[idcol_test].duplicated().any() or a8[idcol_a8].duplicated().any(): raise ValueError("Duplicate IDs found in test or A8 predictions")
    check = test[[idcol_test, ycol_test]].merge(a8[[idcol_a8, ycol_a8]], left_on=idcol_test, right_on=idcol_a8, how="outer", indicator=True, validate="one_to_one")
    if not (check["_merge"].eq("both").all() and (check[ycol_test].to_numpy() == check[ycol_a8].to_numpy()).all()):
        raise ValueError("Locked-test IDs/labels do not exactly match A8 predictions")
    Xdev = dev[FEATURES].apply(pd.to_numeric, errors="raise").to_numpy()
    ydev = dev[ycol_dev].to_numpy().astype(int)
    Xtest = test[FEATURES].apply(pd.to_numeric, errors="raise").to_numpy()
    ytest = test[ycol_test].to_numpy().astype(int)
    splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    fold_probs = []
    torch.set_num_threads(1)
    for fold, (train_idx, _) in enumerate(splitter.split(Xdev, ydev), start=1):
        ckpt_path = MODELS / f"implementation29_a4_flat_chebkan_fold{fold}.pt"
        if not ckpt_path.exists(): raise FileNotFoundError(f"Missing checkpoint: {ckpt_path}")
        try: ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        except TypeError: ckpt = torch.load(ckpt_path, map_location="cpu")
        if list(ckpt.get("features", FEATURES)) != FEATURES:
            raise ValueError(f"Feature order mismatch in fold {fold} checkpoint")
        imputer = SimpleImputer(strategy="median")
        scaler = MinMaxScaler(feature_range=(-1, 1))
        Xtr = scaler.fit_transform(imputer.fit_transform(Xdev[train_idx])).astype(np.float32)
        # The checkpoint was trained with preprocessing fitted on the entire outer-training fold.
        Xt = scaler.transform(imputer.transform(Xtest)).astype(np.float32)
        model = FlatChebKAN(int(ckpt["input_dim"]), int(ckpt["hidden_dim"]), int(ckpt["chebyshev_degree"]))
        model.load_state_dict(ckpt["model_state_dict"])
        model.eval()
        with torch.no_grad():
            logits = model(torch.from_numpy(Xt))
            probs = torch.sigmoid(logits).numpy()
        if not np.isfinite(probs).all(): raise ValueError(f"Non-finite probabilities in fold {fold}")
        fold_probs.append(probs)
        print(f"Fold {fold}: checkpoint loaded; predictions generated.")
    ensemble_prob = np.mean(np.vstack(fold_probs), axis=0)
    pred = (ensemble_prob >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(ytest, pred, labels=[0,1]).ravel()
    metrics = {
      "model": "Flat ChebKAN five-fold probability-averaging ensemble (inference-only)",
      "n_test": len(ytest), "ROC_AUC": roc_auc_score(ytest, ensemble_prob),
      "PR_AUC_average_precision": average_precision_score(ytest, ensemble_prob),
      "accuracy_threshold_0.5": accuracy_score(ytest, pred),
      "precision_threshold_0.5": precision_score(ytest, pred, zero_division=0),
      "sensitivity_threshold_0.5": recall_score(ytest, pred, zero_division=0),
      "specificity_threshold_0.5": tn/(tn+fp) if tn+fp else float("nan"),
      "F1_threshold_0.5": f1_score(ytest, pred, zero_division=0),
      "Brier_score": brier_score_loss(ytest, ensemble_prob),
      "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)
    }
    out = pd.DataFrame({"id": test[idcol_test].to_numpy(), "true_label": ytest, "probability": ensemble_prob, "prediction_050": pred})
    out.to_csv(OUT_PATH, index=False)
    pd.DataFrame([metrics]).to_csv(METRICS_PATH, index=False)
    print("\nIMPORTANT: This is a newly defined five-fold ensemble evaluation, not the original single-model Flat ChebKAN CV result.")
    print(pd.Series(metrics).to_string())
    print(f"\nPredictions saved: {OUT_PATH}")
    print(f"Metrics saved:     {METRICS_PATH}")
    print("Upload the predictions CSV here for paired bootstrap comparison against A8.")

if __name__ == "__main__": main()
