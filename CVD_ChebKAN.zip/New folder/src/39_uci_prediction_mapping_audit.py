# ============================================================
# IMPLEMENTATION 39
# DEVELOPMENT-DERIVED THRESHOLD SELECTION
# AND CROSS-DATASET THRESHOLD TRANSFER
#
# Purpose:
#   1. Reproduce the A7 4,900-record internal validation split.
#   2. Generate validation probabilities using the SAVED A7 model.
#   3. Select one threshold using Youden's J.
#   4. Freeze that threshold.
#   5. Apply it to:
#        - Kaggle locked test
#        - UCI Cleveland
#        - UCI Hungarian
#        - UCI VA
#
# IMPORTANT:
#   - No model retraining
#   - No UCI threshold tuning
#   - No conformal calibration-set use
#   - No locked-test threshold selection
#   - ROC-AUC is NOT changed by threshold transfer
# ============================================================

from pathlib import Path
from datetime import datetime
import json

import numpy as np
import pandas as pd
import torch

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)


# ============================================================
# REPRODUCIBILITY
# ============================================================

SEED = 2026

np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

DEV_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_development_cv.csv"
)

CAL_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_locked_test.csv"
)

A7_MODEL_FILE = (
    PROJECT_ROOT
    / "results"
    / "models"
    / "implementation32_a7_final_model.pt"
)

A7_PREPROCESS_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation32_a7_preprocessing.json"
)

A7_SUMMARY_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation32_a7_summary.json"
)

EXTERNAL_PREDICTION_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation34_uci_external_predictions.csv"
)


OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

OUTPUT_CSV = (
    OUTPUT_DIR
    / "implementation39_threshold_transfer_results.csv"
)

OUTPUT_JSON = (
    OUTPUT_DIR
    / "implementation39_threshold_transfer_summary.json"
)

OUTPUT_VALIDATION_CSV = (
    OUTPUT_DIR
    / "implementation39_internal_validation_threshold_selection.csv"
)

OUTPUT_TEST_CSV = (
    OUTPUT_DIR
    / "implementation39_locked_test_predictions.csv"
)


# ============================================================
# FROZEN FEATURES
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"


# ============================================================
# FROZEN CLINICAL GROUPS
# ============================================================

GROUPS = {
    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


# ============================================================
# A7 INTERNAL VALIDATION SIZE
# ============================================================

EXPECTED_INTERNAL_TRAIN = 44100
EXPECTED_INTERNAL_VALIDATION = 4900


# ============================================================
# MODEL ARCHITECTURE
#
# Must match Implementation 32 A7.
# ============================================================

K = 5
EMBED_DIM = 16


# ============================================================
# CHEBYSHEV BASIS
# ============================================================

def chebyshev_basis(x, degree):

    basis = [
        torch.ones_like(x)
    ]

    if degree >= 1:

        basis.append(x)

    for k in range(2, degree + 1):

        basis.append(
            2.0 * x * basis[-1]
            - basis[-2]
        )

    return torch.stack(
        basis,
        dim=-1
    )


# ============================================================
# CHEBYSHEV KAN LAYER
# ============================================================

class ChebyshevKANLayer(
    torch.nn.Module
):

    def __init__(
        self,
        in_features,
        out_features,
        degree=5
    ):

        super().__init__()

        self.in_features = (
            in_features
        )

        self.out_features = (
            out_features
        )

        self.degree = degree

        self.coefficients = (
            torch.nn.Parameter(
                torch.randn(
                    out_features,
                    in_features,
                    degree + 1
                )
                * 0.05
            )
        )

    def forward(self, x):

        basis = chebyshev_basis(
            x,
            self.degree
        )

        # x:
        # [batch, in_features]
        #
        # basis:
        # [batch, in_features, degree+1]
        #
        # coefficients:
        # [out, in, degree+1]

        output = torch.einsum(
            "bid,oid->bo",
            basis,
            self.coefficients
        )

        return output


# ============================================================
# GROUP BRANCH
# ============================================================

class GroupBranch(
    torch.nn.Module
):

    def __init__(
        self,
        in_features,
        embed_dim=16,
        degree=5
    ):

        super().__init__()

        self.kan = (
            ChebyshevKANLayer(
                in_features,
                embed_dim,
                degree
            )
        )

        self.activation = (
            torch.nn.SiLU()
        )

    def forward(self, x):

        return self.activation(
            self.kan(x)
        )


# ============================================================
# A7 MODEL
# ============================================================

class A7Model(
    torch.nn.Module
):

    def __init__(self):

        super().__init__()

        self.demographic = (
            GroupBranch(
                2,
                EMBED_DIM,
                K
            )
        )

        self.physiological = (
            GroupBranch(
                6,
                EMBED_DIM,
                K
            )
        )

        self.lifestyle = (
            GroupBranch(
                3,
                EMBED_DIM,
                K
            )
        )

        self.gate_logits = (
            torch.nn.Parameter(
                torch.zeros(3)
            )
        )

        self.output = (
            torch.nn.Linear(
                EMBED_DIM,
                1
            )
        )

    def forward(
        self,
        x
    ):

        x_demo = x[
            :,
            [0, 1]
        ]

        x_phys = x[
            :,
            [2, 3, 4, 5, 6, 7]
        ]

        x_life = x[
            :,
            [8, 9, 10]
        ]

        h_demo = (
            self.demographic(
                x_demo
            )
        )

        h_phys = (
            self.physiological(
                x_phys
            )
        )

        h_life = (
            self.lifestyle(
                x_life
            )
        )

        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        fused = (
            gates[0] * h_demo
            +
            gates[1] * h_phys
            +
            gates[2] * h_life
        )

        logits = self.output(
            fused
        )

        return logits.squeeze(
            -1
        )


# ============================================================
# LOAD MODEL
# ============================================================

def load_a7_model():

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    model = A7Model().to(
        device
    )

    checkpoint = torch.load(
        A7_MODEL_FILE,
        map_location=device,
        weights_only=False
    )

    if isinstance(
        checkpoint,
        dict
    ):

        if "model_state_dict" in checkpoint:

            state_dict = (
                checkpoint[
                    "model_state_dict"
                ]
            )

        elif "state_dict" in checkpoint:

            state_dict = (
                checkpoint[
                    "state_dict"
                ]
            )

        else:

            state_dict = checkpoint

    else:

        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.eval()

    return model, device


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    dev = pd.read_csv(
        DEV_FILE
    )

    cal = pd.read_csv(
        CAL_FILE
    )

    test = pd.read_csv(
        TEST_FILE
    )

    return dev, cal, test


# ============================================================
# REPRODUCE A7 INTERNAL SPLIT
#
# IMPORTANT:
# A7 used:
#   49,000 development
#   44,100 training
#    4,900 internal validation
#
# We reproduce the split using the fixed seed.
# ============================================================

def reproduce_internal_split(
    dev
):

    if len(dev) != 49000:

        raise ValueError(
            "Development dataset does not "
            "contain exactly 49,000 rows."
        )

    rng = np.random.RandomState(
        SEED
    )

    indices = np.arange(
        len(dev)
    )

    rng.shuffle(
        indices
    )

    validation_size = (
        EXPECTED_INTERNAL_VALIDATION
    )

    val_indices = (
        indices[
            -validation_size:
        ]
    )

    train_indices = (
        indices[
            :-validation_size
        ]
    )

    internal_train = (
        dev.iloc[
            train_indices
        ]
        .copy()
    )

    internal_validation = (
        dev.iloc[
            val_indices
        ]
        .copy()
    )

    return (
        internal_train,
        internal_validation
    )


# ============================================================
# FIT A7 PREPROCESSING ON INTERNAL TRAIN ONLY
# ============================================================

def fit_preprocessing(
    train_df
):

    X_train = (
        train_df[
            FEATURES
        ]
        .copy()
    )

    imputer = (
        SimpleImputer(
            strategy="median"
        )
    )

    scaler = (
        MinMaxScaler(
            feature_range=(-1, 1)
        )
    )

    X_train_imp = (
        imputer.fit_transform(
            X_train
        )
    )

    scaler.fit(
        X_train_imp
    )

    return (
        imputer,
        scaler
    )


# ============================================================
# TRANSFORM DATA
# ============================================================

def transform(
    df,
    imputer,
    scaler
):

    X = (
        df[
            FEATURES
        ]
        .copy()
    )

    X_imp = (
        imputer.transform(
            X
        )
    )

    X_scaled = (
        scaler.transform(
            X_imp
        )
    )

    y = (
        df[TARGET]
        .astype(int)
        .to_numpy()
    )

    return (
        X_scaled.astype(
            np.float32
        ),
        y
    )


# ============================================================
# PREDICT
# ============================================================

def predict(
    model,
    X,
    device,
    batch_size=2048
):

    probabilities = []

    with torch.no_grad():

        for start in range(
            0,
            len(X),
            batch_size
        ):

            end = min(
                start + batch_size,
                len(X)
            )

            xb = torch.tensor(
                X[
                    start:end
                ],
                dtype=torch.float32,
                device=device
            )

            logits = model(
                xb
            )

            probs = torch.sigmoid(
                logits
            )

            probabilities.extend(
                probs.detach()
                .cpu()
                .numpy()
                .tolist()
            )

    return np.asarray(
        probabilities
    )


# ============================================================
# YOUDEN THRESHOLD
# ============================================================

def select_youden_threshold(
    y_true,
    probabilities
):

    thresholds = np.unique(
        probabilities
    )

    best_threshold = 0.5
    best_j = -np.inf

    rows = []

    for threshold in thresholds:

        predictions = (
            probabilities
            >= threshold
        ).astype(int)

        tn, fp, fn, tp = (
            confusion_matrix(
                y_true,
                predictions,
                labels=[0, 1]
            )
            .ravel()
        )

        sensitivity = (
            tp / (tp + fn)
            if (tp + fn) > 0
            else 0.0
        )

        specificity = (
            tn / (tn + fp)
            if (tn + fp) > 0
            else 0.0
        )

        j = (
            sensitivity
            +
            specificity
            -
            1.0
        )

        rows.append({
            "threshold":
                float(threshold),

            "sensitivity":
                float(sensitivity),

            "specificity":
                float(specificity),

            "youden_j":
                float(j),
        })

        if j > best_j:

            best_j = j
            best_threshold = (
                float(threshold)
            )

    threshold_table = (
        pd.DataFrame(rows)
    )

    return (
        best_threshold,
        best_j,
        threshold_table
    )


# ============================================================
# METRICS
# ============================================================

def calculate_metrics(
    y_true,
    probabilities,
    threshold
):

    predictions = (
        probabilities
        >= threshold
    ).astype(int)

    tn, fp, fn, tp = (
        confusion_matrix(
            y_true,
            predictions,
            labels=[0, 1]
        )
        .ravel()
    )

    return {

        "n":
            int(len(y_true)),

        "prevalence":
            float(
                np.mean(y_true)
            ),

        "threshold":
            float(threshold),

        "accuracy":
            float(
                accuracy_score(
                    y_true,
                    predictions
                )
            ),

        "precision":
            float(
                precision_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "sensitivity":
            float(
                recall_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "specificity":
            float(
                tn / (tn + fp)
                if (tn + fp) > 0
                else 0.0
            ),

        "f1":
            float(
                f1_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "roc_auc":
            float(
                roc_auc_score(
                    y_true,
                    probabilities
                )
            ),

        "pr_auc":
            float(
                average_precision_score(
                    y_true,
                    probabilities
                )
            ),

        "true_negative":
            int(tn),

        "false_positive":
            int(fp),

        "false_negative":
            int(fn),

        "true_positive":
            int(tp),

        "positive_prediction_rate":
            float(
                np.mean(predictions)
            ),
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 39"
    )
    print(
        "DEVELOPMENT-DERIVED THRESHOLD SELECTION "
        "AND CROSS-DATASET THRESHOLD TRANSFER"
    )
    print("=" * 100)

    print(
        "Timestamp:",
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    )

    print(
        "\nThreshold selection source:"
    )

    print(
        "A7 internal validation = 4,900 records"
    )

    print(
        "Selection criterion = Youden's J"
    )

    print(
        "Conformal calibration = PROTECTED"
    )

    print(
        "Locked test = PROTECTED"
    )

    print(
        "UCI labels = NOT USED FOR THRESHOLD SELECTION"
    )

    # ========================================================
    # FILE CHECK
    # ========================================================

    required_files = [
        DEV_FILE,
        CAL_FILE,
        TEST_FILE,
        A7_MODEL_FILE,
        EXTERNAL_PREDICTION_FILE,
    ]

    for path in required_files:

        if not path.exists():

            raise FileNotFoundError(
                f"Required file not found:\n{path}"
            )

    # ========================================================
    # LOAD
    # ========================================================

    dev, cal, locked_test = (
        load_data()
    )

    external_predictions = (
        pd.read_csv(
            EXTERNAL_PREDICTION_FILE
        )
    )

    print("\nPartition sizes:")

    print(
        f"Development: "
        f"{len(dev):,}"
    )

    print(
        f"Calibration: "
        f"{len(cal):,}"
    )

    print(
        f"Locked test: "
        f"{len(locked_test):,}"
    )

    # ========================================================
    # REPRODUCE INTERNAL SPLIT
    # ========================================================

    (
        internal_train,
        internal_validation
    ) = reproduce_internal_split(
        dev
    )

    print("\nA7 internal split:")

    print(
        f"Internal training: "
        f"{len(internal_train):,}"
    )

    print(
        f"Internal validation: "
        f"{len(internal_validation):,}"
    )

    if (
        len(internal_train)
        != EXPECTED_INTERNAL_TRAIN
    ):

        raise RuntimeError(
            "Internal training size does not "
            "match expected A7 size."
        )

    if (
        len(internal_validation)
        != EXPECTED_INTERNAL_VALIDATION
    ):

        raise RuntimeError(
            "Internal validation size does not "
            "match expected A7 size."
        )

    # ========================================================
    # CHECK ID DISJOINTNESS
    # ========================================================

    train_ids = set(
        internal_train["id"]
        .astype(int)
        .tolist()
    )

    validation_ids = set(
        internal_validation["id"]
        .astype(int)
        .tolist()
    )

    if train_ids & validation_ids:

        raise RuntimeError(
            "Internal training and validation "
            "IDs overlap."
        )

    print(
        "Internal split ID overlap: 0 PASS"
    )

    # ========================================================
    # LOAD MODEL
    # ========================================================

    model, device = (
        load_a7_model()
    )

    print(
        f"\nInference device: "
        f"{device}"
    )

    # ========================================================
    # PREPROCESSING
    # ========================================================

    (
        imputer,
        scaler
    ) = fit_preprocessing(
        internal_train
    )

    X_val, y_val = (
        transform(
            internal_validation,
            imputer,
            scaler
        )
    )

    # ========================================================
    # INTERNAL VALIDATION PROBABILITIES
    # ========================================================

    val_probabilities = (
        predict(
            model,
            X_val,
            device
        )
    )

    # ========================================================
    # VALIDATION AUC
    # ========================================================

    validation_auc = (
        roc_auc_score(
            y_val,
            val_probabilities
        )
    )

    validation_pr_auc = (
        average_precision_score(
            y_val,
            val_probabilities
        )
    )

    print("\n" + "=" * 100)
    print(
        "INTERNAL VALIDATION PERFORMANCE"
    )
    print("=" * 100)

    print(
        f"n:       {len(y_val):,}"
    )

    print(
        f"ROC-AUC: {validation_auc:.6f}"
    )

    print(
        f"PR-AUC:  {validation_pr_auc:.6f}"
    )

    # ========================================================
    # THRESHOLD SELECTION
    # ========================================================

    (
        selected_threshold,
        selected_j,
        threshold_table
    ) = select_youden_threshold(
        y_val,
        val_probabilities
    )

    print("\n" + "=" * 100)
    print(
        "THRESHOLD SELECTION"
    )
    print("=" * 100)

    print(
        f"Selected threshold: "
        f"{selected_threshold:.6f}"
    )

    print(
        f"Maximum Youden J: "
        f"{selected_j:.6f}"
    )

    # ========================================================
    # INTERNAL VALIDATION METRICS
    # ========================================================

    val_metrics_050 = (
        calculate_metrics(
            y_val,
            val_probabilities,
            0.50
        )
    )

    val_metrics_selected = (
        calculate_metrics(
            y_val,
            val_probabilities,
            selected_threshold
        )
    )

    print("\nInternal validation:")
    print(
        f"Threshold 0.50 "
        f"sensitivity: "
        f"{val_metrics_050['sensitivity']:.6f}"
    )

    print(
        f"Threshold 0.50 "
        f"specificity: "
        f"{val_metrics_050['specificity']:.6f}"
    )

    print(
        f"Selected threshold "
        f"sensitivity: "
        f"{val_metrics_selected['sensitivity']:.6f}"
    )

    print(
        f"Selected threshold "
        f"specificity: "
        f"{val_metrics_selected['specificity']:.6f}"
    )

    # ========================================================
    # SAVE INTERNAL VALIDATION PREDICTIONS
    # ========================================================

    validation_output = (
        internal_validation[
            ["id", TARGET]
        ]
        .copy()
    )

    validation_output[
        "probability"
    ] = val_probabilities

    validation_output[
        "prediction_050"
    ] = (
        val_probabilities >= 0.50
    ).astype(int)

    validation_output[
        "prediction_selected_threshold"
    ] = (
        val_probabilities
        >= selected_threshold
    ).astype(int)

    validation_output.to_csv(
        OUTPUT_VALIDATION_CSV,
        index=False
    )

    # ========================================================
    # LOCKED KAGGLE TEST
    #
    # IMPORTANT:
    # Existing locked-test predictions are NOT assumed
    # available. We generate them with the same saved model.
    # ========================================================

    X_test, y_test = (
        transform(
            locked_test,
            imputer,
            scaler
        )
    )

    test_probabilities = (
        predict(
            model,
            X_test,
            device
        )
    )

    test_050 = (
        calculate_metrics(
            y_test,
            test_probabilities,
            0.50
        )
    )

    test_selected = (
        calculate_metrics(
            y_test,
            test_probabilities,
            selected_threshold
        )
    )

    # ========================================================
    # UCI EXTERNAL DATA
    # ========================================================

    external_results = []

    for cohort in [
        "cleveland",
        "hungarian",
        "va",
    ]:

        cohort_df = (
            external_predictions[
                external_predictions[
                    "cohort"
                ]
                .astype(str)
                .str.lower()
                .str.strip()
                == cohort
            ]
            .copy()
        )

        if len(cohort_df) == 0:

            raise RuntimeError(
                f"No predictions found for {cohort}."
            )

        y_external = (
            cohort_df[
                "true_label"
            ]
            .astype(int)
            .to_numpy()
        )

        p_external = (
            cohort_df[
                "probability"
            ]
            .astype(float)
            .to_numpy()
        )

        metrics_050 = (
            calculate_metrics(
                y_external,
                p_external,
                0.50
            )
        )

        metrics_selected = (
            calculate_metrics(
                y_external,
                p_external,
                selected_threshold
            )
        )

        external_results.append({

            "dataset":
                cohort,

            "threshold_type":
                "0.50",

            **metrics_050,

        })

        external_results.append({

            "dataset":
                cohort,

            "threshold_type":
                "development_youden",

            **metrics_selected,

        })

    # ========================================================
    # KAGGLE RESULTS
    # ========================================================

    result_rows = []

    result_rows.append({

        "dataset":
            "kaggle_locked_test",

        "threshold_type":
            "0.50",

        **test_050,

    })

    result_rows.append({

        "dataset":
            "kaggle_locked_test",

        "threshold_type":
            "development_youden",

        **test_selected,

    })

    result_rows.extend(
        external_results
    )

    results_df = (
        pd.DataFrame(
            result_rows
        )
    )

    results_df.to_csv(
        OUTPUT_CSV,
        index=False
    )

    # ========================================================
    # SAVE SUMMARY JSON
    # ========================================================

    summary = {

        "implementation":
            "39",

        "timestamp":
            datetime.now().isoformat(),

        "threshold_selection_dataset":
            "A7_internal_validation",

        "threshold_selection_n":
            int(len(y_val)),

        "threshold_selection_criterion":
            "Youden_J",

        "selected_threshold":
            float(selected_threshold),

        "maximum_youden_J":
            float(selected_j),

        "default_threshold":
            0.50,

        "conformal_calibration_used":
            False,

        "locked_test_used_for_selection":
            False,

        "uci_labels_used_for_selection":
            False,

        "model_retrained":
            False,

        "internal_validation_auc":
            float(validation_auc),

        "internal_validation_pr_auc":
            float(validation_pr_auc),

        "results":
            results_df.to_dict(
                orient="records"
            ),

        "protocol_statement":
            (
                "A single classification threshold was "
                "selected using Youden's J on the A7 "
                "internal validation subset of 4,900 "
                "Development records. The threshold was "
                "then frozen and transferred without "
                "modification to the Kaggle locked test "
                "set and the UCI Cleveland, Hungarian, "
                "and VA cohorts. The conformal calibration "
                "set and UCI labels were not used for "
                "threshold selection."
            ),

        "roc_auc_statement":
            (
                "ROC-AUC is threshold-independent and "
                "therefore remains unchanged by threshold "
                "transfer."
            ),
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            indent=2
        )

    # ========================================================
    # PRINT RESULTS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "FINAL THRESHOLD"
    )
    print("=" * 100)

    print(
        f"Development-derived threshold: "
        f"{selected_threshold:.6f}"
    )

    print(
        f"Youden J: "
        f"{selected_j:.6f}"
    )

    print("\n" + "=" * 100)
    print(
        "THRESHOLD TRANSFER RESULTS"
    )
    print("=" * 100)

    display_columns = [
        "dataset",
        "threshold_type",
        "n",
        "threshold",
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "positive_prediction_rate",
    ]

    print(
        results_df[
            display_columns
        ].to_string(
            index=False
        )
    )

    # ========================================================
    # PROTECTION CHECK
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "PROTOCOL PROTECTION"
    )
    print("=" * 100)

    print(
        "Conformal calibration used for "
        "threshold selection: FALSE"
    )

    print(
        "Locked test used for "
        "threshold selection: FALSE"
    )

    print(
        "UCI labels used for "
        "threshold selection: FALSE"
    )

    print(
        "Model retrained: FALSE"
    )

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        OUTPUT_CSV
    )

    print(
        OUTPUT_JSON
    )

    print(
        OUTPUT_VALIDATION_CSV
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 39 COMPLETE"
    )
    print("=" * 100)


if __name__ == "__main__":
    main()