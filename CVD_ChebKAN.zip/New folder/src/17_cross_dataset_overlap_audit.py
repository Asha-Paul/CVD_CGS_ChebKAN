# ================================================================
# AUDIT 17
# ADASYN PLACEMENT, CLASS-BALANCE, IMPUTATION AND LEAKAGE AUDIT
# ================================================================

from pathlib import Path
import sys
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from imblearn.over_sampling import ADASYN


# ================================================================
# 1. CONFIGURATION
# ================================================================

RANDOM_STATE = 2026
N_OUTER_FOLDS = 5

# If minority/majority >= 0.95, the fold is considered
# sufficiently balanced and ADASYN is not required.
ADASYN_RATIO_THRESHOLD = 0.95

ADASYN_N_NEIGHBORS = 5

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"

DEVELOPMENT_FILE = DATA_DIR / "kaggle_development_cv.csv"
CALIBRATION_FILE = DATA_DIR / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

warnings.filterwarnings("ignore")


# ================================================================
# 2. PREDICTOR VARIABLES
# ================================================================

PREDICTORS = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"
ID_COLUMN = "id"


# ================================================================
# 3. HEADER
# ================================================================

print("=" * 70)
print("AUDIT 17")
print("ADASYN PLACEMENT, CLASS-BALANCE,")
print("IMPUTATION AND LEAKAGE AUDIT")
print("=" * 70)

print()
print(f"Project root : {PROJECT_ROOT}")
print(f"Development  : {DEVELOPMENT_FILE}")
print(f"Calibration  : {CALIBRATION_FILE}")
print(f"Locked test  : {TEST_FILE}")
print()


# ================================================================
# 4. CHECK INPUT FILES
# ================================================================

print("=" * 70)
print("STEP 1: INPUT FILE CHECK")
print("=" * 70)

input_files = {
    "Development": DEVELOPMENT_FILE,
    "Calibration": CALIBRATION_FILE,
    "Locked Test": TEST_FILE,
}

for name, path in input_files.items():

    if not path.exists():

        print()
        print(f"ERROR: {name} file not found:")
        print(path)
        sys.exit(1)

    size_mb = path.stat().st_size / (1024 ** 2)

    print(
        f"{name:15s}: EXISTS | "
        f"{size_mb:.2f} MB"
    )

print()


# ================================================================
# 5. LOAD PARTITIONS
# ================================================================

print("=" * 70)
print("STEP 2: LOAD PARTITIONS")
print("=" * 70)

dev = pd.read_csv(DEVELOPMENT_FILE)
cal = pd.read_csv(CALIBRATION_FILE)
test = pd.read_csv(TEST_FILE)

print(
    f"Development : {len(dev):,} rows"
)

print(
    f"Calibration : {len(cal):,} rows"
)

print(
    f"Locked Test : {len(test):,} rows"
)

print()


# ================================================================
# 6. PARTITION SIZE CHECK
# ================================================================

print("=" * 70)
print("STEP 3: PARTITION SIZE CHECK")
print("=" * 70)

expected_sizes = {
    "Development": 49000,
    "Calibration": 7000,
    "Locked Test": 14000,
}

actual_sizes = {
    "Development": len(dev),
    "Calibration": len(cal),
    "Locked Test": len(test),
}

partition_size_pass = True

for name in expected_sizes:

    expected = expected_sizes[name]
    actual = actual_sizes[name]

    passed = expected == actual

    print(
        f"{name:15s}: "
        f"expected={expected:,} | "
        f"actual={actual:,} | "
        f"{'PASS' if passed else 'FAIL'}"
    )

    if not passed:
        partition_size_pass = False


if not partition_size_pass:

    print()
    print("ERROR: Partition sizes do not match the frozen split.")
    sys.exit(1)

print()


# ================================================================
# 7. REQUIRED COLUMN CHECK
# ================================================================

print("=" * 70)
print("STEP 4: REQUIRED COLUMN CHECK")
print("=" * 70)

required_columns = set(
    PREDICTORS + [TARGET, ID_COLUMN]
)

column_check_pass = True

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    missing = sorted(
        required_columns - set(df.columns)
    )

    if len(missing) == 0:

        print(
            f"{name:15s}: PASS"
        )

    else:

        print(
            f"{name:15s}: FAIL"
        )

        print(
            f"  Missing columns: {missing}"
        )

        column_check_pass = False


if not column_check_pass:

    sys.exit(1)

print()


# ================================================================
# 8. TARGET CHECK
# ================================================================

print("=" * 70)
print("STEP 5: TARGET CHECK")
print("=" * 70)

target_check_pass = True

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    values = sorted(
        df[TARGET].dropna().unique().tolist()
    )

    print(
        f"{name:15s}: "
        f"target values = {values}"
    )

    if values != [0, 1]:
        target_check_pass = False


if not target_check_pass:

    print()
    print("ERROR: Target is not binary 0/1.")
    sys.exit(1)

print()


# ================================================================
# 9. GLOBAL CLASS BALANCE
# ================================================================

print("=" * 70)
print("STEP 6: GLOBAL CLASS-BALANCE AUDIT")
print("=" * 70)

global_balance_records = []

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    counts = (
        df[TARGET]
        .value_counts()
        .sort_index()
    )

    class0 = int(
        counts.get(0, 0)
    )

    class1 = int(
        counts.get(1, 0)
    )

    total = class0 + class1

    minority = min(
        class0,
        class1
    )

    majority = max(
        class0,
        class1
    )

    ratio = (
        minority / majority
        if majority > 0
        else np.nan
    )

    positive_rate = (
        class1 / total
        if total > 0
        else np.nan
    )

    absolute_difference = abs(
        class0 - class1
    )

    print()
    print(name)

    print(
        f"  Class 0: {class0:,}"
    )

    print(
        f"  Class 1: {class1:,}"
    )

    print(
        f"  Total:   {total:,}"
    )

    print(
        f"  Positive rate: {positive_rate:.6f}"
    )

    print(
        f"  Minority/majority ratio: {ratio:.6f}"
    )

    print(
        f"  Absolute class difference: "
        f"{absolute_difference:,}"
    )

    global_balance_records.append({
        "dataset": name,
        "n_total": total,
        "class_0": class0,
        "class_1": class1,
        "positive_rate": positive_rate,
        "minority_count": minority,
        "majority_count": majority,
        "minority_majority_ratio": ratio,
        "absolute_class_difference":
            absolute_difference,
        "adasyn_required_by_threshold":
            ratio < ADASYN_RATIO_THRESHOLD,
    })


global_balance_df = pd.DataFrame(
    global_balance_records
)

global_balance_file = (
    RESULTS_DIR /
    "audit17_global_class_balance.csv"
)

global_balance_df.to_csv(
    global_balance_file,
    index=False
)

print()
print(
    f"Saved: {global_balance_file}"
)
print()


# ================================================================
# 10. DEVELOPMENT MISSINGNESS
# ================================================================

print("=" * 70)
print("STEP 7: DEVELOPMENT MISSINGNESS")
print("=" * 70)

missingness_records = []

for variable in PREDICTORS:

    count = int(
        dev[variable].isna().sum()
    )

    percentage = (
        100.0 * count / len(dev)
    )

    print(
        f"{variable:12s}: "
        f"{count:6,} "
        f"({percentage:7.3f}%)"
    )

    missingness_records.append({
        "dataset": "Development",
        "variable": variable,
        "missing_count": count,
        "missing_percentage": percentage,
    })

print()


# ================================================================
# 11. PARTITION DISJOINTNESS
# ================================================================

print("=" * 70)
print("STEP 8: PARTITION DISJOINTNESS")
print("=" * 70)

dev_ids = set(
    dev[ID_COLUMN].astype(int)
)

cal_ids = set(
    cal[ID_COLUMN].astype(int)
)

test_ids = set(
    test[ID_COLUMN].astype(int)
)

dev_cal_overlap = (
    dev_ids.intersection(cal_ids)
)

dev_test_overlap = (
    dev_ids.intersection(test_ids)
)

cal_test_overlap = (
    cal_ids.intersection(test_ids)
)

print(
    f"Development ∩ Calibration: "
    f"{len(dev_cal_overlap)}"
)

print(
    f"Development ∩ Test:        "
    f"{len(dev_test_overlap)}"
)

print(
    f"Calibration ∩ Test:         "
    f"{len(cal_test_overlap)}"
)

partition_disjoint_pass = (
    len(dev_cal_overlap) == 0
    and len(dev_test_overlap) == 0
    and len(cal_test_overlap) == 0
)

print()
print(
    "Partition disjointness: "
    f"{'PASS' if partition_disjoint_pass else 'FAIL'}"
)

if not partition_disjoint_pass:

    print(
        "ERROR: Partition overlap detected."
    )

    sys.exit(1)

print()


# ================================================================
# 12. DUPLICATE ID CHECK
# ================================================================

print("=" * 70)
print("STEP 9: DUPLICATE-ID CHECK")
print("=" * 70)

duplicate_id_pass = True

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    duplicates = int(
        df[ID_COLUMN].duplicated().sum()
    )

    print(
        f"{name:15s}: "
        f"{duplicates} duplicate IDs"
    )

    if duplicates != 0:
        duplicate_id_pass = False


print()
print(
    "Duplicate-ID check: "
    f"{'PASS' if duplicate_id_pass else 'FAIL'}"
)

if not duplicate_id_pass:
    sys.exit(1)

print()


# ================================================================
# 13. PREPARE DEVELOPMENT DATA
# ================================================================

X_dev = dev[PREDICTORS].copy()

y_dev = (
    dev[TARGET]
    .astype(int)
    .copy()
)

ids_dev = (
    dev[ID_COLUMN]
    .astype(int)
    .copy()
)


# ================================================================
# 14. OUTER CROSS-VALIDATION
# ================================================================

print("=" * 70)
print("STEP 10: OUTER STRATIFIED 5-FOLD CV")
print("=" * 70)

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_FOLDS,
    shuffle=True,
    random_state=RANDOM_STATE
)


# ================================================================
# 15. OUTPUT STORAGE
# ================================================================

fold_summary_records = []

leakage_records = []

imputation_records = []

balance_records = []


# ================================================================
# 16. OUTER FOLD LOOP
# ================================================================

for fold_number, (
    train_idx,
    val_idx
) in enumerate(
    outer_cv.split(X_dev, y_dev),
    start=1
):

    print()
    print("-" * 70)
    print(
        f"OUTER FOLD {fold_number}"
    )
    print("-" * 70)

    # ------------------------------------------------------------
    # 16.1 Split data
    # ------------------------------------------------------------

    X_train_raw = (
        X_dev.iloc[train_idx]
        .copy()
    )

    X_val_raw = (
        X_dev.iloc[val_idx]
        .copy()
    )

    y_train = (
        y_dev.iloc[train_idx]
        .copy()
    )

    y_val = (
        y_dev.iloc[val_idx]
        .copy()
    )

    train_ids = (
        ids_dev.iloc[train_idx]
        .copy()
    )

    val_ids = (
        ids_dev.iloc[val_idx]
        .copy()
    )

    # ------------------------------------------------------------
    # 16.2 Train/validation ID overlap
    # ------------------------------------------------------------

    train_id_set = set(train_ids)

    val_id_set = set(val_ids)

    train_val_overlap = (
        train_id_set
        .intersection(val_id_set)
    )

    overlap_count = len(
        train_val_overlap
    )

    print(
        f"Train/validation ID overlap: "
        f"{overlap_count}"
    )

    if overlap_count != 0:

        print(
            "ERROR: Train/validation overlap."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.3 Class balance before ADASYN
    # ------------------------------------------------------------

    train_counts = (
        y_train
        .value_counts()
        .sort_index()
    )

    train_class0_before = int(
        train_counts.get(0, 0)
    )

    train_class1_before = int(
        train_counts.get(1, 0)
    )

    train_total_before = (
        train_class0_before
        + train_class1_before
    )

    minority_before = min(
        train_class0_before,
        train_class1_before
    )

    majority_before = max(
        train_class0_before,
        train_class1_before
    )

    imbalance_ratio_before = (
        minority_before /
        majority_before
    )

    print()
    print(
        "Training before ADASYN:"
    )

    print(
        f"  Class 0: "
        f"{train_class0_before:,}"
    )

    print(
        f"  Class 1: "
        f"{train_class1_before:,}"
    )

    print(
        f"  Total:   "
        f"{train_total_before:,}"
    )

    print(
        f"  Minority/majority ratio: "
        f"{imbalance_ratio_before:.6f}"
    )

    # ------------------------------------------------------------
    # 16.4 Validation class distribution
    # ------------------------------------------------------------

    val_counts = (
        y_val
        .value_counts()
        .sort_index()
    )

    val_class0 = int(
        val_counts.get(0, 0)
    )

    val_class1 = int(
        val_counts.get(1, 0)
    )

    print()
    print(
        "Validation:"
    )

    print(
        f"  Class 0: {val_class0:,}"
    )

    print(
        f"  Class 1: {val_class1:,}"
    )

    print(
        f"  Total:   {len(y_val):,}"
    )

    # ------------------------------------------------------------
    # 16.5 Fold-specific median imputation
    # ------------------------------------------------------------

    print()
    print(
        "Fold-specific median imputation:"
    )

    imputer = SimpleImputer(
        strategy="median"
    )

    # IMPORTANT:
    # Fit imputer ONLY on outer training data.
    X_train_imputed_array = (
        imputer.fit_transform(
            X_train_raw
        )
    )

    # Validation is transformed using
    # training-derived medians.
    X_val_imputed_array = (
        imputer.transform(
            X_val_raw
        )
    )

    X_train_imputed = pd.DataFrame(
        X_train_imputed_array,
        columns=PREDICTORS,
        index=X_train_raw.index
    )

    X_val_imputed = pd.DataFrame(
        X_val_imputed_array,
        columns=PREDICTORS,
        index=X_val_raw.index
    )

    # ------------------------------------------------------------
    # 16.6 Record training medians
    # ------------------------------------------------------------

    for variable, median_value in zip(
        PREDICTORS,
        imputer.statistics_
    ):

        missing_before = int(
            X_train_raw[
                variable
            ].isna().sum()
        )

        print(
            f"  {variable:12s}: "
            f"median={median_value:.6f} | "
            f"missing={missing_before}"
        )

        imputation_records.append({
            "fold": fold_number,
            "variable": variable,
            "training_missing_before":
                missing_before,
            "training_median":
                float(median_value),
        })

    # ------------------------------------------------------------
    # 16.7 Verify imputation
    # ------------------------------------------------------------

    train_nan_after = int(
        X_train_imputed
        .isna()
        .sum()
        .sum()
    )

    val_nan_after = int(
        X_val_imputed
        .isna()
        .sum()
        .sum()
    )

    print()
    print(
        "NaN after imputation:"
    )

    print(
        f"  Training:   {train_nan_after}"
    )

    print(
        f"  Validation: {val_nan_after}"
    )

    if train_nan_after != 0:

        print(
            "ERROR: Training NaN remains."
        )

        sys.exit(1)

    if val_nan_after != 0:

        print(
            "ERROR: Validation NaN remains."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.8 ADASYN DECISION
    # ------------------------------------------------------------

    print()
    print(
        "ADASYN assessment:"
    )

    if (
        imbalance_ratio_before
        >= ADASYN_RATIO_THRESHOLD
    ):

        # --------------------------------------------------------
        # Already balanced
        # --------------------------------------------------------

        adasyn_status = (
            "NOT_REQUIRED"
        )

        synthetic_samples = 0

        print(
            f"  Threshold: "
            f"{ADASYN_RATIO_THRESHOLD:.2f}"
        )

        print(
            f"  Observed ratio: "
            f"{imbalance_ratio_before:.6f}"
        )

        print(
            "  Status: NOT REQUIRED"
        )

        print(
            "  Reason: "
            "Training fold is already highly balanced."
        )

        print(
            "  Synthetic samples: 0"
        )

        X_train_resampled = (
            X_train_imputed.copy()
        )

        y_train_resampled = (
            y_train.copy()
        )

    else:

        # --------------------------------------------------------
        # Genuine imbalance
        # --------------------------------------------------------

        print(
            f"  Threshold: "
            f"{ADASYN_RATIO_THRESHOLD:.2f}"
        )

        print(
            f"  Observed ratio: "
            f"{imbalance_ratio_before:.6f}"
        )

        print(
            "  Status: APPLYING ADASYN"
        )

        adasyn_status = "APPLIED"

        adasyn = ADASYN(
            sampling_strategy="auto",
            n_neighbors=ADASYN_N_NEIGHBORS,
            random_state=(
                RANDOM_STATE + fold_number
            )
        )

        try:

            (
                X_resampled_array,
                y_resampled_array
            ) = adasyn.fit_resample(
                X_train_imputed,
                y_train
            )

        except ValueError as error:

            error_message = str(error)

            # This protects the audit if a future
            # version of imbalanced-learn considers
            # the requested resampling unnecessary.

            if (
                "No samples will be generated"
                in error_message
            ):

                print()
                print(
                    "  ADASYN requested no synthetic "
                    "samples."
                )

                print(
                    "  Status changed to: "
                    "NOT_REQUIRED_ADASYN_ZERO"
                )

                adasyn_status = (
                    "NOT_REQUIRED_ADASYN_ZERO"
                )

                synthetic_samples = 0

                X_train_resampled = (
                    X_train_imputed.copy()
                )

                y_train_resampled = (
                    y_train.copy()
                )

            else:

                print()
                print(
                    "ERROR: Unexpected ADASYN error:"
                )

                print(
                    error_message
                )

                raise

        else:

            X_train_resampled = pd.DataFrame(
                X_resampled_array,
                columns=PREDICTORS
            )

            y_train_resampled = pd.Series(
                y_resampled_array,
                name=TARGET
            )

            synthetic_samples = (
                len(y_train_resampled)
                - len(y_train)
            )

            print(
                f"  Synthetic samples: "
                f"{synthetic_samples:,}"
            )

    # ------------------------------------------------------------
    # 16.9 Class balance after ADASYN decision
    # ------------------------------------------------------------

    after_counts = (
        y_train_resampled
        .value_counts()
        .sort_index()
    )

    train_class0_after = int(
        after_counts.get(0, 0)
    )

    train_class1_after = int(
        after_counts.get(1, 0)
    )

    train_total_after = (
        train_class0_after
        + train_class1_after
    )

    print()
    print(
        "Training used for model:"
    )

    print(
        f"  Class 0: "
        f"{train_class0_after:,}"
    )

    print(
        f"  Class 1: "
        f"{train_class1_after:,}"
    )

    print(
        f"  Total:   "
        f"{train_total_after:,}"
    )

    # ------------------------------------------------------------
    # 16.10 Validation protection
    # ------------------------------------------------------------

    validation_ids_unchanged = (
        set(val_ids) == val_id_set
    )

    validation_size_unchanged = (
        len(y_val)
        == (
            val_class0
            + val_class1
        )
    )

    validation_target_unchanged = (
        int(y_val.sum())
        == val_class1
    )

    print()
    print(
        "Validation protection checks:"
    )

    print(
        f"  IDs unchanged: "
        f"{'PASS' if validation_ids_unchanged else 'FAIL'}"
    )

    print(
        f"  Size unchanged: "
        f"{'PASS' if validation_size_unchanged else 'FAIL'}"
    )

    print(
        f"  Target unchanged: "
        f"{'PASS' if validation_target_unchanged else 'FAIL'}"
    )

    if not validation_ids_unchanged:

        print(
            "ERROR: Validation IDs changed."
        )

        sys.exit(1)

    if not validation_size_unchanged:

        print(
            "ERROR: Validation size changed."
        )

        sys.exit(1)

    if not validation_target_unchanged:

        print(
            "ERROR: Validation target changed."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.11 Calibration protection
    # ------------------------------------------------------------

    calibration_ids_current = set(
        cal[ID_COLUMN].astype(int)
    )

    calibration_untouched = (
        len(cal) == 7000
        and calibration_ids_current == cal_ids
    )

    print()
    print(
        "Calibration protection: "
        f"{'PASS' if calibration_untouched else 'FAIL'}"
    )

    if not calibration_untouched:

        print(
            "ERROR: Calibration partition changed."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.12 Locked test protection
    # ------------------------------------------------------------

    test_ids_current = set(
        test[ID_COLUMN].astype(int)
    )

    test_untouched = (
        len(test) == 14000
        and test_ids_current == test_ids
    )

    print(
        "Locked test protection: "
        f"{'PASS' if test_untouched else 'FAIL'}"
    )

    if not test_untouched:

        print(
            "ERROR: Locked test partition changed."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.13 Fold-level leakage result
    # ------------------------------------------------------------

    fold_leakage_pass = (
        overlap_count == 0
        and train_nan_after == 0
        and val_nan_after == 0
        and validation_ids_unchanged
        and validation_size_unchanged
        and validation_target_unchanged
        and calibration_untouched
        and test_untouched
    )

    print()
    print(
        f"FOLD {fold_number} LEAKAGE CHECK: "
        f"{'PASS' if fold_leakage_pass else 'FAIL'}"
    )

    if not fold_leakage_pass:

        print(
            "ERROR: Fold leakage check failed."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 16.14 Store fold summary
    # ------------------------------------------------------------

    fold_summary_records.append({

        "fold": fold_number,

        "train_n_before":
            train_total_before,

        "train_class0_before":
            train_class0_before,

        "train_class1_before":
            train_class1_before,

        "imbalance_ratio_before":
            imbalance_ratio_before,

        "validation_n":
            len(y_val),

        "validation_class0":
            val_class0,

        "validation_class1":
            val_class1,

        "adasyn_threshold":
            ADASYN_RATIO_THRESHOLD,

        "adasyn_status":
            adasyn_status,

        "synthetic_samples":
            synthetic_samples,

        "train_n_after":
            train_total_after,

        "train_class0_after":
            train_class0_after,

        "train_class1_after":
            train_class1_after,

        "train_validation_id_overlap":
            overlap_count,

        "training_nan_after_imputation":
            train_nan_after,

        "validation_nan_after_imputation":
            val_nan_after,

        "validation_ids_unchanged":
            validation_ids_unchanged,

        "validation_size_unchanged":
            validation_size_unchanged,

        "validation_target_unchanged":
            validation_target_unchanged,

        "calibration_untouched":
            calibration_untouched,

        "locked_test_untouched":
            test_untouched,

        "fold_leakage_pass":
            fold_leakage_pass,
    })

    balance_records.append({

        "fold": fold_number,

        "class0_before":
            train_class0_before,

        "class1_before":
            train_class1_before,

        "minority_majority_ratio":
            imbalance_ratio_before,

        "adasyn_threshold":
            ADASYN_RATIO_THRESHOLD,

        "adasyn_status":
            adasyn_status,

        "synthetic_samples":
            synthetic_samples,

        "class0_after":
            train_class0_after,

        "class1_after":
            train_class1_after,

        "total_before":
            train_total_before,

        "total_after":
            train_total_after,
    })


# ================================================================
# 17. SAVE FOLD SUMMARY
# ================================================================

print()
print("=" * 70)
print("STEP 11: SAVE AUDIT TABLES")
print("=" * 70)

fold_summary_df = pd.DataFrame(
    fold_summary_records
)

fold_summary_file = (
    RESULTS_DIR /
    "audit17_adasyn_fold_summary.csv"
)

fold_summary_df.to_csv(
    fold_summary_file,
    index=False
)

print(
    f"Saved: {fold_summary_file}"
)


# ================================================================
# 18. SAVE LEAKAGE TABLE
# ================================================================

leakage_records = []

for record in fold_summary_records:

    leakage_records.append({

        "fold":
            record["fold"],

        "train_validation_id_overlap":
            record[
                "train_validation_id_overlap"
            ],

        "training_nan_after_imputation":
            record[
                "training_nan_after_imputation"
            ],

        "validation_nan_after_imputation":
            record[
                "validation_nan_after_imputation"
            ],

        "validation_ids_unchanged":
            record[
                "validation_ids_unchanged"
            ],

        "validation_size_unchanged":
            record[
                "validation_size_unchanged"
            ],

        "validation_target_unchanged":
            record[
                "validation_target_unchanged"
            ],

        "calibration_untouched":
            record[
                "calibration_untouched"
            ],

        "locked_test_untouched":
            record[
                "locked_test_untouched"
            ],

        "fold_leakage_pass":
            record[
                "fold_leakage_pass"
            ],
    })


leakage_df = pd.DataFrame(
    leakage_records
)

leakage_file = (
    RESULTS_DIR /
    "audit17_adasyn_leakage_records.csv"
)

leakage_df.to_csv(
    leakage_file,
    index=False
)

print(
    f"Saved: {leakage_file}"
)


# ================================================================
# 19. SAVE IMPUTATION STATISTICS
# ================================================================

imputation_df = pd.DataFrame(
    imputation_records
)

imputation_file = (
    RESULTS_DIR /
    "audit17_adasyn_imputation_statistics.csv"
)

imputation_df.to_csv(
    imputation_file,
    index=False
)

print(
    f"Saved: {imputation_file}"
)


# ================================================================
# 20. SAVE BALANCE SUMMARY
# ================================================================

balance_df = pd.DataFrame(
    balance_records
)

balance_file = (
    RESULTS_DIR /
    "audit17_adasyn_balance_summary.csv"
)

balance_df.to_csv(
    balance_file,
    index=False
)

print(
    f"Saved: {balance_file}"
)


# ================================================================
# 21. FINAL AUDIT CALCULATIONS
# ================================================================

all_folds_pass = bool(
    fold_summary_df[
        "fold_leakage_pass"
    ].all()
)

all_validation_untouched = bool(
    fold_summary_df[
        "validation_ids_unchanged"
    ].all()
    and
    fold_summary_df[
        "validation_size_unchanged"
    ].all()
    and
    fold_summary_df[
        "validation_target_unchanged"
    ].all()
)

all_calibration_untouched = bool(
    fold_summary_df[
        "calibration_untouched"
    ].all()
)

all_test_untouched = bool(
    fold_summary_df[
        "locked_test_untouched"
    ].all()
)

all_imputation_pass = bool(
    (
        fold_summary_df[
            "training_nan_after_imputation"
        ] == 0
    ).all()
    and
    (
        fold_summary_df[
            "validation_nan_after_imputation"
        ] == 0
    ).all()
)

total_synthetic_samples = int(
    fold_summary_df[
        "synthetic_samples"
    ].sum()
)

adasyn_applied_folds = int(
    (
        fold_summary_df[
            "adasyn_status"
        ] == "APPLIED"
    ).sum()
)

adasyn_not_required_folds = int(
    fold_summary_df[
        "adasyn_status"
    ].isin([
        "NOT_REQUIRED",
        "NOT_REQUIRED_ADASYN_ZERO"
    ]).sum()
)


# ================================================================
# 22. DEVELOPMENT BALANCE DECISION
# ================================================================

development_ratio = float(
    global_balance_df.loc[
        global_balance_df["dataset"]
        == "Development",
        "minority_majority_ratio"
    ].iloc[0]
)

if (
    development_ratio
    >= ADASYN_RATIO_THRESHOLD
):

    primary_decision = (
        "ADASYN NOT INCLUDED IN PRIMARY PIPELINE"
    )

else:

    primary_decision = (
        "ADASYN SHOULD BE EVALUATED AS A CANDIDATE "
        "TRAINING CONDITION"
    )


# ================================================================
# 23. FINAL AUDIT PASS
# ================================================================

audit_pass = (
    partition_size_pass
    and column_check_pass
    and target_check_pass
    and partition_disjoint_pass
    and duplicate_id_pass
    and all_folds_pass
    and all_validation_untouched
    and all_calibration_untouched
    and all_test_untouched
    and all_imputation_pass
)


# ================================================================
# 24. FINAL REPORT
# ================================================================

print()
print("=" * 70)
print("FINAL AUDIT 17 REPORT")
print("=" * 70)

print()

print(
    f"Development rows: "
    f"{len(dev):,}"
)

print(
    f"Calibration rows: "
    f"{len(cal):,}"
)

print(
    f"Locked test rows: "
    f"{len(test):,}"
)

print()

print(
    f"Development minority/majority ratio: "
    f"{development_ratio:.6f}"
)

print(
    f"ADASYN threshold: "
    f"{ADASYN_RATIO_THRESHOLD:.2f}"
)

print()

print(
    f"ADASYN applied folds: "
    f"{adasyn_applied_folds}"
)

print(
    f"ADASYN not-required folds: "
    f"{adasyn_not_required_folds}"
)

print(
    f"Total synthetic samples: "
    f"{total_synthetic_samples:,}"
)

print()

print(
    "Leakage checks:"
)

print(
    f"  Partition disjointness: "
    f"{'PASS' if partition_disjoint_pass else 'FAIL'}"
)

print(
    f"  Duplicate IDs: "
    f"{'PASS' if duplicate_id_pass else 'FAIL'}"
)

print(
    f"  Fold leakage: "
    f"{'PASS' if all_folds_pass else 'FAIL'}"
)

print(
    f"  Validation untouched: "
    f"{'PASS' if all_validation_untouched else 'FAIL'}"
)

print(
    f"  Calibration untouched: "
    f"{'PASS' if all_calibration_untouched else 'FAIL'}"
)

print(
    f"  Locked test untouched: "
    f"{'PASS' if all_test_untouched else 'FAIL'}"
)

print(
    f"  Fold-specific imputation: "
    f"{'PASS' if all_imputation_pass else 'FAIL'}"
)

print()

print(
    "PRIMARY PIPELINE DECISION:"
)

print(
    f"  {primary_decision}"
)

print()

print(
    "Overall Audit 17:"
)

print(
    f"  {'PASS' if audit_pass else 'FAIL'}"
)


# ================================================================
# 25. SAVE JSON DECISION
# ================================================================

decision = {

    "audit": "Audit 17",

    "result":
        "PASS" if audit_pass else "FAIL",

    "development_n":
        len(dev),

    "calibration_n":
        len(cal),

    "locked_test_n":
        len(test),

    "development_minority_majority_ratio":
        development_ratio,

    "adasyn_threshold":
        ADASYN_RATIO_THRESHOLD,

    "adasyn_applied_folds":
        adasyn_applied_folds,

    "adasyn_not_required_folds":
        adasyn_not_required_folds,

    "total_synthetic_samples":
        total_synthetic_samples,

    "primary_pipeline_decision":
        primary_decision,

    "partition_disjoint_pass":
        partition_disjoint_pass,

    "duplicate_id_pass":
        duplicate_id_pass,

    "fold_leakage_pass":
        all_folds_pass,

    "validation_untouched":
        all_validation_untouched,

    "calibration_untouched":
        all_calibration_untouched,

    "locked_test_untouched":
        all_test_untouched,

    "fold_specific_imputation_pass":
        all_imputation_pass,

    "random_state":
        RANDOM_STATE,

    "outer_folds":
        N_OUTER_FOLDS,

    "adasyn_n_neighbors":
        ADASYN_N_NEIGHBORS,
}

decision_file = (
    RESULTS_DIR /
    "audit17_adasyn_methodological_decision.json"
)

with open(
    decision_file,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        decision,
        f,
        indent=4
    )

print()
print(
    f"Saved: {decision_file}"
)

print()
print("=" * 70)
print("AUDIT 17 COMPLETED")
print("=" * 70)