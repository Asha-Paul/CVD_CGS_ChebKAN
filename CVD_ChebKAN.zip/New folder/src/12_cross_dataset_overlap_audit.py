# ================================================================
# AUDIT 12: UCI SHARED-FEATURE QUALITY AUDIT
# ================================================================
#
# Purpose:
#   Audit the variables that will be used in the harmonized
#   Kaggle -> UCI external-validation model.
#
# Shared variables:
#   Kaggle                    UCI
#   --------------------------------------------------------------
#   age                       age
#   gender                    sex
#   ap_hi                     trestbps
#   cholesterol               chol
#   gluc                      fbs
#   cardio                    target
#
# IMPORTANT:
#   - No records are deleted.
#   - No values are corrected.
#   - No imputation is performed.
#   - No permanent harmonization is performed.
#   - No train/test split is performed.
#   - Target mapping is provisional only for audit reporting.
#
# Provisional target mapping:
#   UCI target 0    -> 0
#   UCI target 1-4  -> 1
#
# ================================================================

from pathlib import Path
import zipfile
import pandas as pd
import numpy as np


# ================================================================
# 1. PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

ZIP_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ================================================================
# 2. UCI FILES
# ================================================================

UCI_FILES = {
    "Cleveland": "processed.cleveland.data",
    "Hungarian": "processed.hungarian.data",
    "Switzerland": "processed.switzerland.data",
    "VA Long Beach": "processed.va.data"
}


# ================================================================
# 3. ORIGINAL UCI COLUMN NAMES
# ================================================================

COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target"
]


# ================================================================
# 4. SHARED FEATURES
# ================================================================

SHARED_FEATURES = [
    "age",
    "sex",
    "trestbps",
    "chol",
    "fbs"
]


# ================================================================
# 5. OUTPUT FILES
# ================================================================

COHORT_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_shared_feature_cohort_summary.csv"
)

FEATURE_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_shared_feature_quality.csv"
)

TARGET_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_provisional_target_distribution.csv"
)

ELIGIBILITY_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_external_validation_eligibility.csv"
)

DUPLICATE_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_duplicate_analysis.csv"
)

EXAMPLES_OUTPUT = (
    RESULTS_DIR
    / "audit12_uci_quality_problem_examples.csv"
)


# ================================================================
# 6. HEADER
# ================================================================

print("=" * 80)
print("AUDIT 12: UCI SHARED-FEATURE QUALITY AUDIT")
print("=" * 80)

print("\nZIP file:")
print(ZIP_PATH)


# ================================================================
# 7. CHECK ZIP
# ================================================================

if not ZIP_PATH.exists():

    raise FileNotFoundError(
        f"UCI ZIP file not found:\n{ZIP_PATH}"
    )


# ================================================================
# 8. READ UCI DATA
# ================================================================

cohort_data = {}

with zipfile.ZipFile(ZIP_PATH, "r") as z:

    zip_names = z.namelist()

    for cohort, filename in UCI_FILES.items():

        print("\n" + "=" * 80)
        print(f"LOADING: {cohort}")
        print("=" * 80)

        if filename not in zip_names:

            print(
                f"WARNING: {filename} not found."
            )

            continue

        with z.open(filename) as f:

            df = pd.read_csv(
                f,
                header=None,
                names=COLUMNS,
                na_values=["?"],
                skipinitialspace=True
            )

        cohort_data[cohort] = df.copy()

        print(
            f"Rows loaded: {len(df):,}"
        )


# ================================================================
# 9. ANALYZE EACH COHORT
# ================================================================

cohort_summary_rows = []
feature_rows = []
target_rows = []
eligibility_rows = []
duplicate_rows = []
problem_examples = []


for cohort, df in cohort_data.items():

    N = len(df)

    print("\n" + "=" * 80)
    print(f"SHARED-FEATURE AUDIT: {cohort}")
    print("=" * 80)

    # ------------------------------------------------------------
    # 9.1 Basic information
    # ------------------------------------------------------------

    print(
        f"\nRecords: {N:,}"
    )


    # ============================================================
    # 9.2 AGE
    # ============================================================

    age = pd.to_numeric(
        df["age"],
        errors="coerce"
    )

    age_missing = age.isna()

    # Conservative plausibility range for audit only.
    age_invalid = (
        age.notna()
        & (
            (age < 18)
            | (age > 100)
        )
    )

    print("\nAGE")
    print("-" * 60)

    print(
        f"Missing : {age_missing.sum():,}"
    )

    print(
        f"Invalid (<18 or >100) : "
        f"{age_invalid.sum():,}"
    )

    if age.notna().any():

        print(
            f"Minimum : {age.min()}"
        )

        print(
            f"Maximum : {age.max()}"
        )

        print(
            f"Mean    : {age.mean():.3f}"
        )


    # ============================================================
    # 9.3 SEX
    # ============================================================

    sex = pd.to_numeric(
        df["sex"],
        errors="coerce"
    )

    sex_missing = sex.isna()

    sex_invalid = (
        sex.notna()
        & ~sex.isin([0, 1])
    )

    print("\nSEX")
    print("-" * 60)

    print(
        f"Missing : {sex_missing.sum():,}"
    )

    print(
        f"Invalid : {sex_invalid.sum():,}"
    )

    print(
        "Observed values:",
        sorted(
            sex.dropna().unique().tolist()
        )
    )


    # ============================================================
    # 9.4 RESTING SYSTOLIC BP
    # ============================================================

    trestbps = pd.to_numeric(
        df["trestbps"],
        errors="coerce"
    )

    trestbps_missing = trestbps.isna()

    # For audit purposes only.
    # We flag zero/non-positive values separately from
    # implausibly high values.
    trestbps_nonpositive = (
        trestbps.notna()
        & (trestbps <= 0)
    )

    trestbps_low = (
        trestbps.notna()
        & (trestbps > 0)
        & (trestbps < 70)
    )

    trestbps_high = (
        trestbps.notna()
        & (trestbps > 250)
    )

    print("\nRESTING SYSTOLIC BP (trestbps)")
    print("-" * 60)

    print(
        f"Missing : {trestbps_missing.sum():,}"
    )

    print(
        f"Non-positive : {trestbps_nonpositive.sum():,}"
    )

    print(
        f"Positive but <70 : {trestbps_low.sum():,}"
    )

    print(
        f">250 : {trestbps_high.sum():,}"
    )

    if trestbps.notna().any():

        print(
            f"Minimum : {trestbps.min()}"
        )

        print(
            f"Maximum : {trestbps.max()}"
        )

        print(
            f"Mean    : {trestbps.mean():.3f}"
        )


    # ============================================================
    # 9.5 CHOLESTEROL
    # ============================================================

    chol = pd.to_numeric(
        df["chol"],
        errors="coerce"
    )

    chol_missing = chol.isna()

    chol_zero = (
        chol.notna()
        & (chol == 0)
    )

    chol_negative = (
        chol.notna()
        & (chol < 0)
    )

    chol_low = (
        chol.notna()
        & (chol > 0)
        & (chol < 100)
    )

    chol_high = (
        chol.notna()
        & (chol > 600)
    )

    print("\nCHOLESTEROL (chol)")
    print("-" * 60)

    print(
        f"Missing : {chol_missing.sum():,}"
    )

    print(
        f"Zero : {chol_zero.sum():,}"
    )

    print(
        f"Negative : {chol_negative.sum():,}"
    )

    print(
        f"Positive but <100 : {chol_low.sum():,}"
    )

    print(
        f">600 : {chol_high.sum():,}"
    )

    if chol.notna().any():

        print(
            f"Minimum : {chol.min()}"
        )

        print(
            f"Maximum : {chol.max()}"
        )

        print(
            f"Mean    : {chol.mean():.3f}"
        )


    # ============================================================
    # 9.6 FASTING BLOOD SUGAR
    # ============================================================

    fbs = pd.to_numeric(
        df["fbs"],
        errors="coerce"
    )

    fbs_missing = fbs.isna()

    fbs_invalid = (
        fbs.notna()
        & ~fbs.isin([0, 1])
    )

    print("\nFASTING BLOOD SUGAR (fbs)")
    print("-" * 60)

    print(
        f"Missing : {fbs_missing.sum():,}"
    )

    print(
        f"Invalid : {fbs_invalid.sum():,}"
    )

    print(
        "Observed values:",
        sorted(
            fbs.dropna().unique().tolist()
        )
    )


    # ============================================================
    # 9.7 TARGET
    # ============================================================

    target = pd.to_numeric(
        df["target"],
        errors="coerce"
    )

    target_missing = target.isna()

    print("\nTARGET")
    print("-" * 60)

    print(
        f"Missing : {target_missing.sum():,}"
    )

    raw_targets = sorted(
        target.dropna().unique().tolist()
    )

    print(
        f"Raw target values: {raw_targets}"
    )


    # ------------------------------------------------------------
    # Provisional binary mapping ONLY for audit
    # ------------------------------------------------------------

    provisional_target = target.map(
        lambda x:
            np.nan
            if pd.isna(x)
            else (
                0
                if x == 0
                else 1
            )
    )

    print("\nProvisional binary target:")
    print("  0 -> no disease")
    print("  1-4 -> disease")

    provisional_counts = (
        provisional_target
        .value_counts(dropna=False)
        .sort_index()
    )

    for value, count in provisional_counts.items():

        pct = (
            100 * count / N
        )

        print(
            f"  {value} : "
            f"{int(count):,} "
            f"({pct:.3f}%)"
        )


    # ============================================================
    # 9.8 DUPLICATE ANALYSIS
    # ============================================================

    exact_duplicate_mask = df.duplicated(
        keep=False
    )

    exact_duplicate_count = int(
        df.duplicated().sum()
    )

    duplicate_groups = (
        int(
            df[
                exact_duplicate_mask
            ].shape[0]
        )
        if exact_duplicate_count > 0
        else 0
    )

    print("\nDUPLICATES")
    print("-" * 60)

    print(
        f"Exact duplicate rows: "
        f"{exact_duplicate_count:,}"
    )

    print(
        f"Rows belonging to duplicate groups: "
        f"{duplicate_groups:,}"
    )


    # ------------------------------------------------------------
    # Shared-feature duplicate check
    # ------------------------------------------------------------

    shared_duplicate_columns = [
        "age",
        "sex",
        "trestbps",
        "chol",
        "fbs",
        "target"
    ]

    shared_duplicate_mask = df.duplicated(
        subset=shared_duplicate_columns,
        keep=False
    )

    shared_duplicate_count = int(
        df.duplicated(
            subset=shared_duplicate_columns
        ).sum()
    )

    print(
        f"Duplicate rows based on shared variables: "
        f"{shared_duplicate_count:,}"
    )


    # ============================================================
    # 9.9 SHARED-FEATURE COMPLETE CASES
    # ============================================================

    shared_complete = (
        age.notna()
        & sex.notna()
        & trestbps.notna()
        & chol.notna()
        & fbs.notna()
        & target.notna()
    )

    # Basic validity only.
    # This does NOT modify the data.
    shared_basic_valid = (
        shared_complete
        & ~age_invalid
        & ~sex_invalid
        & ~trestbps_nonpositive
        & ~trestbps_low
        & ~trestbps_high
        & ~chol_zero
        & ~chol_negative
        & ~chol_low
        & ~chol_high
        & ~fbs_invalid
    )

    print("\nSHARED-FEATURE ELIGIBILITY")
    print("-" * 60)

    print(
        f"Complete shared variables : "
        f"{shared_complete.sum():,} "
        f"({100 * shared_complete.sum() / N:.3f}%)"
    )

    print(
        f"Complete + basic validity : "
        f"{shared_basic_valid.sum():,} "
        f"({100 * shared_basic_valid.sum() / N:.3f}%)"
    )


    # ============================================================
    # 9.10 RECORD-LEVEL QUALITY FLAGS
    # ============================================================

    any_shared_missing = (
        ~shared_complete
    )

    any_shared_invalid = (
        shared_complete
        & ~shared_basic_valid
    )

    quality_problem = (
        any_shared_missing
        | any_shared_invalid
    )

    print("\nRECORD-LEVEL QUALITY")
    print("-" * 60)

    print(
        f"Any shared-feature missingness : "
        f"{any_shared_missing.sum():,}"
    )

    print(
        f"Complete but invalid shared value : "
        f"{any_shared_invalid.sum():,}"
    )

    print(
        f"Any shared-feature quality issue : "
        f"{quality_problem.sum():,}"
    )


    # ============================================================
    # 9.11 STORE COHORT SUMMARY
    # ============================================================

    cohort_summary_rows.append({

        "cohort": cohort,

        "records": N,

        "age_missing": int(age_missing.sum()),
        "age_invalid": int(age_invalid.sum()),

        "sex_missing": int(sex_missing.sum()),
        "sex_invalid": int(sex_invalid.sum()),

        "trestbps_missing":
            int(trestbps_missing.sum()),

        "trestbps_nonpositive":
            int(trestbps_nonpositive.sum()),

        "trestbps_low":
            int(trestbps_low.sum()),

        "trestbps_high":
            int(trestbps_high.sum()),

        "chol_missing":
            int(chol_missing.sum()),

        "chol_zero":
            int(chol_zero.sum()),

        "chol_negative":
            int(chol_negative.sum()),

        "chol_low":
            int(chol_low.sum()),

        "chol_high":
            int(chol_high.sum()),

        "fbs_missing":
            int(fbs_missing.sum()),

        "fbs_invalid":
            int(fbs_invalid.sum()),

        "target_missing":
            int(target_missing.sum()),

        "exact_duplicate_rows":
            exact_duplicate_count,

        "shared_feature_duplicate_rows":
            shared_duplicate_count,

        "shared_complete_records":
            int(shared_complete.sum()),

        "shared_basic_valid_records":
            int(shared_basic_valid.sum())
    })


    # ============================================================
    # 9.12 FEATURE-LEVEL RESULTS
    # ============================================================

    feature_information = {

        "age": {
            "missing": age_missing.sum(),
            "invalid": age_invalid.sum(),
            "minimum": age.min(),
            "maximum": age.max()
        },

        "sex": {
            "missing": sex_missing.sum(),
            "invalid": sex_invalid.sum(),
            "minimum": sex.min(),
            "maximum": sex.max()
        },

        "trestbps": {
            "missing": trestbps_missing.sum(),
            "invalid": (
                trestbps_nonpositive
                | trestbps_low
                | trestbps_high
            ).sum(),
            "minimum": trestbps.min(),
            "maximum": trestbps.max()
        },

        "chol": {
            "missing": chol_missing.sum(),
            "invalid": (
                chol_zero
                | chol_negative
                | chol_low
                | chol_high
            ).sum(),
            "minimum": chol.min(),
            "maximum": chol.max()
        },

        "fbs": {
            "missing": fbs_missing.sum(),
            "invalid": fbs_invalid.sum(),
            "minimum": fbs.min(),
            "maximum": fbs.max()
        }
    }


    for feature, info in feature_information.items():

        feature_rows.append({

            "cohort": cohort,

            "feature": feature,

            "missing_count":
                int(info["missing"]),

            "invalid_count":
                int(info["invalid"]),

            "minimum":
                info["minimum"],

            "maximum":
                info["maximum"]
        })


    # ============================================================
    # 9.13 TARGET RESULTS
    # ============================================================

    for raw_target, count in (
        target
        .value_counts(dropna=False)
        .sort_index()
        .items()
    ):

        target_rows.append({

            "cohort": cohort,

            "raw_target":
                raw_target,

            "count":
                int(count),

            "percentage":
                100 * count / N,

            "provisional_binary_target":
                (
                    np.nan
                    if pd.isna(raw_target)
                    else (
                        0
                        if raw_target == 0
                        else 1
                    )
                )
        })


    # ============================================================
    # 9.14 ELIGIBILITY RESULTS
    # ============================================================

    eligibility_rows.append({

        "cohort": cohort,

        "total_records": N,

        "complete_shared_features":
            int(shared_complete.sum()),

        "complete_shared_features_pct":
            100 * shared_complete.sum() / N,

        "basic_valid_shared_features":
            int(shared_basic_valid.sum()),

        "basic_valid_shared_features_pct":
            100 * shared_basic_valid.sum() / N,

        "records_with_missing_shared_feature":
            int(any_shared_missing.sum()),

        "records_with_invalid_shared_feature":
            int(any_shared_invalid.sum())
    })


    # ============================================================
    # 9.15 QUALITY-PROBLEM EXAMPLES
    # ============================================================

    problem_mask = (
        age_invalid
        | sex_invalid
        | trestbps_nonpositive
        | trestbps_low
        | trestbps_high
        | chol_zero
        | chol_negative
        | chol_low
        | chol_high
        | fbs_invalid
    )

    examples = df.loc[
        problem_mask,
        [
            "age",
            "sex",
            "trestbps",
            "chol",
            "fbs",
            "target"
        ]
    ].copy()

    if len(examples) > 0:

        examples.insert(
            0,
            "cohort",
            cohort
        )

        examples = examples.head(20)

        problem_examples.append(
            examples
        )


# ================================================================
# 10. SAVE COHORT SUMMARY
# ================================================================

cohort_summary_df = pd.DataFrame(
    cohort_summary_rows
)

cohort_summary_df.to_csv(
    COHORT_OUTPUT,
    index=False
)


# ================================================================
# 11. SAVE FEATURE QUALITY
# ================================================================

feature_df = pd.DataFrame(
    feature_rows
)

feature_df.to_csv(
    FEATURE_OUTPUT,
    index=False
)


# ================================================================
# 12. SAVE TARGET DISTRIBUTION
# ================================================================

target_df = pd.DataFrame(
    target_rows
)

target_df.to_csv(
    TARGET_OUTPUT,
    index=False
)


# ================================================================
# 13. SAVE EXTERNAL VALIDATION ELIGIBILITY
# ================================================================

eligibility_df = pd.DataFrame(
    eligibility_rows
)

eligibility_df.to_csv(
    ELIGIBILITY_OUTPUT,
    index=False
)


# ================================================================
# 14. SAVE DUPLICATE ANALYSIS
# ================================================================

duplicate_analysis = cohort_summary_df[
    [
        "cohort",
        "records",
        "exact_duplicate_rows",
        "shared_feature_duplicate_rows"
    ]
].copy()

duplicate_analysis.to_csv(
    DUPLICATE_OUTPUT,
    index=False
)


# ================================================================
# 15. SAVE QUALITY PROBLEM EXAMPLES
# ================================================================

if problem_examples:

    examples_df = pd.concat(
        problem_examples,
        ignore_index=True
    )

else:

    examples_df = pd.DataFrame(
        columns=[
            "cohort",
            "age",
            "sex",
            "trestbps",
            "chol",
            "fbs",
            "target"
        ]
    )

examples_df.to_csv(
    EXAMPLES_OUTPUT,
    index=False
)


# ================================================================
# 16. PRINT FINAL SUMMARY
# ================================================================

print("\n" + "=" * 80)
print("AUDIT 12 FINAL SUMMARY")
print("=" * 80)

print("\nCohort-level shared-feature eligibility:")

print(
    eligibility_df.to_string(
        index=False
    )
)


# ================================================================
# 17. GLOBAL ELIGIBILITY
# ================================================================

total_records = int(
    eligibility_df["total_records"].sum()
)

total_complete = int(
    eligibility_df[
        "complete_shared_features"
    ].sum()
)

total_valid = int(
    eligibility_df[
        "basic_valid_shared_features"
    ].sum()
)

print("\n" + "=" * 80)
print("GLOBAL SHARED-FEATURE ELIGIBILITY")
print("=" * 80)

print(
    f"Total UCI records                 : "
    f"{total_records:,}"
)

print(
    f"Complete shared-feature records   : "
    f"{total_complete:,} "
    f"({100 * total_complete / total_records:.3f}%)"
)

print(
    f"Basic-valid shared-feature records: "
    f"{total_valid:,} "
    f"({100 * total_valid / total_records:.3f}%)"
)


# ================================================================
# 18. IMPORTANT DATASET-SPECIFIC CHECKS
# ================================================================

print("\n" + "=" * 80)
print("IMPORTANT DATASET-SPECIFIC CHECKS")
print("=" * 80)

for cohort, df in cohort_data.items():

    print(f"\n{cohort}:")

    print(
        f"  Cholesterol = 0 : "
        f"{int((df['chol'] == 0).sum()):,}"
    )

    print(
        f"  trestbps <= 0   : "
        f"{int((df['trestbps'] <= 0).sum()):,}"
    )

    print(
        f"  Missing fbs     : "
        f"{int(df['fbs'].isna().sum()):,}"
    )

    print(
        f"  Missing chol    : "
        f"{int(df['chol'].isna().sum()):,}"
    )

    print(
        f"  Missing trestbps: "
        f"{int(df['trestbps'].isna().sum()):,}"
    )


# ================================================================
# 19. FINAL STATUS
# ================================================================

print("\n" + "=" * 80)
print("AUDIT 12 COMPLETE")
print("=" * 80)

print("\nOutputs:")

print(
    "\nCohort summary:"
)
print(COHORT_OUTPUT)

print(
    "\nFeature quality:"
)
print(FEATURE_OUTPUT)

print(
    "\nProvisional target distribution:"
)
print(TARGET_OUTPUT)

print(
    "\nExternal-validation eligibility:"
)
print(ELIGIBILITY_OUTPUT)

print(
    "\nDuplicate analysis:"
)
print(DUPLICATE_OUTPUT)

print(
    "\nQuality-problem examples:"
)
print(EXAMPLES_OUTPUT)

print("\nIMPORTANT:")
print("No records were deleted.")
print("No values were corrected.")
print("No imputation was performed.")
print("No permanent target mapping was applied.")
print("No harmonization was performed.")
print("No train/test split was performed.")