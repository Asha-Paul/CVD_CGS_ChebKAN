from pathlib import Path
import pandas as pd

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

KAGGLE_FILE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

print("=" * 70)
print("CVD CGS-ChebKAN — CLINICAL QUALITY AUDIT")
print("=" * 70)

df = pd.read_csv(KAGGLE_FILE)

print(f"\nTotal records: {len(df):,}")

# ------------------------------------------------------------
# AGE
# ------------------------------------------------------------

df["age_years"] = df["age"] / 365.25

print("\n" + "=" * 70)
print("AGE")
print("=" * 70)

print(df["age_years"].describe())

print("\nAge frequency outside 18–100 years:")
print(
    ((df["age_years"] < 18) | (df["age_years"] > 100)).sum()
)

# ------------------------------------------------------------
# HEIGHT
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("HEIGHT")
print("=" * 70)

print(df["height"].describe())

height_ranges = [
    ("< 100 cm", df["height"] < 100),
    ("100–140 cm", (df["height"] >= 100) & (df["height"] < 140)),
    ("140–200 cm", (df["height"] >= 140) & (df["height"] <= 200)),
    ("> 200 cm", df["height"] > 200),
]

for label, condition in height_ranges:
    print(f"{label}: {condition.sum():,}")

# ------------------------------------------------------------
# WEIGHT
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("WEIGHT")
print("=" * 70)

print(df["weight"].describe())

weight_ranges = [
    ("< 30 kg", df["weight"] < 30),
    ("30–40 kg", (df["weight"] >= 30) & (df["weight"] < 40)),
    ("40–200 kg", (df["weight"] >= 40) & (df["weight"] <= 200)),
    ("> 200 kg", df["weight"] > 200),
]

for label, condition in weight_ranges:
    print(f"{label}: {condition.sum():,}")

# ------------------------------------------------------------
# SYSTOLIC BP
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("SYSTOLIC BLOOD PRESSURE — ap_hi")
print("=" * 70)

print(df["ap_hi"].describe())

sbp_ranges = [
    ("<= 0", df["ap_hi"] <= 0),
    ("1–69", (df["ap_hi"] > 0) & (df["ap_hi"] < 70)),
    ("70–89", (df["ap_hi"] >= 70) & (df["ap_hi"] < 90)),
    ("90–139", (df["ap_hi"] >= 90) & (df["ap_hi"] <= 139)),
    ("140–179", (df["ap_hi"] >= 140) & (df["ap_hi"] <= 179)),
    ("180–250", (df["ap_hi"] >= 180) & (df["ap_hi"] <= 250)),
    ("251–300", (df["ap_hi"] > 250) & (df["ap_hi"] <= 300)),
    ("> 300", df["ap_hi"] > 300),
]

for label, condition in sbp_ranges:
    print(f"{label}: {condition.sum():,}")

# ------------------------------------------------------------
# DIASTOLIC BP
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("DIASTOLIC BLOOD PRESSURE — ap_lo")
print("=" * 70)

print(df["ap_lo"].describe())

dbp_ranges = [
    ("<= 0", df["ap_lo"] <= 0),
    ("1–39", (df["ap_lo"] > 0) & (df["ap_lo"] < 40)),
    ("40–59", (df["ap_lo"] >= 40) & (df["ap_lo"] < 60)),
    ("60–89", (df["ap_lo"] >= 60) & (df["ap_lo"] <= 89)),
    ("90–119", (df["ap_lo"] >= 90) & (df["ap_lo"] <= 119)),
    ("120–150", (df["ap_lo"] > 119) & (df["ap_lo"] <= 150)),
    ("151–200", (df["ap_lo"] > 150) & (df["ap_lo"] <= 200)),
    ("> 200", df["ap_lo"] > 200),
]

for label, condition in dbp_ranges:
    print(f"{label}: {condition.sum():,}")

# ------------------------------------------------------------
# BLOOD PRESSURE LOGICAL CONSISTENCY
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("BLOOD PRESSURE LOGICAL CONSISTENCY")
print("=" * 70)

print(
    "ap_hi <= ap_lo:",
    (df["ap_hi"] <= df["ap_lo"]).sum()
)

print(
    "ap_hi > ap_lo:",
    (df["ap_hi"] > df["ap_lo"]).sum()
)

# ------------------------------------------------------------
# MOST EXTREME VALUES
# ------------------------------------------------------------

print("\n" + "=" * 70)
print("MOST EXTREME VALUES")
print("=" * 70)

print("\nLargest systolic values:")
print(df.nlargest(20, "ap_hi")[["id", "age_years", "gender", "ap_hi", "ap_lo", "cardio"]])

print("\nSmallest systolic values:")
print(df.nsmallest(20, "ap_hi")[["id", "age_years", "gender", "ap_hi", "ap_lo", "cardio"]])

print("\nLargest diastolic values:")
print(df.nlargest(20, "ap_lo")[["id", "age_years", "gender", "ap_hi", "ap_lo", "cardio"]])

print("\nSmallest diastolic values:")
print(df.nsmallest(20, "ap_lo")[["id", "age_years", "gender", "ap_hi", "ap_lo", "cardio"]])

print("\n" + "=" * 70)
print("CLINICAL QUALITY AUDIT COMPLETED")
print("=" * 70)
print("No raw data were modified.")