# ================================================================
# AUDIT 16: FOLD-SPECIFIC PREPROCESSING + FEATURE SELECTION
# ================================================================
#
# Purpose:
#   Verify that preprocessing and supervised feature selection are
#   performed strictly within CV training folds.
#
# Frozen dataset:
#   Kaggle development/CV = 49,000
#
# Frozen CV:
#   Outer = 5-fold StratifiedKFold
#   Inner = 4-fold StratifiedKFold
#
# Feature-selection methods:
#   1. XGBoost feature importance
#   2. Boruta
#   3. RFE
#   4. Chi-square
#
# IMPORTANT:
#   This is an AUDIT.
#
#   It does NOT:
#       - train the final CGS-ChebKAN
#       - use calibration data
#       - use locked test data
#       - perform ADASYN
#       - perform final hyperparameter tuning
#
#   Every supervised operation is fitted using only the
#   corresponding outer-training fold.
#
# ================================================================

from pathlib import Path
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.feature_selection import chi2
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestClassifier

try:
    from xgboost import XGBClassifier
except ImportError:
    raise ImportError(
        "XGBoost is not installed. Run:\n"
        "pip install xgboost"
    )

try:
    from boruta import BorutaPy
except ImportError:
    raise ImportError(
        "Boruta is not installed. Run:\n"
        "pip install boruta"
    )


warnings.filterwarnings("ignore")


# ================================================================
# 1. PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

PROCESSED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

DEVELOPMENT_FILE = (
    PROCESSED_DIR
    / "kaggle_development_cv.csv"
)

CALIBRATION_FILE = (
    PROCESSED_DIR
    / "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROCESSED_DIR
    / "kaggle_locked_test.csv"
)


# ================================================================
# 2. FROZEN PARAMETERS
# ================================================================

RANDOM_STATE = 2026

N_OUTER_SPLITS = 5

# Number of features to retain in the audit.
#
# The final number can be frozen later after comparing
# stability and predictive performance.
N_SELECTED_FEATURES = 6

# XGBoost audit configuration.
XGB_N_ESTIMATORS = 150
XGB_MAX_DEPTH = 4
XGB_LEARNING_RATE = 0.05
XGB_SUBSAMPLE = 0.80
XGB_COLSAMPLE_BYTREE = 0.80

# RFE configuration.
RFE_ESTIMATOR_TREES = 100

# Boruta configuration.
BORUTA_N_ESTIMATORS = 150
BORUTA_MAX_ITER = 50


# ================================================================
# 3. LOAD DATA
# ================================================================

print("=" * 70)
print("AUDIT 16: FOLD-SPECIFIC PREPROCESSING + FEATURE SELECTION")
print("=" * 70)

print("\nChecking input files...")

for path in [
    DEVELOPMENT_FILE,
    CALIBRATION_FILE,
    TEST_FILE
]:
    print(path)

    if not path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )


development = pd.read_csv(
    DEVELOPMENT_FILE
)

calibration = pd.read_csv(
    CALIBRATION_FILE
)

test = pd.read_csv(
    TEST_FILE
)


print("\nDataset sizes")
print("-" * 70)

print(
    f"Development/CV : {len(development):,}"
)

print(
    f"Calibration     : {len(calibration):,}"
)

print(
    f"Locked test     : {len(test):,}"
)


# ================================================================
# 4. BASIC VALIDATION
# ================================================================

if len(development) != 49_000:
    raise RuntimeError(
        "Development dataset must contain 49,000 records."
    )

if len(calibration) != 7_000:
    raise RuntimeError(
        "Calibration dataset must contain 7,000 records."
    )

if len(test) != 14_000:
    raise RuntimeError(
        "Locked test dataset must contain 14,000 records."
    )

required_columns = {
    "id",
    "cardio"
}

for name, df in [
    ("development", development),
    ("calibration", calibration),
    ("test", test)
]:

    missing = required_columns - set(df.columns)

    if missing:
        raise RuntimeError(
            f"{name} missing columns: {missing}"
        )


# ================================================================
# 5. GLOBAL LEAKAGE CHECK
# ================================================================

development_ids = set(
    development["id"]
)

calibration_ids = set(
    calibration["id"]
)

test_ids = set(
    test["id"]
)

if development_ids.intersection(calibration_ids):
    raise RuntimeError(
        "Development/calibration overlap detected."
    )

if development_ids.intersection(test_ids):
    raise RuntimeError(
        "Development/test overlap detected."
    )

if calibration_ids.intersection(test_ids):
    raise RuntimeError(
        "Calibration/test overlap detected."
    )

print("\nPASS: Global partition separation verified.")


# ================================================================
# 6. DEFINE FEATURES
# ================================================================
#
# At this stage we use the full eligible Kaggle feature space.
#
# ID is NEVER a predictor.
# Target is NEVER a predictor.
#
# Full Kaggle model variables:
#
#   age
#   gender
#   height
#   weight
#   ap_hi
#   ap_lo
#   cholesterol
#   gluc
#   smoke
#   alco
#   active
#
# ================================================================

EXCLUDED_COLUMNS = {
    "id",
    "cardio",
    "partition"
}

feature_columns = [
    c
    for c in development.columns
    if c not in EXCLUDED_COLUMNS
]

print("\nFeature columns")
print("-" * 70)

for i, feature in enumerate(
    feature_columns,
    start=1
):
    print(
        f"{i:2d}. {feature}"
    )

print(
    f"\nTotal predictor variables: "
    f"{len(feature_columns)}"
)


# ================================================================
# 7. CHECK TARGET / FEATURE TYPES
# ================================================================

X_all = development[
    feature_columns
].copy()

y_all = development[
    "cardio"
].copy()

non_numeric = [
    c
    for c in feature_columns
    if not pd.api.types.is_numeric_dtype(
        X_all[c]
    )
]

if non_numeric:
    raise TypeError(
        "Non-numeric predictor columns detected: "
        f"{non_numeric}"
    )


# ================================================================
# 8. OUTER CV
# ================================================================

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)


# ================================================================
# 9. STORAGE
# ================================================================

selection_records = []

fold_feature_records = []

leakage_records = []

importance_records = []

rfe_records = []

chi2_records = []

boruta_records = []


# ================================================================
# 10. HELPER FUNCTION
# ================================================================

def make_feature_mask(
    selected_features,
    all_features
):
    return [
        feature in selected_features
        for feature in all_features
    ]


# ================================================================
# 11. OUTER-FOLD LOOP
# ================================================================

print("\n" + "=" * 70)
print("OUTER-FOLD FEATURE-SELECTION AUDIT")
print("=" * 70)


for outer_fold, (
    train_idx,
    val_idx
) in enumerate(
    outer_cv.split(
        X_all,
        y_all
    ),
    start=1
):

    print("\n" + "-" * 70)
    print(
        f"OUTER FOLD {outer_fold}"
    )
    print("-" * 70)

    X_train_raw = X_all.iloc[
        train_idx
    ].copy()

    X_val_raw = X_all.iloc[
        val_idx
    ].copy()

    y_train = y_all.iloc[
        train_idx
    ].copy()

    y_val = y_all.iloc[
        val_idx
    ].copy()

    train_ids = set(
        development.iloc[
            train_idx
        ]["id"]
    )

    val_ids = set(
        development.iloc[
            val_idx
        ]["id"]
    )

    # ------------------------------------------------------------
    # 11.1 TRAIN/VALIDATION OVERLAP
    # ------------------------------------------------------------

    if train_ids.intersection(val_ids):
        raise RuntimeError(
            f"Fold {outer_fold}: "
            "training/validation overlap."
        )

    # ------------------------------------------------------------
    # 11.2 IMPUTATION
    # ------------------------------------------------------------
    #
    # IMPORTANT:
    # The imputer is FIT ONLY on X_train_raw.
    #
    # It is then applied to X_val_raw.
    #
    # ------------------------------------------------------------

    imputer = SimpleImputer(
        strategy="median"
    )

    X_train_imp = imputer.fit_transform(
        X_train_raw
    )

    X_val_imp = imputer.transform(
        X_val_raw
    )

    # Verify that validation data did not affect
    # the learned imputation statistics.
    #
    # Refit independently on training data and compare.
    independent_imputer = SimpleImputer(
        strategy="median"
    )

    independent_imputer.fit(
        X_train_raw
    )

    if not np.allclose(
        imputer.statistics_,
        independent_imputer.statistics_,
        equal_nan=True
    ):
        raise RuntimeError(
            f"Fold {outer_fold}: "
            "imputation statistics inconsistency."
        )

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "imputation",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.3 STANDARDIZATION
    # ------------------------------------------------------------
    #
    # Scaling is FIT ONLY on training data.
    #
    # This scaled matrix is used for RFE.
    #
    # ------------------------------------------------------------

    scaler = StandardScaler()

    X_train_scaled = scaler.fit_transform(
        X_train_imp
    )

    X_val_scaled = scaler.transform(
        X_val_imp
    )

    independent_scaler = StandardScaler()

    independent_scaler.fit(
        X_train_imp
    )

    if not np.allclose(
        scaler.mean_,
        independent_scaler.mean_,
        equal_nan=True
    ):
        raise RuntimeError(
            f"Fold {outer_fold}: "
            "scaling statistics inconsistency."
        )

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "standardization",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.4 CHI-SQUARE
    # ------------------------------------------------------------
    #
    # Chi-square requires non-negative features.
    #
    # Therefore MinMaxScaler is FIT ONLY on training data.
    #
    # ------------------------------------------------------------

    chi_scaler = MinMaxScaler()

    X_train_nonnegative = (
        chi_scaler.fit_transform(
            X_train_imp
        )
    )

    X_val_nonnegative = (
        chi_scaler.transform(
            X_val_imp
        )
    )

    chi_scores, chi_pvalues = chi2(
        X_train_nonnegative,
        y_train
    )

    chi_table = pd.DataFrame({
        "feature": feature_columns,
        "chi2_score": chi_scores,
        "p_value": chi_pvalues,
        "outer_fold": outer_fold
    })

    chi_table = chi_table.sort_values(
        "chi2_score",
        ascending=False
    )

    chi_selected = (
        chi_table
        .head(N_SELECTED_FEATURES)
        ["feature"]
        .tolist()
    )

    for _, row in chi_table.iterrows():
        chi2_records.append(
            row.to_dict()
        )

    selection_records.append({
        "outer_fold": outer_fold,
        "method": "chi_square",
        "n_selected": len(chi_selected),
        "selected_features":
            "|".join(chi_selected)
    })

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "chi_square",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.5 XGBOOST FEATURE IMPORTANCE
    # ------------------------------------------------------------

    xgb_model = XGBClassifier(
        n_estimators=XGB_N_ESTIMATORS,
        max_depth=XGB_MAX_DEPTH,
        learning_rate=XGB_LEARNING_RATE,
        subsample=XGB_SUBSAMPLE,
        colsample_bytree=XGB_COLSAMPLE_BYTREE,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=RANDOM_STATE + outer_fold,
        n_jobs=-1,
        tree_method="hist"
    )

    xgb_model.fit(
        X_train_imp,
        y_train
    )

    xgb_importances = (
        xgb_model.feature_importances_
    )

    xgb_table = pd.DataFrame({
        "feature": feature_columns,
        "importance": xgb_importances,
        "outer_fold": outer_fold
    })

    xgb_table = xgb_table.sort_values(
        "importance",
        ascending=False
    )

    xgb_selected = (
        xgb_table
        .head(N_SELECTED_FEATURES)
        ["feature"]
        .tolist()
    )

    for _, row in xgb_table.iterrows():
        importance_records.append(
            row.to_dict()
        )

    selection_records.append({
        "outer_fold": outer_fold,
        "method": "xgboost_importance",
        "n_selected": len(xgb_selected),
        "selected_features":
            "|".join(xgb_selected)
    })

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "xgboost_feature_importance",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.6 RFE
    # ------------------------------------------------------------

    rfe_estimator = RandomForestClassifier(
        n_estimators=RFE_ESTIMATOR_TREES,
        random_state=RANDOM_STATE + outer_fold,
        n_jobs=-1,
        class_weight="balanced"
    )

    rfe = RFE(
        estimator=rfe_estimator,
        n_features_to_select=N_SELECTED_FEATURES,
        step=1
    )

    rfe.fit(
        X_train_scaled,
        y_train
    )

    rfe_selected = [
        feature
        for feature, selected
        in zip(
            feature_columns,
            rfe.support_
        )
        if selected
    ]

    for feature, ranking, selected in zip(
        feature_columns,
        rfe.ranking_,
        rfe.support_
    ):
        rfe_records.append({
            "outer_fold": outer_fold,
            "feature": feature,
            "ranking": ranking,
            "selected": bool(selected)
        })

    selection_records.append({
        "outer_fold": outer_fold,
        "method": "rfe",
        "n_selected": len(rfe_selected),
        "selected_features":
            "|".join(rfe_selected)
    })

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "rfe",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.7 BORUTA
    # ------------------------------------------------------------

    boruta_estimator = RandomForestClassifier(
        n_estimators=BORUTA_N_ESTIMATORS,
        random_state=RANDOM_STATE + outer_fold,
        n_jobs=-1,
        class_weight="balanced"
    )

    boruta = BorutaPy(
        estimator=boruta_estimator,
        n_estimators="auto",
        max_iter=BORUTA_MAX_ITER,
        random_state=RANDOM_STATE + outer_fold,
        verbose=0
    )

    boruta.fit(
        X_train_imp,
        y_train.to_numpy()
    )

    boruta_selected_all = [
        feature
        for feature, selected
        in zip(
            feature_columns,
            boruta.support_
        )
        if selected
    ]

    # If Boruta selects more than the frozen audit number,
    # retain the highest-ranking confirmed Boruta features.
    #
    # If fewer than N_SELECTED_FEATURES are confirmed,
    # retain all confirmed features.
    boruta_ranking_table = pd.DataFrame({
        "feature": feature_columns,
        "rank": boruta.ranking_,
        "confirmed": boruta.support_,
        "tentative": boruta.support_weak_
    })

    boruta_confirmed = (
        boruta_ranking_table[
            boruta_ranking_table["confirmed"]
        ]
        .sort_values(
            "rank",
            ascending=True
        )
        .head(N_SELECTED_FEATURES)
        ["feature"]
        .tolist()
    )

    for _, row in boruta_ranking_table.iterrows():
        boruta_records.append({
            "outer_fold": outer_fold,
            **row.to_dict()
        })

    selection_records.append({
        "outer_fold": outer_fold,
        "method": "boruta",
        "n_selected": len(boruta_confirmed),
        "selected_features":
            "|".join(boruta_confirmed)
    })

    leakage_records.append({
        "outer_fold": outer_fold,
        "operation": "boruta",
        "fit_data": "outer_training_only",
        "validation_used_for_fit": False,
        "calibration_used_for_fit": False,
        "test_used_for_fit": False
    })

    # ------------------------------------------------------------
    # 11.8 FEATURE-SELECTION CONSISTENCY
    # ------------------------------------------------------------

    method_sets = {
        "xgboost_importance":
            set(xgb_selected),

        "boruta":
            set(boruta_confirmed),

        "rfe":
            set(rfe_selected),

        "chi_square":
            set(chi_selected)
    }

    union_features = set().union(
        *method_sets.values()
    )

    intersection_features = set(
        xgb_selected
    )

    for selected_set in method_sets.values():
        intersection_features = (
            intersection_features
            .intersection(selected_set)
        )

    fold_feature_records.append({
        "outer_fold": outer_fold,
        "xgboost_features":
            "|".join(xgb_selected),
        "boruta_features":
            "|".join(boruta_confirmed),
        "rfe_features":
            "|".join(rfe_selected),
        "chi_square_features":
            "|".join(chi_selected),
        "union_n":
            len(union_features),
        "intersection_n":
            len(intersection_features),
        "intersection_features":
            "|".join(
                sorted(intersection_features)
            )
    })

    print(
        "\nSelected features:"
    )

    print(
        f"XGBoost      : {xgb_selected}"
    )

    print(
        f"Boruta       : {boruta_confirmed}"
    )

    print(
        f"RFE          : {rfe_selected}"
    )

    print(
        f"Chi-square   : {chi_selected}"
    )

    print(
        f"Union        : {len(union_features)}"
    )

    print(
        f"Intersection : "
        f"{len(intersection_features)}"
    )


# ================================================================
# 12. CONVERT RESULTS TO DATAFRAMES
# ================================================================

selection_df = pd.DataFrame(
    selection_records
)

fold_features_df = pd.DataFrame(
    fold_feature_records
)

leakage_df = pd.DataFrame(
    leakage_records
)

importance_df = pd.DataFrame(
    importance_records
)

rfe_df = pd.DataFrame(
    rfe_records
)

chi2_df = pd.DataFrame(
    chi2_records
)

boruta_df = pd.DataFrame(
    boruta_records
)


# ================================================================
# 13. FEATURE SELECTION FREQUENCY
# ================================================================

print("\n" + "=" * 70)
print("STEP 12: FEATURE-SELECTION STABILITY")
print("=" * 70)

frequency_records = []

methods = [
    "xgboost_importance",
    "boruta",
    "rfe",
    "chi_square"
]

for method in methods:

    method_df = selection_df[
        selection_df["method"] == method
    ]

    counts = {}

    for feature_string in (
        method_df["selected_features"]
    ):

        features = feature_string.split("|")

        for feature in features:

            if feature:
                counts[feature] = (
                    counts.get(feature, 0) + 1
                )

    for feature in feature_columns:

        frequency_records.append({
            "method": method,
            "feature": feature,
            "folds_selected":
                counts.get(feature, 0),
            "selection_frequency":
                counts.get(feature, 0)
                / N_OUTER_SPLITS
        })


frequency_df = pd.DataFrame(
    frequency_records
)


# ================================================================
# 14. OVERALL FEATURE FREQUENCY
# ================================================================

overall_frequency = (
    frequency_df
    .groupby("feature")[
        "selection_frequency"
    ]
    .mean()
    .reset_index()
    .rename(
        columns={
            "selection_frequency":
                "mean_selection_frequency"
        }
    )
    .sort_values(
        "mean_selection_frequency",
        ascending=False
    )
)

print(
    "\nMean selection frequency across methods:"
)

print(
    overall_frequency.to_string(
        index=False
    )
)


# ================================================================
# 15. LEAKAGE ASSERTION
# ================================================================

print("\n" + "=" * 70)
print("STEP 13: LEAKAGE ASSERTION")
print("=" * 70)

if not (
    leakage_df[
        "validation_used_for_fit"
    ] == False
).all():

    raise RuntimeError(
        "Validation data were marked as used "
        "during fitting."
    )

if not (
    leakage_df[
        "calibration_used_for_fit"
    ] == False
).all():

    raise RuntimeError(
        "Calibration data were marked as used "
        "during fitting."
    )

if not (
    leakage_df[
        "test_used_for_fit"
    ] == False
).all():

    raise RuntimeError(
        "Test data were marked as used "
        "during fitting."
    )

print(
    "PASS: No validation data used for fitting."
)

print(
    "PASS: No calibration data used for fitting."
)

print(
    "PASS: No locked-test data used for fitting."
)

print(
    "PASS: All supervised feature-selection operations "
    "were fitted on outer-training data only."
)


# ================================================================
# 16. SAVE OUTPUTS
# ================================================================

print("\n" + "=" * 70)
print("STEP 14: SAVING AUDIT OUTPUTS")
print("=" * 70)

files = {
    "audit16_feature_selection_by_fold.csv":
        selection_df,

    "audit16_feature_selection_stability.csv":
        frequency_df,

    "audit16_feature_selection_fold_summary.csv":
        fold_features_df,

    "audit16_xgboost_importance.csv":
        importance_df,

    "audit16_rfe_results.csv":
        rfe_df,

    "audit16_chi_square_results.csv":
        chi2_df,

    "audit16_boruta_results.csv":
        boruta_df,

    "audit16_leakage_records.csv":
        leakage_df,

    "audit16_overall_feature_frequency.csv":
        overall_frequency
}

for filename, output_df in files.items():

    output_path = (
        RESULTS_DIR
        / filename
    )

    output_df.to_csv(
        output_path,
        index=False
    )

    print(
        output_path
    )


# ================================================================
# 17. FINAL SUMMARY
# ================================================================

print("\n" + "=" * 70)
print("AUDIT 16 COMPLETE")
print("=" * 70)

print("\nFrozen checks")
print("-" * 70)

print(
    "✓ Development/CV data only"
)

print(
    "✓ Calibration data excluded"
)

print(
    "✓ Locked test data excluded"
)

print(
    "✓ 5 outer folds"
)

print(
    "✓ Fold-specific imputation"
)

print(
    "✓ Fold-specific standardization"
)

print(
    "✓ Fold-specific chi-square selection"
)

print(
    "✓ Fold-specific XGBoost importance"
)

print(
    "✓ Fold-specific RFE"
)

print(
    "✓ Fold-specific Boruta"
)

print(
    "✓ Feature-selection stability recorded"
)

print(
    "✓ No ADASYN performed"
)

print(
    "✓ No final model trained"
)

print(
    "✓ No conformal calibration performed"
)

print(
    "✓ No locked-test evaluation performed"
)

print("\nIMPORTANT:")
print(
    "The selected features from this audit are NOT yet "
    "frozen as the final feature subset."
)

print(
    "Feature count and selection strategy should be "
    "decided after reviewing the stability results "
    "and predictive ablations."
)

print("\n" + "=" * 70)