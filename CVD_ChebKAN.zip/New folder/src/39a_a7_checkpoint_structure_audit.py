from pathlib import Path
import torch


PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

MODEL_FILE = (
    PROJECT_ROOT
    / "results"
    / "models"
    / "implementation32_a7_final_model.pt"
)


print("=" * 100)
print("IMPLEMENTATION 39a")
print("A7 CHECKPOINT STRUCTURE AUDIT")
print("=" * 100)

print("\nCheckpoint:")
print(MODEL_FILE)

checkpoint = torch.load(
    MODEL_FILE,
    map_location="cpu",
    weights_only=False
)

print("\nCheckpoint object type:")
print(type(checkpoint))

if isinstance(checkpoint, dict):

    print("\nCheckpoint top-level keys:")

    for key in checkpoint.keys():
        print(
            f"  {key}"
        )

    if "model_state_dict" in checkpoint:

        state_dict = checkpoint[
            "model_state_dict"
        ]

    elif "state_dict" in checkpoint:

        state_dict = checkpoint[
            "state_dict"
        ]

    else:

        # Determine whether this is already
        # a state dictionary.
        state_dict = checkpoint

else:

    raise RuntimeError(
        "Checkpoint is not a dictionary."
    )


print("\n" + "=" * 100)
print("STATE DICT KEYS AND SHAPES")
print("=" * 100)

for key, value in state_dict.items():

    if hasattr(value, "shape"):

        print(
            f"{key:55s} "
            f"{tuple(value.shape)}"
        )

    else:

        print(
            f"{key:55s} "
            f"{type(value)}"
        )


print("\n" + "=" * 100)
print("PARAMETER COUNT")
print("=" * 100)

parameter_count = 0

for value in state_dict.values():

    if hasattr(value, "numel"):

        parameter_count += value.numel()

print(
    f"Total checkpoint parameters: "
    f"{parameter_count:,}"
)

print("\n" + "=" * 100)
print("IMPLEMENTATION 39a COMPLETE")
print("=" * 100)