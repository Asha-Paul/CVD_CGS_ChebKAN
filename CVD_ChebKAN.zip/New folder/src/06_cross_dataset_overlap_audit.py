# =============================================================================
# CVD CGS-ChebKAN
# AUDIT 06 — CROSS-DATASET OVERLAP / DUPLICATE AUDIT
# =============================================================================

from pathlib import Path
import zipfile
import pandas as pd
import numpy as np

# -------------------------------------------------------------------------
# Paths
# -------------------------------------------------------------------------
PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

KAGGLE_FILE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

UCI_FILES = {
    "Cleveland": "processed.cleveland.data",
    "Hungarian": "processed.hungarian.data",
    "Switzerland": "processed.switzerland.data",
    "VA_Long_Beach": "processed.va.data",
}

UCI_COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target",
]

# -------------------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------------------

def normalize_sex_kaggle(x):
    """
    Kaggle:
        gender = 1 or 2

    UCI:
        sex = 0 or 1

    We map both to:
        0 = female
        1 = male
    """
    if pd.isna(x):
        return np.nan

    x = int(x)

    if x == 1:
        return 0
    elif x == 2:
        return 1

    return np.nan


def normalize_sex_uci(x):
    """
    UCI sex:
        0 = female
        1 = male
    """
    if pd.isna(x):
        return np.nan

    x = int(x)

    if x in [0, 1]:
        return x

    return np.nan


def age_kaggle_years(age_days):
    return age_days / 365.25


def create_age_bins(age_years):
    """
    Broad age bins used ONLY for overlap auditing.
    These are not modeling features.
    """
    if pd.isna(age_years):
        return np.nan

    return int(round(age_years))


def load_uci_from_zip(zip_path, filename):
    with zipfile.ZipFile(zip_path, "r") as z:
        with z.open(filename) as f:
            df = pd.read_csv(
                f,
                header=None,
                names=UCI_COLUMNS,
                na_values=["?"],
            )

    return df


# -------------------------------------------------------------------------
# Start
# -------------------------------------------------------------------------

print("=" * 78)
print("CVD CGS-ChebKAN — AUDIT 06")
print("CROSS-DATASET OVERLAP / DUPLICATE AUDIT")
print("=" * 78)

# -------------------------------------------------------------------------
# 1. Load Kaggle
# -------------------------------------------------------------------------

print("\n" + "=" * 78)
print("1. LOADING KAGGLE")
print("=" * 78)

kaggle = pd.read_csv(KAGGLE_FILE, sep=",")

print(f"Rows: {len(kaggle):,}")
print(f"Columns: {len(kaggle.columns)}")

# Minimal harmonization ONLY for overlap auditing
kaggle_overlap = pd.DataFrame()

kaggle_overlap["age_years"] = age_kaggle_years(kaggle["age"])
kaggle_overlap["age_round"] = kaggle_overlap["age_years"].round().astype(int)

kaggle_overlap["sex"] = kaggle["gender"].apply(normalize_sex_kaggle)

kaggle_overlap["age_sex_key"] = (
    kaggle_overlap["age_round"].astype(str)
    + "_"
    + kaggle_overlap["sex"].astype(str)
)

print("\nKaggle age range:")
print(
    f"  {kaggle_overlap['age_years'].min():.2f} "
    f"to "
    f"{kaggle_overlap['age_years'].max():.2f} years"
)

print("Kaggle normalized sex:")
print(kaggle_overlap["sex"].value_counts(dropna=False).sort_index())


# -------------------------------------------------------------------------
# 2. Check duplicate age-sex combinations inside Kaggle
# -------------------------------------------------------------------------

print("\n" + "=" * 78)
print("2. KAGGLE AGE-SEX DUPLICATE STRUCTURE")
print("=" * 78)

kaggle_key_counts = (
    kaggle_overlap
    .groupby(["age_round", "sex"], dropna=False)
    .size()
    .reset_index(name="count")
)

print(
    f"Unique age-sex combinations: "
    f"{len(kaggle_key_counts):,}"
)

print(
    f"Age-sex combinations occurring >1 time: "
    f"{(kaggle_key_counts['count'] > 1).sum():,}"
)

print(
    f"Maximum records sharing one age-sex combination: "
    f"{kaggle_key_counts['count'].max():,}"
)


# -------------------------------------------------------------------------
# 3. Load UCI cohorts
# -------------------------------------------------------------------------

uci_data = {}

print("\n" + "=" * 78)
print("3. LOADING UCI COHORTS")
print("=" * 78)

for cohort, filename in UCI_FILES.items():

    df = load_uci_from_zip(UCI_ZIP, filename)

    uci_data[cohort] = df

    print(f"{cohort:20s}: {len(df):4d} rows")


# -------------------------------------------------------------------------
# 4. Create minimal UCI overlap keys
# -------------------------------------------------------------------------

print("\n" + "=" * 78)
print("4. CREATING MINIMAL AGE-SEX OVERLAP KEYS")
print("=" * 78)

uci_overlap = {}

for cohort, df in uci_data.items():

    temp = pd.DataFrame()

    temp["age_years"] = pd.to_numeric(df["age"], errors="coerce")
    temp["age_round"] = temp["age_years"].round().astype("Int64")

    temp["sex"] = df["sex"].apply(normalize_sex_uci)

    temp["age_sex_key"] = (
        temp["age_round"].astype(str)
        + "_"
        + temp["sex"].astype(str)
    )

    uci_overlap[cohort] = temp

    print(
        f"{cohort:20s}: "
        f"{temp['age_sex_key'].nunique(dropna=True):4d} "
        f"unique age-sex keys"
    )


# -------------------------------------------------------------------------
# 5. Cross-dataset age-sex intersection
# -------------------------------------------------------------------------

print("\n" + "=" * 78)
print("5. CROSS-DATASET AGE-SEX INTERSECTION")
print("=" * 78)

kaggle_keys = set(
    kaggle_overlap["age_sex_key"]
    .dropna()
    .unique()
)

for cohort, temp in uci_overlap.items():

    uci_keys = set(
        temp["age_sex_key"]
        .dropna()
        .unique()
    )

    intersection = kaggle_keys.intersection(uci_keys)

    print(f"\n{cohort}")
    print("-" * 50)
    print(f"Kaggle unique age-sex keys : {len(kaggle_keys):,}")
    print(f"UCI unique age-sex keys    : {len(uci_keys):,}")
    print(f"Intersection               : {len(intersection):,}")

    if len(intersection) > 0:
        print("WARNING: Age-sex key overlap exists.")
    else:
        print("No exact rounded age-sex key overlap.")


# -------------------------------------------------------------------------
# 6. More stringent overlap audit
# -------------------------------------------------------------------------
# We now use:
#
#   age (rounded year)
#   sex
#   systolic BP
#   cholesterol category
#   glucose category
#
# This is still an AUDIT KEY only.
# It is NOT used as a model feature.

print("\n" + "=" * 78)
print("6. STRINGENT CROSS-DATASET OVERLAP AUDIT")
print("=" * 78)

# Kaggle harmonization

kaggle_key = pd.DataFrame()

kaggle_key["age"] = (
    kaggle["age"] / 365.25
).round().astype(int)

kaggle_key["sex"] = kaggle["gender"].apply(
    normalize_sex_kaggle
)

kaggle_key["sbp"] = kaggle["ap_hi"]

kaggle_key["chol_cat"] = kaggle["cholesterol"]

# Practical glucose harmonization for overlap audit
# 1 -> 0
# 2/3 -> 1
kaggle_key["glucose_high"] = np.where(
    kaggle["gluc"] == 1,
    0,
    1
)

kaggle_key["strict_key"] = (
    kaggle_key["age"].astype(str)
    + "_"
    + kaggle_key["sex"].astype(str)
    + "_"
    + kaggle_key["sbp"].astype(str)
    + "_"
    + kaggle_key["chol_cat"].astype(str)
    + "_"
    + kaggle_key["glucose_high"].astype(str)
)

kaggle_strict_keys = set(
    kaggle_key["strict_key"].dropna().unique()
)


# -------------------------------------------------------------------------
# UCI strict keys
# -------------------------------------------------------------------------

for cohort, df in uci_data.items():

    temp = pd.DataFrame()

    temp["age"] = pd.to_numeric(
        df["age"],
        errors="coerce"
    ).round()

    temp["sex"] = df["sex"].apply(
        normalize_sex_uci
    )

    temp["sbp"] = pd.to_numeric(
        df["trestbps"],
        errors="coerce"
    )

    # UCI cholesterol category:
    #
    # <200       -> 1
    # 200-239    -> 2
    # >=240      -> 3
    #
    # This is ONLY the frozen harmonization rule.

    chol = pd.to_numeric(
        df["chol"],
        errors="coerce"
    )

    temp["chol_cat"] = np.select(
        [
            chol < 200,
            (chol >= 200) & (chol < 240),
            chol >= 240,
        ],
        [
            1,
            2,
            3,
        ],
        default=np.nan,
    )

    # UCI fbs:
    # 0 = <=120
    # 1 = >120
    temp["glucose_high"] = pd.to_numeric(
        df["fbs"],
        errors="coerce"
    )

    # Only complete keys
    complete = temp[
        [
            "age",
            "sex",
            "sbp",
            "chol_cat",
            "glucose_high",
        ]
    ].notna().all(axis=1)

    temp_complete = temp.loc[complete].copy()

    temp_complete["age"] = (
        temp_complete["age"]
        .astype(int)
    )

    temp_complete["sbp"] = (
        temp_complete["sbp"]
        .astype(int)
    )

    temp_complete["chol_cat"] = (
        temp_complete["chol_cat"]
        .astype(int)
    )

    temp_complete["glucose_high"] = (
        temp_complete["glucose_high"]
        .astype(int)
    )

    temp_complete["strict_key"] = (
        temp_complete["age"].astype(str)
        + "_"
        + temp_complete["sex"].astype(str)
        + "_"
        + temp_complete["sbp"].astype(str)
        + "_"
        + temp_complete["chol_cat"].astype(str)
        + "_"
        + temp_complete["glucose_high"].astype(str)
    )

    uci_strict_keys = set(
        temp_complete["strict_key"].unique()
    )

    intersection = (
        kaggle_strict_keys.intersection(
            uci_strict_keys
        )
    )

    print(f"\n{cohort}")
    print("-" * 50)
    print(
        f"Complete UCI strict records : "
        f"{len(temp_complete):,}"
    )
    print(
        f"Unique UCI strict keys       : "
        f"{len(uci_strict_keys):,}"
    )
    print(
        f"Strict-key intersection      : "
        f"{len(intersection):,}"
    )

    if len(intersection) > 0:
        print(
            "NOTE: matching feature signatures exist. "
            "This does NOT prove the same patients."
        )
    else:
        print(
            "No strict feature-signature overlap."
        )


# -------------------------------------------------------------------------
# 7. Duplicate records within UCI
# -------------------------------------------------------------------------

print("\n" + "=" * 78)
print("7. DUPLICATE RECORD AUDIT WITHIN UCI COHORTS")
print("=" * 78)

for cohort, df in uci_data.items():

    exact_duplicates = df.duplicated().sum()

    print(
        f"{cohort:20s}: "
        f"{exact_duplicates:4d} exact duplicate rows"
    )


# -------------------------------------------------------------------------
# 8. Save audit results
# -------------------------------------------------------------------------

RESULTS_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

summary_file = (
    RESULTS_DIR
    / "audit_06_overlap_summary.txt"
)

with open(summary_file, "w", encoding="utf-8") as f:

    f.write(
        "CVD CGS-ChebKAN — AUDIT 06\n"
        "Cross-Dataset Overlap / Duplicate Audit\n"
    )

    f.write(
        "\nKaggle rows: "
        f"{len(kaggle):,}\n"
    )

    f.write(
        "\nUCI cohort sizes:\n"
    )

    for cohort, df in uci_data.items():
        f.write(
            f"{cohort}: {len(df):,}\n"
        )

    f.write(
        "\nThis audit uses minimal age/sex "
        "alignment and a stricter harmonized "
        "feature-signature check.\n"
    )

    f.write(
        "\nA matching key does NOT establish "
        "patient identity.\n"
    )

print("\n" + "=" * 78)
print("AUDIT 06 COMPLETED")
print("=" * 78)

print(f"\nSummary saved to:")
print(summary_file)