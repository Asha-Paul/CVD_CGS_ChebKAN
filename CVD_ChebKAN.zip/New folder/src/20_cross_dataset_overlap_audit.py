# ================================================================
# AUDIT 20
# CGS-ChebKAN ARCHITECTURE SPECIFICATION AUDIT
# ================================================================
#
# Purpose:
#   Freeze and validate the proposed:
#
#   Clinically-Grouped Sparse Chebyshev-KAN (CGS-ChebKAN)
#
#   architecture before implementation/training.
#
# IMPORTANT:
#   This script is SPECIFICATION ONLY.
#   It does NOT train a model.
#   It does NOT modify datasets.
#   It does NOT perform feature selection.
#   It does NOT perform conformal calibration.
#
# ================================================================

from pathlib import Path
from datetime import datetime
import json
import sys


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = DATA_DIR / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR = RESULTS_DIR / "figures"
CHECKPOINT_DIR = RESULTS_DIR / "checkpoints"
LOG_DIR = PROJECT_ROOT / "logs"


# ================================================================
# 2. CREATE REQUIRED DIRECTORIES
# ================================================================

for directory in [
    PROCESSED_DIR,
    RESULTS_DIR,
    TABLES_DIR,
    FIGURES_DIR,
    CHECKPOINT_DIR,
    LOG_DIR,
]:
    directory.mkdir(parents=True, exist_ok=True)


# ================================================================
# 3. AUDIT HEADER
# ================================================================

print("=" * 72)
print("AUDIT 20")
print("CGS-ChebKAN ARCHITECTURE SPECIFICATION AUDIT")
print("=" * 72)

print()
print("Project root:")
print(PROJECT_ROOT)

print()
print("Audit timestamp:")
print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

print()


# ================================================================
# 4. FROZEN DATA PARTITIONS
# ================================================================

PARTITIONS = {
    "development_cv": {
        "file": PROCESSED_DIR / "kaggle_development_cv.csv",
        "n": 49000,
    },
    "conformal_calibration": {
        "file": PROCESSED_DIR / "kaggle_conformal_calibration.csv",
        "n": 7000,
    },
    "locked_test": {
        "file": PROCESSED_DIR / "kaggle_locked_test.csv",
        "n": 14000,
    },
}


print("1. DATA PARTITIONS")
print("-" * 72)

partition_errors = []

for name, info in PARTITIONS.items():

    file_path = info["file"]

    print(f"{name}:")
    print(f"  File: {file_path}")
    print(f"  Expected rows: {info['n']}")

    if not file_path.exists():
        partition_errors.append(
            f"Missing partition file: {file_path}"
        )
        print("  STATUS: MISSING")
    else:
        print("  STATUS: EXISTS")

print()


# ================================================================
# 5. FROZEN INPUT FEATURES
# ================================================================

INPUT_FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"


print("2. INPUT FEATURE SPECIFICATION")
print("-" * 72)

print("Number of predictor variables:")
print(len(INPUT_FEATURES))

print()
print("Predictors:")

for i, feature in enumerate(INPUT_FEATURES, start=1):
    print(f"  {i:02d}. {feature}")

print()
print("Target:")
print(f"  {TARGET}")

print()


# ================================================================
# 6. VALIDATE FEATURE LIST
# ================================================================

print("3. FEATURE LIST VALIDATION")
print("-" * 72)

feature_errors = []

if len(INPUT_FEATURES) != 11:
    feature_errors.append(
        f"Expected 11 predictors, found {len(INPUT_FEATURES)}"
    )

if len(set(INPUT_FEATURES)) != len(INPUT_FEATURES):
    feature_errors.append(
        "Duplicate predictor names detected."
    )

if TARGET in INPUT_FEATURES:
    feature_errors.append(
        "Target variable is incorrectly included among predictors."
    )

if feature_errors:
    for error in feature_errors:
        print("ERROR:", error)
else:
    print("Feature specification: PASS")

print()


# ================================================================
# 7. CLINICAL GROUP DEFINITIONS
# ================================================================

CLINICAL_GROUPS = {
    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


print("4. CLINICAL GROUPING")
print("-" * 72)

for group_name, features in CLINICAL_GROUPS.items():

    print()
    print(group_name.upper())
    print("  Features:")

    for feature in features:
        print(f"    - {feature}")

print()


# ================================================================
# 8. GROUP VALIDATION
# ================================================================

print("5. CLINICAL GROUP VALIDATION")
print("-" * 72)

group_errors = []

if len(CLINICAL_GROUPS) != 3:
    group_errors.append(
        f"Expected exactly 3 clinical groups, found {len(CLINICAL_GROUPS)}"
    )

all_group_features = []

for group_name, features in CLINICAL_GROUPS.items():
    all_group_features.extend(features)

if len(all_group_features) != len(INPUT_FEATURES):
    group_errors.append(
        "Total number of group assignments does not match "
        "the number of predictors."
    )

if len(set(all_group_features)) != len(all_group_features):
    group_errors.append(
        "A predictor is assigned to more than one clinical group."
    )

missing_from_groups = set(INPUT_FEATURES) - set(all_group_features)

extra_in_groups = set(all_group_features) - set(INPUT_FEATURES)

if missing_from_groups:
    group_errors.append(
        f"Predictors missing from clinical groups: "
        f"{sorted(missing_from_groups)}"
    )

if extra_in_groups:
    group_errors.append(
        f"Unknown predictors in clinical groups: "
        f"{sorted(extra_in_groups)}"
    )

if group_errors:

    for error in group_errors:
        print("ERROR:", error)

else:

    print("Clinical grouping: PASS")

    print()
    print("Every predictor is assigned exactly once.")

print()


# ================================================================
# 9. CLINICAL GROUP SUMMARY
# ================================================================

print("6. GROUP SUMMARY")
print("-" * 72)

for group_name, features in CLINICAL_GROUPS.items():

    print(
        f"{group_name}: "
        f"{len(features)} features"
    )

print()


# ================================================================
# 10. CHEBYSHEV-KAN BASIS
# ================================================================

CHEBKAN_CONFIG = {

    "basis": "Chebyshev_first_kind",

    "polynomial_order": 5,

    "normalization_range": [-1.0, 1.0],

    "basis_definition":
        "T_k(x) = cos(k arccos(x))",

    "feature_function":
        "phi_i(x_i) = sum_k a_ik T_k(x_i)",

    "coefficient_regularization":
        "L1",

    "coefficient_penalty":
        "sum_i sum_k |a_ik|",
}


print("7. CHEBYSHEV-KAN BASIS")
print("-" * 72)

print("Basis:")
print(f"  {CHEBKAN_CONFIG['basis']}")

print("Polynomial order:")
print(f"  K = {CHEBKAN_CONFIG['polynomial_order']}")

print("Normalization:")
print(
    f"  [{CHEBKAN_CONFIG['normalization_range'][0]}, "
    f"{CHEBKAN_CONFIG['normalization_range'][1]}]"
)

print("Basis:")
print(f"  {CHEBKAN_CONFIG['basis_definition']}")

print("Univariate feature function:")
print(f"  {CHEBKAN_CONFIG['feature_function']}")

print()


# ================================================================
# 11. BASIS VALIDATION
# ================================================================

print("8. CHEBYSHEV BASIS VALIDATION")
print("-" * 72)

basis_errors = []

if CHEBKAN_CONFIG["basis"] != "Chebyshev_first_kind":
    basis_errors.append(
        "Incorrect Chebyshev basis specification."
    )

if CHEBKAN_CONFIG["polynomial_order"] != 5:
    basis_errors.append(
        "Polynomial order must be K=5."
    )

if CHEBKAN_CONFIG["normalization_range"] != [-1.0, 1.0]:
    basis_errors.append(
        "Input normalization range must be [-1, 1]."
    )

if basis_errors:

    for error in basis_errors:
        print("ERROR:", error)

else:

    print("Chebyshev basis specification: PASS")

print()


# ================================================================
# 12. CLINICALLY-GROUPED BRANCH ARCHITECTURE
# ================================================================

GROUP_BRANCH_CONFIG = {

    "number_of_branches": 3,

    "branch_type":
        "group-specific Chebyshev-KAN branch",

    "group_embedding_dimension": 16,

    "group_activation": "SiLU",

    "feature_processing":
        "Each input feature is represented using a "
        "learnable univariate Chebyshev expansion.",

    "group_aggregation":
        "Feature-level Chebyshev representations are "
        "aggregated within each clinical group.",

    "group_projection":
        "Linear projection to a 16-dimensional group embedding.",
}


print("9. CLINICALLY-GROUPED CHEBKAN BRANCHES")
print("-" * 72)

for key, value in GROUP_BRANCH_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 13. BRANCH VALIDATION
# ================================================================

print("10. BRANCH ARCHITECTURE VALIDATION")
print("-" * 72)

branch_errors = []

if GROUP_BRANCH_CONFIG["number_of_branches"] != 3:
    branch_errors.append(
        "Expected exactly 3 group-specific branches."
    )

if GROUP_BRANCH_CONFIG["group_embedding_dimension"] != 16:
    branch_errors.append(
        "Group embedding dimension must be 16."
    )

if GROUP_BRANCH_CONFIG["group_activation"] != "SiLU":
    branch_errors.append(
        "Group activation must be SiLU."
    )

if branch_errors:

    for error in branch_errors:
        print("ERROR:", error)

else:

    print("Clinically grouped branch architecture: PASS")

print()


# ================================================================
# 14. MISSING-VALUE HANDLING
# ================================================================

MISSING_VALUE_CONFIG = {

    "strategy":
        "fold-specific training-data-fitted median imputation",

    "missing_value_rule":
        "Fit imputation statistics only on the active training fold; "
        "apply the fitted statistics to the corresponding validation "
        "fold without refitting.",

    "development_cv":
        "Allowed inside each training fold only",

    "conformal_calibration":
        "Protected from model-selection preprocessing fitting",

    "locked_test":
        "Protected from preprocessing fitting",

    "data_deletion":
        "No automatic row deletion due to missing predictor values",

    "adasyn":
        "Not used in primary pipeline",
}


print("11. MISSING-VALUE HANDLING")
print("-" * 72)

print("Strategy:")
print(
    f"  {MISSING_VALUE_CONFIG['strategy']}"
)

print("Rule:")
print(
    f"  {MISSING_VALUE_CONFIG['missing_value_rule']}"
)

print("Development/CV:")
print(
    f"  {MISSING_VALUE_CONFIG['development_cv']}"
)

print("Conformal calibration:")
print(
    f"  {MISSING_VALUE_CONFIG['conformal_calibration']}"
)

print("Locked test:")
print(
    f"  {MISSING_VALUE_CONFIG['locked_test']}"
)

print("Row deletion:")
print(
    f"  {MISSING_VALUE_CONFIG['data_deletion']}"
)

print("ADASYN:")
print(
    f"  {MISSING_VALUE_CONFIG['adasyn']}"
)

print()


# ================================================================
# 15. MISSING-VALUE VALIDATION
# ================================================================

print("12. MISSING-VALUE RULE VALIDATION")
print("-" * 72)

missing_errors = []

# Normalize hyphens so that both
# "training-fold" and "training fold"
# are accepted as the same methodological statement.

missing_rule = (
    MISSING_VALUE_CONFIG[
        "missing_value_rule"
    ]
    .lower()
    .replace("-", " ")
)

if (
    "training fold" not in missing_rule
    or
    "only" not in missing_rule
):
    missing_errors.append(
        "Missing-value rule is not explicitly "
        "training-fold-specific."
    )

if "without refitting" not in missing_rule:
    missing_errors.append(
        "Validation-fold application without refitting "
        "is not explicitly specified."
    )

if MISSING_VALUE_CONFIG["adasyn"].lower() != (
    "not used in primary pipeline"
):
    missing_errors.append(
        "ADASYN status is inconsistent with the frozen methodology."
    )

if missing_errors:

    for error in missing_errors:
        print("ERROR:", error)

else:

    print("Missing-value handling specification: PASS")

print()


# ================================================================
# 16. SPARSE GATED GROUP FUSION
# ================================================================

GATE_CONFIG = {

    "fusion_type":
        "sparse gated group fusion",

    "number_of_group_gates":
        3,

    "gate_parameterization":
        "learnable scalar group gates",

    "normalization":
        "softmax",

    "constraint":
        "nonnegative gates summing to one",

    "equation":
        "alpha_g = exp(q_g) / sum_j exp(q_j)",

    "fusion":
        "h = sum_g alpha_g h_g",

    "gate_regularization":
        "L1 penalty on pre-normalized group gate parameters q_g",

    "gate_penalty":
        "sum_g |q_g|",
}


print("13. SPARSE GATED GROUP FUSION")
print("-" * 72)

for key, value in GATE_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 17. GATE VALIDATION
# ================================================================

print("14. GATE VALIDATION")
print("-" * 72)

gate_errors = []

if GATE_CONFIG["number_of_group_gates"] != 3:
    gate_errors.append(
        "There must be three group gates."
    )

if GATE_CONFIG["normalization"] != "softmax":
    gate_errors.append(
        "Gate normalization must be softmax."
    )

if "nonnegative" not in GATE_CONFIG["constraint"].lower():
    gate_errors.append(
        "Gate constraint must specify nonnegative gates."
    )

if "sum" not in GATE_CONFIG["constraint"].lower():
    gate_errors.append(
        "Gate constraint must specify sum-to-one normalization."
    )

if gate_errors:

    for error in gate_errors:
        print("ERROR:", error)

else:

    print("Sparse gated group fusion specification: PASS")

print()


# ================================================================
# 18. KAN SPARSITY REGULARIZATION
# ================================================================

SPARSITY_CONFIG = {

    "regularizer":
        "L1",

    "target":
        "Chebyshev coefficients",

    "equation":
        "L_KAN_L1 = sum_i sum_k |a_ik|",

    "purpose":
        "Encourage sparse/unnecessary basis coefficients "
        "to approach zero.",

    "group_gate_regularization":
        "L1 on pre-normalized group gate parameters q_g",
}


print("15. KAN SPARSITY REGULARIZATION")
print("-" * 72)

for key, value in SPARSITY_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 19. LOSS FUNCTION
# ================================================================

LOSS_CONFIG = {

    "classification_loss":
        "Binary Cross-Entropy",

    "kan_regularization":
        "lambda_KAN * L_KAN_L1",

    "gate_regularization":
        "lambda_gate * L_gate_L1",

    "total_loss":
        "L = L_BCE + lambda_KAN L_KAN_L1 "
        "+ lambda_gate L_gate_L1",

    "lambda_KAN":
        "selected using inner CV on Development data",

    "lambda_gate":
        "selected using inner CV on Development data",
}


print("16. TOTAL TRAINING OBJECTIVE")
print("-" * 72)

for key, value in LOSS_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 20. OUTPUT HEAD
# ================================================================

OUTPUT_CONFIG = {

    "task":
        "binary cardiovascular disease classification",

    "fusion_representation":
        "fused 16-dimensional group representation",

    "prediction_head":
        "binary classification head",

    "activation":
        "sigmoid",

    "output":
        "P(cardio=1 | X)",
}


print("17. OUTPUT HEAD")
print("-" * 72)

for key, value in OUTPUT_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 21. PRIMARY FEATURE STRATEGY
# ================================================================

FEATURE_STRATEGY = {

    "primary":
        "FULL_11_FEATURE_REPRESENTATION",

    "secondary":
        "FEATURE_SELECTION_AS_ABLATION",

    "feature_selection_methods": [
        "XGBoost importance",
        "Boruta",
        "RFE",
        "Chi-square",
    ],

    "feature_selection_scope":
        "performed independently inside training folds",

    "global_feature_freezing":
        False,

    "reason":
        "Feature-selection stability did not justify "
        "freezing a reduced primary feature set.",
}


print("18. FEATURE STRATEGY")
print("-" * 72)

for key, value in FEATURE_STRATEGY.items():

    print(f"{key}:")

    if isinstance(value, list):

        for item in value:
            print(f"  - {item}")

    else:

        print(f"  {value}")

print()


# ================================================================
# 22. ADASYN POLICY
# ================================================================

ADASYN_CONFIG = {

    "primary_pipeline":
        False,

    "reason":
        "The Kaggle development partition is essentially "
        "class balanced.",

    "sensitivity_analysis":
        True,

    "application_scope_if_used":
        "training folds only",

    "validation_modification":
        False,

    "calibration_modification":
        False,

    "test_modification":
        False,
}


print("19. ADASYN POLICY")
print("-" * 72)

for key, value in ADASYN_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 23. CROSS-VALIDATION DESIGN
# ================================================================

CV_CONFIG = {

    "outer_folds":
        5,

    "inner_folds":
        4,

    "stratified":
        True,

    "random_state":
        2026,

    "outer_role":
        "unbiased model-performance estimation during development",

    "inner_role":
        "hyperparameter and model-selection",

    "calibration_in_cv":
        False,

    "locked_test_in_cv":
        False,
}


print("20. NESTED CROSS-VALIDATION")
print("-" * 72)

for key, value in CV_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 24. LEAKAGE CONTROL
# ================================================================

LEAKAGE_CONFIG = {

    "scaling":
        "training fold only",

    "imputation":
        "training fold only",

    "feature_selection":
        "training fold only",

    "hyperparameter_selection":
        "inner CV only",

    "adasyn":
        "training fold only if used in sensitivity analysis",

    "conformal_calibration":
        "dedicated 7,000-record calibration set",

    "locked_test":
        "never used for model selection or calibration",

    "external_uci":
        "not used for Kaggle model training or selection",
}


print("21. LEAKAGE CONTROL")
print("-" * 72)

for key, value in LEAKAGE_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 25. ABLATION MATRIX
# ================================================================

ABLATION_MATRIX = {

    "A0":
        "MLP baseline",

    "A1":
        "Vanilla B-spline KAN",

    "A2":
        "Vanilla Chebyshev-KAN",

    "A3":
        "Alternative-basis KAN",

    "A4":
        "Flat Chebyshev-KAN",

    "A5":
        "Clinically-grouped Chebyshev-KAN",

    "A6":
        "Sparse clinically-grouped Chebyshev-KAN",

    "A7":
        "Sparse clinically-grouped Chebyshev-KAN + conformal prediction",
}


print("22. ABLATION MATRIX")
print("-" * 72)

for ablation_id, description in ABLATION_MATRIX.items():

    print(f"{ablation_id}: {description}")

print()


# ================================================================
# 26. BASELINE MODELS
# ================================================================

BASELINES = [

    "Logistic Regression",

    "Random Forest",

    "XGBoost",

    "MLP",

    "Vanilla B-spline KAN",

    "Vanilla Chebyshev-KAN",

    "Alternative-basis KAN",

    "Previous TabNet + AutoEncoder-Transformer + ResMLP",
]


print("23. BASELINE MODELS")
print("-" * 72)

for i, model in enumerate(BASELINES, start=1):

    print(f"{i:02d}. {model}")

print()


# ================================================================
# 27. BASIS COMPARISON
# ================================================================

BASIS_COMPARISON = {

    "B-spline":
        "Vanilla KAN basis",

    "Chebyshev":
        "Proposed polynomial basis",

    "Alternative":
        "Fourier or another appropriate KAN basis",
}


print("24. KAN BASIS COMPARISON")
print("-" * 72)

for basis, description in BASIS_COMPARISON.items():

    print(f"{basis}:")
    print(f"  {description}")

print()


# ================================================================
# 28. PERFORMANCE METRICS
# ================================================================

METRICS = [

    "Accuracy",

    "Precision",

    "Recall / Sensitivity",

    "Specificity",

    "F1-score",

    "ROC-AUC",

    "PR-AUC",

    "Brier score",

    "Expected Calibration Error (ECE)",
]


print("25. CLASSIFICATION METRICS")
print("-" * 72)

for metric in METRICS:

    print(f"- {metric}")

print()


# ================================================================
# 29. CONFORMAL PREDICTION
# ================================================================

CONFORMAL_CONFIG = {

    "enabled":
        True,

    "calibration_set_size":
        7000,

    "calibration_source":
        "Dedicated Kaggle conformal calibration partition",

    "used_for_model_training":
        False,

    "used_for_hyperparameter_selection":
        False,

    "used_for_model_selection":
        False,

    "used_for_final_test_prediction_sets":
        True,

    "purpose":
        "Quantify predictive uncertainty through "
        "finite-sample prediction-set coverage.",

    "primary_evaluation":
        [
            "Empirical coverage",
            "Average prediction-set size",
            "Singleton rate",
            "Ambiguity rate",
            "Empty-set rate",
        ],
}


print("26. CONFORMAL PREDICTION")
print("-" * 72)

for key, value in CONFORMAL_CONFIG.items():

    print(f"{key}:")

    if isinstance(value, list):

        for item in value:
            print(f"  - {item}")

    else:

        print(f"  {value}")

print()


# ================================================================
# 30. CONFORMAL VALIDATION
# ================================================================

print("27. CONFORMAL VALIDATION")
print("-" * 72)

conformal_errors = []

if CONFORMAL_CONFIG["calibration_set_size"] != 7000:
    conformal_errors.append(
        "Conformal calibration set must contain 7,000 records."
    )

if CONFORMAL_CONFIG["used_for_model_training"]:
    conformal_errors.append(
        "Calibration set must not be used for model training."
    )

if CONFORMAL_CONFIG["used_for_hyperparameter_selection"]:
    conformal_errors.append(
        "Calibration set must not be used for hyperparameter selection."
    )

if CONFORMAL_CONFIG["used_for_model_selection"]:
    conformal_errors.append(
        "Calibration set must not be used for model selection."
    )

if conformal_errors:

    for error in conformal_errors:
        print("ERROR:", error)

else:

    print("Conformal prediction specification: PASS")

print()


# ================================================================
# 31. INTERPRETABILITY
# ================================================================

INTERPRETABILITY_CONFIG = {

    "KAN_response_curves":
        "phi_i(x_i) = sum_k a_ik T_k(x_i)",

    "SHAP":
        "global and local feature attribution",

    "group_gate_analysis":
        "learned group-level contribution",

    "active_edge_ratio":
        "fraction of non-negligible learned KAN coefficients",

    "coefficient_sparsity":
        "proportion of near-zero Chebyshev coefficients",

    "clinical_group_analysis":
        "compare contribution of demographic, "
        "physiological/metabolic, and lifestyle groups",
}


print("28. INTERPRETABILITY")
print("-" * 72)

for key, value in INTERPRETABILITY_CONFIG.items():

    print(f"{key}:")
    print(f"  {value}")

print()


# ================================================================
# 32. EXTERNAL VALIDATION
# ================================================================

EXTERNAL_VALIDATION_CONFIG = {

    "dataset":
        "Official UCI Heart Disease archive",

    "primary_external_cohort":
        "Cleveland",

    "secondary_external_cohort":
        "Hungarian",

    "sensitivity_cohort":
        "VA Long Beach",

    "excluded_cohort":
        "Switzerland for primary shared-feature validation",

    "training_policy":
        "Train a separate model from scratch in the harmonized "
        "shared feature space.",

    "shared_features": [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
    ],

    "external_training_contamination":
        False,

    "kaggle_test_usage":
        False,
}


print("29. EXTERNAL VALIDATION")
print("-" * 72)

for key, value in EXTERNAL_VALIDATION_CONFIG.items():

    print(f"{key}:")

    if isinstance(value, list):

        for item in value:
            print(f"  - {item}")

    else:

        print(f"  {value}")

print()


# ================================================================
# 33. EXTERNAL VALIDATION RULES
# ================================================================

print("30. EXTERNAL VALIDATION RULES")
print("-" * 72)

external_errors = []

if EXTERNAL_VALIDATION_CONFIG[
    "external_training_contamination"
]:
    external_errors.append(
        "UCI data must not contaminate Kaggle model development."
    )

if EXTERNAL_VALIDATION_CONFIG[
    "kaggle_test_usage"
]:
    external_errors.append(
        "Kaggle locked test must not be used during external-model training."
    )

if len(
    EXTERNAL_VALIDATION_CONFIG["shared_features"]
) != 5:
    external_errors.append(
        "Shared external-validation feature space must contain 5 variables."
    )

if external_errors:

    for error in external_errors:
        print("ERROR:", error)

else:

    print("External validation specification: PASS")

print()


# ================================================================
# 34. DATA-FLOW STATEMENT
# ================================================================

DATA_FLOW_STATEMENT = (
    "Training data learns the model; CV validation data selects "
    "the model; conformal calibration data calibrates prediction "
    "sets; locked test data estimates final performance."
)


print("31. FROZEN DATA-FLOW PRINCIPLE")
print("-" * 72)

print(DATA_FLOW_STATEMENT)

print()


# ================================================================
# 35. TRAINING / CALIBRATION / TEST ROLES
# ================================================================

ROLE_MATRIX = {

    "Development_CV":
        [
            "Model training",
            "Nested CV",
            "Hyperparameter selection",
            "Feature-selection ablations",
            "Architecture selection",
        ],

    "Conformal_Calibration":
        [
            "Conformal calibration only",
            "No model fitting",
            "No hyperparameter selection",
        ],

    "Locked_Test":
        [
            "Final performance estimation only",
            "No model selection",
            "No preprocessing fitting",
            "No conformal calibration",
        ],
}


print("32. DATA ROLE MATRIX")
print("-" * 72)

for partition, roles in ROLE_MATRIX.items():

    print()
    print(partition)

    for role in roles:

        print(f"  - {role}")

print()


# ================================================================
# 36. FINAL ARCHITECTURE SUMMARY
# ================================================================

ARCHITECTURE_SUMMARY = {

    "model_name":
        "Clinically-Grouped Sparse Chebyshev-KAN",

    "short_name":
        "CGS-ChebKAN",

    "input_features":
        INPUT_FEATURES,

    "number_of_input_features":
        len(INPUT_FEATURES),

    "clinical_groups":
        CLINICAL_GROUPS,

    "basis":
        "Chebyshev polynomial, first kind",

    "polynomial_order":
        5,

    "normalization":
        "[-1, 1]",

    "group_embedding_dimension":
        16,

    "activation":
        "SiLU",

    "fusion":
        "Sparse gated group fusion",

    "gate_normalization":
        "Softmax",

    "kan_regularization":
        "L1",

    "gate_regularization":
        "L1 on pre-normalized group gates",

    "classification_loss":
        "Binary Cross-Entropy",

    "primary_feature_strategy":
        "All 11 Kaggle predictors",

    "feature_selection":
        "Ablation/sensitivity only",

    "adasyn":
        "Not used in primary pipeline",

    "cross_validation":
        "5-fold outer + 4-fold inner nested CV",

    "conformal_calibration":
        "Dedicated 7,000-record calibration set",

    "locked_test":
        "14,000 records",

    "external_validation":
        "Separate harmonized shared-feature model on UCI",
}


print("33. FINAL ARCHITECTURE SUMMARY")
print("-" * 72)

print(
    json.dumps(
        ARCHITECTURE_SUMMARY,
        indent=2,
        default=str
    )
)

print()


# ================================================================
# 37. GLOBAL AUDIT
# ================================================================

print("34. GLOBAL AUDIT")
print("-" * 72)

ALL_ERRORS = []

ALL_ERRORS.extend(partition_errors)
ALL_ERRORS.extend(feature_errors)
ALL_ERRORS.extend(group_errors)
ALL_ERRORS.extend(basis_errors)
ALL_ERRORS.extend(branch_errors)
ALL_ERRORS.extend(missing_errors)
ALL_ERRORS.extend(gate_errors)
ALL_ERRORS.extend(conformal_errors)
ALL_ERRORS.extend(external_errors)


# ================================================================
# 38. CHECK PARTITION FILES
# ================================================================

for name, info in PARTITIONS.items():

    if not info["file"].exists():

        if (
            f"Missing partition file: {info['file']}"
            not in ALL_ERRORS
        ):

            ALL_ERRORS.append(
                f"Missing partition file: {info['file']}"
            )


# ================================================================
# 39. FINAL RESULT
# ================================================================

print()

if ALL_ERRORS:

    print("=" * 72)
    print("AUDIT 20 FAILED")
    print("=" * 72)

    print()

    for i, error in enumerate(ALL_ERRORS, start=1):

        print(
            f"{i:02d}. {error}"
        )

    print()

    print(
        "The architecture specification must be corrected "
        "before implementation."
    )

    sys.exit(1)


else:

    print("=" * 72)
    print("AUDIT 20 PASS")
    print("=" * 72)

    print()

    print("The CGS-ChebKAN architecture specification is internally")
    print("consistent with the frozen methodology.")

    print()

    print("Frozen components:")
    print("  [PASS] 11 Kaggle predictor variables")
    print("  [PASS] 3 clinical groups")
    print("  [PASS] Chebyshev first-kind basis")
    print("  [PASS] Polynomial order K=5")
    print("  [PASS] Input normalization to [-1, 1]")
    print("  [PASS] Group-specific ChebKAN branches")
    print("  [PASS] 16-dimensional group embeddings")
    print("  [PASS] SiLU group activation")
    print("  [PASS] Sparse gated group fusion")
    print("  [PASS] Softmax group-gate normalization")
    print("  [PASS] L1 KAN coefficient regularization")
    print("  [PASS] L1 group-gate regularization")
    print("  [PASS] BCE classification objective")
    print("  [PASS] Fold-specific median imputation")
    print("  [PASS] ADASYN excluded from primary pipeline")
    print("  [PASS] Full 11-feature primary representation")
    print("  [PASS] Feature selection restricted to ablations")
    print("  [PASS] Nested 5x4 CV")
    print("  [PASS] Dedicated 7,000-record conformal calibration")
    print("  [PASS] Locked 14,000-record test set")
    print("  [PASS] External UCI validation separated")
    print("  [PASS] Ablation matrix A0-A7")
    print("  [PASS] Baseline model specification")
    print("  [PASS] Interpretability specification")

    print()

    print(
        "NO MODEL TRAINING WAS PERFORMED BY THIS AUDIT."
    )

    print()

    print(
        "Next stage: implementation and controlled training "
        "of the baseline and CGS-ChebKAN models."
    )

    print()

    # ============================================================
    # SAVE ARCHITECTURE SPECIFICATION
    # ============================================================

    architecture_output = (
        TABLES_DIR /
        "audit20_cgsc_hebkan_architecture_specification.json"
    )

    with open(
        architecture_output,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            {
                "audit":
                    "Audit 20",

                "timestamp":
                    datetime.now().isoformat(),

                "status":
                    "PASS",

                "architecture":
                    ARCHITECTURE_SUMMARY,

                "clinical_groups":
                    CLINICAL_GROUPS,

                "chebkan_config":
                    CHEBKAN_CONFIG,

                "group_branch_config":
                    GROUP_BRANCH_CONFIG,

                "gate_config":
                    GATE_CONFIG,

                "sparsity_config":
                    SPARSITY_CONFIG,

                "loss_config":
                    LOSS_CONFIG,

                "missing_value_config":
                    MISSING_VALUE_CONFIG,

                "cv_config":
                    CV_CONFIG,

                "conformal_config":
                    CONFORMAL_CONFIG,

                "external_validation_config":
                    EXTERNAL_VALIDATION_CONFIG,

                "ablation_matrix":
                    ABLATION_MATRIX,

                "baselines":
                    BASELINES,
            },
            f,
            indent=2,
            default=str
        )

    print(
        "Architecture specification saved to:"
    )

    print(
        architecture_output
    )

    print()

    print("=" * 72)
    print("END OF AUDIT 20")
    print("=" * 72)