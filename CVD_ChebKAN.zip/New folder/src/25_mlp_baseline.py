# ================================================================
# IMPLEMENTATION 25
# MLP BASELINE
# ================================================================
#
# Project:
# CGS-ChebKAN Cardiovascular Disease Study
#
# Purpose:
# Establish a leakage-controlled MLP baseline under exactly the
# same nested-CV protocol used for LR, Random Forest and XGBoost.
#
# IMPORTANT:
# - Development data only for nested CV/model selection
# - Calibration set remains untouched
# - Locked test set remains untouched
# - Median imputation is fitted inside each training fold
# - StandardScaler is fitted inside each training fold
# - No ADASYN in primary pipeline
# - All 11 Kaggle predictors are used
#
# ================================================================

from pathlib import Path
import json
import sys
import platform
import warnings

import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import (
    StratifiedKFold,
    GridSearchCV
)
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss
)

warnings.filterwarnings("ignore")


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)

DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
CAL_FILE = DATA_DIR / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"


# ================================================================
# 2. OUTPUT FILES
# ================================================================

OUTER_RESULTS_FILE = (
    RESULTS_DIR / "implementation25_mlp_outer_fold_results.csv"
)

AGGREGATE_RESULTS_FILE = (
    RESULTS_DIR / "implementation25_mlp_aggregate_results.csv"
)

HYPERPARAMETER_FILE = (
    RESULTS_DIR / "implementation25_mlp_selected_hyperparameters.csv"
)

POOLED_FILE = (
    RESULTS_DIR / "implementation25_mlp_pooled_outer_cv.csv"
)

PREDICTIONS_FILE = (
    RESULTS_DIR / "implementation25_mlp_outer_predictions.csv"
)

EXPERIMENT_FILE = (
    RESULTS_DIR / "implementation25_mlp_experiment_record.json"
)


# ================================================================
# 3. CONFIGURATION
# ================================================================

RANDOM_STATE = 2026

N_OUTER_SPLITS = 5
N_INNER_SPLITS = 4

TARGET = "cardio"

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active"
]

# MLP hyperparameter grid.
#
# Kept intentionally compact because nested 5x4 CV can be
# computationally expensive.
#
# hidden_layer_sizes:
#   (32,)
#   (64,)
#   (64,32)
#
# alpha:
#   L2 regularization strength
#
# learning_rate_init:
#   Initial learning rate
#
# max_iter:
#   Sufficiently high; early stopping is disabled because the
#   inner CV validation split must remain the only source of
#   model-selection information.
#
MLP_PARAM_GRID = {
    "model__hidden_layer_sizes": [
        (32,),
        (64,),
        (64, 32)
    ],
    "model__alpha": [
        1e-4,
        1e-3,
        1e-2
    ],
    "model__learning_rate_init": [
        1e-3,
        3e-4
    ]
}


# ================================================================
# 4. UTILITY FUNCTIONS
# ================================================================

def print_header(title):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def safe_float(x):
    if x is None:
        return None

    if isinstance(x, (np.floating, np.integer)):
        return float(x)

    return float(x)


def calculate_ece(y_true, y_prob, n_bins=10):
    """
    Expected Calibration Error using equal-width probability bins.
    """

    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)

    ece = 0.0

    for i in range(n_bins):
        lower = bin_edges[i]
        upper = bin_edges[i + 1]

        if i == n_bins - 1:
            mask = (
                (y_prob >= lower) &
                (y_prob <= upper)
            )
        else:
            mask = (
                (y_prob >= lower) &
                (y_prob < upper)
            )

        if not np.any(mask):
            continue

        bin_accuracy = np.mean(y_true[mask])
        bin_confidence = np.mean(y_prob[mask])
        bin_fraction = np.mean(mask)

        ece += (
            bin_fraction *
            abs(bin_accuracy - bin_confidence)
        )

    return float(ece)


def calculate_metrics(y_true, y_prob, threshold=0.50):
    """
    Calculate the complete frozen metric set.
    """

    y_pred = (
        np.asarray(y_prob) >= threshold
    ).astype(int)

    metrics = {}

    metrics["Accuracy"] = accuracy_score(
        y_true,
        y_pred
    )

    metrics["Precision"] = precision_score(
        y_true,
        y_pred,
        zero_division=0
    )

    metrics["Sensitivity"] = recall_score(
        y_true,
        y_pred,
        zero_division=0
    )

    tn = np.sum(
        (np.asarray(y_true) == 0) &
        (y_pred == 0)
    )

    fp = np.sum(
        (np.asarray(y_true) == 0) &
        (y_pred == 1)
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    metrics["Specificity"] = specificity

    metrics["F1"] = f1_score(
        y_true,
        y_pred,
        zero_division=0
    )

    metrics["ROC-AUC"] = roc_auc_score(
        y_true,
        y_prob
    )

    metrics["PR-AUC"] = average_precision_score(
        y_true,
        y_prob
    )

    metrics["Brier"] = brier_score_loss(
        y_true,
        y_prob
    )

    metrics["ECE"] = calculate_ece(
        y_true,
        y_prob
    )

    return metrics


def metric_summary(df, metric):
    values = df[metric].astype(float)

    return (
        values.mean(),
        values.std(ddof=1)
    )


# ================================================================
# 5. ENVIRONMENT AUDIT
# ================================================================

print_header("IMPLEMENTATION 25 — MLP BASELINE")

print("Environment")
print("-" * 72)

print("Python:", sys.version)
print("Platform:", platform.platform())
print("NumPy:", np.__version__)
print("Pandas:", pd.__version__)


# ================================================================
# 6. VERIFY INPUT FILES
# ================================================================

print_header("1. INPUT FILE VERIFICATION")

for file_path in [
    DEV_FILE,
    CAL_FILE,
    TEST_FILE
]:

    if not file_path.exists():
        raise FileNotFoundError(
            f"Required file not found:\n{file_path}"
        )

    print("EXISTS:", file_path)


# ================================================================
# 7. LOAD DATA
# ================================================================

print_header("2. LOAD DATA")

dev = pd.read_csv(DEV_FILE)
cal = pd.read_csv(CAL_FILE)
test = pd.read_csv(TEST_FILE)

print("Development:", dev.shape)
print("Calibration:", cal.shape)
print("Locked test:", test.shape)


# ================================================================
# 8. BASIC DATA VALIDATION
# ================================================================

print_header("3. DATA VALIDATION")

expected_sizes = {
    "Development": 49000,
    "Calibration": 7000,
    "Locked test": 14000
}

actual_sizes = {
    "Development": len(dev),
    "Calibration": len(cal),
    "Locked test": len(test)
}

for name in expected_sizes:

    if actual_sizes[name] != expected_sizes[name]:
        raise AssertionError(
            f"{name} size mismatch: "
            f"expected {expected_sizes[name]}, "
            f"got {actual_sizes[name]}"
        )

    print(
        f"{name}: {actual_sizes[name]} rows -> PASS"
    )


# ================================================================
# 9. CHECK TARGET
# ================================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test)
]:

    if TARGET not in df.columns:
        raise AssertionError(
            f"{TARGET} missing from {name}"
        )

    if df[TARGET].isna().any():
        raise AssertionError(
            f"Missing target values in {name}"
        )

    unique_target = sorted(
        df[TARGET].unique().tolist()
    )

    if unique_target != [0, 1]:
        raise AssertionError(
            f"Unexpected target values in {name}: "
            f"{unique_target}"
        )

    print(
        f"{name} target: {unique_target} -> PASS"
    )


# ================================================================
# 10. CHECK FEATURES
# ================================================================

for feature in FEATURES:

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked test", test)
    ]:

        if feature not in df.columns:
            raise AssertionError(
                f"{feature} missing from {name}"
            )

print(
    f"All {len(FEATURES)} predictors available -> PASS"
)


# ================================================================
# 11. TARGET DISTRIBUTION
# ================================================================

print_header("4. TARGET DISTRIBUTION")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test)
]:

    counts = df[TARGET].value_counts().sort_index()

    print(
        f"{name}: "
        f"class 0 = {counts.get(0, 0)}, "
        f"class 1 = {counts.get(1, 0)}"
    )


# ================================================================
# 12. PARTITION DISJOINTNESS
# ================================================================

print_header("5. PARTITION DISJOINTNESS")

if "id" in dev.columns:

    dev_ids = set(dev["id"])
    cal_ids = set(cal["id"])
    test_ids = set(test["id"])

    overlap_dev_cal = len(
        dev_ids.intersection(cal_ids)
    )

    overlap_dev_test = len(
        dev_ids.intersection(test_ids)
    )

    overlap_cal_test = len(
        cal_ids.intersection(test_ids)
    )

    print(
        "Development × Calibration:",
        overlap_dev_cal
    )

    print(
        "Development × Test:",
        overlap_dev_test
    )

    print(
        "Calibration × Test:",
        overlap_cal_test
    )

    if any([
        overlap_dev_cal,
        overlap_dev_test,
        overlap_cal_test
    ]):
        raise AssertionError(
            "Partition overlap detected."
        )

    print("Partition disjointness -> PASS")

else:
    raise AssertionError(
        "ID column required for partition audit."
    )


# ================================================================
# 13. PROTECT CALIBRATION AND TEST
# ================================================================

print_header("6. CALIBRATION / TEST PROTECTION")

cal_ids = set(cal["id"])
test_ids = set(test["id"])

if len(
    set(dev["id"]).intersection(cal_ids)
) != 0:
    raise AssertionError(
        "Calibration IDs appear in Development."
    )

if len(
    set(dev["id"]).intersection(test_ids)
) != 0:
    raise AssertionError(
        "Test IDs appear in Development."
    )

print(
    "Calibration set excluded from model selection -> PASS"
)

print(
    "Locked test excluded from model selection -> PASS"
)


# ================================================================
# 14. MISSINGNESS AUDIT
# ================================================================

print_header("7. MISSINGNESS AUDIT")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked test", test)
]:

    missing = df[FEATURES].isna().sum()

    print(f"\n{name}")

    for feature, count in missing.items():

        if count > 0:

            percentage = (
                100.0 * count / len(df)
            )

            print(
                f"  {feature}: "
                f"{count} ({percentage:.4f}%)"
            )


# ================================================================
# 15. PREPROCESSING POLICY
# ================================================================

print_header("8. PREPROCESSING POLICY")

print(
    "Median imputation:"
    " fitted only within each training fold."
)

print(
    "StandardScaler:"
    " fitted only within each training fold."
)

print(
    "No global imputation."
)

print(
    "No global scaling."
)

print(
    "ADASYN: NOT USED in primary pipeline."
)

print(
    "Calibration and locked test remain untouched."
)


# ================================================================
# 16. OUTER / INNER CV
# ================================================================

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)

inner_cv = StratifiedKFold(
    n_splits=N_INNER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)


# ================================================================
# 17. MLP PIPELINE
# ================================================================

pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="median"
            )
        ),
        (
            "scaler",
            StandardScaler()
        ),
        (
            "model",
            MLPClassifier(
                activation="relu",
                solver="adam",
                batch_size=256,
                max_iter=300,
                early_stopping=False,
                random_state=RANDOM_STATE,
                verbose=False
            )
        )
    ]
)


# ================================================================
# 18. DEVELOPMENT DATA
# ================================================================

X_dev = dev[FEATURES].copy()
y_dev = dev[TARGET].astype(int).copy()


# ================================================================
# 19. OUTER CV LOOP
# ================================================================

print_header(
    "9. NESTED 5 × 4 CROSS-VALIDATION"
)

outer_results = []
selected_hyperparameters = []
all_outer_predictions = []

for fold_number, (
    train_idx,
    val_idx
) in enumerate(
    outer_cv.split(X_dev, y_dev),
    start=1
):

    print("\n" + "-" * 72)
    print(f"OUTER FOLD {fold_number}/{N_OUTER_SPLITS}")
    print("-" * 72)

    X_train = X_dev.iloc[train_idx].copy()
    X_val = X_dev.iloc[val_idx].copy()

    y_train = y_dev.iloc[train_idx].copy()
    y_val = y_dev.iloc[val_idx].copy()

    print(
        "Training rows:",
        len(X_train)
    )

    print(
        "Validation rows:",
        len(X_val)
    )

    # ------------------------------------------------------------
    # INNER CV HYPERPARAMETER SELECTION
    # ------------------------------------------------------------

    grid = GridSearchCV(
        estimator=pipeline,
        param_grid=MLP_PARAM_GRID,
        scoring="roc_auc",
        cv=inner_cv,
        n_jobs=-1,
        refit=True,
        return_train_score=False
    )

    grid.fit(
        X_train,
        y_train
    )

    best_model = grid.best_estimator_
    best_params = grid.best_params_
    best_inner_auc = grid.best_score_

    print(
        "\nBest inner-CV ROC-AUC:",
        f"{best_inner_auc:.6f}"
    )

    print("Selected hyperparameters:")

    for key, value in best_params.items():
        print(
            f"  {key}: {value}"
        )

    # ------------------------------------------------------------
    # OUTER VALIDATION
    # ------------------------------------------------------------

    y_prob = best_model.predict_proba(
        X_val
    )[:, 1]

    metrics = calculate_metrics(
        y_val.to_numpy(),
        y_prob
    )

    print("\nOuter validation metrics:")

    for metric_name, value in metrics.items():

        print(
            f"  {metric_name}: "
            f"{value:.6f}"
        )

    # ------------------------------------------------------------
    # STORE FOLD RESULTS
    # ------------------------------------------------------------

    result_row = {
        "fold": fold_number,
        "inner_best_roc_auc": best_inner_auc,
        **best_params,
        **metrics
    }

    outer_results.append(
        result_row
    )

    selected_hyperparameters.append(
        {
            "fold": fold_number,
            "inner_best_roc_auc": best_inner_auc,
            **best_params
        }
    )

    # ------------------------------------------------------------
    # STORE PREDICTIONS
    # ------------------------------------------------------------

    prediction_df = pd.DataFrame(
        {
            "fold": fold_number,
            "id": dev.iloc[val_idx]["id"].to_numpy(),
            "y_true": y_val.to_numpy(),
            "y_prob": y_prob
        }
    )

    all_outer_predictions.append(
        prediction_df
    )


# ================================================================
# 20. OUTER RESULTS DATAFRAME
# ================================================================

outer_results_df = pd.DataFrame(
    outer_results
)

hyperparameters_df = pd.DataFrame(
    selected_hyperparameters
)

predictions_df = pd.concat(
    all_outer_predictions,
    axis=0,
    ignore_index=True
)


# ================================================================
# 21. OUTER-CV COVERAGE CHECK
# ================================================================

print_header("10. OUTER-CV COVERAGE CHECK")

expected_prediction_rows = len(dev)

actual_prediction_rows = len(
    predictions_df
)

print(
    "Expected Development predictions:",
    expected_prediction_rows
)

print(
    "Actual outer-CV predictions:",
    actual_prediction_rows
)

if actual_prediction_rows != expected_prediction_rows:
    raise AssertionError(
        "Outer-CV prediction count mismatch."
    )

if predictions_df["id"].nunique() != expected_prediction_rows:
    raise AssertionError(
        "Some Development IDs were not predicted exactly once."
    )

print(
    "Every Development record appears exactly once "
    "as an outer validation prediction -> PASS"
)


# ================================================================
# 22. AGGREGATE METRICS
# ================================================================

print_header("11. AGGREGATE OUTER-CV RESULTS")

METRICS = [
    "Accuracy",
    "Precision",
    "Sensitivity",
    "Specificity",
    "F1",
    "ROC-AUC",
    "PR-AUC",
    "Brier",
    "ECE"
]

aggregate_rows = []

for metric in METRICS:

    mean_value, std_value = metric_summary(
        outer_results_df,
        metric
    )

    aggregate_rows.append(
        {
            "Metric": metric,
            "Mean": mean_value,
            "SD": std_value
        }
    )

aggregate_df = pd.DataFrame(
    aggregate_rows
)

for _, row in aggregate_df.iterrows():

    print(
        f"{row['Metric']}: "
        f"{row['Mean']:.6f} ± "
        f"{row['SD']:.6f}"
    )


# ================================================================
# 23. POOLED OUTER-CV METRICS
# ================================================================

print_header("12. POOLED OUTER-CV RESULTS")

pooled_metrics = calculate_metrics(
    predictions_df["y_true"].to_numpy(),
    predictions_df["y_prob"].to_numpy()
)

for metric_name, value in pooled_metrics.items():

    print(
        f"{metric_name}: "
        f"{value:.6f}"
    )


# ================================================================
# 24. HYPERPARAMETER STABILITY
# ================================================================

print_header("13. HYPERPARAMETER STABILITY")

for column in [
    "model__hidden_layer_sizes",
    "model__alpha",
    "model__learning_rate_init"
]:

    print(f"\n{column}")

    counts = (
        hyperparameters_df[column]
        .astype(str)
        .value_counts()
    )

    for value, count in counts.items():

        print(
            f"  {value}: "
            f"{count}/{N_OUTER_SPLITS}"
        )


# ================================================================
# 25. CALIBRATION / TEST PROTECTION RECHECK
# ================================================================

print_header(
    "14. FINAL CALIBRATION / TEST PROTECTION CHECK"
)

prediction_ids = set(
    predictions_df["id"]
)

cal_overlap = len(
    prediction_ids.intersection(
        cal_ids
    )
)

test_overlap = len(
    prediction_ids.intersection(
        test_ids
    )
)

print(
    "Outer-CV predictions × Calibration:",
    cal_overlap
)

print(
    "Outer-CV predictions × Locked Test:",
    test_overlap
)

if cal_overlap != 0:
    raise AssertionError(
        "Calibration contamination detected."
    )

if test_overlap != 0:
    raise AssertionError(
        "Locked-test contamination detected."
    )

print(
    "Calibration protection -> PASS"
)

print(
    "Locked-test protection -> PASS"
)


# ================================================================
# 26. SAVE RESULTS
# ================================================================

print_header("15. SAVE RESULTS")

outer_results_df.to_csv(
    OUTER_RESULTS_FILE,
    index=False
)

aggregate_df.to_csv(
    AGGREGATE_RESULTS_FILE,
    index=False
)

hyperparameters_df.to_csv(
    HYPERPARAMETER_FILE,
    index=False
)

pooled_df = pd.DataFrame(
    [
        {
            "Metric": metric,
            "Pooled_Value": value
        }
        for metric, value in pooled_metrics.items()
    ]
)

pooled_df.to_csv(
    POOLED_FILE,
    index=False
)

predictions_df.to_csv(
    PREDICTIONS_FILE,
    index=False
)


# ================================================================
# 27. EXPERIMENT RECORD
# ================================================================

experiment_record = {

    "implementation": "25",

    "model": "MLP",

    "model_description": (
        "Multilayer Perceptron baseline "
        "with ReLU activation and Adam optimization."
    ),

    "project": "CGS-ChebKAN cardiovascular study",

    "random_state": RANDOM_STATE,

    "data": {
        "development_rows": len(dev),
        "calibration_rows": len(cal),
        "locked_test_rows": len(test)
    },

    "features": FEATURES,

    "target": TARGET,

    "preprocessing": {
        "imputation": (
            "Median imputation fitted independently "
            "inside each training fold."
        ),
        "scaling": (
            "StandardScaler fitted independently "
            "inside each training fold."
        ),
        "global_imputation": False,
        "global_scaling": False,
        "adasyn_primary": False
    },

    "cross_validation": {
        "outer_folds": N_OUTER_SPLITS,
        "inner_folds": N_INNER_SPLITS,
        "outer_type": "StratifiedKFold",
        "inner_type": "StratifiedKFold",
        "shuffle": True,
        "random_state": RANDOM_STATE
    },

    "hyperparameter_grid": {
        key: [
            list(v)
            if isinstance(v, tuple)
            else v
            for v in values
        ]
        for key, values in MLP_PARAM_GRID.items()
    },

    "scoring_for_model_selection": "ROC-AUC",

    "metrics": METRICS,

    "calibration_set_used": False,

    "locked_test_used": False,

    "outer_cv_prediction_rows": len(
        predictions_df
    ),

    "pooled_outer_cv_metrics": pooled_metrics,

    "aggregate_outer_cv": {
        row["Metric"]: {
            "mean": safe_float(row["Mean"]),
            "sd": safe_float(row["SD"])
        }
        for _, row in aggregate_df.iterrows()
    },

    "status": "PASS"
}

with open(
    EXPERIMENT_FILE,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        experiment_record,
        f,
        indent=2
    )


# ================================================================
# 28. FINAL SUMMARY
# ================================================================

print_header(
    "IMPLEMENTATION 25 FINAL SUMMARY"
)

print(
    f"MLP pooled outer-CV ROC-AUC: "
    f"{pooled_metrics['ROC-AUC']:.6f}"
)

roc_mean = aggregate_df.loc[
    aggregate_df["Metric"] == "ROC-AUC",
    "Mean"
].iloc[0]

roc_sd = aggregate_df.loc[
    aggregate_df["Metric"] == "ROC-AUC",
    "SD"
].iloc[0]

print(
    f"MLP mean outer-CV ROC-AUC: "
    f"{roc_mean:.6f} ± {roc_sd:.6f}"
)

print(
    "Calibration set touched:",
    False
)

print(
    "Locked test touched:",
    False
)

print(
    "ADASYN used:",
    False
)

print(
    "Status: PASS"
)

print("\nSaved files:")

print(
    OUTER_RESULTS_FILE
)

print(
    AGGREGATE_RESULTS_FILE
)

print(
    HYPERPARAMETER_FILE
)

print(
    POOLED_FILE
)

print(
    PREDICTIONS_FILE
)

print(
    EXPERIMENT_FILE
)

print("\nImplementation 25 completed successfully.")