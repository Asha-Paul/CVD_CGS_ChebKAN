# ================================================================
# AUDIT 14: LEAKAGE-CONTROLLED KAGGLE PARTITIONING
# ================================================================
#
# Purpose:
#   Create and audit the locked Kaggle development/test/calibration
#   partitions before any supervised preprocessing or model training.
#
# Frozen methodology:
#   1. Load the BP-quality-controlled Kaggle dataset.
#   2. Create one LOCKED TEST set using stratified splitting.
#   3. Never use the locked test set for:
#        - feature selection
#        - scaling
#        - imputation
#        - ADASYN
#        - hyperparameter tuning
#        - model selection
#        - conformal calibration
#   4. Split the remaining Development set into:
#        - Model-development / CV pool
#        - Separate conformal calibration set
#   5. All splits are stratified by the target.
#   6. Save only partition assignments / partitioned datasets.
#
# No model is trained.
# No feature selection is performed.
# No imputation is performed.
# No ADASYN is performed.
# No scaling is performed.
#
# ================================================================

from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split


# ================================================================
# 1. PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

INPUT_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_bp_quality_controlled.csv"
)

RESULTS_TABLES = PROJECT_ROOT / "results" / "tables"
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"

RESULTS_TABLES.mkdir(parents=True, exist_ok=True)
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


# ================================================================
# 2. FROZEN SPLIT PARAMETERS
# ================================================================

RANDOM_STATE = 2026

# 20% locked test set
TEST_SIZE = 0.20

# Of the remaining 80%, allocate 12.5% to calibration.
#
# 12.5% of 80% = 10% of the complete dataset.
#
# Final:
#   70% Model-development/CV
#   10% Conformal calibration
#   20% Locked test
CALIBRATION_SIZE_WITHIN_DEVELOPMENT = 0.125


# ================================================================
# 3. LOAD DATA
# ================================================================

print("=" * 70)
print("AUDIT 14: LEAKAGE-CONTROLLED KAGGLE PARTITIONING")
print("=" * 70)

print("\nChecking input file...")
print(INPUT_FILE)

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"\nInput file not found:\n{INPUT_FILE}\n\n"
        "Expected file:\n"
        "data\\processed\\kaggle_bp_quality_controlled.csv"
    )

df = pd.read_csv(INPUT_FILE)

print("\nInput dataset")
print("-" * 70)
print(f"Rows    : {len(df):,}")
print(f"Columns : {df.shape[1]}")


# ================================================================
# 4. BASIC VALIDATION
# ================================================================

if "cardio" not in df.columns:
    raise ValueError(
        "Target column 'cardio' was not found in the input dataset."
    )

target = df["cardio"]

if target.isna().any():
    raise ValueError(
        "Target contains missing values. "
        "Partitioning cannot proceed."
    )

unique_target = sorted(target.unique().tolist())

if unique_target != [0, 1]:
    raise ValueError(
        f"Unexpected target values: {unique_target}. "
        "Expected binary target {0, 1}."
    )

if df["id"].duplicated().any():
    raise ValueError(
        "Duplicate patient IDs detected. "
        "Partitioning cannot proceed."
    )

print("\nTarget distribution before splitting")
print("-" * 70)
print(target.value_counts().sort_index())
print(
    target.value_counts(normalize=True)
    .sort_index()
    .rename("proportion")
)


# ================================================================
# 5. CREATE LOCKED TEST SET
# ================================================================

print("\n" + "=" * 70)
print("STEP 1: LOCKED TEST SET")
print("=" * 70)

development_df, test_df = train_test_split(
    df,
    test_size=TEST_SIZE,
    stratify=df["cardio"],
    random_state=RANDOM_STATE,
)

development_df = development_df.copy()
test_df = test_df.copy()

print(f"\nDevelopment pool : {len(development_df):,}")
print(f"Locked test       : {len(test_df):,}")

print("\nLocked test target distribution")
print("-" * 70)
print(
    pd.DataFrame({
        "count": test_df["cardio"].value_counts().sort_index(),
        "proportion": test_df["cardio"]
            .value_counts(normalize=True)
            .sort_index()
    })
)


# ================================================================
# 6. SPLIT DEVELOPMENT INTO:
#       MODEL-DEVELOPMENT / CV
#       CONFORMAL CALIBRATION
# ================================================================

print("\n" + "=" * 70)
print("STEP 2: DEVELOPMENT / CALIBRATION SPLIT")
print("=" * 70)

cv_df, calibration_df = train_test_split(
    development_df,
    test_size=CALIBRATION_SIZE_WITHIN_DEVELOPMENT,
    stratify=development_df["cardio"],
    random_state=RANDOM_STATE,
)

cv_df = cv_df.copy()
calibration_df = calibration_df.copy()

print(f"\nModel-development/CV pool : {len(cv_df):,}")
print(f"Conformal calibration     : {len(calibration_df):,}")


# ================================================================
# 7. ADD PARTITION LABEL
# ================================================================

cv_df["partition"] = "development_cv"
calibration_df["partition"] = "conformal_calibration"
test_df["partition"] = "locked_test"


# ================================================================
# 8. COMBINE FOR PARTITION ASSIGNMENT FILE
# ================================================================

partitioned_df = pd.concat(
    [
        cv_df,
        calibration_df,
        test_df
    ],
    axis=0,
    ignore_index=True
)


# ================================================================
# 9. CHECK TOTALS
# ================================================================

print("\n" + "=" * 70)
print("STEP 3: PARTITION SIZE AUDIT")
print("=" * 70)

partition_counts = (
    partitioned_df["partition"]
    .value_counts()
    .rename_axis("partition")
    .reset_index(name="n")
)

partition_counts["percentage"] = (
    partition_counts["n"] / len(df) * 100
)

print("\n")
print(
    partition_counts
    .sort_values("partition")
    .to_string(index=False)
)

expected_total = len(cv_df) + len(calibration_df) + len(test_df)

if expected_total != len(df):
    raise RuntimeError(
        f"Partition total mismatch: "
        f"{expected_total:,} != {len(df):,}"
    )


# ================================================================
# 10. CHECK PATIENT-ID OVERLAP
# ================================================================

print("\n" + "=" * 70)
print("STEP 4: PATIENT-ID OVERLAP AUDIT")
print("=" * 70)

cv_ids = set(cv_df["id"])
cal_ids = set(calibration_df["id"])
test_ids = set(test_df["id"])

overlap_cv_cal = cv_ids.intersection(cal_ids)
overlap_cv_test = cv_ids.intersection(test_ids)
overlap_cal_test = cal_ids.intersection(test_ids)

print(f"\nDevelopment/CV ∩ Calibration : {len(overlap_cv_cal)}")
print(f"Development/CV ∩ Test        : {len(overlap_cv_test)}")
print(f"Calibration ∩ Test           : {len(overlap_cal_test)}")

if (
    len(overlap_cv_cal) > 0
    or len(overlap_cv_test) > 0
    or len(overlap_cal_test) > 0
):
    raise RuntimeError(
        "Patient-ID overlap detected between partitions."
    )

print("\nPASS: No patient appears in more than one partition.")


# ================================================================
# 11. TARGET DISTRIBUTION ACROSS PARTITIONS
# ================================================================

print("\n" + "=" * 70)
print("STEP 5: TARGET DISTRIBUTION AUDIT")
print("=" * 70)

target_summary = []

for partition_name, part_df in [
    ("development_cv", cv_df),
    ("conformal_calibration", calibration_df),
    ("locked_test", test_df),
]:

    counts = part_df["cardio"].value_counts().to_dict()

    n0 = counts.get(0, 0)
    n1 = counts.get(1, 0)
    n = len(part_df)

    target_summary.append({
        "partition": partition_name,
        "n": n,
        "class_0": n0,
        "class_1": n1,
        "class_0_percentage": 100 * n0 / n,
        "class_1_percentage": 100 * n1 / n,
    })

target_summary_df = pd.DataFrame(target_summary)

print(
    target_summary_df.to_string(index=False)
)


# ================================================================
# 12. STRATIFICATION CHECK
# ================================================================

print("\n" + "=" * 70)
print("STEP 6: STRATIFICATION CHECK")
print("=" * 70)

overall_positive_rate = df["cardio"].mean()

target_summary_df["positive_rate_difference"] = (
    target_summary_df["class_1_percentage"] / 100
    - overall_positive_rate
)

print(
    target_summary_df[
        [
            "partition",
            "n",
            "class_0_percentage",
            "class_1_percentage",
            "positive_rate_difference",
        ]
    ].to_string(index=False)
)

print(
    f"\nOverall positive rate: "
    f"{overall_positive_rate:.6f}"
)


# ================================================================
# 13. CHECK DATA LEAKAGE THROUGH ORIGINAL ROW INDEX
# ================================================================

print("\n" + "=" * 70)
print("STEP 7: ROW-INDEX / DUPLICATE AUDIT")
print("=" * 70)

# The source dataset should contain unique IDs.
# We additionally check complete-row duplication after partitioning.

if partitioned_df["id"].duplicated().any():
    raise RuntimeError(
        "Duplicate IDs detected after partition construction."
    )

if partitioned_df.duplicated().any():
    raise RuntimeError(
        "Duplicate complete records detected after partition construction."
    )

print("PASS: No duplicate IDs.")
print("PASS: No duplicate complete records.")


# ================================================================
# 14. VERIFY NO ORIGINAL RECORDS LOST
# ================================================================

print("\n" + "=" * 70)
print("STEP 8: RECORD CONSERVATION CHECK")
print("=" * 70)

original_ids = set(df["id"])
partition_ids = set(partitioned_df["id"])

missing_ids = original_ids - partition_ids
extra_ids = partition_ids - original_ids

print(f"Original IDs       : {len(original_ids):,}")
print(f"Partitioned IDs    : {len(partition_ids):,}")
print(f"Missing IDs        : {len(missing_ids):,}")
print(f"Unexpected IDs     : {len(extra_ids):,}")

if missing_ids or extra_ids:
    raise RuntimeError(
        "Record conservation failed."
    )

print("\nPASS: Every original record appears exactly once.")


# ================================================================
# 15. VERIFY TEST SET IS NEVER USED FOR CALIBRATION
# ================================================================

print("\n" + "=" * 70)
print("STEP 9: CONFORMAL-CALIBRATION SEPARATION")
print("=" * 70)

if test_ids.intersection(cal_ids):
    raise RuntimeError(
        "Locked test and calibration sets overlap."
    )

if test_ids.intersection(cv_ids):
    raise RuntimeError(
        "Locked test and development/CV sets overlap."
    )

print("PASS: Locked test set is completely isolated.")
print("PASS: Calibration set is independent of the locked test set.")


# ================================================================
# 16. SAVE PARTITIONED DATASETS
# ================================================================

print("\n" + "=" * 70)
print("STEP 10: SAVING PARTITIONS")
print("=" * 70)

cv_file = (
    PROCESSED_DIR
    / "kaggle_development_cv.csv"
)

calibration_file = (
    PROCESSED_DIR
    / "kaggle_conformal_calibration.csv"
)

test_file = (
    PROCESSED_DIR
    / "kaggle_locked_test.csv"
)

partition_assignment_file = (
    PROCESSED_DIR
    / "kaggle_partition_assignments.csv"
)

cv_df.to_csv(cv_file, index=False)
calibration_df.to_csv(calibration_file, index=False)
test_df.to_csv(test_file, index=False)

partitioned_df[
    ["id", "partition"]
].to_csv(
    partition_assignment_file,
    index=False
)

print(f"\nDevelopment/CV:")
print(cv_file)

print(f"\nConformal calibration:")
print(calibration_file)

print(f"\nLocked test:")
print(test_file)

print(f"\nPartition assignments:")
print(partition_assignment_file)


# ================================================================
# 17. SAVE AUDIT TABLES
# ================================================================

partition_counts_file = (
    RESULTS_TABLES
    / "audit14_partition_counts.csv"
)

target_distribution_file = (
    RESULTS_TABLES
    / "audit14_partition_target_distribution.csv"
)

partition_counts.sort_values("partition").to_csv(
    partition_counts_file,
    index=False
)

target_summary_df.to_csv(
    target_distribution_file,
    index=False
)


# ================================================================
# 18. FINAL AUDIT SUMMARY
# ================================================================

print("\n" + "=" * 70)
print("AUDIT 14 COMPLETE")
print("=" * 70)

print("\nFINAL PARTITION DESIGN")
print("-" * 70)

print(
    f"Total Kaggle records          : {len(df):,}"
)

print(
    f"Development/CV pool          : {len(cv_df):,} "
    f"({len(cv_df)/len(df)*100:.2f}%)"
)

print(
    f"Conformal calibration        : {len(calibration_df):,} "
    f"({len(calibration_df)/len(df)*100:.2f}%)"
)

print(
    f"Locked test                  : {len(test_df):,} "
    f"({len(test_df)/len(df)*100:.2f}%)"
)

print("\nLeakage checks")
print("-" * 70)
print("✓ No patient-ID overlap")
print("✓ No duplicate records")
print("✓ No records lost")
print("✓ No records added")
print("✓ Test set isolated")
print("✓ Calibration set isolated from test")
print("✓ Stratified target partitioning")

print("\nNo model was trained.")
print("No feature selection was performed.")
print("No scaling was performed.")
print("No imputation was performed.")
print("No ADASYN was performed.")
print("No conformal calibration was performed.")

print("\nOutputs:")
print(f"  {partition_counts_file}")
print(f"  {target_distribution_file}")
print(f"  {cv_file}")
print(f"  {calibration_file}")
print(f"  {test_file}")
print(f"  {partition_assignment_file}")

print("\n" + "=" * 70)