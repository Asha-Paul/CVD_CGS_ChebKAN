# ================================================================
# 34 — UCI EXTERNAL VALIDATION
#     SHARED-FEATURE CGS-CHEBKAN
# ================================================================
#
# Purpose:
#   Train a separate CGS-ChebKAN model using the Kaggle
#   Development dataset restricted to the five features that
#   can be harmonized with the official UCI Heart Disease data.
#
# Shared feature space:
#   age
#   sex
#   systolic_bp
#   cholesterol_category
#   elevated_glucose
#
# External cohorts:
#   Cleveland  -> primary
#   Hungarian  -> secondary
#   VA          -> sensitivity
#   Switzerland -> excluded
#
# IMPORTANT:
#   UCI data are NEVER used for training, preprocessing fitting,
#   hyperparameter selection, or model calibration.
#
#   The model is trained from scratch on Kaggle Development data.
#
# ================================================================

import os
import json
import time
import random
import warnings

import numpy as np
import pandas as pd

import torch
import torch.nn as nn

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
)

warnings.filterwarnings("ignore")


# ================================================================
# 1. PATHS
# ================================================================

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

KAGGLE_DEV = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "kaggle_development_cv.csv"
)

UCI_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "uci_harmonized"
)

RESULTS_TABLES = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

RESULTS_MODELS = os.path.join(
    PROJECT_ROOT,
    "results",
    "models"
)

os.makedirs(
    RESULTS_TABLES,
    exist_ok=True
)

os.makedirs(
    RESULTS_MODELS,
    exist_ok=True
)


# ================================================================
# 2. REPRODUCIBILITY
# ================================================================

SEED = 2026

random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


# ================================================================
# 3. DEVICE
# ================================================================

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available()
    else "cpu"
)

print("=" * 80)
print("UCI EXTERNAL VALIDATION")
print("SHARED-FEATURE CGS-CHEBKAN")
print("=" * 80)

print()
print("Python:", __import__("sys").version.split()[0])
print("PyTorch:", torch.__version__)
print("NumPy:", np.__version__)
print("Pandas:", pd.__version__)
print("Device:", DEVICE)

if torch.cuda.is_available():

    print(
        "CUDA:",
        torch.version.cuda
    )

    print(
        "GPU:",
        torch.cuda.get_device_name(0)
    )


# ================================================================
# 4. SHARED FEATURE SPACE
# ================================================================

FEATURES = [
    "age",
    "sex",
    "systolic_bp",
    "cholesterol_category",
    "elevated_glucose",
]

TARGET_KAGGLE = "cardio"
TARGET_UCI = "target_binary"


# ================================================================
# 5. CLINICAL GROUPS
# ================================================================
#
# The original Kaggle dataset has three groups, but the frozen
# cross-dataset feature space contains no defensible lifestyle
# counterpart.
#
# Therefore, for external validation:
#
#   demographic:
#       age, sex
#
#   physiological_metabolic:
#       systolic_bp,
#       cholesterol_category,
#       elevated_glucose
#
# There is intentionally NO artificial lifestyle group.
# ================================================================

GROUPS = {
    "demographic": [
        "age",
        "sex",
    ],

    "physiological_metabolic": [
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
    ],
}

GROUP_NAMES = list(
    GROUPS.keys()
)

GROUP_INDICES = {
    name: [
        FEATURES.index(feature)
        for feature in feature_list
    ]
    for name, feature_list in GROUPS.items()
}


# ================================================================
# 6. FROZEN ARCHITECTURE
# ================================================================

CHEB_DEGREE = 5
GROUP_EMBEDDING = 16

LEARNING_RATE = 1e-3
L2 = 1e-4
KAN_L1 = 1e-5
GATE_L1 = 1e-4

BATCH_SIZE = 1024
MAX_EPOCHS = 100
PATIENCE = 10


# ================================================================
# 7. LOAD KAGGLE DEVELOPMENT DATA
# ================================================================

if not os.path.exists(KAGGLE_DEV):

    raise FileNotFoundError(
        f"Kaggle Development file not found:\n{KAGGLE_DEV}"
    )

dev = pd.read_csv(
    KAGGLE_DEV
)

print()
print(
    "Kaggle Development:",
    dev.shape
)


# ================================================================
# 8. VERIFY KAGGLE SOURCE
# ================================================================

required_kaggle = [
    "age",
    "gender",
    "ap_hi",
    "cholesterol",
    "gluc",
    "cardio",
]

missing = [
    c for c in required_kaggle
    if c not in dev.columns
]

if missing:

    raise ValueError(
        "Missing Kaggle columns: "
        + str(missing)
    )


# ================================================================
# 9. KAGGLE HARMONIZATION
# ================================================================
#
# The external model must be trained in exactly the same
# five-feature semantic space used by UCI.
# ================================================================

kaggle_shared = pd.DataFrame(
    index=dev.index
)

# Age:
# Kaggle stores age in days.
kaggle_shared["age"] = (
    pd.to_numeric(
        dev["age"],
        errors="coerce"
    ) / 365.25
)

# Sex:
# Frozen mapping:
# gender 1/2 -> sex 0/1
kaggle_shared["sex"] = (
    pd.to_numeric(
        dev["gender"],
        errors="coerce"
    ).map({
        1: 0,
        2: 1,
    })
)

# Systolic blood pressure:
kaggle_shared["systolic_bp"] = (
    pd.to_numeric(
        dev["ap_hi"],
        errors="coerce"
    )
)

# Cholesterol:
# Kaggle ordinal values already correspond to:
# 1 = normal
# 2 = above normal
# 3 = well above normal
kaggle_shared[
    "cholesterol_category"
] = pd.to_numeric(
    dev["cholesterol"],
    errors="coerce"
)

# Elevated glucose:
# Frozen harmonization:
#   1 -> 0
#   2/3 -> 1
glucose_raw = pd.to_numeric(
    dev["gluc"],
    errors="coerce"
)

kaggle_shared[
    "elevated_glucose"
] = glucose_raw.map({
    1: 0,
    2: 1,
    3: 1,
})

kaggle_shared[
    "target"
] = pd.to_numeric(
    dev["cardio"],
    errors="coerce"
)


# ================================================================
# 10. VERIFY KAGGLE SHARED DATA
# ================================================================

print()
print("=" * 80)
print("KAGGLE SHARED-FEATURE AUDIT")
print("=" * 80)

print(
    "Rows:",
    len(kaggle_shared)
)

print(
    "Features:",
    FEATURES
)

print(
    "Missing values:"
)

print(
    kaggle_shared[
        FEATURES
    ].isna().sum()
)

print(
    "Target:",
    kaggle_shared[
        "target"
    ].value_counts().sort_index().to_dict()
)


# ================================================================
# 11. VALID KAGGLE RECORDS
# ================================================================

kaggle_valid_mask = (
    kaggle_shared[
        FEATURES
    ].notna().all(axis=1)
    &
    kaggle_shared[
        "target"
    ].isin([0, 1])
)

kaggle_valid = (
    kaggle_shared[
        kaggle_valid_mask
    ].copy()
)

print()
print(
    "Valid complete shared-feature Kaggle records:",
    len(kaggle_valid)
)

if len(kaggle_valid) == 0:

    raise ValueError(
        "No valid Kaggle shared-feature records."
    )


# ================================================================
# 12. EXTERNAL UCI FILES
# ================================================================

UCI_FILES = {

    "cleveland":
        "uci_cleveland_harmonized_shared_features.csv",

    "hungarian":
        "uci_hungarian_harmonized_shared_features.csv",

    "va":
        "uci_va_harmonized_shared_features.csv",

}


# ================================================================
# 13. LOAD UCI COHORTS
# ================================================================

uci = {}

print()
print("=" * 80)
print("LOADING UCI EXTERNAL COHORTS")
print("=" * 80)

for cohort, filename in UCI_FILES.items():

    path = os.path.join(
        UCI_DIR,
        filename
    )

    if not os.path.exists(path):

        raise FileNotFoundError(
            f"UCI file not found:\n{path}"
        )

    df = pd.read_csv(
        path
    )

    required = (
        FEATURES
        + [TARGET_UCI]
    )

    missing = [
        c for c in required
        if c not in df.columns
    ]

    if missing:

        raise ValueError(
            f"{cohort}: missing columns "
            f"{missing}"
        )

    # Only eligible complete records.
    valid_mask = (
        df[
            FEATURES
        ].notna().all(axis=1)
        &
        df[
            TARGET_UCI
        ].isin([0, 1])
    )

    df_valid = df[
        valid_mask
    ].copy()

    uci[cohort] = df_valid

    print(
        f"{cohort}: "
        f"{len(df)} total, "
        f"{len(df_valid)} eligible"
    )


# ================================================================
# 14. VERIFY EXPECTED ELIGIBLE COUNTS
# ================================================================

expected_counts = {
    "cleveland": 303,
    "hungarian": 262,
    "va": 100,
}

for cohort, expected in expected_counts.items():

    observed = len(
        uci[cohort]
    )

    if observed != expected:

        raise ValueError(
            f"{cohort}: expected "
            f"{expected} eligible records, "
            f"observed {observed}."
        )

print()
print(
    "Expected UCI eligibility counts: PASS"
)


# ================================================================
# 15. PREPROCESSING
# ================================================================
#
# Fit preprocessing ONLY on Kaggle Development.
#
# UCI data are transformed using the same objects.
#
# No UCI-derived imputation/scaling parameters are used.
# ================================================================

imputer = SimpleImputer(
    strategy="median"
)

scaler = MinMaxScaler(
    feature_range=(-1, 1)
)

x_kaggle = kaggle_valid[
    FEATURES
].astype(
    np.float32
)

y_kaggle = kaggle_valid[
    "target"
].astype(
    int
).to_numpy()

x_kaggle_imp = imputer.fit_transform(
    x_kaggle
)

x_kaggle_scaled = scaler.fit_transform(
    x_kaggle_imp
).astype(
    np.float32
)

print()
print(
    "Preprocessing fitted on Kaggle Development only."
)


# ================================================================
# 16. CHEBYSHEV BASIS
# ================================================================

def chebyshev_basis(
    x,
    degree
):

    basis = [
        torch.ones_like(x)
    ]

    if degree >= 1:

        basis.append(x)

    for k in range(
        2,
        degree + 1
    ):

        basis.append(
            2.0 * x * basis[-1]
            - basis[-2]
        )

    return torch.stack(
        basis,
        dim=-1
    )


# ================================================================
# 17. CHEBYSHEV KAN LAYER
# ================================================================

class ChebyshevKANLayer(
    nn.Module
):

    def __init__(
        self,
        in_features,
        out_features,
        degree
    ):

        super().__init__()

        self.in_features = (
            in_features
        )

        self.out_features = (
            out_features
        )

        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                degree + 1
            )
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.05
        )

        self.bias = nn.Parameter(
            torch.zeros(
                out_features
            )
        )

    def forward(
        self,
        x
    ):

        basis = chebyshev_basis(
            x,
            self.degree
        )

        output = torch.einsum(
            "bik,oik->bo",
            basis,
            self.coefficients
        )

        return (
            output
            + self.bias
        )

    def l1_penalty(
        self
    ):

        return torch.sum(
            torch.abs(
                self.coefficients
            )
        )


# ================================================================
# 18. GROUP BRANCH
# ================================================================

class GroupBranch(
    nn.Module
):

    def __init__(
        self,
        input_dim,
        embedding_dim,
        degree
    ):

        super().__init__()

        self.kan = (
            ChebyshevKANLayer(
                input_dim,
                embedding_dim,
                degree
            )
        )

        self.activation = nn.SiLU()

    def forward(
        self,
        x
    ):

        return self.activation(
            self.kan(x)
        )

    def l1_penalty(
        self
    ):

        return (
            self.kan.l1_penalty()
        )


# ================================================================
# 19. SHARED-FEATURE CGS-CHEBKAN
# ================================================================

class SharedCGSChebKAN(
    nn.Module
):

    def __init__(
        self,
        group_indices,
        degree=5,
        embedding_dim=16
    ):

        super().__init__()

        self.group_indices = (
            group_indices
        )

        self.demographic = (
            GroupBranch(
                input_dim=len(
                    group_indices[
                        "demographic"
                    ]
                ),
                embedding_dim=
                    embedding_dim,
                degree=degree,
            )
        )

        self.physiological = (
            GroupBranch(
                input_dim=len(
                    group_indices[
                        "physiological_metabolic"
                    ]
                ),
                embedding_dim=
                    embedding_dim,
                degree=degree,
            )
        )

        # Two-group fusion.
        self.gate_logits = nn.Parameter(
            torch.zeros(2)
        )

        self.output_layer = nn.Linear(
            embedding_dim,
            1
        )

    def forward(
        self,
        x
    ):

        x_demo = x[
            :,
            self.group_indices[
                "demographic"
            ]
        ]

        x_phys = x[
            :,
            self.group_indices[
                "physiological_metabolic"
            ]
        ]

        h_demo = self.demographic(
            x_demo
        )

        h_phys = self.physiological(
            x_phys
        )

        embeddings = torch.stack(
            [
                h_demo,
                h_phys,
            ],
            dim=1
        )

        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        fused = torch.sum(
            embeddings
            * gates.view(
                1,
                2,
                1
            ),
            dim=1
        )

        logits = self.output_layer(
            fused
        ).squeeze(1)

        return logits

    def kan_l1_penalty(
        self
    ):

        return (
            self.demographic.l1_penalty()
            + self.physiological.l1_penalty()
        )

    def gate_l1_penalty(
        self
    ):

        return torch.sum(
            torch.abs(
                self.gate_logits
            )
        )

    def get_gates(
        self
    ):

        with torch.no_grad():

            gates = torch.softmax(
                self.gate_logits,
                dim=0
            ).cpu().numpy()

        return {
            "demographic":
                float(gates[0]),

            "physiological_metabolic":
                float(gates[1]),
        }


# ================================================================
# 20. PARAMETER COUNT
# ================================================================

def count_parameters(
    model
):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ================================================================
# 21. INTERNAL VALIDATION SPLIT
# ================================================================
#
# UCI remains completely external.
#
# The Kaggle Development data are divided into:
#
#   90% training
#   10% internal validation
#
# The internal validation is used ONLY for early stopping.
# ================================================================

from sklearn.model_selection import train_test_split

train_df, val_df = train_test_split(
    kaggle_valid,
    test_size=0.10,
    stratify=kaggle_valid["target"],
    random_state=SEED
)

print()
print("=" * 80)
print("KAGGLE SHARED-FEATURE TRAINING SPLIT")
print("=" * 80)

print(
    "Training:",
    len(train_df)
)

print(
    "Internal validation:",
    len(val_df)
)

# ---------------------------------------------------------------
# Fit preprocessing again strictly on training subset.
# ---------------------------------------------------------------

train_imputer = SimpleImputer(
    strategy="median"
)

train_scaler = MinMaxScaler(
    feature_range=(-1, 1)
)

x_train = train_df[
    FEATURES
].astype(
    np.float32
)

y_train = train_df[
    "target"
].astype(
    int
).to_numpy()

x_val = val_df[
    FEATURES
].astype(
    np.float32
)

y_val = val_df[
    "target"
].astype(
    int
).to_numpy()

x_train = train_imputer.fit_transform(
    x_train
)

x_train = train_scaler.fit_transform(
    x_train
).astype(
    np.float32
)

x_val = train_scaler.transform(
    train_imputer.transform(
        x_val
    )
).astype(
    np.float32
)


# ================================================================
# 22. MODEL
# ================================================================

model = SharedCGSChebKAN(
    group_indices={
        "demographic": [
            FEATURES.index("age"),
            FEATURES.index("sex"),
        ],

        "physiological_metabolic": [
            FEATURES.index(
                "systolic_bp"
            ),

            FEATURES.index(
                "cholesterol_category"
            ),

            FEATURES.index(
                "elevated_glucose"
            ),
        ],
    },

    degree=CHEB_DEGREE,

    embedding_dim=
        GROUP_EMBEDDING,
)

model = model.to(
    DEVICE
)

print()
print(
    "Parameters:",
    count_parameters(model)
)


# ================================================================
# 23. TENSORS
# ================================================================

x_train_t = torch.tensor(
    x_train,
    dtype=torch.float32,
    device=DEVICE
)

y_train_t = torch.tensor(
    y_train,
    dtype=torch.float32,
    device=DEVICE
)

x_val_t = torch.tensor(
    x_val,
    dtype=torch.float32,
    device=DEVICE
)

y_val_t = torch.tensor(
    y_val,
    dtype=torch.float32,
    device=DEVICE
)


# ================================================================
# 24. DATALOADER
# ================================================================

from torch.utils.data import (
    TensorDataset,
    DataLoader,
)

train_dataset = TensorDataset(
    x_train_t,
    y_train_t
)

train_loader = DataLoader(
    train_dataset,
    batch_size=BATCH_SIZE,
    shuffle=True
)


# ================================================================
# 25. TRAINING
# ================================================================

criterion = nn.BCEWithLogitsLoss()

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=LEARNING_RATE,
    weight_decay=L2
)

best_auc = -np.inf
best_epoch = 0
best_state = None
patience_counter = 0

start_time = time.time()

print()
print("=" * 80)
print("TRAINING SHARED-FEATURE CGS-CHEBKAN")
print("=" * 80)

for epoch in range(
    1,
    MAX_EPOCHS + 1
):

    model.train()

    for xb, yb in train_loader:

        optimizer.zero_grad(
            set_to_none=True
        )

        logits = model(
            xb
        )

        bce = criterion(
            logits,
            yb
        )

        kan_penalty = (
            model.kan_l1_penalty()
        )

        gate_penalty = (
            model.gate_l1_penalty()
        )

        loss = (
            bce
            + KAN_L1 * kan_penalty
            + GATE_L1 * gate_penalty
        )

        loss.backward()

        optimizer.step()

    # ------------------------------------------------------------
    # Internal validation
    # ------------------------------------------------------------

    model.eval()

    with torch.no_grad():

        val_logits = model(
            x_val_t
        )

        val_probability = (
            torch.sigmoid(
                val_logits
            )
            .cpu()
            .numpy()
        )

    val_auc = roc_auc_score(
        y_val,
        val_probability
    )

    if val_auc > best_auc:

        best_auc = val_auc

        best_epoch = epoch

        best_state = {
            k: v.detach().cpu().clone()
            for k, v in
            model.state_dict().items()
        }

        patience_counter = 0

    else:

        patience_counter += 1

    if epoch == 1 or epoch % 10 == 0:

        print(
            f"Epoch {epoch:03d} | "
            f"Validation AUC: {val_auc:.6f}"
        )

    if patience_counter >= PATIENCE:

        print(
            "Early stopping at epoch:",
            epoch
        )

        break


# ================================================================
# 26. RESTORE BEST MODEL
# ================================================================

if best_state is not None:

    model.load_state_dict(
        best_state
    )

training_time = (
    time.time() - start_time
)

print()
print(
    "Best epoch:",
    best_epoch
)

print(
    "Best internal validation AUC:",
    f"{best_auc:.6f}"
)

print(
    "Training time:",
    f"{training_time / 60:.2f} minutes"
)


# ================================================================
# 27. SAVE MODEL
# ================================================================

model_path = os.path.join(
    RESULTS_MODELS,
    "implementation34_uci_shared_cgsc_hebkan.pt"
)

torch.save(
    {
        "model_state_dict":
            model.state_dict(),

        "features":
            FEATURES,

        "groups":
            GROUPS,

        "chebyshev_degree":
            CHEB_DEGREE,

        "group_embedding":
            GROUP_EMBEDDING,

        "learning_rate":
            LEARNING_RATE,

        "l2":
            L2,

        "kan_l1":
            KAN_L1,

        "gate_l1":
            GATE_L1,

        "best_epoch":
            best_epoch,

        "seed":
            SEED,

        "training_source":
            "Kaggle Development only",

        "external_validation_source":
            "Official UCI Heart Disease cohorts",
    },
    model_path
)

print(
    "Model saved:",
    model_path
)


# ================================================================
# 28. FINAL GROUP GATES
# ================================================================

gates = model.get_gates()

print()
print("Learned group gates:")

for name, value in gates.items():

    print(
        f"  {name}: {value:.6f}"
    )


# ================================================================
# 29. PREDICTION FUNCTION
# ================================================================

def predict(
    model,
    x
):

    model.eval()

    x_tensor = torch.tensor(
        x,
        dtype=torch.float32,
        device=DEVICE
    )

    with torch.no_grad():

        logits = model(
            x_tensor
        )

        probability = torch.sigmoid(
            logits
        ).cpu().numpy()

    return probability


# ================================================================
# 30. METRICS
# ================================================================

def evaluate(
    y_true,
    probability
):

    prediction = (
        probability >= 0.5
    ).astype(int)

    tn, fp, fn, tp = (
        confusion_matrix(
            y_true,
            prediction,
            labels=[0, 1]
        ).ravel()
    )

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {
        "n":
            len(y_true),

        "accuracy":
            accuracy_score(
                y_true,
                prediction
            ),

        "precision":
            precision_score(
                y_true,
                prediction,
                zero_division=0
            ),

        "sensitivity":
            sensitivity,

        "specificity":
            specificity,

        "f1":
            f1_score(
                y_true,
                prediction,
                zero_division=0
            ),

        "roc_auc":
            roc_auc_score(
                y_true,
                probability
            ),

        "pr_auc":
            average_precision_score(
                y_true,
                probability
            ),

        "brier":
            brier_score_loss(
                y_true,
                probability
            ),

        "positive_predictions":
            int(
                prediction.sum()
            ),

        "positive_true":
            int(
                np.sum(y_true)
            ),
    }


# ================================================================
# 31. EXTERNAL VALIDATION
# ================================================================

print()
print("=" * 80)
print("UCI EXTERNAL VALIDATION")
print("=" * 80)

external_results = []
external_predictions = {}


for cohort, df in uci.items():

    print()
    print("-" * 80)

    print(
        cohort.upper()
    )

    print("-" * 80)

    x_external = df[
        FEATURES
    ].astype(
        np.float32
    )

    y_external = df[
        TARGET_UCI
    ].astype(
        int
    ).to_numpy()

    # ------------------------------------------------------------
    # Apply preprocessing learned from Kaggle training only.
    # ------------------------------------------------------------

    x_external = train_scaler.transform(
        train_imputer.transform(
            x_external
        )
    ).astype(
        np.float32
    )

    probability = predict(
        model,
        x_external
    )

    metrics = evaluate(
        y_external,
        probability
    )

    metrics["cohort"] = cohort

    metrics["role"] = (
        "primary_external_validation"
        if cohort == "cleveland"
        else
        "secondary_external_validation"
        if cohort == "hungarian"
        else
        "sensitivity_analysis"
    )

    external_results.append(
        metrics
    )

    external_predictions[
        cohort
    ] = probability

    print(
        "N:",
        metrics["n"]
    )

    print(
        "Accuracy:",
        f"{metrics['accuracy']:.6f}"
    )

    print(
        "Precision:",
        f"{metrics['precision']:.6f}"
    )

    print(
        "Sensitivity:",
        f"{metrics['sensitivity']:.6f}"
    )

    print(
        "Specificity:",
        f"{metrics['specificity']:.6f}"
    )

    print(
        "F1:",
        f"{metrics['f1']:.6f}"
    )

    print(
        "ROC-AUC:",
        f"{metrics['roc_auc']:.6f}"
    )

    print(
        "PR-AUC:",
        f"{metrics['pr_auc']:.6f}"
    )

    print(
        "Brier:",
        f"{metrics['brier']:.6f}"
    )


# ================================================================
# 32. SAVE EXTERNAL RESULTS
# ================================================================

results_df = pd.DataFrame(
    external_results
)

results_df = results_df[
    [
        "cohort",
        "role",
        "n",
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "brier",
        "positive_predictions",
        "positive_true",
    ]
]

results_path = os.path.join(
    RESULTS_TABLES,
    "implementation34_uci_external_validation_results.csv"
)

results_df.to_csv(
    results_path,
    index=False
)


# ================================================================
# 33. SAVE PREDICTIONS
# ================================================================

prediction_rows = []

for cohort, df in uci.items():

    probability = (
        external_predictions[
            cohort
        ]
    )

    prediction = (
        probability >= 0.5
    ).astype(int)

    for i in range(
        len(df)
    ):

        row = {
            "cohort":
                cohort,

            "source_row":
                int(
                    df.iloc[i][
                        "source_row"
                    ]
                )
                if "source_row" in df.columns
                else i,

            "true_label":
                int(
                    df.iloc[i][
                        TARGET_UCI
                    ]
                ),

            "probability":
                float(
                    probability[i]
                ),

            "prediction":
                int(
                    prediction[i]
                ),
        }

        prediction_rows.append(
            row
        )

prediction_df = pd.DataFrame(
    prediction_rows
)

prediction_path = os.path.join(
    RESULTS_TABLES,
    "implementation34_uci_external_predictions.csv"
)

prediction_df.to_csv(
    prediction_path,
    index=False
)


# ================================================================
# 34. SAVE PROTOCOL
# ================================================================

protocol = {

    "experiment":
        "UCI External Validation — Shared-feature CGS-ChebKAN",

    "training_dataset":
        "Kaggle Cardiovascular Disease Development partition",

    "training_size":
        int(len(train_df)),

    "internal_validation_size":
        int(len(val_df)),

    "external_datasets": {
        "cleveland": 303,
        "hungarian": 262,
        "va": 100,
        "switzerland": 0,
    },

    "features":
        FEATURES,

    "groups":
        GROUPS,

    "chebyshev_degree":
        CHEB_DEGREE,

    "group_embedding":
        GROUP_EMBEDDING,

    "learning_rate":
        LEARNING_RATE,

    "l2":
        L2,

    "kan_l1":
        KAN_L1,

    "gate_l1":
        GATE_L1,

    "batch_size":
        BATCH_SIZE,

    "maximum_epochs":
        MAX_EPOCHS,

    "patience":
        PATIENCE,

    "adasyn":
        False,

    "conformal_prediction":
        False,

    "uci_used_for_training":
        False,

    "uci_used_for_hyperparameter_selection":
        False,

    "uci_used_for_preprocessing_fit":
        False,

    "imputation_fit_source":
        "Kaggle training subset only",

    "scaling_fit_source":
        "Kaggle training subset only",

    "external_validation_roles": {
        "cleveland":
            "primary",
        "hungarian":
            "secondary",
        "va":
            "sensitivity",
        "switzerland":
            "excluded",
    },

    "seed":
        SEED,
}

protocol_path = os.path.join(
    RESULTS_TABLES,
    "implementation34_uci_external_validation_protocol.json"
)

with open(
    protocol_path,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        protocol,
        f,
        indent=2
    )


# ================================================================
# 35. FINAL SUMMARY
# ================================================================

print()
print("=" * 80)

print(
    "UCI EXTERNAL VALIDATION FINAL SUMMARY"
)

print("=" * 80)

print()
print(
    "Training source: Kaggle Development only"
)

print(
    "UCI used for training: NO"
)

print(
    "UCI used for hyperparameter selection: NO"
)

print(
    "UCI used for preprocessing fitting: NO"
)

print(
    "ADASYN: NO"
)

print(
    "Conformal prediction: NO"
)

print()
print(
    "Group gates:"
)

for name, value in gates.items():

    print(
        f"  {name}: {value:.6f}"
    )

print()

for _, row in results_df.iterrows():

    print(
        f"{row['cohort'].upper()} "
        f"(n={int(row['n'])}): "
        f"ROC-AUC={row['roc_auc']:.6f}, "
        f"PR-AUC={row['pr_auc']:.6f}, "
        f"F1={row['f1']:.6f}, "
        f"Sensitivity={row['sensitivity']:.6f}, "
        f"Specificity={row['specificity']:.6f}"
    )

print()
print(
    "Results:",
    results_path
)

print(
    "Predictions:",
    prediction_path
)

print(
    "Protocol:",
    protocol_path
)

print()
print("=" * 80)
print("IMPLEMENTATION 34 COMPLETE")
print("=" * 80)