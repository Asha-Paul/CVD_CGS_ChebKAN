# ================================================================
# AUDIT 13: KAGGLE <-> UCI FEATURE HARMONIZATION AUDIT
# ================================================================
#
# Purpose:
#   Verify and freeze the feature mappings required for genuine
#   Kaggle -> UCI external validation.
#
# Shared external-validation variables:
#
#   Clinical concept       Kaggle              UCI
#   ------------------------------------------------------------
#   Age                    age                 age
#   Sex                    gender              sex
#   Systolic BP            ap_hi               trestbps
#   Cholesterol            cholesterol         chol
#   Elevated glucose       gluc                fbs
#   Target                 cardio              target
#
# Frozen harmonization:
#
#   1. AGE
#      Kaggle age is stored in days.
#      Convert:
#          age_years = age / 365.25
#
#      UCI age is already in years.
#
#   2. SEX
#      Kaggle:
#          gender = 1 / 2
#
#      UCI:
#          sex = 0 / 1
#
#      Harmonization:
#          Kaggle gender=1 -> 0
#          Kaggle gender=2 -> 1
#          UCI sex=0 -> 0
#          UCI sex=1 -> 1
#
#   3. SYSTOLIC BP
#      Kaggle:
#          ap_hi
#
#      UCI:
#          trestbps
#
#      Shared model uses systolic BP only.
#
#      Kaggle BP quality-control rules from Audit 10:
#          70 <= ap_hi <= 250
#
#      Invalid Kaggle BP values are represented as NaN.
#
#   4. CHOLESTEROL
#
#      Kaggle cholesterol is ordinal:
#          1 = normal
#          2 = above normal
#          3 = well above normal
#
#      UCI cholesterol is continuous serum cholesterol.
#
#      Frozen UCI mapping:
#          chol < 200       -> 1
#          200 <= chol <240 -> 2
#          chol >= 240      -> 3
#
#      IMPORTANT:
#      These thresholds are an imposed harmonization rule.
#      They are not claimed to reproduce the exact semantics
#      of the Kaggle source categories.
#
#   5. GLUCOSE
#
#      Kaggle gluc:
#          1 = category 1
#          2 = category 2
#          3 = category 3
#
#      Frozen practical harmonization:
#          Kaggle gluc=1 -> 0
#          Kaggle gluc=2 -> 1
#          Kaggle gluc=3 -> 1
#
#      UCI:
#          fbs=0 -> 0
#          fbs=1 -> 1
#
#      IMPORTANT:
#      This is an "elevated-glucose indicator", NOT a diabetes
#      diagnosis. UCI fbs specifically refers to fasting blood
#      sugar >120 mg/dL, whereas the Kaggle gluc metadata do not
#      establish exact measurement equivalence.
#
#   6. TARGET
#
#      Kaggle:
#          cardio=0 -> 0
#          cardio=1 -> 1
#
#      UCI:
#          target=0 -> 0
#          target=1,2,3,4 -> 1
#
# ================================================================
#
# IMPORTANT:
#   - No records are deleted.
#   - No imputation is performed.
#   - No model is trained.
#   - No train/test split is performed.
#   - This script is an AUDIT ONLY.
#
# ================================================================

from pathlib import Path
import zipfile

import numpy as np
import pandas as pd


# ================================================================
# 1. PATHS
# ================================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

KAGGLE_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

UCI_ZIP_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ================================================================
# 2. OUTPUT FILES
# ================================================================

SUMMARY_OUTPUT = (
    RESULTS_DIR
    / "audit13_harmonization_summary.csv"
)

KAGGLE_DIST_OUTPUT = (
    RESULTS_DIR
    / "audit13_kaggle_harmonized_distribution.csv"
)

UCI_DIST_OUTPUT = (
    RESULTS_DIR
    / "audit13_uci_harmonized_distribution.csv"
)

COMPARISON_OUTPUT = (
    RESULTS_DIR
    / "audit13_kaggle_uci_distribution_comparison.csv"
)

EXAMPLE_OUTPUT = (
    RESULTS_DIR
    / "audit13_harmonization_examples.csv"
)


# ================================================================
# 3. UCI FILES
# ================================================================

UCI_FILES = {
    "Cleveland":
        "processed.cleveland.data",

    "Hungarian":
        "processed.hungarian.data",

    "Switzerland":
        "processed.switzerland.data",

    "VA Long Beach":
        "processed.va.data"
}


UCI_COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target"
]


# ================================================================
# 4. HEADER
# ================================================================

print("=" * 80)
print("AUDIT 13: KAGGLE <-> UCI FEATURE HARMONIZATION AUDIT")
print("=" * 80)


# ================================================================
# 5. CHECK FILES
# ================================================================

print("\nChecking input files...")

if not KAGGLE_PATH.exists():

    raise FileNotFoundError(
        f"Kaggle dataset not found:\n{KAGGLE_PATH}"
    )

if not UCI_ZIP_PATH.exists():

    raise FileNotFoundError(
        f"UCI ZIP not found:\n{UCI_ZIP_PATH}"
    )

print(
    f"Kaggle : {KAGGLE_PATH}"
)

print(
    f"UCI    : {UCI_ZIP_PATH}"
)


# ================================================================
# 6. LOAD KAGGLE
# ================================================================

print("\n" + "=" * 80)
print("LOADING KAGGLE")
print("=" * 80)

kaggle = pd.read_csv(
    KAGGLE_PATH,
    sep=","
)

print(
    f"Rows    : {len(kaggle):,}"
)

print(
    f"Columns : {len(kaggle.columns)}"
)


# ================================================================
# 7. KAGGLE AGE HARMONIZATION
# ================================================================

print("\n" + "=" * 80)
print("KAGGLE AGE HARMONIZATION")
print("=" * 80)

kaggle_h = pd.DataFrame()

kaggle_h["age_years"] = (
    pd.to_numeric(
        kaggle["age"],
        errors="coerce"
    )
    / 365.25
)

print(
    "Original Kaggle age unit: days"
)

print(
    "Harmonized unit: years"
)

print(
    f"Minimum age: "
    f"{kaggle_h['age_years'].min():.3f}"
)

print(
    f"Maximum age: "
    f"{kaggle_h['age_years'].max():.3f}"
)

print(
    f"Mean age: "
    f"{kaggle_h['age_years'].mean():.3f}"
)


# ================================================================
# 8. KAGGLE SEX HARMONIZATION
# ================================================================

print("\n" + "=" * 80)
print("KAGGLE SEX HARMONIZATION")
print("=" * 80)

print(
    "Original gender values:",
    sorted(
        kaggle["gender"]
        .dropna()
        .unique()
        .tolist()
    )
)

# Frozen mapping:
# Kaggle gender 1 -> 0
# Kaggle gender 2 -> 1

kaggle_h["sex"] = (
    kaggle["gender"]
    .map({
        1: 0,
        2: 1
    })
)

print("\nHarmonized sex distribution:")

print(
    kaggle_h["sex"]
    .value_counts(dropna=False)
    .sort_index()
)


# ================================================================
# 9. KAGGLE SYSTOLIC BP
# ================================================================

print("\n" + "=" * 80)
print("KAGGLE SYSTOLIC BP")
print("=" * 80)

kaggle_h["sbp"] = pd.to_numeric(
    kaggle["ap_hi"],
    errors="coerce"
)

kaggle_sbp_valid = (
    kaggle_h["sbp"].notna()
    & (kaggle_h["sbp"] >= 70)
    & (kaggle_h["sbp"] <= 250)
)

invalid_kaggle_sbp = (
    ~kaggle_sbp_valid
)

print(
    f"Valid SBP : "
    f"{kaggle_sbp_valid.sum():,} "
    f"({100 * kaggle_sbp_valid.mean():.3f}%)"
)

print(
    f"Invalid SBP : "
    f"{invalid_kaggle_sbp.sum():,} "
    f"({100 * invalid_kaggle_sbp.mean():.3f}%)"
)

# Represent invalid values as missing for harmonization audit.
kaggle_h.loc[
    invalid_kaggle_sbp,
    "sbp"
] = np.nan


# ================================================================
# 10. KAGGLE CHOLESTEROL
# ================================================================

print("\n" + "=" * 80)
print("KAGGLE CHOLESTEROL")
print("=" * 80)

print(
    "Original Kaggle cholesterol values:",
    sorted(
        kaggle["cholesterol"]
        .dropna()
        .unique()
        .tolist()
    )
)

# Kaggle categories are retained as the harmonized
# ordinal representation.

kaggle_h["cholesterol_category"] = (
    pd.to_numeric(
        kaggle["cholesterol"],
        errors="coerce"
    )
)

print("\nKaggle cholesterol distribution:")

print(
    kaggle_h["cholesterol_category"]
    .value_counts(dropna=False)
    .sort_index()
)


# ================================================================
# 11. KAGGLE GLUCOSE HARMONIZATION
# ================================================================

print("\n" + "=" * 80)
print("KAGGLE GLUCOSE HARMONIZATION")
print("=" * 80)

print(
    "Original Kaggle gluc values:",
    sorted(
        kaggle["gluc"]
        .dropna()
        .unique()
        .tolist()
    )
)

# Frozen mapping:
# 1 -> 0
# 2 -> 1
# 3 -> 1

kaggle_h["elevated_glucose"] = (
    kaggle["gluc"]
    .map({
        1: 0,
        2: 1,
        3: 1
    })
)

print("\nHarmonized elevated-glucose distribution:")

print(
    kaggle_h["elevated_glucose"]
    .value_counts(dropna=False)
    .sort_index()
)


# ================================================================
# 12. KAGGLE TARGET
# ================================================================

kaggle_h["target"] = (
    pd.to_numeric(
        kaggle["cardio"],
        errors="coerce"
    )
)

print("\nKaggle target distribution:")

print(
    kaggle_h["target"]
    .value_counts(dropna=False)
    .sort_index()
)


# ================================================================
# 13. LOAD UCI COHORTS
# ================================================================

print("\n" + "=" * 80)
print("LOADING UCI COHORTS")
print("=" * 80)

uci_data = {}

with zipfile.ZipFile(
    UCI_ZIP_PATH,
    "r"
) as z:

    zip_names = z.namelist()

    for cohort, filename in UCI_FILES.items():

        if filename not in zip_names:

            print(
                f"{cohort}: FILE NOT FOUND"
            )

            continue

        with z.open(filename) as f:

            df = pd.read_csv(
                f,
                header=None,
                names=UCI_COLUMNS,
                na_values=["?"],
                skipinitialspace=True
            )

        uci_data[cohort] = df.copy()

        print(
            f"{cohort:<20} : "
            f"{len(df):,} rows"
        )


# ================================================================
# 14. UCI HARMONIZATION FUNCTION
# ================================================================

def harmonize_uci(df):

    out = pd.DataFrame()

    # ------------------------------------------------------------
    # AGE
    # ------------------------------------------------------------

    out["age_years"] = pd.to_numeric(
        df["age"],
        errors="coerce"
    )


    # ------------------------------------------------------------
    # SEX
    # ------------------------------------------------------------

    out["sex"] = pd.to_numeric(
        df["sex"],
        errors="coerce"
    )


    # ------------------------------------------------------------
    # SYSTOLIC BP
    # ------------------------------------------------------------

    out["sbp"] = pd.to_numeric(
        df["trestbps"],
        errors="coerce"
    )


    # ------------------------------------------------------------
    # CHOLESTEROL
    # ------------------------------------------------------------

    chol = pd.to_numeric(
        df["chol"],
        errors="coerce"
    )

    # IMPORTANT:
    # Zero is not treated as a valid serum cholesterol
    # measurement for harmonization.

    chol = chol.mask(
        chol <= 0,
        np.nan
    )

    out["cholesterol_category"] = np.select(
        [
            chol < 200,

            (chol >= 200)
            & (chol < 240),

            chol >= 240
        ],
        [
            1,
            2,
            3
        ],
        default=np.nan
    )


    # ------------------------------------------------------------
    # GLUCOSE
    # ------------------------------------------------------------

    fbs = pd.to_numeric(
        df["fbs"],
        errors="coerce"
    )

    out["elevated_glucose"] = fbs


    # ------------------------------------------------------------
    # TARGET
    # ------------------------------------------------------------

    target = pd.to_numeric(
        df["target"],
        errors="coerce"
    )

    out["target"] = target.map(
        lambda x:
            np.nan
            if pd.isna(x)
            else (
                0
                if x == 0
                else 1
            )
    )

    return out


# ================================================================
# 15. HARMONIZE UCI
# ================================================================

uci_harmonized = {}

for cohort, df in uci_data.items():

    uci_harmonized[cohort] = (
        harmonize_uci(df)
    )


# ================================================================
# 16. UCI HARMONIZED SUMMARY
# ================================================================

print("\n" + "=" * 80)
print("UCI HARMONIZED FEATURE SUMMARY")
print("=" * 80)

for cohort, df in uci_harmonized.items():

    print(
        f"\n{cohort}"
    )

    print("-" * 60)

    for col in [
        "age_years",
        "sex",
        "sbp",
        "cholesterol_category",
        "elevated_glucose",
        "target"
    ]:

        missing = int(
            df[col].isna().sum()
        )

        print(
            f"{col:<25} "
            f"missing = {missing:>4,}"
        )


# ================================================================
# 17. CHOLESTEROL MAPPING AUDIT
# ================================================================

print("\n" + "=" * 80)
print("UCI CHOLESTEROL CATEGORY MAPPING")
print("=" * 80)

for cohort, original in uci_data.items():

    chol = pd.to_numeric(
        original["chol"],
        errors="coerce"
    )

    chol = chol.mask(
        chol <= 0,
        np.nan
    )

    category = np.select(
        [
            chol < 200,

            (chol >= 200)
            & (chol < 240),

            chol >= 240
        ],
        [
            1,
            2,
            3
        ],
        default=np.nan
    )

    temp = pd.DataFrame({
        "original_chol": chol,
        "mapped_category": category
    })

    print(
        f"\n{cohort}"
    )

    print(
        temp[
            "mapped_category"
        ]
        .value_counts(dropna=False)
        .sort_index()
    )


# ================================================================
# 18. AGE DISTRIBUTION COMPARISON
# ================================================================

print("\n" + "=" * 80)
print("AGE DISTRIBUTION COMPARISON")
print("=" * 80)

age_comparison_rows = []

age_comparison_rows.append({

    "dataset":
        "Kaggle",

    "cohort":
        "Kaggle",

    "n":
        kaggle_h["age_years"].notna().sum(),

    "mean":
        kaggle_h["age_years"].mean(),

    "std":
        kaggle_h["age_years"].std(),

    "min":
        kaggle_h["age_years"].min(),

    "median":
        kaggle_h["age_years"].median(),

    "max":
        kaggle_h["age_years"].max()
})


for cohort, df in uci_harmonized.items():

    age_comparison_rows.append({

        "dataset":
            "UCI",

        "cohort":
            cohort,

        "n":
            df["age_years"].notna().sum(),

        "mean":
            df["age_years"].mean(),

        "std":
            df["age_years"].std(),

        "min":
            df["age_years"].min(),

        "median":
            df["age_years"].median(),

        "max":
            df["age_years"].max()
    })


age_comparison_df = pd.DataFrame(
    age_comparison_rows
)

print(
    age_comparison_df.to_string(
        index=False
    )
)


# ================================================================
# 19. SEX DISTRIBUTION COMPARISON
# ================================================================

print("\n" + "=" * 80)
print("SEX DISTRIBUTION COMPARISON")
print("=" * 80)

for dataset_name, df in [
    ("Kaggle", kaggle_h)
]:

    print(
        f"\n{dataset_name}"
    )

    print(
        df["sex"]
        .value_counts(
            dropna=False
        )
        .sort_index()
    )


for cohort, df in uci_harmonized.items():

    print(
        f"\nUCI - {cohort}"
    )

    print(
        df["sex"]
        .value_counts(
            dropna=False
        )
        .sort_index()
    )


# ================================================================
# 20. SYSTOLIC BP DISTRIBUTION
# ================================================================

print("\n" + "=" * 80)
print("SYSTOLIC BP DISTRIBUTION")
print("=" * 80)

sbp_rows = []

sbp_rows.append({

    "dataset":
        "Kaggle",

    "cohort":
        "Kaggle",

    "n":
        kaggle_h["sbp"].notna().sum(),

    "mean":
        kaggle_h["sbp"].mean(),

    "std":
        kaggle_h["sbp"].std(),

    "min":
        kaggle_h["sbp"].min(),

    "median":
        kaggle_h["sbp"].median(),

    "max":
        kaggle_h["sbp"].max()
})


for cohort, df in uci_harmonized.items():

    sbp_rows.append({

        "dataset":
            "UCI",

        "cohort":
            cohort,

        "n":
            df["sbp"].notna().sum(),

        "mean":
            df["sbp"].mean(),

        "std":
            df["sbp"].std(),

        "min":
            df["sbp"].min(),

        "median":
            df["sbp"].median(),

        "max":
            df["sbp"].max()
    })


sbp_comparison_df = pd.DataFrame(
    sbp_rows
)

print(
    sbp_comparison_df.to_string(
        index=False
    )
)


# ================================================================
# 21. TARGET DISTRIBUTION
# ================================================================

print("\n" + "=" * 80)
print("HARMONIZED TARGET DISTRIBUTION")
print("=" * 80)

target_rows = []

target_rows.append({

    "dataset":
        "Kaggle",

    "cohort":
        "Kaggle",

    "target_0":
        int(
            (kaggle_h["target"] == 0)
            .sum()
        ),

    "target_1":
        int(
            (kaggle_h["target"] == 1)
            .sum()
        )
})


for cohort, df in uci_harmonized.items():

    target_rows.append({

        "dataset":
            "UCI",

        "cohort":
            cohort,

        "target_0":
            int(
                (df["target"] == 0)
                .sum()
            ),

        "target_1":
            int(
                (df["target"] == 1)
                .sum()
            )
    })


target_comparison_df = pd.DataFrame(
    target_rows
)

target_comparison_df["total"] = (
    target_comparison_df["target_0"]
    + target_comparison_df["target_1"]
)

target_comparison_df["positive_rate"] = (
    target_comparison_df["target_1"]
    / target_comparison_df["total"]
)

print(
    target_comparison_df.to_string(
        index=False
    )
)


# ================================================================
# 22. COMPLETE SHARED-FEATURE COUNTS
# ================================================================

print("\n" + "=" * 80)
print("COMPLETE HARMONIZED SHARED-FEATURE RECORDS")
print("=" * 80)

comparison_rows = []

kaggle_complete = kaggle_h[
    [
        "age_years",
        "sex",
        "sbp",
        "cholesterol_category",
        "elevated_glucose",
        "target"
    ]
].notna().all(axis=1)

comparison_rows.append({

    "dataset":
        "Kaggle",

    "cohort":
        "Kaggle",

    "total_records":
        len(kaggle_h),

    "complete_shared_records":
        int(kaggle_complete.sum()),

    "complete_percentage":
        100 * kaggle_complete.mean()
})


for cohort, df in uci_harmonized.items():

    complete = df[
        [
            "age_years",
            "sex",
            "sbp",
            "cholesterol_category",
            "elevated_glucose",
            "target"
        ]
    ].notna().all(axis=1)

    comparison_rows.append({

        "dataset":
            "UCI",

        "cohort":
            cohort,

        "total_records":
            len(df),

        "complete_shared_records":
            int(complete.sum()),

        "complete_percentage":
            100 * complete.mean()
    })


complete_comparison_df = pd.DataFrame(
    comparison_rows
)

print(
    complete_comparison_df.to_string(
        index=False
    )
)


# ================================================================
# 23. SAVE DISTRIBUTIONS
# ================================================================

kaggle_dist_rows = []

for feature in [
    "sex",
    "cholesterol_category",
    "elevated_glucose",
    "target"
]:

    counts = (
        kaggle_h[feature]
        .value_counts(dropna=False)
        .sort_index()
    )

    for value, count in counts.items():

        kaggle_dist_rows.append({

            "dataset":
                "Kaggle",

            "feature":
                feature,

            "value":
                value,

            "count":
                int(count),

            "percentage":
                100 * count / len(kaggle_h)
        })


kaggle_dist_df = pd.DataFrame(
    kaggle_dist_rows
)

kaggle_dist_df.to_csv(
    KAGGLE_DIST_OUTPUT,
    index=False
)


uci_dist_rows = []

for cohort, df in uci_harmonized.items():

    for feature in [
        "sex",
        "cholesterol_category",
        "elevated_glucose",
        "target"
    ]:

        counts = (
            df[feature]
            .value_counts(dropna=False)
            .sort_index()
        )

        for value, count in counts.items():

            uci_dist_rows.append({

                "cohort":
                    cohort,

                "feature":
                    feature,

                "value":
                    value,

                "count":
                    int(count),

                "percentage":
                    100 * count / len(df)
            })


uci_dist_df = pd.DataFrame(
    uci_dist_rows
)

uci_dist_df.to_csv(
    UCI_DIST_OUTPUT,
    index=False
)


# ================================================================
# 24. SAVE COMPARISON TABLE
# ================================================================

comparison_df = pd.concat(
    [
        age_comparison_df.assign(
            variable="age_years"
        ),

        sbp_comparison_df.assign(
            variable="sbp"
        )
    ],
    ignore_index=True
)

comparison_df.to_csv(
    COMPARISON_OUTPUT,
    index=False
)


# ================================================================
# 25. HARMONIZATION EXAMPLES
# ================================================================

example_rows = []

# ------------------------------------------------
# Kaggle examples
# ------------------------------------------------

kaggle_examples = kaggle[
    [
        "id",
        "age",
        "gender",
        "ap_hi",
        "cholesterol",
        "gluc",
        "cardio"
    ]
].head(20).copy()

for _, row in kaggle_examples.iterrows():

    example_rows.append({

        "dataset":
            "Kaggle",

        "cohort":
            "Kaggle",

        "original_age":
            row["age"],

        "harmonized_age_years":
            row["age"] / 365.25,

        "original_sex":
            row["gender"],

        "harmonized_sex":
            {1: 0, 2: 1}.get(
                row["gender"],
                np.nan
            ),

        "original_sbp":
            row["ap_hi"],

        "harmonized_sbp":
            row["ap_hi"]
            if (
                70
                <= row["ap_hi"]
                <= 250
            )
            else np.nan,

        "original_cholesterol":
            row["cholesterol"],

        "harmonized_cholesterol":
            row["cholesterol"],

        "original_glucose":
            row["gluc"],

        "harmonized_glucose":
            {
                1: 0,
                2: 1,
                3: 1
            }.get(
                row["gluc"],
                np.nan
            ),

        "original_target":
            row["cardio"],

        "harmonized_target":
            row["cardio"]
    })


# ------------------------------------------------
# UCI examples
# ------------------------------------------------

for cohort, df in uci_data.items():

    temp = harmonize_uci(df)

    original_examples = df.head(5)

    for idx in original_examples.index:

        row = df.loc[idx]
        hrow = temp.loc[idx]

        example_rows.append({

            "dataset":
                "UCI",

            "cohort":
                cohort,

            "original_age":
                row["age"],

            "harmonized_age_years":
                hrow["age_years"],

            "original_sex":
                row["sex"],

            "harmonized_sex":
                hrow["sex"],

            "original_sbp":
                row["trestbps"],

            "harmonized_sbp":
                hrow["sbp"],

            "original_cholesterol":
                row["chol"],

            "harmonized_cholesterol":
                hrow["cholesterol_category"],

            "original_glucose":
                row["fbs"],

            "harmonized_glucose":
                hrow["elevated_glucose"],

            "original_target":
                row["target"],

            "harmonized_target":
                hrow["target"]
        })


examples_df = pd.DataFrame(
    example_rows
)

examples_df.to_csv(
    EXAMPLE_OUTPUT,
    index=False
)


# ================================================================
# 26. FINAL SUMMARY
# ================================================================

summary_rows = [

    {
        "variable":
            "Age",

        "Kaggle_source":
            "age (days)",

        "UCI_source":
            "age (years)",

        "harmonization":
            "Kaggle / 365.25; UCI unchanged",

        "unit":
            "years"
    },

    {
        "variable":
            "Sex",

        "Kaggle_source":
            "gender (1/2)",

        "UCI_source":
            "sex (0/1)",

        "harmonization":
            "Kaggle 1->0, 2->1; UCI unchanged",

        "unit":
            "binary"
    },

    {
        "variable":
            "Systolic BP",

        "Kaggle_source":
            "ap_hi",

        "UCI_source":
            "trestbps",

        "harmonization":
            "Direct systolic BP correspondence",

        "unit":
            "mmHg"
    },

    {
        "variable":
            "Cholesterol",

        "Kaggle_source":
            "cholesterol (1/2/3)",

        "UCI_source":
            "chol (continuous)",

        "harmonization":
            "<200->1; 200-239->2; >=240->3",

        "unit":
            "ordinal category"
    },

    {
        "variable":
            "Elevated glucose",

        "Kaggle_source":
            "gluc (1/2/3)",

        "UCI_source":
            "fbs (0/1)",

        "harmonization":
            "Kaggle 1->0; 2/3->1; UCI unchanged",

        "unit":
            "binary indicator"
    },

    {
        "variable":
            "Target",

        "Kaggle_source":
            "cardio (0/1)",

        "UCI_source":
            "target (0-4)",

        "harmonization":
            "0->0; 1-4->1",

        "unit":
            "binary"
    }
]

summary_df = pd.DataFrame(
    summary_rows
)

summary_df.to_csv(
    SUMMARY_OUTPUT,
    index=False
)


# ================================================================
# 27. PRINT FROZEN MAPPING
# ================================================================

print("\n" + "=" * 80)
print("FROZEN HARMONIZATION TABLE")
print("=" * 80)

print(
    summary_df.to_string(
        index=False
    )
)


# ================================================================
# 28. FINAL STATUS
# ================================================================

print("\n" + "=" * 80)
print("AUDIT 13 COMPLETE")
print("=" * 80)

print("\nOutputs:")

print(
    "\nHarmonization summary:"
)
print(SUMMARY_OUTPUT)

print(
    "\nKaggle distributions:"
)
print(KAGGLE_DIST_OUTPUT)

print(
    "\nUCI distributions:"
)
print(UCI_DIST_OUTPUT)

print(
    "\nContinuous-variable comparison:"
)
print(COMPARISON_OUTPUT)

print(
    "\nHarmonization examples:"
)
print(EXAMPLE_OUTPUT)

print("\nIMPORTANT:")
print("No records were deleted.")
print("No imputation was performed.")
print("No model was trained.")
print("No train/test split was performed.")
print("No permanent dataset modification was performed.")
print("The target mapping is used only for this audit.")