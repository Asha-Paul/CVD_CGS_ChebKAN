# ============================================================
# IMPLEMENTATION 41
# CALIBRATION + DECISION CURVE ANALYSIS
#
# Purpose:
#   Evaluate probabilistic calibration and clinical utility
#   using already-generated predictions.
#
# Datasets:
#   1. Kaggle locked test = 14,000
#   2. Cleveland = 303
#   3. Hungarian = 262
#   4. VA Long Beach = 100
#
# IMPORTANT:
#   - No model retraining
#   - No hyperparameter tuning
#   - No threshold re-selection
#   - No UCI-based model development
#   - No changes to the frozen model
#
# Calibration:
#   - Calibration-in-the-large / intercept
#   - Calibration slope
#   - ECE
#   - Maximum calibration error
#   - Brier score
#
# Clinical utility:
#   - Decision Curve Analysis
#   - Net benefit
#   - Treat-all strategy
#   - Treat-none strategy
#
# Bootstrap:
#   2,000 stratified repetitions
#   95% percentile bootstrap intervals
#
# ============================================================

import os
import json
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    brier_score_loss
)

warnings.filterwarnings("ignore")


# ============================================================
# 1. CONFIGURATION
# ============================================================

SEED = 20261006

N_BOOTSTRAP = 2000

ALPHA = 0.05

# Frozen threshold from Implementation 39
FROZEN_THRESHOLD = 0.477343

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

RESULTS_DIR = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

FIGURES_DIR = os.path.join(
    PROJECT_ROOT,
    "results",
    "figures"
)

os.makedirs(
    RESULTS_DIR,
    exist_ok=True
)

os.makedirs(
    FIGURES_DIR,
    exist_ok=True
)


# ============================================================
# 2. INPUT FILES
# ============================================================

KAGGLE_FILE = os.path.join(
    RESULTS_DIR,
    "implementation39_locked_test_predictions.csv"
)

UCI_FILE = os.path.join(
    RESULTS_DIR,
    "implementation34_uci_external_predictions.csv"
)


# ============================================================
# 3. GENERAL SETTINGS
# ============================================================

# Calibration bins
N_CALIBRATION_BINS = 10

# DCA thresholds.
#
# We avoid 0 and 1 because the DCA formula contains:
#
#       pt / (1 - pt)
#
DCA_THRESHOLDS = np.arange(
    0.01,
    0.96,
    0.01
)


# ============================================================
# 4. HEADER
# ============================================================

print("\n" + "=" * 70)
print("IMPLEMENTATION 41")
print("CALIBRATION + DECISION CURVE ANALYSIS")
print("=" * 70)

print("\nConfiguration")
print("-" * 70)

print(
    f"Bootstrap repetitions : {N_BOOTSTRAP:,}"
)

print(
    f"Confidence level      : {100 * (1 - ALPHA):.0f}%"
)

print(
    f"Calibration bins      : {N_CALIBRATION_BINS}"
)

print(
    f"DCA thresholds        : "
    f"{DCA_THRESHOLDS[0]:.2f}–"
    f"{DCA_THRESHOLDS[-1]:.2f}"
)

print(
    f"Frozen operating threshold: "
    f"{FROZEN_THRESHOLD:.6f}"
)


# ============================================================
# 5. HELPER FUNCTIONS
# ============================================================

def sigmoid(x):
    """
    Numerically stable sigmoid.
    """

    x = np.clip(
        x,
        -40,
        40
    )

    return 1.0 / (
        1.0 + np.exp(-x)
    )


def logit(p):
    """
    Convert probability to log-odds.
    """

    p = np.clip(
        p,
        1e-6,
        1 - 1e-6
    )

    return np.log(
        p / (1 - p)
    )


# ============================================================
# 6. CALIBRATION INTERCEPT + SLOPE
# ============================================================

def fit_calibration_model(
    y_true,
    probability,
    max_iterations=100
):
    """
    Estimate calibration intercept and slope using
    logistic calibration.

    Model:

        logit(P(Y=1)) =
            intercept +
            slope * logit(predicted_probability)

    The fitting is performed with Newton-Raphson / IRLS
    without regularization.
    """

    y = np.asarray(
        y_true,
        dtype=float
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    lp = logit(p)

    X = np.column_stack(
        [
            np.ones(len(lp)),
            lp
        ]
    )

    beta = np.array(
        [0.0, 1.0],
        dtype=float
    )

    converged = False

    for _ in range(
        max_iterations
    ):

        eta = X @ beta

        mu = sigmoid(
            eta
        )

        # Score
        gradient = (
            X.T @ (y - mu)
        )

        # Hessian
        weights = (
            mu * (1 - mu)
        )

        H = (
            X.T
            @
            (weights[:, None] * X)
        )

        # Small numerical stabilization.
        H = H + (
            np.eye(2)
            * 1e-10
        )

        try:

            step = np.linalg.solve(
                H,
                gradient
            )

        except np.linalg.LinAlgError:

            break

        beta_new = (
            beta + step
        )

        if np.max(
            np.abs(
                beta_new - beta
            )
        ) < 1e-8:

            beta = beta_new
            converged = True
            break

        beta = beta_new

    return {
        "intercept": float(beta[0]),
        "slope": float(beta[1]),
        "converged": bool(converged)
    }


# ============================================================
# 7. CALIBRATION-IN-THE-LARGE
# ============================================================

def calibration_in_the_large(
    y_true,
    probability,
    max_iterations=100
):
    """
    Calibration-in-the-large.

    This estimates an intercept while keeping the
    original prediction logit as an offset:

        logit(P(Y=1)) =
            intercept + logit(predicted_probability)

    Ideal value:
        intercept = 0
    """

    y = np.asarray(
        y_true,
        dtype=float
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    lp = logit(p)

    intercept = 0.0

    for _ in range(
        max_iterations
    ):

        eta = (
            intercept + lp
        )

        mu = sigmoid(
            eta
        )

        gradient = np.sum(
            y - mu
        )

        hessian = -np.sum(
            mu * (1 - mu)
        )

        if abs(hessian) < 1e-12:
            break

        step = (
            gradient / hessian
        )

        new_intercept = (
            intercept - step
        )

        if abs(
            new_intercept
            - intercept
        ) < 1e-8:

            intercept = (
                new_intercept
            )

            break

        intercept = (
            new_intercept
        )

    return float(
        intercept
    )


# ============================================================
# 8. ECE
# ============================================================

def expected_calibration_error(
    y_true,
    probability,
    n_bins=10
):
    """
    Equal-width Expected Calibration Error.

    ECE =
        sum(
            n_bin / N *
            |observed_frequency - mean_probability|
        )
    """

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    for i in range(
        n_bins
    ):

        if i == n_bins - 1:

            mask = (
                (p >= edges[i])
                &
                (p <= edges[i + 1])
            )

        else:

            mask = (
                (p >= edges[i])
                &
                (p < edges[i + 1])
            )

        if not np.any(mask):
            continue

        observed = np.mean(
            y[mask]
        )

        predicted = np.mean(
            p[mask]
        )

        fraction = (
            np.sum(mask)
            /
            len(y)
        )

        ece += (
            fraction
            *
            abs(
                observed
                -
                predicted
            )
        )

    return float(
        ece
    )


# ============================================================
# 9. MAXIMUM CALIBRATION ERROR
# ============================================================

def maximum_calibration_error(
    y_true,
    probability,
    n_bins=10
):
    """
    Maximum absolute difference between
    observed and predicted probabilities
    across calibration bins.
    """

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    errors = []

    for i in range(
        n_bins
    ):

        if i == n_bins - 1:

            mask = (
                (p >= edges[i])
                &
                (p <= edges[i + 1])
            )

        else:

            mask = (
                (p >= edges[i])
                &
                (p < edges[i + 1])
            )

        if not np.any(mask):
            continue

        observed = np.mean(
            y[mask]
        )

        predicted = np.mean(
            p[mask]
        )

        errors.append(
            abs(
                observed
                -
                predicted
            )
        )

    if len(errors) == 0:
        return np.nan

    return float(
        np.max(errors)
    )


# ============================================================
# 10. CALIBRATION CURVE
# ============================================================

def calibration_curve_data(
    y_true,
    probability,
    n_bins=10
):
    """
    Generate equal-width calibration-bin statistics.
    """

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    rows = []

    for i in range(
        n_bins
    ):

        lower = edges[i]
        upper = edges[i + 1]

        if i == n_bins - 1:

            mask = (
                (p >= lower)
                &
                (p <= upper)
            )

        else:

            mask = (
                (p >= lower)
                &
                (p < upper)
            )

        count = int(
            np.sum(mask)
        )

        if count == 0:

            rows.append(
                {
                    "bin": i + 1,
                    "lower": lower,
                    "upper": upper,
                    "n": 0,
                    "mean_predicted": np.nan,
                    "observed_frequency": np.nan
                }
            )

            continue

        rows.append(
            {
                "bin": i + 1,
                "lower": lower,
                "upper": upper,
                "n": count,
                "mean_predicted": float(
                    np.mean(
                        p[mask]
                    )
                ),
                "observed_frequency": float(
                    np.mean(
                        y[mask]
                    )
                )
            }
        )

    return pd.DataFrame(
        rows
    )


# ============================================================
# 11. DECISION CURVE ANALYSIS
# ============================================================

def decision_curve(
    y_true,
    probability,
    thresholds
):
    """
    Calculate net benefit for a prediction model.

    Net benefit:

        NB =
            TP/N
            -
            FP/N *
            pt/(1-pt)

    Also calculates:

        Treat all
        Treat none
    """

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    n = len(y)

    prevalence = np.mean(
        y
    )

    rows = []

    for threshold in thresholds:

        predicted_positive = (
            p >= threshold
        )

        tp = np.sum(
            predicted_positive
            &
            (y == 1)
        )

        fp = np.sum(
            predicted_positive
            &
            (y == 0)
        )

        net_benefit = (
            tp / n
            -
            (
                fp / n
            )
            *
            (
                threshold
                /
                (1 - threshold)
            )
        )

        # Treat everyone
        treat_all = (
            prevalence
            -
            (
                1 - prevalence
            )
            *
            (
                threshold
                /
                (1 - threshold)
            )
        )

        # Treat none
        treat_none = 0.0

        rows.append(
            {
                "threshold": threshold,
                "net_benefit_model": net_benefit,
                "net_benefit_treat_all": treat_all,
                "net_benefit_treat_none": treat_none
            }
        )

    return pd.DataFrame(
        rows
    )


# ============================================================
# 12. BOOTSTRAP CALIBRATION STATISTICS
# ============================================================

def bootstrap_calibration(
    y_true,
    probability,
    n_bootstrap,
    seed
):

    rng = np.random.default_rng(
        seed
    )

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    negative_indices = np.where(
        y == 0
    )[0]

    positive_indices = np.where(
        y == 1
    )[0]

    if (
        len(negative_indices) == 0
        or
        len(positive_indices) == 0
    ):

        raise ValueError(
            "Both classes are required."
        )

    intercept_values = []
    slope_values = []
    ece_values = []
    max_error_values = []
    brier_values = []

    for _ in range(
        n_bootstrap
    ):

        sampled_negative = rng.choice(
            negative_indices,
            size=len(negative_indices),
            replace=True
        )

        sampled_positive = rng.choice(
            positive_indices,
            size=len(positive_indices),
            replace=True
        )

        indices = np.concatenate(
            [
                sampled_negative,
                sampled_positive
            ]
        )

        y_b = y[
            indices
        ]

        p_b = p[
            indices
        ]

        # Calibration model
        cal = fit_calibration_model(
            y_b,
            p_b
        )

        intercept_values.append(
            cal["intercept"]
        )

        slope_values.append(
            cal["slope"]
        )

        ece_values.append(
            expected_calibration_error(
                y_b,
                p_b,
                N_CALIBRATION_BINS
            )
        )

        max_error_values.append(
            maximum_calibration_error(
                y_b,
                p_b,
                N_CALIBRATION_BINS
            )
        )

        brier_values.append(
            brier_score_loss(
                y_b,
                p_b
            )
        )

    return {
        "Calibration_Intercept": np.asarray(
            intercept_values
        ),
        "Calibration_Slope": np.asarray(
            slope_values
        ),
        "ECE": np.asarray(
            ece_values
        ),
        "Max_Calibration_Error": np.asarray(
            max_error_values
        ),
        "Brier": np.asarray(
            brier_values
        )
    }


# ============================================================
# 13. BOOTSTRAP DCA
# ============================================================

def bootstrap_dca(
    y_true,
    probability,
    thresholds,
    n_bootstrap,
    seed
):

    rng = np.random.default_rng(
        seed
    )

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    negative_indices = np.where(
        y == 0
    )[0]

    positive_indices = np.where(
        y == 1
    )[0]

    all_bootstrap = []

    for b in range(
        n_bootstrap
    ):

        sampled_negative = rng.choice(
            negative_indices,
            size=len(negative_indices),
            replace=True
        )

        sampled_positive = rng.choice(
            positive_indices,
            size=len(positive_indices),
            replace=True
        )

        indices = np.concatenate(
            [
                sampled_negative,
                sampled_positive
            ]
        )

        y_b = y[
            indices
        ]

        p_b = p[
            indices
        ]

        dca_b = decision_curve(
            y_b,
            p_b,
            thresholds
        )

        dca_b[
            "bootstrap"
        ] = b

        all_bootstrap.append(
            dca_b[
                "net_benefit_model"
            ].to_numpy()
        )

    bootstrap_array = np.asarray(
        all_bootstrap
    )

    lower = np.percentile(
        bootstrap_array,
        2.5,
        axis=0
    )

    upper = np.percentile(
        bootstrap_array,
        97.5,
        axis=0
    )

    return (
        lower,
        upper
    )


# ============================================================
# 14. DATASET EVALUATION
# ============================================================

def evaluate_dataset(
    dataset_name,
    y_true,
    probability,
    seed
):

    print("\n" + "-" * 70)

    print(
        dataset_name.upper()
    )

    print("-" * 70)

    y = np.asarray(
        y_true,
        dtype=int
    )

    p = np.asarray(
        probability,
        dtype=float
    )

    print(
        f"Records: {len(y):,}"
    )

    print(
        "Class distribution:"
    )

    print(
        pd.Series(
            y
        )
        .value_counts()
        .sort_index()
        .to_dict()
    )

    # --------------------------------------------------------
    # Calibration statistics
    # --------------------------------------------------------

    calibration = (
        fit_calibration_model(
            y,
            p
        )
    )

    intercept = (
        calibration[
            "intercept"
        ]
    )

    slope = (
        calibration[
            "slope"
        ]
    )

    ece = (
        expected_calibration_error(
            y,
            p,
            N_CALIBRATION_BINS
        )
    )

    max_error = (
        maximum_calibration_error(
            y,
            p,
            N_CALIBRATION_BINS
        )
    )

    brier = (
        brier_score_loss(
            y,
            p
        )
    )

    calibration_in_large = (
        calibration_in_the_large(
            y,
            p
        )
    )

    # --------------------------------------------------------
    # DCA
    # --------------------------------------------------------

    dca = decision_curve(
        y,
        p,
        DCA_THRESHOLDS
    )

    # --------------------------------------------------------
    # Bootstrap calibration
    # --------------------------------------------------------

    print(
        "\nRunning calibration bootstrap..."
    )

    bootstrap_cal = bootstrap_calibration(
        y,
        p,
        N_BOOTSTRAP,
        seed
    )

    # --------------------------------------------------------
    # Bootstrap DCA
    # --------------------------------------------------------

    print(
        "Running DCA bootstrap..."
    )

    dca_lower, dca_upper = (
        bootstrap_dca(
            y,
            p,
            DCA_THRESHOLDS,
            N_BOOTSTRAP,
            seed + 50000
        )
    )

    dca[
        "net_benefit_lower"
    ] = dca_lower

    dca[
        "net_benefit_upper"
    ] = dca_upper

    dca[
        "Dataset"
    ] = dataset_name

    # --------------------------------------------------------
    # Calibration CI function
    # --------------------------------------------------------

    def ci(
        values
    ):

        values = np.asarray(
            values,
            dtype=float
        )

        values = values[
            np.isfinite(values)
        ]

        return (
            float(
                np.percentile(
                    values,
                    2.5
                )
            ),
            float(
                np.percentile(
                    values,
                    97.5
                )
            )
        )

    intercept_low, intercept_high = ci(
        bootstrap_cal[
            "Calibration_Intercept"
        ]
    )

    slope_low, slope_high = ci(
        bootstrap_cal[
            "Calibration_Slope"
        ]
    )

    ece_low, ece_high = ci(
        bootstrap_cal[
            "ECE"
        ]
    )

    max_low, max_high = ci(
        bootstrap_cal[
            "Max_Calibration_Error"
        ]
    )

    brier_low, brier_high = ci(
        bootstrap_cal[
            "Brier"
        ]
    )

    # --------------------------------------------------------
    # Print
    # --------------------------------------------------------

    print(
        "\nCalibration results:"
    )

    print(
        f"Calibration intercept: "
        f"{intercept:.4f} "
        f"({intercept_low:.4f}–"
        f"{intercept_high:.4f})"
    )

    print(
        f"Calibration-in-the-large: "
        f"{calibration_in_large:.4f}"
    )

    print(
        f"Calibration slope: "
        f"{slope:.4f} "
        f"({slope_low:.4f}–"
        f"{slope_high:.4f})"
    )

    print(
        f"ECE: "
        f"{ece:.4f} "
        f"({ece_low:.4f}–"
        f"{ece_high:.4f})"
    )

    print(
        f"Maximum calibration error: "
        f"{max_error:.4f} "
        f"({max_low:.4f}–"
        f"{max_high:.4f})"
    )

    print(
        f"Brier score: "
        f"{brier:.4f} "
        f"({brier_low:.4f}–"
        f"{brier_high:.4f})"
    )

    # --------------------------------------------------------
    # Summary record
    # --------------------------------------------------------

    summary = {
        "Dataset":
            dataset_name,

        "N":
            len(y),

        "Prevalence":
            float(np.mean(y)),

        "Calibration_Intercept":
            intercept,

        "Calibration_Intercept_CI_Lower":
            intercept_low,

        "Calibration_Intercept_CI_Upper":
            intercept_high,

        "Calibration_in_the_Large":
            calibration_in_large,

        "Calibration_Slope":
            slope,

        "Calibration_Slope_CI_Lower":
            slope_low,

        "Calibration_Slope_CI_Upper":
            slope_high,

        "ECE":
            ece,

        "ECE_CI_Lower":
            ece_low,

        "ECE_CI_Upper":
            ece_high,

        "Maximum_Calibration_Error":
            max_error,

        "Max_Calibration_Error_CI_Lower":
            max_low,

        "Max_Calibration_Error_CI_Upper":
            max_high,

        "Brier":
            brier,

        "Brier_CI_Lower":
            brier_low,

        "Brier_CI_Upper":
            brier_high,

        "Bootstrap_N":
            N_BOOTSTRAP
    }

    calibration_table = (
        calibration_curve_data(
            y,
            p,
            N_CALIBRATION_BINS
        )
    )

    calibration_table[
        "Dataset"
    ] = dataset_name

    return (
        summary,
        calibration_table,
        dca
    )


# ============================================================
# 15. LOAD KAGGLE
# ============================================================

print("\n" + "=" * 70)
print("LOADING KAGGLE LOCKED-TEST PREDICTIONS")
print("=" * 70)

if not os.path.exists(
    KAGGLE_FILE
):

    raise FileNotFoundError(
        f"Kaggle prediction file not found:\n"
        f"{KAGGLE_FILE}"
    )

kaggle = pd.read_csv(
    KAGGLE_FILE
)

required_kaggle = [
    "cardio",
    "probability"
]

for col in required_kaggle:

    if col not in kaggle.columns:

        raise ValueError(
            f"Missing Kaggle column: {col}"
        )

kaggle_y = pd.to_numeric(
    kaggle["cardio"],
    errors="coerce"
)

kaggle_p = pd.to_numeric(
    kaggle["probability"],
    errors="coerce"
)

valid = (
    kaggle_y.notna()
    &
    kaggle_p.notna()
)

kaggle_y = (
    kaggle_y.loc[
        valid
    ]
    .astype(int)
    .to_numpy()
)

kaggle_p = (
    kaggle_p.loc[
        valid
    ]
    .astype(float)
    .to_numpy()
)

if len(kaggle_y) != 14000:

    raise ValueError(
        f"Expected 14,000 Kaggle records; "
        f"found {len(kaggle_y)}."
    )


# ============================================================
# 16. LOAD UCI
# ============================================================

print("\n" + "=" * 70)
print("LOADING UCI EXTERNAL PREDICTIONS")
print("=" * 70)

if not os.path.exists(
    UCI_FILE
):

    raise FileNotFoundError(
        f"UCI prediction file not found:\n"
        f"{UCI_FILE}"
    )

uci = pd.read_csv(
    UCI_FILE
)

required_uci = [
    "cohort",
    "source_row",
    "true_label",
    "probability"
]

for col in required_uci:

    if col not in uci.columns:

        raise ValueError(
            f"Missing UCI column: {col}"
        )


def normalize_cohort(
    value
):

    text = str(
        value
    ).strip().lower()

    if "cleveland" in text:

        return "Cleveland"

    if "hungarian" in text:

        return "Hungarian"

    if (
        "va" in text
        or
        "long beach" in text
        or
        "long_beach" in text
    ):

        return "VA Long Beach"

    return str(value)


uci[
    "_cohort"
] = uci[
    "cohort"
].apply(
    normalize_cohort
)


# ============================================================
# 17. EVALUATE ALL DATASETS
# ============================================================

dataset_summaries = []

all_calibration_tables = []

all_dca_tables = []


# ------------------------------------------------------------
# Kaggle
# ------------------------------------------------------------

summary, calibration_table, dca = (
    evaluate_dataset(
        "Kaggle Locked Test",
        kaggle_y,
        kaggle_p,
        SEED
    )
)

dataset_summaries.append(
    summary
)

all_calibration_tables.append(
    calibration_table
)

all_dca_tables.append(
    dca
)


# ------------------------------------------------------------
# UCI
# ------------------------------------------------------------

expected_sizes = {
    "Cleveland": 303,
    "Hungarian": 262,
    "VA Long Beach": 100
}

cohort_order = [
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]


for index, cohort in enumerate(
    cohort_order,
    start=1
):

    subset = uci[
        uci["_cohort"] == cohort
    ].copy()

    expected = expected_sizes[
        cohort
    ]

    print(
        f"\n{cohort}: "
        f"{len(subset)} records "
        f"(expected {expected})"
    )

    if len(subset) != expected:

        raise ValueError(
            f"{cohort} size mismatch."
        )

    if subset[
        "source_row"
    ].duplicated().any():

        raise ValueError(
            f"Duplicate source_row values "
            f"in {cohort}."
        )

    y = pd.to_numeric(
        subset["true_label"],
        errors="coerce"
    )

    p = pd.to_numeric(
        subset["probability"],
        errors="coerce"
    )

    valid = (
        y.notna()
        &
        p.notna()
    )

    if not valid.all():

        raise ValueError(
            f"Invalid labels/probabilities "
            f"in {cohort}."
        )

    y = (
        y.astype(int)
        .to_numpy()
    )

    p = (
        p.astype(float)
        .to_numpy()
    )

    if sorted(
        np.unique(y).tolist()
    ) != [0, 1]:

        raise ValueError(
            f"{cohort} does not contain "
            f"both classes."
        )

    summary, calibration_table, dca = (
        evaluate_dataset(
            cohort,
            y,
            p,
            SEED + index * 100
        )
    )

    dataset_summaries.append(
        summary
    )

    all_calibration_tables.append(
        calibration_table
    )

    all_dca_tables.append(
        dca
    )


# ============================================================
# 18. COMBINE RESULTS
# ============================================================

summary_df = pd.DataFrame(
    dataset_summaries
)

calibration_df = pd.concat(
    all_calibration_tables,
    ignore_index=True
)

dca_df = pd.concat(
    all_dca_tables,
    ignore_index=True
)


# ============================================================
# 19. SAVE CALIBRATION SUMMARY
# ============================================================

calibration_summary_file = os.path.join(
    RESULTS_DIR,
    "implementation41_calibration_summary.csv"
)

summary_df.to_csv(
    calibration_summary_file,
    index=False
)

print(
    "\nSaved:"
)

print(
    calibration_summary_file
)


# ============================================================
# 20. SAVE CALIBRATION CURVE DATA
# ============================================================

calibration_curve_file = os.path.join(
    RESULTS_DIR,
    "implementation41_calibration_curve_data.csv"
)

calibration_df.to_csv(
    calibration_curve_file,
    index=False
)

print(
    "Saved:"
)

print(
    calibration_curve_file
)


# ============================================================
# 21. SAVE DCA RESULTS
# ============================================================

dca_file = os.path.join(
    RESULTS_DIR,
    "implementation41_decision_curve_analysis.csv"
)

dca_df.to_csv(
    dca_file,
    index=False
)

print(
    "Saved:"
)

print(
    dca_file
)


# ============================================================
# 22. SAVE JSON SUMMARY
# ============================================================

json_file = os.path.join(
    RESULTS_DIR,
    "implementation41_calibration_dca_summary.json"
)

json_summary = {
    "implementation":
        "Implementation 41",

    "bootstrap_repetitions":
        N_BOOTSTRAP,

    "confidence_level":
        0.95,

    "calibration_bins":
        N_CALIBRATION_BINS,

    "frozen_operating_threshold":
        FROZEN_THRESHOLD,

    "model_retrained":
        False,

    "hyperparameter_tuning":
        False,

    "uci_labels_used_for_model_development":
        False,

    "results":
        summary_df.to_dict(
            orient="records"
        )
}


with open(
    json_file,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        json_summary,
        f,
        indent=4
    )


print(
    "Saved:"
)

print(
    json_file
)


# ============================================================
# 23. CALIBRATION FIGURES
# ============================================================

print(
    "\nGenerating calibration figures..."
)


for dataset in [
    "Kaggle Locked Test",
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]:

    subset = calibration_df[
        calibration_df[
            "Dataset"
        ] == dataset
    ].copy()

    subset = subset[
        subset["n"] > 0
    ]

    plt.figure(
        figsize=(7, 6)
    )

    plt.plot(
        [0, 1],
        [0, 1],
        linestyle="--",
        linewidth=2,
        label="Perfect calibration"
    )

    plt.plot(
        subset[
            "mean_predicted"
        ],
        subset[
            "observed_frequency"
        ],
        marker="o",
        linewidth=2,
        label="CGS-ChebKAN"
    )

    plt.xlabel(
        "Mean predicted probability"
    )

    plt.ylabel(
        "Observed event frequency"
    )

    plt.title(
        f"Calibration Curve - {dataset}"
    )

    plt.xlim(
        0,
        1
    )

    plt.ylim(
        0,
        1
    )

    plt.grid(
        alpha=0.25
    )

    plt.legend()

    safe_name = (
        dataset
        .lower()
        .replace(
            " ",
            "_"
        )
    )

    output = os.path.join(
        FIGURES_DIR,
        f"implementation41_calibration_{safe_name}.png"
    )

    plt.tight_layout()

    plt.savefig(
        output,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(
        f"Saved: {output}"
    )


# ============================================================
# 24. DCA FIGURES
# ============================================================

print(
    "\nGenerating DCA figures..."
)


for dataset in [
    "Kaggle Locked Test",
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]:

    subset = dca_df[
        dca_df[
            "Dataset"
        ] == dataset
    ].copy()

    plt.figure(
        figsize=(8, 6)
    )

    plt.plot(
        subset[
            "threshold"
        ],
        subset[
            "net_benefit_model"
        ],
        linewidth=2,
        label="CGS-ChebKAN"
    )

    plt.plot(
        subset[
            "threshold"
        ],
        subset[
            "net_benefit_treat_all"
        ],
        linestyle="--",
        linewidth=2,
        label="Treat all"
    )

    plt.plot(
        subset[
            "threshold"
        ],
        subset[
            "net_benefit_treat_none"
        ],
        linestyle=":",
        linewidth=2,
        label="Treat none"
    )

    # Bootstrap confidence band
    plt.fill_between(
        subset[
            "threshold"
        ],
        subset[
            "net_benefit_lower"
        ],
        subset[
            "net_benefit_upper"
        ],
        alpha=0.15
    )

    # Frozen threshold marker
    plt.axvline(
        FROZEN_THRESHOLD,
        linestyle="--",
        linewidth=1.5,
        label=(
            f"Frozen threshold "
            f"({FROZEN_THRESHOLD:.3f})"
        )
    )

    plt.xlabel(
        "Threshold probability"
    )

    plt.ylabel(
        "Net benefit"
    )

    plt.title(
        f"Decision Curve Analysis - {dataset}"
    )

    plt.xlim(
        0.01,
        0.95
    )

    plt.grid(
        alpha=0.25
    )

    plt.legend()

    safe_name = (
        dataset
        .lower()
        .replace(
            " ",
            "_"
        )
    )

    output = os.path.join(
        FIGURES_DIR,
        f"implementation41_dca_{safe_name}.png"
    )

    plt.tight_layout()

    plt.savefig(
        output,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(
        f"Saved: {output}"
    )


# ============================================================
# 25. MANUSCRIPT-READY DISPLAY
# ============================================================

print("\n" + "=" * 70)
print("MANUSCRIPT-READY CALIBRATION SUMMARY")
print("=" * 70)

display_columns = [
    "Dataset",
    "N",
    "Prevalence",
    "Calibration_Intercept",
    "Calibration_Intercept_CI_Lower",
    "Calibration_Intercept_CI_Upper",
    "Calibration_Slope",
    "Calibration_Slope_CI_Lower",
    "Calibration_Slope_CI_Upper",
    "ECE",
    "ECE_CI_Lower",
    "ECE_CI_Upper",
    "Maximum_Calibration_Error",
    "Brier",
    "Brier_CI_Lower",
    "Brier_CI_Upper"
]

print(
    summary_df[
        display_columns
    ].to_string(
        index=False,
        float_format=lambda x: f"{x:.4f}"
    )
)


# ============================================================
# 26. PROTOCOL CHECK
# ============================================================

print("\n" + "=" * 70)
print("PROTOCOL VERIFICATION")
print("=" * 70)

print(
    "Model retrained:                         FALSE"
)

print(
    "Hyperparameters tuned:                  FALSE"
)

print(
    "UCI labels used for model development:  FALSE"
)

print(
    "Kaggle locked test retained:             TRUE"
)

print(
    "External UCI cohorts retained:           TRUE"
)

print(
    f"Frozen operating threshold:              "
    f"{FROZEN_THRESHOLD:.6f}"
)

print(
    f"Bootstrap repetitions:                   "
    f"{N_BOOTSTRAP:,}"
)

print(
    "Calibration evaluation:                 TRUE"
)

print(
    "Decision curve analysis:                TRUE"
)

print(
    "\nSTATUS: PASS_CALIBRATION_DCA_EVALUATION"
)

print("=" * 70)