# ================================================================
# 33 — UCI EXTERNAL VALIDATION / HARMONIZATION AUDIT
# ================================================================
#
# Purpose:
#   Prepare and audit the official UCI Heart Disease archive
#   for external validation of the cardiovascular CGS-ChebKAN
#   framework.
#
# IMPORTANT:
#   This script DOES NOT train a model.
#
# Frozen shared feature space:
#   age
#   sex
#   systolic_bp
#   cholesterol_category
#   elevated_glucose
#
# Cohorts:
#   Cleveland  -> primary external validation
#   Hungarian  -> secondary external validation
#   VA         -> sensitivity analysis
#   Switzerland -> excluded from primary validation because
#                  cholesterol is unusable (all values are 0)
#
# Frozen harmonization:
#
#   Age:
#       UCI age is already in years.
#
#   Sex:
#       UCI sex is converted to binary 0/1.
#
#   Blood pressure:
#       UCI trestbps -> systolic_bp
#
#   Cholesterol:
#       <200       -> 1
#       200–239    -> 2
#       >=240      -> 3
#
#   Glucose:
#       UCI fbs 0 -> 0
#       UCI fbs 1 -> 1
#
#   Target:
#       UCI target 0 -> 0
#       UCI target 1–4 -> 1
#
# No model fitting.
# No imputation.
# No row deletion.
# No Kaggle data used.
#
# ================================================================

import os
import zipfile
import shutil
import json
import hashlib
from datetime import datetime

import numpy as np
import pandas as pd


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

UCI_ZIP = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "uci",
    "heart+disease.zip"
)

UCI_RAW_EXTRACTED = os.path.join(
    PROJECT_ROOT,
    "data",
    "raw",
    "uci",
    "extracted"
)

UCI_HARMONIZED = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed",
    "uci_harmonized"
)

RESULTS_TABLES = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

os.makedirs(
    UCI_RAW_EXTRACTED,
    exist_ok=True
)

os.makedirs(
    UCI_HARMONIZED,
    exist_ok=True
)

os.makedirs(
    RESULTS_TABLES,
    exist_ok=True
)


# ================================================================
# 2. SOURCE FILE DEFINITIONS
# ================================================================

UCI_FILES = {
    "cleveland":
        "processed.cleveland.data",

    "hungarian":
        "processed.hungarian.data",

    "switzerland":
        "processed.switzerland.data",

    "va":
        "processed.va.data",
}


# ================================================================
# 3. UCI ORIGINAL COLUMN NAMES
# ================================================================

UCI_COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target",
]


# ================================================================
# 4. FROZEN SHARED FEATURE SPACE
# ================================================================

SHARED_FEATURES = [
    "age",
    "sex",
    "systolic_bp",
    "cholesterol_category",
    "elevated_glucose",
]

TARGET = "target_binary"


# ================================================================
# 5. COHORT ROLES
# ================================================================

COHORT_ROLES = {

    "cleveland":
        "primary_external_validation",

    "hungarian":
        "secondary_external_validation",

    "va":
        "sensitivity_analysis",

    "switzerland":
        "excluded_from_primary_external_validation",
}


# ================================================================
# 6. UTILITY FUNCTIONS
# ================================================================

def sha256_file(path):

    sha256 = hashlib.sha256()

    with open(
        path,
        "rb"
    ) as f:

        while True:

            chunk = f.read(
                1024 * 1024
            )

            if not chunk:
                break

            sha256.update(
                chunk
            )

    return sha256.hexdigest()


def print_separator():

    print("=" * 80)


# ================================================================
# 7. START
# ================================================================

print_separator()

print(
    "UCI EXTERNAL VALIDATION / "
    "HARMONIZATION AUDIT"
)

print_separator()

print(
    "Timestamp:",
    datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )
)

print(
    "Project root:",
    PROJECT_ROOT
)

print(
    "UCI archive:",
    UCI_ZIP
)


# ================================================================
# 8. VERIFY UCI ZIP
# ================================================================

if not os.path.exists(UCI_ZIP):

    raise FileNotFoundError(
        f"UCI ZIP not found:\n{UCI_ZIP}"
    )

print()
print("UCI archive found.")

zip_hash = sha256_file(
    UCI_ZIP
)

print(
    "SHA-256:",
    zip_hash
)


# ================================================================
# 9. EXTRACT UCI ARCHIVE
# ================================================================

print()
print_separator()

print("EXTRACTING UCI ARCHIVE")

print_separator()

if os.path.exists(
    UCI_RAW_EXTRACTED
):

    print(
        "Existing extraction directory found."
    )

    print(
        "Existing files will be reused."
    )

else:

    os.makedirs(
        UCI_RAW_EXTRACTED,
        exist_ok=True
    )


with zipfile.ZipFile(
    UCI_ZIP,
    "r"
) as z:

    members = z.namelist()

    print(
        "Archive entries:",
        len(members)
    )

    z.extractall(
        UCI_RAW_EXTRACTED
    )


print(
    "Extraction complete."
)


# ================================================================
# 10. LOCATE PROCESSED FILES
# ================================================================

def locate_file(
    root,
    filename
):

    matches = []

    for current_root, dirs, files in os.walk(root):

        if filename in files:

            matches.append(
                os.path.join(
                    current_root,
                    filename
                )
            )

    return matches


located_files = {}

print()
print_separator()

print("LOCATING UCI COHORT FILES")

print_separator()

for cohort, filename in UCI_FILES.items():

    matches = locate_file(
        UCI_RAW_EXTRACTED,
        filename
    )

    if len(matches) == 0:

        raise FileNotFoundError(
            f"Could not locate {filename}"
        )

    if len(matches) > 1:

        print(
            f"WARNING: multiple matches for {filename}"
        )

        for m in matches:
            print(
                "  ",
                m
            )

    located_files[cohort] = matches[0]

    print(
        f"{cohort}: {matches[0]}"
    )


# ================================================================
# 11. LOAD UCI DATA
# ================================================================

cohorts = {}

print()
print_separator()

print("LOADING UCI COHORTS")

print_separator()

for cohort, path in located_files.items():

    df = pd.read_csv(
        path,
        header=None,
        names=UCI_COLUMNS,
        na_values=["?"],
        skipinitialspace=True
    )

    cohorts[cohort] = df

    print(
        f"{cohort}: {df.shape}"
    )


# ================================================================
# 12. BASIC SOURCE AUDIT
# ================================================================

print()
print_separator()

print("SOURCE-LEVEL AUDIT")

print_separator()

source_summary = []

for cohort, df in cohorts.items():

    print()
    print(
        f"--- {cohort.upper()} ---"
    )

    print(
        "Rows:",
        len(df)
    )

    print(
        "Columns:",
        len(df.columns)
    )

    print(
        "Target values:",
        sorted(
            df["target"].dropna().unique().tolist()
        )
    )

    print(
        "Exact duplicate rows:",
        int(
            df.duplicated().sum()
        )
    )

    print(
        "Missing target:",
        int(
            df["target"].isna().sum()
        )
    )

    source_summary.append(
        {
            "cohort": cohort,
            "rows": len(df),
            "columns": len(df.columns),
            "duplicate_rows": int(
                df.duplicated().sum()
            ),
            "missing_target": int(
                df["target"].isna().sum()
            ),
            "role": COHORT_ROLES[cohort],
        }
    )


# ================================================================
# 13. HARMONIZATION FUNCTIONS
# ================================================================

def harmonize_sex(series):

    # UCI sex:
    #   0 = female
    #   1 = male
    #
    # Already binary, retained as 0/1.

    result = pd.to_numeric(
        series,
        errors="coerce"
    )

    result = result.where(
        result.isin([0, 1])
    )

    return result


def harmonize_cholesterol(series):

    chol = pd.to_numeric(
        series,
        errors="coerce"
    )

    result = pd.Series(
        np.nan,
        index=chol.index,
        dtype=float
    )

    valid = chol.notna()

    result.loc[
        valid & (chol < 200)
    ] = 1

    result.loc[
        valid
        & (chol >= 200)
        & (chol < 240)
    ] = 2

    result.loc[
        valid & (chol >= 240)
    ] = 3

    # A value of exactly 0 is retained as 1 by the
    # mathematical rule above, but later validity checks
    # explicitly identify zero cholesterol as unusable
    # because in these UCI files it represents missing/
    # unavailable cholesterol information.
    #
    # Therefore explicitly convert zero to missing.
    result.loc[
        chol == 0
    ] = np.nan

    return result


def harmonize_glucose(series):

    fbs = pd.to_numeric(
        series,
        errors="coerce"
    )

    result = pd.Series(
        np.nan,
        index=fbs.index,
        dtype=float
    )

    result.loc[
        fbs == 0
    ] = 0

    result.loc[
        fbs == 1
    ] = 1

    return result


def harmonize_target(series):

    target = pd.to_numeric(
        series,
        errors="coerce"
    )

    result = pd.Series(
        np.nan,
        index=target.index,
        dtype=float
    )

    result.loc[
        target == 0
    ] = 0

    result.loc[
        target.isin([1, 2, 3, 4])
    ] = 1

    return result


# ================================================================
# 14. HARMONIZE EACH COHORT
# ================================================================

harmonized = {}

print()
print_separator()

print("CROSS-DATASET HARMONIZATION")

print_separator()

for cohort, df in cohorts.items():

    h = pd.DataFrame(
        index=df.index
    )

    # ------------------------------------------------------------
    # Age
    # ------------------------------------------------------------

    h["age"] = pd.to_numeric(
        df["age"],
        errors="coerce"
    )

    # ------------------------------------------------------------
    # Sex
    # ------------------------------------------------------------

    h["sex"] = harmonize_sex(
        df["sex"]
    )

    # ------------------------------------------------------------
    # Systolic blood pressure
    # ------------------------------------------------------------

    h["systolic_bp"] = pd.to_numeric(
        df["trestbps"],
        errors="coerce"
    )

    # ------------------------------------------------------------
    # Cholesterol category
    # ------------------------------------------------------------

    h["cholesterol_category"] = (
        harmonize_cholesterol(
            df["chol"]
        )
    )

    # ------------------------------------------------------------
    # Elevated glucose indicator
    # ------------------------------------------------------------

    h["elevated_glucose"] = (
        harmonize_glucose(
            df["fbs"]
        )
    )

    # ------------------------------------------------------------
    # Binary target
    # ------------------------------------------------------------

    h["target_binary"] = (
        harmonize_target(
            df["target"]
        )
    )

    # ------------------------------------------------------------
    # Retain source index for traceability
    # ------------------------------------------------------------

    h["source_row"] = np.arange(
        len(h)
    )

    h["cohort"] = cohort

    harmonized[cohort] = h

    print(
        f"{cohort}: harmonized {h.shape}"
    )


# ================================================================
# 15. VALIDITY RULES
# ================================================================
#
# These are audit rules only.
#
# NO IMPUTATION.
# NO MODEL TRAINING.
# NO ROW DELETION FROM THE HARMONIZED MASTER FILE.
#
# A record is externally eligible only when all five shared
# predictors and the binary target are valid.
#
# ================================================================

def validity_audit(
    df
):

    out = pd.DataFrame(
        index=df.index
    )

    out["valid_age"] = (
        df["age"].between(
            18,
            100,
            inclusive="both"
        )
    )

    out["valid_sex"] = (
        df["sex"].isin([0, 1])
    )

    out["valid_systolic_bp"] = (
        df["systolic_bp"].between(
            70,
            250,
            inclusive="both"
        )
    )

    out["valid_cholesterol_category"] = (
        df["cholesterol_category"].isin(
            [1, 2, 3]
        )
    )

    out["valid_elevated_glucose"] = (
        df["elevated_glucose"].isin(
            [0, 1]
        )
    )

    out["valid_target"] = (
        df["target_binary"].isin(
            [0, 1]
        )
    )

    out["all_shared_features_valid"] = (
        out[
            [
                "valid_age",
                "valid_sex",
                "valid_systolic_bp",
                "valid_cholesterol_category",
                "valid_elevated_glucose",
                "valid_target",
            ]
        ].all(axis=1)
    )

    return out


# ================================================================
# 16. RUN VALIDITY AUDIT
# ================================================================

audit_tables = {}
eligibility_rows = []

print()
print_separator()

print("EXTERNAL VALIDATION ELIGIBILITY")

print_separator()

for cohort, h in harmonized.items():

    audit = validity_audit(
        h
    )

    audit_tables[cohort] = audit

    print()
    print(
        f"--- {cohort.upper()} ---"
    )

    print(
        "Total:",
        len(h)
    )

    for column in [
        "valid_age",
        "valid_sex",
        "valid_systolic_bp",
        "valid_cholesterol_category",
        "valid_elevated_glucose",
        "valid_target",
    ]:

        print(
            f"{column}:",
            int(
                audit[column].sum()
            )
        )

    eligible = int(
        audit[
            "all_shared_features_valid"
        ].sum()
    )

    print(
        "All shared features valid:",
        eligible
    )

    print(
        "Eligibility percentage:",
        f"{100 * eligible / len(h):.3f}%"
    )

    eligibility_rows.append(
        {
            "cohort": cohort,
            "role": COHORT_ROLES[cohort],
            "total_records": len(h),
            "valid_age": int(
                audit["valid_age"].sum()
            ),
            "valid_sex": int(
                audit["valid_sex"].sum()
            ),
            "valid_systolic_bp": int(
                audit["valid_systolic_bp"].sum()
            ),
            "valid_cholesterol_category": int(
                audit[
                    "valid_cholesterol_category"
                ].sum()
            ),
            "valid_elevated_glucose": int(
                audit[
                    "valid_elevated_glucose"
                ].sum()
            ),
            "valid_target": int(
                audit["valid_target"].sum()
            ),
            "eligible_records": eligible,
            "eligible_percentage":
                100 * eligible / len(h),
        }
    )


# ================================================================
# 17. SPECIAL CHOLESTEROL AUDIT
# ================================================================

print()
print_separator()

print("CHOLESTEROL USABILITY AUDIT")

print_separator()

cholesterol_rows = []

for cohort, df in cohorts.items():

    chol = pd.to_numeric(
        df["chol"],
        errors="coerce"
    )

    zeros = int(
        (chol == 0).sum()
    )

    missing = int(
        chol.isna().sum()
    )

    valid_nonzero = int(
        (
            chol.notna()
            & (chol > 0)
        ).sum()
    )

    print()
    print(
        f"{cohort}:"
    )

    print(
        "  cholesterol missing:",
        missing
    )

    print(
        "  cholesterol zero:",
        zeros
    )

    print(
        "  positive cholesterol:",
        valid_nonzero
    )

    if valid_nonzero > 0:

        print(
            "  min positive:",
            float(
                chol[chol > 0].min()
            )
        )

        print(
            "  max positive:",
            float(
                chol[chol > 0].max()
            )
        )

    cholesterol_rows.append(
        {
            "cohort": cohort,
            "cholesterol_missing":
                missing,
            "cholesterol_zero":
                zeros,
            "positive_cholesterol":
                valid_nonzero,
        }
    )


# ================================================================
# 18. TARGET AUDIT
# ================================================================

print()
print_separator()

print("TARGET HARMONIZATION AUDIT")

print_separator()

target_rows = []

for cohort, h in harmonized.items():

    raw_target = cohorts[
        cohort
    ]["target"]

    binary_target = h[
        "target_binary"
    ]

    print()
    print(
        f"--- {cohort.upper()} ---"
    )

    print(
        "Raw target:",
        raw_target.value_counts(
            dropna=False
        ).sort_index().to_dict()
    )

    print(
        "Binary target:",
        binary_target.value_counts(
            dropna=False
        ).sort_index().to_dict()
    )

    target_rows.append(
        {
            "cohort": cohort,
            "raw_target_distribution":
                str(
                    raw_target.value_counts(
                        dropna=False
                    ).sort_index().to_dict()
                ),
            "binary_target_distribution":
                str(
                    binary_target.value_counts(
                        dropna=False
                    ).sort_index().to_dict()
                ),
        }
    )


# ================================================================
# 19. DESCRIPTIVE SUMMARY OF ELIGIBLE RECORDS
# ================================================================

print()
print_separator()

print("ELIGIBLE COHORT DESCRIPTIVE SUMMARY")

print_separator()

eligible_summary = []

for cohort, h in harmonized.items():

    audit = audit_tables[
        cohort
    ]

    eligible = h[
        audit[
            "all_shared_features_valid"
        ]
    ].copy()

    print()
    print(
        f"--- {cohort.upper()} ---"
    )

    if len(eligible) == 0:

        print(
            "No eligible observations."
        )

        continue

    print(
        "Eligible n:",
        len(eligible)
    )

    print(
        "Age mean:",
        f"{eligible['age'].mean():.3f}"
    )

    print(
        "Age SD:",
        f"{eligible['age'].std():.3f}"
    )

    print(
        "Systolic BP mean:",
        f"{eligible['systolic_bp'].mean():.3f}"
    )

    print(
        "Systolic BP SD:",
        f"{eligible['systolic_bp'].std():.3f}"
    )

    print(
        "Cholesterol categories:",
        eligible[
            "cholesterol_category"
        ].value_counts(
            normalize=False
        ).sort_index().to_dict()
    )

    print(
        "Elevated glucose:",
        eligible[
            "elevated_glucose"
        ].value_counts(
            normalize=False
        ).sort_index().to_dict()
    )

    print(
        "Target:",
        eligible[
            "target_binary"
        ].value_counts(
            normalize=False
        ).sort_index().to_dict()
    )

    eligible_summary.append(
        {
            "cohort": cohort,
            "eligible_n": len(eligible),
            "age_mean": eligible["age"].mean(),
            "age_sd": eligible["age"].std(),
            "systolic_bp_mean":
                eligible[
                    "systolic_bp"
                ].mean(),
            "systolic_bp_sd":
                eligible[
                    "systolic_bp"
                ].std(),
            "cholesterol_1":
                int(
                    (
                        eligible[
                            "cholesterol_category"
                        ] == 1
                    ).sum()
                ),
            "cholesterol_2":
                int(
                    (
                        eligible[
                            "cholesterol_category"
                        ] == 2
                    ).sum()
                ),
            "cholesterol_3":
                int(
                    (
                        eligible[
                            "cholesterol_category"
                        ] == 3
                    ).sum()
                ),
            "elevated_glucose_0":
                int(
                    (
                        eligible[
                            "elevated_glucose"
                        ] == 0
                    ).sum()
                ),
            "elevated_glucose_1":
                int(
                    (
                        eligible[
                            "elevated_glucose"
                        ] == 1
                    ).sum()
                ),
            "target_0":
                int(
                    (
                        eligible[
                            "target_binary"
                        ] == 0
                    ).sum()
                ),
            "target_1":
                int(
                    (
                        eligible[
                            "target_binary"
                        ] == 1
                    ).sum()
                ),
        }
    )


# ================================================================
# 20. SAVE HARMONIZED COHORT FILES
# ================================================================

print()
print_separator()

print("SAVING HARMONIZED COHORTS")

print_separator()

saved_files = {}

for cohort, h in harmonized.items():

    output_path = os.path.join(
        UCI_HARMONIZED,
        f"uci_{cohort}_harmonized_shared_features.csv"
    )

    h.to_csv(
        output_path,
        index=False
    )

    saved_files[
        cohort
    ] = output_path

    print(
        cohort,
        "->",
        output_path
    )


# ================================================================
# 21. SAVE ELIGIBILITY SUMMARY
# ================================================================

eligibility_df = pd.DataFrame(
    eligibility_rows
)

eligibility_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_external_validation_eligibility.csv"
)

eligibility_df.to_csv(
    eligibility_path,
    index=False
)


# ================================================================
# 22. SAVE SOURCE SUMMARY
# ================================================================

source_df = pd.DataFrame(
    source_summary
)

source_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_source_summary.csv"
)

source_df.to_csv(
    source_path,
    index=False
)


# ================================================================
# 23. SAVE CHOLESTEROL SUMMARY
# ================================================================

cholesterol_df = pd.DataFrame(
    cholesterol_rows
)

cholesterol_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_cholesterol_usability.csv"
)

cholesterol_df.to_csv(
    cholesterol_path,
    index=False
)


# ================================================================
# 24. SAVE TARGET SUMMARY
# ================================================================

target_df = pd.DataFrame(
    target_rows
)

target_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_target_harmonization.csv"
)

target_df.to_csv(
    target_path,
    index=False
)


# ================================================================
# 25. SAVE ELIGIBLE DESCRIPTIVE SUMMARY
# ================================================================

eligible_summary_df = pd.DataFrame(
    eligible_summary
)

eligible_summary_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_eligible_descriptive_summary.csv"
)

eligible_summary_df.to_csv(
    eligible_summary_path,
    index=False
)


# ================================================================
# 26. SAVE AUDIT JSON
# ================================================================

audit_json = {

    "audit":
        "Audit 33 — UCI External Validation/Harmonization",

    "timestamp":
        datetime.now().isoformat(),

    "source_archive":
        UCI_ZIP,

    "source_sha256":
        zip_hash,

    "shared_features":
        SHARED_FEATURES,

    "target":
        TARGET,

    "cohort_roles":
        COHORT_ROLES,

    "harmonization": {

        "age":
            "UCI age retained in years",

        "sex":
            "UCI sex retained as binary 0/1",

        "systolic_bp":
            "UCI trestbps",

        "cholesterol":
            {
                "<200": 1,
                "200-239": 2,
                ">=240": 3,
                "zero_treated_as_missing":
                    True,
            },

        "glucose":
            {
                "fbs_0": 0,
                "fbs_1": 1,
            },

        "target":
            {
                "0": 0,
                "1-4": 1,
            },
    },

    "important_methodological_notes": [

        "No model training was performed.",

        "No imputation was performed.",

        "No UCI records were used for Kaggle model development.",

        "Cleveland is the primary external validation cohort.",

        "Hungarian is the secondary external validation cohort.",

        "VA is retained as a sensitivity analysis cohort.",

        "Switzerland is excluded from primary shared-feature "
        "validation because cholesterol is unavailable/unusable.",

        "Harmonization does not imply perfect measurement equivalence "
        "between Kaggle and UCI variables.",

    ],

    "saved_harmonized_files":
        saved_files,
}


audit_json_path = os.path.join(
    RESULTS_TABLES,
    "audit33_uci_external_validation_audit.json"
)

with open(
    audit_json_path,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        audit_json,
        f,
        indent=2
    )


# ================================================================
# 27. FINAL DECISION SUMMARY
# ================================================================

print()
print_separator()

print("FINAL EXTERNAL VALIDATION DECISION")

print_separator()

for cohort in [
    "cleveland",
    "hungarian",
    "switzerland",
    "va",
]:

    row = eligibility_df[
        eligibility_df["cohort"] == cohort
    ]

    if len(row) == 0:
        continue

    row = row.iloc[0]

    eligible_n = int(
        row["eligible_records"]
    )

    total_n = int(
        row["total_records"]
    )

    print()
    print(
        cohort.upper()
    )

    print(
        "  Role:",
        COHORT_ROLES[cohort]
    )

    print(
        "  Total:",
        total_n
    )

    print(
        "  Eligible:",
        eligible_n
    )

    print(
        "  Eligibility:",
        f"{row['eligible_percentage']:.3f}%"
    )


# ================================================================
# 28. EXPECTED METHODOLOGICAL STATUS
# ================================================================

cleveland_eligible = int(
    eligibility_df.loc[
        eligibility_df["cohort"] == "cleveland",
        "eligible_records"
    ].iloc[0]
)

hungarian_eligible = int(
    eligibility_df.loc[
        eligibility_df["cohort"] == "hungarian",
        "eligible_records"
    ].iloc[0]
)

switzerland_eligible = int(
    eligibility_df.loc[
        eligibility_df["cohort"] == "switzerland",
        "eligible_records"
    ].iloc[0]
)

va_eligible = int(
    eligibility_df.loc[
        eligibility_df["cohort"] == "va",
        "eligible_records"
    ].iloc[0]
)

print()
print_separator()

print("PROTOCOL STATUS")

print_separator()

print(
    "Cleveland primary:",
    "READY" if cleveland_eligible > 0
    else "NOT READY"
)

print(
    "Hungarian secondary:",
    "READY" if hungarian_eligible > 0
    else "NOT READY"
)

print(
    "VA sensitivity:",
    "READY" if va_eligible > 0
    else "NOT READY"
)

print(
    "Switzerland primary shared-feature validation:",
    "EXCLUDED"
)

print()
print(
    "Model training performed: NO"
)

print(
    "Kaggle data modified: NO"
)

print(
    "UCI data deleted: NO"
)

print(
    "Imputation performed: NO"
)

print(
    "Audit status: COMPLETE"
)

print()
print(
    "Eligibility summary:",
    eligibility_path
)

print(
    "Harmonized data directory:",
    UCI_HARMONIZED
)

print(
    "Audit JSON:",
    audit_json_path
)

print_separator()

print(
    "AUDIT 33 COMPLETE"
)

print_separator()