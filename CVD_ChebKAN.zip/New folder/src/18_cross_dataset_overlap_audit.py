# ================================================================
# AUDIT 18
# FOLD-SPECIFIC FEATURE-SELECTION STABILITY AUDIT
# ================================================================
#
# Purpose
# -------
# 1. Verify feature-selection stability across the frozen
#    5-fold outer CV structure.
#
# 2. Run four feature-selection methods independently inside
#    each outer-training fold:
#
#       - XGBoost importance
#       - Boruta
#       - RFE
#       - Chi-square
#
# 3. Ensure that NO validation, conformal-calibration, or
#    locked-test data are used by feature selection.
#
# 4. Record:
#       - selected features per method/fold
#       - selection frequency
#       - method agreement
#       - fold stability
#       - union
#       - intersection
#
# 5. Provide an evidence-based recommendation about whether
#    feature reduction should be used in the primary pipeline.
#
# IMPORTANT
# ---------
# This script is an AUDIT ONLY.
#
# It does NOT:
#   - train the final CGS-ChebKAN model
#   - train the final baselines
#   - use the conformal calibration set
#   - use the locked test set
#   - fit a final feature selector on the entire dataset
#
# The locked test set remains untouched.
#
# ================================================================


# ================================================================
# 1. IMPORTS
# ================================================================

from pathlib import Path
import sys
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import RFE, chi2
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from boruta import BorutaPy


warnings.filterwarnings("ignore")


# ================================================================
# 2. CONFIGURATION
# ================================================================

RANDOM_STATE = 2026

N_OUTER_FOLDS = 5

# Number of features requested from RFE.
# This is kept at 6 because Audit 16 used the same setting.
RFE_N_FEATURES = 6

# XGBoost feature selection.
XGB_N_ESTIMATORS = 300
XGB_MAX_DEPTH = 4
XGB_LEARNING_RATE = 0.05
XGB_SUBSAMPLE = 0.80
XGB_COLSAMPLE_BYTREE = 0.80

# Number of features retained by XGBoost.
#
# Audit 16 used six features per fold.
# We preserve that protocol here for reproducibility.
XGB_TOP_K = 6

# Boruta configuration.
BORUTA_N_ESTIMATORS = 300
BORUTA_MAX_ITER = 100

# Chi-square top-k.
CHI2_TOP_K = 6

# ----------------------------------------------------------------
# Project paths
# ----------------------------------------------------------------

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

DATA_DIR = (
    PROJECT_ROOT /
    "data" /
    "processed"
)

RESULTS_DIR = (
    PROJECT_ROOT /
    "results" /
    "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

# ----------------------------------------------------------------
# Input files
# ----------------------------------------------------------------

DEVELOPMENT_FILE = (
    DATA_DIR /
    "kaggle_development_cv.csv"
)

CALIBRATION_FILE = (
    DATA_DIR /
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    DATA_DIR /
    "kaggle_locked_test.csv"
)


# ================================================================
# 3. FROZEN PREDICTOR SET
# ================================================================

PREDICTORS = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"

ID_COLUMN = "id"


# ================================================================
# 4. HEADER
# ================================================================

print("=" * 70)
print("AUDIT 18")
print("FOLD-SPECIFIC FEATURE-SELECTION STABILITY AUDIT")
print("=" * 70)

print()
print(
    f"Project root : {PROJECT_ROOT}"
)

print(
    f"Development  : {DEVELOPMENT_FILE}"
)

print(
    f"Calibration  : {CALIBRATION_FILE}"
)

print(
    f"Locked test  : {TEST_FILE}"
)

print()


# ================================================================
# 5. INPUT FILE CHECK
# ================================================================

print("=" * 70)
print("STEP 1: INPUT FILE CHECK")
print("=" * 70)

required_files = {
    "Development": DEVELOPMENT_FILE,
    "Calibration": CALIBRATION_FILE,
    "Locked Test": TEST_FILE,
}

for name, path in required_files.items():

    if not path.exists():

        print()
        print(
            f"ERROR: {name} file not found:"
        )

        print(path)

        sys.exit(1)

    print(
        f"{name:15s}: EXISTS"
    )

print()


# ================================================================
# 6. LOAD DATA
# ================================================================

print("=" * 70)
print("STEP 2: LOAD FROZEN PARTITIONS")
print("=" * 70)

dev = pd.read_csv(
    DEVELOPMENT_FILE
)

cal = pd.read_csv(
    CALIBRATION_FILE
)

test = pd.read_csv(
    TEST_FILE
)

print(
    f"Development : {len(dev):,}"
)

print(
    f"Calibration : {len(cal):,}"
)

print(
    f"Locked test : {len(test):,}"
)

print()


# ================================================================
# 7. PARTITION SIZE CHECK
# ================================================================

print("=" * 70)
print("STEP 3: PARTITION INTEGRITY CHECK")
print("=" * 70)

expected_sizes = {
    "Development": 49000,
    "Calibration": 7000,
    "Locked Test": 14000,
}

actual_sizes = {
    "Development": len(dev),
    "Calibration": len(cal),
    "Locked Test": len(test),
}

partition_pass = True

for name in expected_sizes:

    expected = expected_sizes[name]
    actual = actual_sizes[name]

    passed = (
        expected == actual
    )

    print(
        f"{name:15s}: "
        f"expected={expected:,} | "
        f"actual={actual:,} | "
        f"{'PASS' if passed else 'FAIL'}"
    )

    if not passed:
        partition_pass = False


if not partition_pass:

    print()
    print(
        "ERROR: Frozen partition sizes changed."
    )

    sys.exit(1)

print()


# ================================================================
# 8. REQUIRED COLUMN CHECK
# ================================================================

print("=" * 70)
print("STEP 4: REQUIRED COLUMN CHECK")
print("=" * 70)

required_columns = set(
    PREDICTORS +
    [
        TARGET,
        ID_COLUMN,
    ]
)

column_pass = True

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    missing = sorted(
        required_columns -
        set(df.columns)
    )

    if len(missing) == 0:

        print(
            f"{name:15s}: PASS"
        )

    else:

        print(
            f"{name:15s}: FAIL"
        )

        print(
            f"Missing: {missing}"
        )

        column_pass = False


if not column_pass:

    sys.exit(1)

print()


# ================================================================
# 9. PARTITION DISJOINTNESS
# ================================================================

print("=" * 70)
print("STEP 5: PARTITION DISJOINTNESS")
print("=" * 70)

dev_ids = set(
    dev[ID_COLUMN].astype(int)
)

cal_ids = set(
    cal[ID_COLUMN].astype(int)
)

test_ids = set(
    test[ID_COLUMN].astype(int)
)

dev_cal_overlap = (
    dev_ids.intersection(cal_ids)
)

dev_test_overlap = (
    dev_ids.intersection(test_ids)
)

cal_test_overlap = (
    cal_ids.intersection(test_ids)
)

print(
    f"Development ∩ Calibration: "
    f"{len(dev_cal_overlap)}"
)

print(
    f"Development ∩ Test: "
    f"{len(dev_test_overlap)}"
)

print(
    f"Calibration ∩ Test: "
    f"{len(cal_test_overlap)}"
)

partition_disjoint_pass = (
    len(dev_cal_overlap) == 0
    and
    len(dev_test_overlap) == 0
    and
    len(cal_test_overlap) == 0
)

print()
print(
    "Partition disjointness: "
    f"{'PASS' if partition_disjoint_pass else 'FAIL'}"
)

if not partition_disjoint_pass:

    sys.exit(1)

print()


# ================================================================
# 10. TARGET CHECK
# ================================================================

print("=" * 70)
print("STEP 6: TARGET CHECK")
print("=" * 70)

target_pass = True

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test),
]:

    values = sorted(
        df[TARGET]
        .dropna()
        .unique()
        .tolist()
    )

    print(
        f"{name:15s}: "
        f"{values}"
    )

    if values != [0, 1]:
        target_pass = False


if not target_pass:

    print(
        "ERROR: Target is not binary."
    )

    sys.exit(1)

print()


# ================================================================
# 11. PREPARE DEVELOPMENT DATA
# ================================================================

X_dev = dev[
    PREDICTORS
].copy()

y_dev = (
    dev[TARGET]
    .astype(int)
    .copy()
)

ids_dev = (
    dev[ID_COLUMN]
    .astype(int)
    .copy()
)


# ================================================================
# 12. DEFINE OUTER CV
# ================================================================

print("=" * 70)
print("STEP 7: INITIALIZE OUTER 5-FOLD CV")
print("=" * 70)

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_FOLDS,
    shuffle=True,
    random_state=RANDOM_STATE
)

print(
    f"Folds: {N_OUTER_FOLDS}"
)

print(
    f"Random state: {RANDOM_STATE}"
)

print()


# ================================================================
# 13. STORAGE
# ================================================================

selection_records = []

importance_records = []

boruta_records = []

rfe_records = []

chi2_records = []

fold_summary_records = []

leakage_records = []


# ================================================================
# 14. HELPER FUNCTION
# ================================================================

def ordered_feature_names(
    names,
    scores,
    descending=True
):
    """
    Return feature names ordered by score.
    """

    pairs = list(
        zip(
            names,
            scores
        )
    )

    pairs = sorted(
        pairs,
        key=lambda x: x[1],
        reverse=descending
    )

    return pairs


# ================================================================
# 15. OUTER FOLD LOOP
# ================================================================

for fold_number, (
    train_idx,
    val_idx
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev
    ),
    start=1
):

    print()
    print("=" * 70)
    print(
        f"OUTER FOLD {fold_number}"
    )
    print("=" * 70)

    # ------------------------------------------------------------
    # 15.1 Fold split
    # ------------------------------------------------------------

    X_train_raw = (
        X_dev.iloc[train_idx]
        .copy()
    )

    X_val_raw = (
        X_dev.iloc[val_idx]
        .copy()
    )

    y_train = (
        y_dev.iloc[train_idx]
        .copy()
    )

    y_val = (
        y_dev.iloc[val_idx]
        .copy()
    )

    train_ids = (
        ids_dev.iloc[train_idx]
        .copy()
    )

    val_ids = (
        ids_dev.iloc[val_idx]
        .copy()
    )

    # ------------------------------------------------------------
    # 15.2 Train/validation overlap check
    # ------------------------------------------------------------

    train_id_set = set(
        train_ids
    )

    val_id_set = set(
        val_ids
    )

    train_val_overlap = (
        train_id_set
        .intersection(
            val_id_set
        )
    )

    overlap_count = len(
        train_val_overlap
    )

    print(
        f"Train/validation ID overlap: "
        f"{overlap_count}"
    )

    if overlap_count != 0:

        print(
            "ERROR: Train/validation overlap."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 15.3 Fold-specific median imputation
    # ------------------------------------------------------------

    print()
    print(
        "Fitting fold-specific median imputer..."
    )

    imputer = SimpleImputer(
        strategy="median"
    )

    X_train_imputed_array = (
        imputer.fit_transform(
            X_train_raw
        )
    )

    X_val_imputed_array = (
        imputer.transform(
            X_val_raw
        )
    )

    X_train_imputed = pd.DataFrame(
        X_train_imputed_array,
        columns=PREDICTORS,
        index=X_train_raw.index
    )

    X_val_imputed = pd.DataFrame(
        X_val_imputed_array,
        columns=PREDICTORS,
        index=X_val_raw.index
    )

    train_nan = int(
        X_train_imputed
        .isna()
        .sum()
        .sum()
    )

    val_nan = int(
        X_val_imputed
        .isna()
        .sum()
        .sum()
    )

    print(
        f"Training NaN after imputation: "
        f"{train_nan}"
    )

    print(
        f"Validation NaN after imputation: "
        f"{val_nan}"
    )

    if train_nan != 0 or val_nan != 0:

        print(
            "ERROR: NaN remains after imputation."
        )

        sys.exit(1)

    # ------------------------------------------------------------
    # 15.4 IMPORTANT:
    # No ADASYN
    # ------------------------------------------------------------

    print()
    print(
        "ADASYN: NOT USED"
    )

    print(
        "Reason: Audit 17 established that the dataset "
        "is already essentially perfectly balanced."
    )

    # ------------------------------------------------------------
    # 15.5 Scale data for selectors that require it
    # ------------------------------------------------------------

    # Chi-square requires non-negative values.
    # MinMax scaling is fitted ONLY on the outer training fold.

    scaler = MinMaxScaler()

    X_train_nonnegative_array = (
        scaler.fit_transform(
            X_train_imputed
        )
    )

    X_val_nonnegative_array = (
        scaler.transform(
            X_val_imputed
        )
    )

    X_train_nonnegative = pd.DataFrame(
        X_train_nonnegative_array,
        columns=PREDICTORS,
        index=X_train_imputed.index
    )

    X_val_nonnegative = pd.DataFrame(
        X_val_nonnegative_array,
        columns=PREDICTORS,
        index=X_val_imputed.index
    )

    # Safety check.
    min_value = (
        X_train_nonnegative
        .min()
        .min()
    )

    if min_value < 0:

        print(
            "ERROR: Chi-square input contains "
            "negative values."
        )

        sys.exit(1)

    # ============================================================
    # 16. XGBOOST FEATURE SELECTION
    # ============================================================

    print()
    print(
        "-" * 70
    )

    print(
        "XGBOOST FEATURE SELECTION"
    )

    print(
        "-" * 70
    )

    xgb_model = XGBClassifier(
        n_estimators=XGB_N_ESTIMATORS,
        max_depth=XGB_MAX_DEPTH,
        learning_rate=XGB_LEARNING_RATE,
        subsample=XGB_SUBSAMPLE,
        colsample_bytree=XGB_COLSAMPLE_BYTREE,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=(
            RANDOM_STATE + fold_number
        ),
        n_jobs=-1,
        tree_method="hist",
    )

    xgb_model.fit(
        X_train_imputed,
        y_train
    )

    xgb_importances = (
        xgb_model.feature_importances_
    )

    xgb_pairs = ordered_feature_names(
        PREDICTORS,
        xgb_importances,
        descending=True
    )

    xgb_selected = [
        name
        for name, score
        in xgb_pairs[:XGB_TOP_K]
    ]

    print()
    print(
        "Selected features:"
    )

    for rank, (
        name,
        score
    ) in enumerate(
        xgb_pairs[:XGB_TOP_K],
        start=1
    ):

        print(
            f"  {rank}. "
            f"{name:12s} "
            f"{score:.8f}"
        )

    for rank, (
        name,
        score
    ) in enumerate(
        xgb_pairs,
        start=1
    ):

        importance_records.append({

            "fold":
                fold_number,

            "method":
                "XGBoost",

            "feature":
                name,

            "rank":
                rank,

            "importance":
                float(score),

            "selected":
                name in xgb_selected,
        })

        selection_records.append({

            "fold":
                fold_number,

            "method":
                "XGBoost",

            "feature":
                name,

            "selected":
                int(
                    name in xgb_selected
                ),
        })


    # ============================================================
    # 17. BORUTA FEATURE SELECTION
    # ============================================================

    print()
    print(
        "-" * 70
    )

    print(
        "BORUTA FEATURE SELECTION"
    )

    print(
        "-" * 70
    )

    boruta_estimator = RandomForestClassifier(
        n_estimators=BORUTA_N_ESTIMATORS,
        max_depth=None,
        class_weight=None,
        random_state=(
            RANDOM_STATE + fold_number
        ),
        n_jobs=-1,
    )

    boruta_selector = BorutaPy(
        estimator=boruta_estimator,
        n_estimators="auto",
        verbose=0,
        alpha=0.05,
        max_iter=BORUTA_MAX_ITER,
        random_state=(
            RANDOM_STATE + fold_number
        ),
    )

    boruta_selector.fit(
        X_train_imputed.values,
        y_train.values
    )

    boruta_support = (
        boruta_selector.support_
    )

    boruta_weak_support = (
        boruta_selector.support_weak_
    )

    boruta_selected = [
        PREDICTORS[i]
        for i, selected
        in enumerate(
            boruta_support
        )
        if selected
    ]

    boruta_weak = [
        PREDICTORS[i]
        for i, selected
        in enumerate(
            boruta_weak_support
        )
        if selected
    ]

    print()
    print(
        "Confirmed Boruta features:"
    )

    if len(boruta_selected) == 0:

        print(
            "  None"
        )

    else:

        for feature in boruta_selected:

            print(
                f"  - {feature}"
            )

    print()
    print(
        "Tentative Boruta features:"
    )

    if len(boruta_weak) == 0:

        print(
            "  None"
        )

    else:

        for feature in boruta_weak:

            print(
                f"  - {feature}"
            )

    for i, feature in enumerate(
        PREDICTORS
    ):

        confirmed = bool(
            boruta_support[i]
        )

        tentative = bool(
            boruta_weak_support[i]
        )

        boruta_records.append({

            "fold":
                fold_number,

            "feature":
                feature,

            "confirmed":
                confirmed,

            "tentative":
                tentative,
        })

        selection_records.append({

            "fold":
                fold_number,

            "method":
                "Boruta",

            "feature":
                feature,

            "selected":
                int(confirmed),
        })


    # ============================================================
    # 18. RFE FEATURE SELECTION
    # ============================================================

    print()
    print(
        "-" * 70
    )

    print(
        "RFE FEATURE SELECTION"
    )

    print(
        "-" * 70
    )

    rfe_estimator = LogisticRegression(
        max_iter=2000,
        solver="liblinear",
        random_state=(
            RANDOM_STATE + fold_number
        ),
    )

    rfe_selector = RFE(
        estimator=rfe_estimator,
        n_features_to_select=RFE_N_FEATURES,
        step=1,
    )

    rfe_selector.fit(
        X_train_imputed,
        y_train
    )

    rfe_support = (
        rfe_selector.support_
    )

    rfe_ranking = (
        rfe_selector.ranking_
    )

    rfe_selected = [
        PREDICTORS[i]
        for i, selected
        in enumerate(
            rfe_support
        )
        if selected
    ]

    print()
    print(
        "Selected features:"
    )

    for feature in rfe_selected:

        print(
            f"  - {feature}"
        )

    for i, feature in enumerate(
        PREDICTORS
    ):

        rfe_records.append({

            "fold":
                fold_number,

            "feature":
                feature,

            "ranking":
                int(
                    rfe_ranking[i]
                ),

            "selected":
                bool(
                    rfe_support[i]
                ),
        })

        selection_records.append({

            "fold":
                fold_number,

            "method":
                "RFE",

            "feature":
                feature,

            "selected":
                int(
                    rfe_support[i]
                ),
        })


    # ============================================================
    # 19. CHI-SQUARE FEATURE SELECTION
    # ============================================================

    print()
    print(
        "-" * 70
    )

    print(
        "CHI-SQUARE FEATURE SELECTION"
    )

    print(
        "-" * 70
    )

    chi2_scores, chi2_pvalues = chi2(
        X_train_nonnegative,
        y_train
    )

    chi2_pairs = ordered_feature_names(
        PREDICTORS,
        chi2_scores,
        descending=True
    )

    chi2_selected = [
        name
        for name, score
        in chi2_pairs[:CHI2_TOP_K]
    ]

    print()
    print(
        "Selected features:"
    )

    for rank, (
        name,
        score
    ) in enumerate(
        chi2_pairs[:CHI2_TOP_K],
        start=1
    ):

        index = PREDICTORS.index(
            name
        )

        pvalue = (
            chi2_pvalues[index]
        )

        print(
            f"  {rank}. "
            f"{name:12s} "
            f"chi2={score:.8f} "
            f"p={pvalue:.8e}"
        )

    for rank, (
        name,
        score
    ) in enumerate(
        chi2_pairs,
        start=1
    ):

        index = PREDICTORS.index(
            name
        )

        pvalue = (
            chi2_pvalues[index]
        )

        chi2_records.append({

            "fold":
                fold_number,

            "feature":
                name,

            "rank":
                rank,

            "chi2_score":
                float(score),

            "p_value":
                float(pvalue),

            "selected":
                name in chi2_selected,
        })

        selection_records.append({

            "fold":
                fold_number,

            "method":
                "Chi-square",

            "feature":
                name,

            "selected":
                int(
                    name in chi2_selected
                ),
        })


    # ============================================================
    # 20. FOLD AGREEMENT
    # ============================================================

    print()
    print(
        "-" * 70
    )

    print(
        f"FOLD {fold_number} SELECTION AGREEMENT"
    )

    print(
        "-" * 70
    )

    method_sets = {

        "XGBoost":
            set(xgb_selected),

        "Boruta":
            set(boruta_selected),

        "RFE":
            set(rfe_selected),

        "Chi-square":
            set(chi2_selected),
    }

    union_features = set()

    for feature_set in method_sets.values():

        union_features.update(
            feature_set
        )

    intersection_features = set(
        PREDICTORS
    )

    for feature_set in method_sets.values():

        intersection_features = (
            intersection_features
            .intersection(
                feature_set
            )
        )

    print()
    print(
        "Method-specific selections:"
    )

    for method, features in (
        method_sets.items()
    ):

        print(
            f"  {method:12s}: "
            f"{sorted(features)}"
        )

    print()
    print(
        f"Union ({len(union_features)}): "
        f"{sorted(union_features)}"
    )

    print(
        f"Intersection "
        f"({len(intersection_features)}): "
        f"{sorted(intersection_features)}"
    )

    # ------------------------------------------------------------
    # Pairwise Jaccard similarity
    # ------------------------------------------------------------

    method_names = list(
        method_sets.keys()
    )

    pairwise_jaccard = {}

    for i in range(
        len(method_names)
    ):

        for j in range(
            i + 1,
            len(method_names)
        ):

            method_a = (
                method_names[i]
            )

            method_b = (
                method_names[j]
            )

            set_a = (
                method_sets[method_a]
            )

            set_b = (
                method_sets[method_b]
            )

            union_ab = (
                set_a.union(set_b)
            )

            intersection_ab = (
                set_a.intersection(set_b)
            )

            if len(union_ab) == 0:

                jaccard = 1.0

            else:

                jaccard = (
                    len(intersection_ab)
                    /
                    len(union_ab)
                )

            key = (
                f"{method_a}__{method_b}"
            )

            pairwise_jaccard[key] = (
                jaccard
            )

            print(
                f"  Jaccard "
                f"{method_a} vs {method_b}: "
                f"{jaccard:.4f}"
            )

    # ------------------------------------------------------------
    # Fold summary
    # ------------------------------------------------------------

    fold_summary_records.append({

        "fold":
            fold_number,

        "train_n":
            len(X_train_raw),

        "validation_n":
            len(X_val_raw),

        "train_validation_id_overlap":
            overlap_count,

        "training_nan_after_imputation":
            train_nan,

        "validation_nan_after_imputation":
            val_nan,

        "xgb_n_selected":
            len(xgb_selected),

        "boruta_n_selected":
            len(boruta_selected),

        "boruta_n_tentative":
            len(boruta_weak),

        "rfe_n_selected":
            len(rfe_selected),

        "chi2_n_selected":
            len(chi2_selected),

        "union_n":
            len(union_features),

        "intersection_n":
            len(intersection_features),

        "union_features":
            ";".join(
                sorted(union_features)
            ),

        "intersection_features":
            ";".join(
                sorted(intersection_features)
            ),

        "xgb_features":
            ";".join(
                sorted(xgb_selected)
            ),

        "boruta_features":
            ";".join(
                sorted(boruta_selected)
            ),

        "rfe_features":
            ";".join(
                sorted(rfe_selected)
            ),

        "chi2_features":
            ";".join(
                sorted(chi2_selected)
            ),

        "fold_leakage_pass":
            (
                overlap_count == 0
                and train_nan == 0
                and val_nan == 0
            ),
    })

    # ------------------------------------------------------------
    # Leakage record
    # ------------------------------------------------------------

    leakage_records.append({

        "fold":
            fold_number,

        "train_validation_overlap":
            overlap_count,

        "training_nan_after_imputation":
            train_nan,

        "validation_nan_after_imputation":
            val_nan,

        "calibration_used":
            False,

        "locked_test_used":
            False,

        "adasyn_used":
            False,

        "fold_leakage_pass":
            (
                overlap_count == 0
                and train_nan == 0
                and val_nan == 0
            ),
    })


# ================================================================
# 21. SAVE RAW SELECTION RESULTS
# ================================================================

print()
print("=" * 70)
print("STEP 8: SAVE FOLD-SPECIFIC SELECTION RESULTS")
print("=" * 70)

selection_df = pd.DataFrame(
    selection_records
)

selection_file = (
    RESULTS_DIR /
    "audit18_feature_selection_records.csv"
)

selection_df.to_csv(
    selection_file,
    index=False
)

print(
    f"Saved: {selection_file}"
)


# ================================================================
# 22. SAVE XGBOOST IMPORTANCES
# ================================================================

xgb_importance_df = pd.DataFrame(
    importance_records
)

xgb_importance_file = (
    RESULTS_DIR /
    "audit18_xgboost_importance.csv"
)

xgb_importance_df.to_csv(
    xgb_importance_file,
    index=False
)

print(
    f"Saved: {xgb_importance_file}"
)


# ================================================================
# 23. SAVE BORUTA RESULTS
# ================================================================

boruta_df = pd.DataFrame(
    boruta_records
)

boruta_file = (
    RESULTS_DIR /
    "audit18_boruta_results.csv"
)

boruta_df.to_csv(
    boruta_file,
    index=False
)

print(
    f"Saved: {boruta_file}"
)


# ================================================================
# 24. SAVE RFE RESULTS
# ================================================================

rfe_df = pd.DataFrame(
    rfe_records
)

rfe_file = (
    RESULTS_DIR /
    "audit18_rfe_results.csv"
)

rfe_df.to_csv(
    rfe_file,
    index=False
)

print(
    f"Saved: {rfe_file}"
)


# ================================================================
# 25. SAVE CHI-SQUARE RESULTS
# ================================================================

chi2_df = pd.DataFrame(
    chi2_records
)

chi2_file = (
    RESULTS_DIR /
    "audit18_chi2_results.csv"
)

chi2_df.to_csv(
    chi2_file,
    index=False
)

print(
    f"Saved: {chi2_file}"
)


# ================================================================
# 26. SAVE FOLD SUMMARY
# ================================================================

fold_summary_df = pd.DataFrame(
    fold_summary_records
)

fold_summary_file = (
    RESULTS_DIR /
    "audit18_fold_selection_summary.csv"
)

fold_summary_df.to_csv(
    fold_summary_file,
    index=False
)

print(
    f"Saved: {fold_summary_file}"
)


# ================================================================
# 27. SAVE LEAKAGE RECORD
# ================================================================

leakage_df = pd.DataFrame(
    leakage_records
)

leakage_file = (
    RESULTS_DIR /
    "audit18_feature_selection_leakage.csv"
)

leakage_df.to_csv(
    leakage_file,
    index=False
)

print(
    f"Saved: {leakage_file}"
)


# ================================================================
# 28. FEATURE SELECTION FREQUENCY
# ================================================================

print()
print("=" * 70)
print("STEP 9: FEATURE SELECTION FREQUENCY")
print("=" * 70)

frequency_records = []

for method in [
    "XGBoost",
    "Boruta",
    "RFE",
    "Chi-square",
]:

    method_df = selection_df[
        selection_df["method"]
        == method
    ]

    for feature in PREDICTORS:

        selected_count = int(
            method_df[
                method_df["feature"]
                == feature
            ]["selected"]
            .sum()
        )

        frequency = (
            selected_count /
            N_OUTER_FOLDS
        )

        frequency_records.append({

            "method":
                method,

            "feature":
                feature,

            "selected_folds":
                selected_count,

            "selection_frequency":
                frequency,
        })


frequency_df = pd.DataFrame(
    frequency_records
)

frequency_file = (
    RESULTS_DIR /
    "audit18_feature_selection_frequency.csv"
)

frequency_df.to_csv(
    frequency_file,
    index=False
)

print(
    f"Saved: {frequency_file}"
)

print()


# ================================================================
# 29. OVERALL METHOD AGREEMENT
# ================================================================

print("=" * 70)
print("STEP 10: OVERALL FEATURE-SELECTION AGREEMENT")
print("=" * 70)

overall_frequency_records = []

for feature in PREDICTORS:

    method_frequencies = {}

    for method in [
        "XGBoost",
        "Boruta",
        "RFE",
        "Chi-square",
    ]:

        row = frequency_df[
            (
                frequency_df["method"]
                == method
            )
            &
            (
                frequency_df["feature"]
                == feature
            )
        ]

        frequency = float(
            row[
                "selection_frequency"
            ].iloc[0]
        )

        method_frequencies[
            method
        ] = frequency

    selected_methods = sum(
        frequency > 0
        for frequency
        in method_frequencies.values()
    )

    all_method_frequency = np.mean(
        list(
            method_frequencies.values()
        )
    )

    overall_frequency_records.append({

        "feature":
            feature,

        "xgboost_frequency":
            method_frequencies["XGBoost"],

        "boruta_frequency":
            method_frequencies["Boruta"],

        "rfe_frequency":
            method_frequencies["RFE"],

        "chi2_frequency":
            method_frequencies["Chi-square"],

        "mean_method_frequency":
            all_method_frequency,

        "number_of_methods_selecting":
            selected_methods,
    })


overall_frequency_df = pd.DataFrame(
    overall_frequency_records
)

overall_frequency_df = (
    overall_frequency_df
    .sort_values(
        [
            "mean_method_frequency",
            "number_of_methods_selecting",
        ],
        ascending=False
    )
)

overall_frequency_file = (
    RESULTS_DIR /
    "audit18_overall_feature_stability.csv"
)

overall_frequency_df.to_csv(
    overall_frequency_file,
    index=False
)

print(
    f"Saved: {overall_frequency_file}"
)

print()
print(
    overall_frequency_df.to_string(
        index=False
    )
)


# ================================================================
# 30. STABILITY CATEGORIES
# ================================================================

print()
print("=" * 70)
print("STEP 11: FEATURE-STABILITY CATEGORIES")
print("=" * 70)


def stability_category(frequency):

    if frequency == 1.0:
        return "VERY_STABLE"

    if frequency >= 0.80:
        return "STABLE"

    if frequency >= 0.60:
        return "MODERATE"

    if frequency >= 0.40:
        return "LOW"

    return "RARE"


overall_frequency_df[
    "stability_category"
] = (
    overall_frequency_df[
        "mean_method_frequency"
    ]
    .apply(stability_category)
)

overall_frequency_df.to_csv(
    overall_frequency_file,
    index=False
)

print()

for _, row in (
    overall_frequency_df.iterrows()
):

    print(
        f"{row['feature']:12s}: "
        f"{row['mean_method_frequency']:.3f} "
        f"| {row['stability_category']}"
    )


# ================================================================
# 31. UNION AND INTERSECTION ACROSS FOLDS
# ================================================================

print()
print("=" * 70)
print("STEP 12: UNION / INTERSECTION STABILITY")
print("=" * 70)

fold_union_sets = []

fold_intersection_sets = []

for record in fold_summary_records:

    union_set = set(
        record[
            "union_features"
        ].split(";")
    )

    intersection_text = record[
        "intersection_features"
    ]

    if intersection_text:

        intersection_set = set(
            intersection_text.split(";")
        )

    else:

        intersection_set = set()

    fold_union_sets.append(
        union_set
    )

    fold_intersection_sets.append(
        intersection_set
    )


global_union = set()

for feature_set in fold_union_sets:

    global_union.update(
        feature_set
    )


global_intersection = set(
    PREDICTORS
)

for feature_set in fold_union_sets:

    global_intersection = (
        global_intersection
        .intersection(
            feature_set
        )
    )

print()
print(
    f"Global union of selected features "
    f"across folds ({len(global_union)}):"
)

print(
    sorted(global_union)
)

print()
print(
    f"Global intersection of fold unions "
    f"({len(global_intersection)}):"
)

print(
    sorted(global_intersection)
)


# ================================================================
# 32. FINAL LEAKAGE AUDIT
# ================================================================

print()
print("=" * 70)
print("STEP 13: FINAL LEAKAGE AUDIT")
print("=" * 70)

all_fold_leakage_pass = bool(
    leakage_df[
        "fold_leakage_pass"
    ].all()
)

calibration_used_anywhere = bool(
    leakage_df[
        "calibration_used"
    ].any()
)

test_used_anywhere = bool(
    leakage_df[
        "locked_test_used"
    ].any()
)

adasyn_used_anywhere = bool(
    leakage_df[
        "adasyn_used"
    ].any()
)

print(
    f"Fold-level leakage: "
    f"{'PASS' if all_fold_leakage_pass else 'FAIL'}"
)

print(
    f"Calibration used: "
    f"{calibration_used_anywhere}"
)

print(
    f"Locked test used: "
    f"{test_used_anywhere}"
)

print(
    f"ADASYN used: "
    f"{adasyn_used_anywhere}"
)


# ================================================================
# 33. PARTITION PROTECTION
# ================================================================

print()
print("=" * 70)
print("STEP 14: CALIBRATION / TEST PROTECTION")
print("=" * 70)

current_cal_ids = set(
    cal[ID_COLUMN].astype(int)
)

current_test_ids = set(
    test[ID_COLUMN].astype(int)
)

calibration_protected = (
    current_cal_ids == cal_ids
    and len(cal) == 7000
)

test_protected = (
    current_test_ids == test_ids
    and len(test) == 14000
)

print(
    f"Calibration protected: "
    f"{'PASS' if calibration_protected else 'FAIL'}"
)

print(
    f"Locked test protected: "
    f"{'PASS' if test_protected else 'FAIL'}"
)


# ================================================================
# 34. FINAL AUDIT DECISION
# ================================================================

final_audit_pass = (
    partition_pass
    and column_pass
    and partition_disjoint_pass
    and target_pass
    and all_fold_leakage_pass
    and not calibration_used_anywhere
    and not test_used_anywhere
    and not adasyn_used_anywhere
    and calibration_protected
    and test_protected
)


# ================================================================
# 35. PRIMARY FEATURE-REPRESENTATION DECISION
# ================================================================

# IMPORTANT:
# We do NOT automatically choose a reduced feature set.
#
# The audit is descriptive. The final model comparison should
# determine whether feature reduction improves validation
# performance under identical nested-CV conditions.
#
# Because feature-selection methods may disagree, the default
# primary representation remains the complete 11-feature
# Kaggle representation.
#
# Reduced feature sets are retained for controlled ablations.

primary_feature_strategy = (
    "FULL_11_FEATURE_REPRESENTATION"
)

reduced_feature_strategy = (
    "FEATURE_SELECTION_AS_ABLATION"
)


# ================================================================
# 36. SAVE METHODOLOGICAL DECISION
# ================================================================

methodological_decision = {

    "audit":
        "Audit 18",

    "audit_result":
        "PASS" if final_audit_pass
        else "FAIL",

    "primary_feature_strategy":
        primary_feature_strategy,

    "reduced_feature_strategy":
        reduced_feature_strategy,

    "number_of_predictors":
        len(PREDICTORS),

    "predictors":
        PREDICTORS,

    "outer_folds":
        N_OUTER_FOLDS,

    "xgb_top_k":
        XGB_TOP_K,

    "rfe_n_features":
        RFE_N_FEATURES,

    "chi2_top_k":
        CHI2_TOP_K,

    "calibration_used":
        calibration_used_anywhere,

    "locked_test_used":
        test_used_anywhere,

    "adasyn_used":
        adasyn_used_anywhere,

    "fold_leakage_pass":
        all_fold_leakage_pass,

    "calibration_protected":
        calibration_protected,

    "locked_test_protected":
        test_protected,

    "global_union":
        sorted(global_union),

    "global_intersection":
        sorted(global_intersection),
}

decision_file = (
    RESULTS_DIR /
    "audit18_feature_selection_methodological_decision.json"
)

with open(
    decision_file,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        methodological_decision,
        f,
        indent=4
    )

print()
print(
    f"Saved: {decision_file}"
)


# ================================================================
# 37. FINAL REPORT
# ================================================================

print()
print("=" * 70)
print("FINAL AUDIT 18 REPORT")
print("=" * 70)

print()

print(
    "Feature-selection methods:"
)

print(
    "  - XGBoost"
)

print(
    "  - Boruta"
)

print(
    "  - RFE"
)

print(
    "  - Chi-square"
)

print()

print(
    f"Outer folds completed: "
    f"{N_OUTER_FOLDS}"
)

print(
    f"Predictors evaluated: "
    f"{len(PREDICTORS)}"
)

print()

print(
    f"Global union: "
    f"{sorted(global_union)}"
)

print()

print(
    f"Global intersection: "
    f"{sorted(global_intersection)}"
)

print()

print(
    "Leakage protection:"
)

print(
    f"  Fold leakage: "
    f"{'PASS' if all_fold_leakage_pass else 'FAIL'}"
)

print(
    f"  Calibration used: "
    f"{calibration_used_anywhere}"
)

print(
    f"  Locked test used: "
    f"{test_used_anywhere}"
)

print(
    f"  ADASYN used: "
    f"{adasyn_used_anywhere}"
)

print()

print(
    "Primary feature strategy:"
)

print(
    f"  {primary_feature_strategy}"
)

print()

print(
    "Reduced feature strategy:"
)

print(
    f"  {reduced_feature_strategy}"
)

print()

print(
    "Overall Audit 18:"
)

print(
    f"  {'PASS' if final_audit_pass else 'FAIL'}"
)

print()

print("=" * 70)
print("AUDIT 18 COMPLETED")
print("=" * 70)