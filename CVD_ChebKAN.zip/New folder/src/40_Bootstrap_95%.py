# ============================================================
# IMPLEMENTATION 40
# BOOTSTRAP 95% CONFIDENCE INTERVALS
#
# Purpose:
#   Estimate 95% bootstrap confidence intervals for:
#   1. Kaggle locked test set
#   2. Cleveland external cohort
#   3. Hungarian external cohort
#   4. VA Long Beach external cohort
#
# Frozen evaluation protocol:
#   Kaggle locked test = 14,000
#   Cleveland = 303
#   Hungarian = 262
#   VA Long Beach = 100
#
# No:
#   - model retraining
#   - hyperparameter tuning
#   - threshold re-selection
#   - UCI-based threshold selection
#
# Frozen threshold:
#   0.477343
#
# Bootstrap:
#   2,000 stratified bootstrap repetitions
#   95% percentile confidence intervals
#
# ============================================================

import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    brier_score_loss
)

warnings.filterwarnings("ignore")


# ============================================================
# 1. CONFIGURATION
# ============================================================

SEED = 20261006

N_BOOTSTRAP = 2000

ALPHA = 0.05

# Frozen threshold selected in Implementation 39
FROZEN_THRESHOLD = 0.477343

# Project root
PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

# Results directory
OUTPUT_DIR = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)


# ============================================================
# 2. INPUT FILES
# ============================================================

KAGGLE_FILE = os.path.join(
    OUTPUT_DIR,
    "implementation39_locked_test_predictions.csv"
)

UCI_EXTERNAL_FILE = os.path.join(
    OUTPUT_DIR,
    "implementation34_uci_external_predictions.csv"
)


# ============================================================
# 3. BASIC FILE CHECK
# ============================================================

print("\n" + "=" * 70)
print("IMPLEMENTATION 40")
print("BOOTSTRAP 95% CONFIDENCE INTERVALS")
print("=" * 70)

print("\nConfiguration")
print("-" * 70)

print(
    f"Bootstrap repetitions : {N_BOOTSTRAP:,}"
)

print(
    f"Confidence level      : {100 * (1 - ALPHA):.0f}%"
)

print(
    f"Frozen threshold      : {FROZEN_THRESHOLD:.6f}"
)

print(
    f"Output directory      : {OUTPUT_DIR}"
)


# ============================================================
# 4. METRIC CALCULATION
# ============================================================

def calculate_metrics(
    y_true,
    y_probability,
    threshold
):

    y_true = np.asarray(
        y_true,
        dtype=int
    )

    y_probability = np.asarray(
        y_probability,
        dtype=float
    )

    y_prediction = (
        y_probability >= threshold
    ).astype(int)

    # --------------------------------------------------------
    # Confusion matrix
    # --------------------------------------------------------

    cm = confusion_matrix(
        y_true,
        y_prediction,
        labels=[0, 1]
    )

    tn, fp, fn, tp = cm.ravel()

    # --------------------------------------------------------
    # Classification metrics
    # --------------------------------------------------------

    accuracy = accuracy_score(
        y_true,
        y_prediction
    )

    precision = precision_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    sensitivity = recall_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    if (tn + fp) > 0:

        specificity = (
            tn / (tn + fp)
        )

    else:

        specificity = np.nan

    f1 = f1_score(
        y_true,
        y_prediction,
        zero_division=0
    )

    # --------------------------------------------------------
    # Discrimination
    # --------------------------------------------------------

    try:

        roc_auc = roc_auc_score(
            y_true,
            y_probability
        )

    except Exception:

        roc_auc = np.nan

    try:

        pr_auc = average_precision_score(
            y_true,
            y_probability
        )

    except Exception:

        pr_auc = np.nan

    # --------------------------------------------------------
    # Calibration
    # --------------------------------------------------------

    brier = brier_score_loss(
        y_true,
        y_probability
    )

    return {
        "ROC_AUC": roc_auc,
        "PR_AUC": pr_auc,
        "Accuracy": accuracy,
        "Precision": precision,
        "Sensitivity": sensitivity,
        "Specificity": specificity,
        "F1": f1,
        "Brier": brier
    }


# ============================================================
# 5. STRATIFIED BOOTSTRAP
# ============================================================

def bootstrap_metrics(
    y_true,
    y_probability,
    threshold,
    n_bootstrap,
    seed
):

    rng = np.random.default_rng(seed)

    y_true = np.asarray(
        y_true,
        dtype=int
    )

    y_probability = np.asarray(
        y_probability,
        dtype=float
    )

    # --------------------------------------------------------
    # Verify binary classes
    # --------------------------------------------------------

    negative_indices = np.where(
        y_true == 0
    )[0]

    positive_indices = np.where(
        y_true == 1
    )[0]

    if len(negative_indices) == 0:

        raise ValueError(
            "No negative class records found."
        )

    if len(positive_indices) == 0:

        raise ValueError(
            "No positive class records found."
        )

    metric_names = [
        "ROC_AUC",
        "PR_AUC",
        "Accuracy",
        "Precision",
        "Sensitivity",
        "Specificity",
        "F1",
        "Brier"
    ]

    bootstrap_values = {
        metric: []
        for metric in metric_names
    }

    # --------------------------------------------------------
    # Bootstrap repetitions
    # --------------------------------------------------------

    for b in range(
        n_bootstrap
    ):

        sampled_negative = rng.choice(
            negative_indices,
            size=len(negative_indices),
            replace=True
        )

        sampled_positive = rng.choice(
            positive_indices,
            size=len(positive_indices),
            replace=True
        )

        sampled_indices = np.concatenate(
            [
                sampled_negative,
                sampled_positive
            ]
        )

        y_bootstrap = (
            y_true[sampled_indices]
        )

        probability_bootstrap = (
            y_probability[sampled_indices]
        )

        metrics = calculate_metrics(
            y_bootstrap,
            probability_bootstrap,
            threshold
        )

        for metric in metric_names:

            value = metrics[metric]

            if np.isfinite(value):

                bootstrap_values[
                    metric
                ].append(value)

    # --------------------------------------------------------
    # Original point estimates
    # --------------------------------------------------------

    original_metrics = calculate_metrics(
        y_true,
        y_probability,
        threshold
    )

    results = []

    for metric in metric_names:

        values = np.asarray(
            bootstrap_values[metric],
            dtype=float
        )

        values = values[
            np.isfinite(values)
        ]

        if len(values) == 0:

            lower = np.nan
            upper = np.nan

        else:

            lower = np.percentile(
                values,
                2.5
            )

            upper = np.percentile(
                values,
                97.5
            )

        results.append(
            {
                "Metric": metric,
                "Estimate": original_metrics[metric],
                "CI_lower": lower,
                "CI_upper": upper,
                "Bootstrap_N": len(values)
            }
        )

    return pd.DataFrame(
        results
    )


# ============================================================
# 6. LOAD KAGGLE LOCKED TEST
# ============================================================

print("\n" + "=" * 70)
print("1. KAGGLE LOCKED TEST")
print("=" * 70)

if not os.path.exists(
    KAGGLE_FILE
):

    raise FileNotFoundError(
        f"\nKaggle prediction file not found:\n"
        f"{KAGGLE_FILE}"
    )

kaggle_df = pd.read_csv(
    KAGGLE_FILE
)

print(
    f"\nRows loaded: {len(kaggle_df):,}"
)

print(
    "Columns:"
)

print(
    kaggle_df.columns.tolist()
)


# ------------------------------------------------------------
# Verify required columns
# ------------------------------------------------------------

required_kaggle = [
    "cardio",
    "probability"
]

for column in required_kaggle:

    if column not in kaggle_df.columns:

        raise ValueError(
            f"Kaggle file is missing required "
            f"column: {column}"
        )


kaggle_y = pd.to_numeric(
    kaggle_df["cardio"],
    errors="coerce"
)

kaggle_probability = pd.to_numeric(
    kaggle_df["probability"],
    errors="coerce"
)

valid_kaggle = (
    kaggle_y.notna()
    &
    kaggle_probability.notna()
)

kaggle_y = (
    kaggle_y.loc[
        valid_kaggle
    ]
    .astype(int)
    .to_numpy()
)

kaggle_probability = (
    kaggle_probability.loc[
        valid_kaggle
    ]
    .astype(float)
    .to_numpy()
)

print(
    f"\nValid rows: {len(kaggle_y):,}"
)

print(
    "Class distribution:"
)

print(
    pd.Series(
        kaggle_y
    )
    .value_counts()
    .sort_index()
    .to_dict()
)

if len(kaggle_y) != 14000:

    raise ValueError(
        "Expected exactly 14,000 Kaggle locked-test "
        f"records, but found {len(kaggle_y)}."
    )


# ============================================================
# 7. KAGGLE BOOTSTRAP
# ============================================================

print("\nRunning Kaggle bootstrap...")

kaggle_results = bootstrap_metrics(
    kaggle_y,
    kaggle_probability,
    FROZEN_THRESHOLD,
    N_BOOTSTRAP,
    SEED
)

kaggle_results.insert(
    0,
    "Dataset",
    "Kaggle Locked Test"
)

print(
    "\nKaggle results:"
)

print(
    kaggle_results.to_string(
        index=False,
        float_format=lambda x: f"{x:.6f}"
    )
)


# ============================================================
# 8. LOAD UCI EXTERNAL PREDICTIONS
# ============================================================

print("\n" + "=" * 70)
print("2. UCI EXTERNAL VALIDATION")
print("=" * 70)

if not os.path.exists(
    UCI_EXTERNAL_FILE
):

    raise FileNotFoundError(
        f"\nUCI prediction file not found:\n"
        f"{UCI_EXTERNAL_FILE}"
    )

uci_df = pd.read_csv(
    UCI_EXTERNAL_FILE
)

print(
    f"\nRows loaded: {len(uci_df):,}"
)

print(
    "Columns:"
)

print(
    uci_df.columns.tolist()
)


# ============================================================
# 9. VERIFY UCI FILE STRUCTURE
# ============================================================

required_uci = [
    "cohort",
    "source_row",
    "true_label",
    "probability",
    "prediction"
]

for column in required_uci:

    if column not in uci_df.columns:

        raise ValueError(
            f"UCI prediction file is missing "
            f"required column: {column}"
        )


print(
    "\nUCI file structure verified."
)


# ============================================================
# 10. NORMALIZE COHORT NAMES
# ============================================================

def normalize_cohort(
    value
):

    text = str(
        value
    ).strip().lower()

    if "cleveland" in text:

        return "Cleveland"

    if "hungarian" in text:

        return "Hungarian"

    if (
        "va" in text
        or "long beach" in text
        or "long_beach" in text
    ):

        return "VA Long Beach"

    return str(value)


uci_df[
    "_cohort"
] = uci_df[
    "cohort"
].apply(
    normalize_cohort
)


print(
    "\nCohort distribution:"
)

print(
    uci_df[
        "_cohort"
    ]
    .value_counts()
)


# ============================================================
# 11. EXPECTED COHORT SIZES
# ============================================================

expected_sizes = {
    "Cleveland": 303,
    "Hungarian": 262,
    "VA Long Beach": 100
}


cohort_order = [
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]


# ============================================================
# 12. BOOTSTRAP UCI COHORTS
# ============================================================

uci_results = []

for cohort_number, cohort in enumerate(
    cohort_order,
    start=1
):

    print("\n" + "-" * 70)

    print(
        f"{cohort.upper()}"
    )

    print("-" * 70)

    subset = uci_df[
        uci_df["_cohort"] == cohort
    ].copy()

    expected = expected_sizes[
        cohort
    ]

    print(
        f"Rows found: {len(subset):,}"
    )

    print(
        f"Expected:   {expected:,}"
    )

    if len(subset) != expected:

        raise ValueError(
            f"{cohort} cohort size mismatch. "
            f"Expected {expected}, found {len(subset)}."
        )

    # --------------------------------------------------------
    # Exact prediction-cohort validation
    # --------------------------------------------------------

    if subset[
        "source_row"
    ].duplicated().any():

        raise ValueError(
            f"Duplicate source_row values detected "
            f"in {cohort}."
        )

    # --------------------------------------------------------
    # Labels and probabilities
    # --------------------------------------------------------

    y = pd.to_numeric(
        subset["true_label"],
        errors="coerce"
    )

    probability = pd.to_numeric(
        subset["probability"],
        errors="coerce"
    )

    valid = (
        y.notna()
        &
        probability.notna()
    )

    if not valid.all():

        invalid_count = (
            (~valid).sum()
        )

        raise ValueError(
            f"{cohort} contains "
            f"{invalid_count} invalid "
            f"label/probability records."
        )

    y = (
        y.astype(int)
        .to_numpy()
    )

    probability = (
        probability.astype(float)
        .to_numpy()
    )

    # --------------------------------------------------------
    # Verify binary labels
    # --------------------------------------------------------

    unique_labels = sorted(
        np.unique(y).tolist()
    )

    if unique_labels != [0, 1]:

        raise ValueError(
            f"{cohort} does not contain both "
            f"binary classes. Found: "
            f"{unique_labels}"
        )

    print(
        "Class distribution:"
    )

    print(
        pd.Series(y)
        .value_counts()
        .sort_index()
        .to_dict()
    )

    # --------------------------------------------------------
    # IMPORTANT:
    # Existing prediction column is NOT used.
    #
    # We recompute predictions using the frozen
    # threshold = 0.477343.
    # --------------------------------------------------------

    transferred_prediction = (
        probability >= FROZEN_THRESHOLD
    ).astype(int)

    print(
        "Transferred threshold:"
        f" {FROZEN_THRESHOLD:.6f}"
    )

    print(
        "Positive predictions:"
        f" {transferred_prediction.sum():,}"
    )

    # --------------------------------------------------------
    # Deterministic seed
    # --------------------------------------------------------

    cohort_seed = (
        SEED
        +
        cohort_number * 100
    )

    print(
        f"Bootstrap seed: {cohort_seed}"
    )

    # --------------------------------------------------------
    # Bootstrap
    # --------------------------------------------------------

    cohort_result = bootstrap_metrics(
        y,
        probability,
        FROZEN_THRESHOLD,
        N_BOOTSTRAP,
        cohort_seed
    )

    cohort_result.insert(
        0,
        "Dataset",
        cohort
    )

    uci_results.append(
        cohort_result
    )

    print(
        "\nBootstrap results:"
    )

    print(
        cohort_result.to_string(
            index=False,
            float_format=lambda x: f"{x:.6f}"
        )
    )


# ============================================================
# 13. COMBINE ALL RESULTS
# ============================================================

all_results = pd.concat(
    [
        kaggle_results,
        *uci_results
    ],
    ignore_index=True
)


# ============================================================
# 14. MANUSCRIPT FORMAT
# ============================================================

def format_ci(
    estimate,
    lower,
    upper
):

    if not (
        np.isfinite(estimate)
        and
        np.isfinite(lower)
        and
        np.isfinite(upper)
    ):

        return "NA"

    return (
        f"{estimate:.3f} "
        f"({lower:.3f}–{upper:.3f})"
    )


all_results[
    "Estimate_CI_95"
] = all_results.apply(
    lambda row:
        format_ci(
            row["Estimate"],
            row["CI_lower"],
            row["CI_upper"]
        ),
    axis=1
)


# ============================================================
# 15. SAVE FULL LONG-FORM RESULTS
# ============================================================

full_output = os.path.join(
    OUTPUT_DIR,
    "implementation40_bootstrap_95CI_results.csv"
)

all_results.to_csv(
    full_output,
    index=False
)

print(
    "\nSaved full results:"
)

print(
    full_output
)


# ============================================================
# 16. CREATE MANUSCRIPT TABLE
# ============================================================

wide_rows = []

for dataset in [
    "Kaggle Locked Test",
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]:

    subset = all_results[
        all_results["Dataset"] == dataset
    ]

    row = {
        "Dataset": dataset
    }

    for _, item in subset.iterrows():

        metric = item[
            "Metric"
        ]

        row[
            metric + "_95CI"
        ] = item[
            "Estimate_CI_95"
        ]

    wide_rows.append(
        row
    )


wide_df = pd.DataFrame(
    wide_rows
)


desired_columns = [
    "Dataset",
    "ROC_AUC_95CI",
    "PR_AUC_95CI",
    "Accuracy_95CI",
    "Precision_95CI",
    "Sensitivity_95CI",
    "Specificity_95CI",
    "F1_95CI",
    "Brier_95CI"
]


existing_columns = [
    col
    for col in desired_columns
    if col in wide_df.columns
]


wide_df = wide_df[
    existing_columns
]


# ============================================================
# 17. SAVE MANUSCRIPT TABLE
# ============================================================

wide_output = os.path.join(
    OUTPUT_DIR,
    "implementation40_bootstrap_95CI_manuscript_table.csv"
)

wide_df.to_csv(
    wide_output,
    index=False
)

print(
    "\nSaved manuscript table:"
)

print(
    wide_output
)


# ============================================================
# 18. SAVE JSON SUMMARY
# ============================================================

json_output = os.path.join(
    OUTPUT_DIR,
    "implementation40_bootstrap_95CI_summary.json"
)


summary = {

    "implementation":
        "Implementation 40",

    "purpose":
        "Bootstrap 95% confidence intervals "
        "for locked Kaggle test and UCI "
        "external validation",

    "bootstrap_repetitions":
        N_BOOTSTRAP,

    "confidence_level":
        0.95,

    "alpha":
        ALPHA,

    "frozen_threshold":
        FROZEN_THRESHOLD,

    "threshold_source":
        "Implementation 39 Youden threshold",

    "model_retrained":
        False,

    "hyperparameter_tuning":
        False,

    "calibration_set_used":
        False,

    "locked_test_used_for_threshold_selection":
        False,

    "uci_labels_used_for_threshold_selection":
        False,

    "uci_cohort_sizes":
        expected_sizes,

    "results":
        {}
}


for dataset in [
    "Kaggle Locked Test",
    "Cleveland",
    "Hungarian",
    "VA Long Beach"
]:

    subset = all_results[
        all_results["Dataset"] == dataset
    ]

    summary[
        "results"
    ][dataset] = {}

    for _, row in subset.iterrows():

        estimate = row[
            "Estimate"
        ]

        lower = row[
            "CI_lower"
        ]

        upper = row[
            "CI_upper"
        ]

        summary[
            "results"
        ][dataset][
            row["Metric"]
        ] = {

            "estimate":
                None
                if not np.isfinite(estimate)
                else float(estimate),

            "ci_lower":
                None
                if not np.isfinite(lower)
                else float(lower),

            "ci_upper":
                None
                if not np.isfinite(upper)
                else float(upper),

            "bootstrap_n":
                int(
                    row["Bootstrap_N"]
                )
        }


with open(
    json_output,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        summary,
        f,
        indent=4
    )


print(
    "\nSaved JSON summary:"
)

print(
    json_output
)


# ============================================================
# 19. DISPLAY FINAL TABLE
# ============================================================

print("\n" + "=" * 70)
print("FINAL MANUSCRIPT-READY BOOTSTRAP TABLE")
print("=" * 70)

print()

print(
    wide_df.to_string(
        index=False
    )
)


# ============================================================
# 20. PROTOCOL VERIFICATION
# ============================================================

print("\n" + "=" * 70)
print("PROTOCOL VERIFICATION")
print("=" * 70)

print(
    "Model retrained:                         FALSE"
)

print(
    "Hyperparameters tuned:                  FALSE"
)

print(
    "Calibration set used for CI estimation: FALSE"
)

print(
    "Locked test used for threshold choice:  FALSE"
)

print(
    "UCI labels used for threshold choice:   FALSE"
)

print(
    f"Frozen threshold:                       "
    f"{FROZEN_THRESHOLD:.6f}"
)

print(
    f"Bootstrap repetitions:                  "
    f"{N_BOOTSTRAP:,}"
)

print(
    "Confidence interval:                    "
    "95% percentile bootstrap"
)

print(
    "\nSTATUS: PASS_BOOTSTRAP_CI_EVALUATION"
)

print("=" * 70)