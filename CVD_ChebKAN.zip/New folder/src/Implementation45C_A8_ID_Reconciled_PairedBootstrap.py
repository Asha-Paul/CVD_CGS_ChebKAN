"""
IMPLEMENTATION 45B
A8 vs A6 + VERIFIED BASELINES
PAIRED DEVELOPMENT-CV STATISTICAL COMPARISON

This is a clean replacement for the failed Implementation 45.

Identity protocol
-----------------
A8/A6:
    row_index -> kaggle_development_cv.csv -> id

RF/XGBoost/MLP/B-spline KAN/Vanilla Chebyshev KAN:
    id -> kaggle_development_cv.csv -> row_index

Statistical protocol
--------------------
- Development CV only: 49,000 records
- 5,000 outcome-stratified paired patient-level bootstrap replicates
- 95% percentile bootstrap CI
- Two-sided empirical p-value with +1 correction
- Holm correction across six comparisons
- No retraining
- No tuning
- No calibration set
- No locked test
- No UCI

Outputs
-------
implementation45B_a8_paired_statistical_comparison.csv
implementation45B_a8_paired_statistical_comparison.json
implementation45B_a8_paired_statistical_comparison_report.txt
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


# ============================================================
# CONFIGURATION
# ============================================================

SEED = 20261006
BOOTSTRAP_REPS = 5000
ALPHA = 0.05
N = 49000

ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DEV_FILE = ROOT / "data" / "processed" / "kaggle_development_cv.csv"
TABLES = ROOT / "results" / "tables"

A8_FILE = TABLES / "implementation44_a8_outer_predictions.csv"
A6_FILE = TABLES / "implementation31b_reduced_corrected_a6_outer_predictions.csv"

BASELINE_FILES = {
    "Random Forest":
        TABLES / "implementation23_random_forest_outer_predictions.csv",
    "XGBoost":
        TABLES / "implementation24_xgboost_outer_predictions.csv",
    "MLP":
        TABLES / "implementation25_mlp_outer_predictions.csv",
    "B-spline KAN":
        TABLES / "implementation26_bspline_kan_outer_predictions.csv",
    "Vanilla Chebyshev KAN":
        TABLES / "implementation27_chebyshev_outer_predictions.csv",
}

OUT_CSV = TABLES / "implementation45B_a8_paired_statistical_comparison.csv"
OUT_JSON = TABLES / "implementation45B_a8_paired_statistical_comparison.json"
OUT_REPORT = TABLES / "implementation45B_a8_paired_statistical_comparison_report.txt"


# ============================================================
# BASIC HELPERS
# ============================================================

def require_file(path, name):
    if not path.exists():
        raise FileNotFoundError(
            f"{name} was not found:\n{path}"
        )


def find_col(df, candidates, description):
    for c in candidates:
        if c in df.columns:
            return c
    raise ValueError(
        f"Could not find {description}. "
        f"Expected one of {candidates}. "
        f"Available columns: {list(df.columns)}"
    )


def auc(y, p):
    return float(roc_auc_score(y, p))


# ============================================================
# DEVELOPMENT IDENTITY MAP
# ============================================================

def build_identity_map():
    require_file(DEV_FILE, "Development dataset")

    dev = pd.read_csv(DEV_FILE)

    if len(dev) != N:
        raise ValueError(
            f"Development dataset contains {len(dev)} rows; "
            f"expected {N}."
        )

    required = {"id", "cardio"}
    missing = required - set(dev.columns)

    if missing:
        raise ValueError(
            f"Development dataset missing columns: {sorted(missing)}"
        )

    if dev["id"].duplicated().any():
        raise ValueError(
            "Development dataset contains duplicate IDs."
        )

    identity = pd.DataFrame({
        "row_index": np.arange(N, dtype=int),
        "id": dev["id"].to_numpy(),
        "source_target": dev["cardio"].astype(int).to_numpy(),
    })

    return identity


# ============================================================
# A8 / A6 LOADER
# ============================================================

def load_row_index_model(path, model_name, identity):
    require_file(path, model_name)

    raw = pd.read_csv(path)

    row_col = find_col(
        raw,
        ["row_index"],
        f"{model_name} row_index"
    )

    y_col = find_col(
        raw,
        ["y_true"],
        f"{model_name} target"
    )

    p_col = find_col(
        raw,
        ["probability", "y_prob"],
        f"{model_name} probability"
    )

    out = pd.DataFrame({
        "row_index": pd.to_numeric(
            raw[row_col],
            errors="raise"
        ).astype(int),

        "y_true": pd.to_numeric(
            raw[y_col],
            errors="raise"
        ).astype(int),

        "probability": pd.to_numeric(
            raw[p_col],
            errors="raise"
        ).astype(float),
    })

    if len(out) != N:
        raise ValueError(
            f"{model_name}: {len(out)} rows; expected {N}."
        )

    if out["row_index"].duplicated().any():
        raise ValueError(
            f"{model_name}: duplicate row_index values."
        )

    if set(out["row_index"]) != set(range(N)):
        raise ValueError(
            f"{model_name}: row_index is not exactly 0..48,999."
        )

    if not np.isfinite(out["probability"]).all():
        raise ValueError(
            f"{model_name}: non-finite probabilities."
        )

    if (
        (out["probability"] < 0) |
        (out["probability"] > 1)
    ).any():
        raise ValueError(
            f"{model_name}: probabilities outside [0,1]."
        )

    # CRITICAL:
    # row_index -> frozen Development dataset -> patient ID
    out = out.merge(
        identity,
        on="row_index",
        how="left",
        validate="one_to_one"
    )

    if out["id"].isna().any():
        raise ValueError(
            f"{model_name}: failed row_index -> patient ID mapping."
        )

    target_mismatch = int(
        (out["y_true"] != out["source_target"]).sum()
    )

    if target_mismatch != 0:
        raise ValueError(
            f"{model_name}: {target_mismatch} target mismatches."
        )

    return (
        out
        .sort_values("row_index")
        .reset_index(drop=True)
    )


# ============================================================
# BASELINE LOADER
# ============================================================

def load_id_model(path, model_name, identity):
    require_file(path, model_name)

    raw = pd.read_csv(path)

    print(
        f"  {model_name} raw columns: "
        f"{list(raw.columns)}"
    )

    id_col = find_col(
        raw,
        ["id"],
        f"{model_name} patient ID"
    )

    y_col = find_col(
        raw,
        ["y_true"],
        f"{model_name} target"
    )

    p_col = find_col(
        raw,
        ["probability", "y_prob"],
        f"{model_name} probability"
    )

    out = pd.DataFrame({
        "id": raw[id_col],

        "y_true": pd.to_numeric(
            raw[y_col],
            errors="raise"
        ).astype(int),

        "probability": pd.to_numeric(
            raw[p_col],
            errors="raise"
        ).astype(float),
    })

    if len(out) != N:
        raise ValueError(
            f"{model_name}: {len(out)} rows; expected {N}."
        )

    if out["id"].duplicated().any():
        raise ValueError(
            f"{model_name}: duplicate patient IDs."
        )

    if not np.isfinite(out["probability"]).all():
        raise ValueError(
            f"{model_name}: non-finite probabilities."
        )

    if (
        (out["probability"] < 0) |
        (out["probability"] > 1)
    ).any():
        raise ValueError(
            f"{model_name}: probabilities outside [0,1]."
        )

    # CRITICAL:
    # baseline patient ID -> frozen Development dataset -> row_index
    out = out.merge(
        identity,
        on="id",
        how="left",
        validate="one_to_one"
    )

    if out["row_index"].isna().any():
        missing = int(out["row_index"].isna().sum())
        raise ValueError(
            f"{model_name}: {missing} IDs not found "
            f"in kaggle_development_cv.csv."
        )

    target_mismatch = int(
        (out["y_true"] != out["source_target"]).sum()
    )

    if target_mismatch != 0:
        raise ValueError(
            f"{model_name}: {target_mismatch} target mismatches."
        )

    out["row_index"] = out["row_index"].astype(int)

    if set(out["row_index"]) != set(range(N)):
        raise ValueError(
            f"{model_name}: reconciled row_index does not cover "
            f"exactly 0..48,999."
        )

    return (
        out
        .sort_values("row_index")
        .reset_index(drop=True)
    )


# ============================================================
# PAIRED BOOTSTRAP
# ============================================================

def stratified_bootstrap_indices(y, rng):
    positive = np.flatnonzero(y == 1)
    negative = np.flatnonzero(y == 0)

    positive_sample = rng.choice(
        positive,
        size=len(positive),
        replace=True
    )

    negative_sample = rng.choice(
        negative,
        size=len(negative),
        replace=True
    )

    indices = np.concatenate(
        [positive_sample, negative_sample]
    )

    rng.shuffle(indices)

    return indices


def paired_bootstrap(y, p_a8, p_other, seed):
    observed_a8 = auc(y, p_a8)
    observed_other = auc(y, p_other)
    observed_difference = observed_a8 - observed_other

    rng = np.random.default_rng(seed)

    differences = np.empty(
        BOOTSTRAP_REPS,
        dtype=float
    )

    valid = 0

    for _ in range(BOOTSTRAP_REPS):

        idx = stratified_bootstrap_indices(
            y,
            rng
        )

        y_b = y[idx]

        # Both classes are guaranteed by stratified sampling.
        a8_b = auc(
            y_b,
            p_a8[idx]
        )

        other_b = auc(
            y_b,
            p_other[idx]
        )

        differences[valid] = a8_b - other_b
        valid += 1

    differences = differences[:valid]

    ci_low, ci_high = np.percentile(
        differences,
        [2.5, 97.5]
    )

    n_le_zero = int(
        np.sum(differences <= 0)
    )

    n_ge_zero = int(
        np.sum(differences >= 0)
    )

    # +1 correction: never report literal p=0.
    p_left = (
        n_le_zero + 1
    ) / (
        valid + 1
    )

    p_right = (
        n_ge_zero + 1
    ) / (
        valid + 1
    )

    p_two = min(
        1.0,
        2.0 * min(p_left, p_right)
    )

    return {
        "a8_auc": observed_a8,
        "comparator_auc": observed_other,
        "auc_difference": observed_difference,
        "ci_lower": float(ci_low),
        "ci_upper": float(ci_high),
        "bootstrap_reps": valid,
        "probability_a8_better": float(
            np.mean(differences > 0)
        ),
        "n_diff_le_zero": n_le_zero,
        "n_diff_ge_zero": n_ge_zero,
        "raw_p": float(p_two),
        "ci_excludes_zero": bool(
            ci_low > 0 or ci_high < 0
        ),
        "p_floor_note": (
            f"p < {1/(valid+1):.8f}"
            if (
                n_le_zero == 0 or
                n_ge_zero == 0
            )
            else ""
        )
    }


# ============================================================
# HOLM
# ============================================================

def holm_adjust(p_values):
    p = np.asarray(
        p_values,
        dtype=float
    )

    m = len(p)

    order = np.argsort(p)

    adjusted = np.empty(m)

    running = 0.0

    for rank, idx in enumerate(order):

        value = min(
            1.0,
            (m - rank) * p[idx]
        )

        running = max(
            running,
            value
        )

        adjusted[idx] = running

    return adjusted


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 80)
    print("IMPLEMENTATION 45B")
    print("A8 VS A6 + VERIFIED BASELINES")
    print("PAIRED DEVELOPMENT-CV STATISTICAL COMPARISON")
    print("=" * 80)

    print("\nSTRICT PROTECTION:")
    print("  Development cohort only: YES")
    print("  Calibration data loaded: NO")
    print("  Locked test loaded: NO")
    print("  UCI data loaded: NO")
    print("  Model retraining: NO")
    print("  Hyperparameter tuning: NO")
    print(
        f"  Bootstrap replicates: {BOOTSTRAP_REPS}"
    )
    print(f"  Seed: {SEED}")

    TABLES.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # 1. IDENTITY
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("1. BUILDING DEVELOPMENT IDENTITY MAP")
    print("=" * 80)

    identity = build_identity_map()

    print(
        f"Development rows: {len(identity)}"
    )

    print(
        f"Unique development IDs: "
        f"{identity['id'].nunique()}"
    )

    # --------------------------------------------------------
    # 2. A8
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("2. LOADING A8")
    print("=" * 80)

    a8 = load_row_index_model(
        A8_FILE,
        "A8",
        identity
    )

    print(
        f"A8 rows: {len(a8)}"
    )

    # --------------------------------------------------------
    # 3. A6
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("3. LOADING A6")
    print("=" * 80)

    a6 = load_row_index_model(
        A6_FILE,
        "A6",
        identity
    )

    if not np.array_equal(
        a8["id"].to_numpy(),
        a6["id"].to_numpy()
    ):
        raise RuntimeError(
            "A8/A6 patient IDs do not match."
        )

    if not np.array_equal(
        a8["y_true"].to_numpy(),
        a6["y_true"].to_numpy()
    ):
        raise RuntimeError(
            "A8/A6 targets do not match."
        )

    print(
        "PASS: A8/A6 exact "
        "49,000-patient paired cohort."
    )

    print(
        "Target mismatches: 0"
    )

    y = a8["y_true"].to_numpy()

    p_a8 = a8["probability"].to_numpy()

    p_a6 = a6["probability"].to_numpy()

    print(
        f"A8 pooled ROC-AUC: "
        f"{auc(y, p_a8):.6f}"
    )

    print(
        f"A6 pooled ROC-AUC: "
        f"{auc(y, p_a6):.6f}"
    )

    print(
        f"A8 - A6: "
        f"{auc(y, p_a8) - auc(y, p_a6):+.6f}"
    )

    # --------------------------------------------------------
    # 4. BASELINES
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("4. LOADING BASELINES BY PATIENT ID")
    print("=" * 80)

    baseline_models = {}

    for name, path in BASELINE_FILES.items():

        baseline = load_id_model(
            path,
            name,
            identity
        )

        same_ids = np.array_equal(
            a8["id"].to_numpy(),
            baseline["id"].to_numpy()
        )

        same_targets = np.array_equal(
            a8["y_true"].to_numpy(),
            baseline["y_true"].to_numpy()
        )

        if not same_ids:
            raise RuntimeError(
                f"{name}: ID cohort differs from A8."
            )

        if not same_targets:
            raise RuntimeError(
                f"{name}: target cohort differs from A8."
            )

        baseline_models[name] = baseline

        print(
            f"PASS: {name:25s} | "
            f"49,000 IDs | "
            f"target mismatches=0"
        )

    # --------------------------------------------------------
    # 5. BOOTSTRAP
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("5. 5,000-REPLICATE PAIRED STRATIFIED BOOTSTRAP")
    print("=" * 80)

    comparison_probabilities = {
        "A6 Sparse Grouped ChebKAN": p_a6
    }

    for name, df in baseline_models.items():
        comparison_probabilities[name] = (
            df["probability"].to_numpy()
        )

    records = []

    for i, (name, p_other) in enumerate(
        comparison_probabilities.items(),
        start=1
    ):

        print(
            f"\nComparison {i}/"
            f"{len(comparison_probabilities)}: "
            f"A8 vs {name}"
        )

        r = paired_bootstrap(
            y,
            p_a8,
            p_other,
            SEED + i * 1000
        )

        r["comparison"] = (
            f"A8 vs {name}"
        )

        r["comparator"] = name

        r["relative_difference_percent"] = (
            r["auc_difference"] /
            r["comparator_auc"] *
            100.0
        )

        records.append(r)

        print(
            f"  A8 AUC       : "
            f"{r['a8_auc']:.6f}"
        )

        print(
            f"  Comparator   : "
            f"{r['comparator_auc']:.6f}"
        )

        print(
            f"  Difference   : "
            f"{r['auc_difference']:+.6f}"
        )

        print(
            f"  95% CI       : "
            f"[{r['ci_lower']:.6f}, "
            f"{r['ci_upper']:.6f}]"
        )

        print(
            f"  P(A8 better) : "
            f"{r['probability_a8_better']:.6f}"
        )

        print(
            f"  Raw p        : "
            f"{r['raw_p']:.8f}"
        )

    # --------------------------------------------------------
    # 6. HOLM
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("6. HOLM MULTIPLE-COMPARISON CORRECTION")
    print("=" * 80)

    raw_p = [
        r["raw_p"]
        for r in records
    ]

    adjusted_p = holm_adjust(
        raw_p
    )

    for r, hp in zip(
        records,
        adjusted_p
    ):

        r["holm_adjusted_p"] = float(hp)

        r["holm_significant_0_05"] = bool(
            hp < ALPHA
        )

        print(
            f"{r['comparator']:25s} | "
            f"raw p={r['raw_p']:.8f} | "
            f"Holm p={hp:.8f} | "
            f"CI excludes zero="
            f"{r['ci_excludes_zero']}"
        )

    # --------------------------------------------------------
    # 7. SAVE
    # --------------------------------------------------------

    print("\n" + "=" * 80)
    print("7. SAVING RESULTS")
    print("=" * 80)

    results_df = pd.DataFrame(
        records
    )

    results_df.to_csv(
        OUT_CSV,
        index=False
    )

    summary = {
        "implementation": "45B",
        "status":
            "PASS_A8_PAIRED_STATISTICAL_COMPARISON",
        "seed": SEED,
        "bootstrap_replicates":
            BOOTSTRAP_REPS,
        "development_rows": N,
        "calibration_loaded": False,
        "locked_test_loaded": False,
        "uci_loaded": False,
        "retraining": False,
        "hyperparameter_tuning": False,
        "exact_paired_cohort": True,
        "target_mismatches": 0,
        "results": records
    }

    with open(
        OUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            summary,
            f,
            indent=2
        )

    report_lines = [
        "=" * 80,
        "IMPLEMENTATION 45B REPORT",
        "=" * 80,
        "",
        "Development cohort: 49,000",
        "Exact patient-level paired cohort: YES",
        "Target mismatches: 0",
        "Calibration loaded: NO",
        "Locked test loaded: NO",
        "UCI loaded: NO",
        "Retraining: NO",
        "Hyperparameter tuning: NO",
        f"Bootstrap replicates: {BOOTSTRAP_REPS}",
        "Bootstrap type: outcome-stratified paired patient-level",
        "CI: 95% percentile bootstrap",
        "Multiple comparison correction: Holm",
        "",
        "RESULTS",
        "-" * 80
    ]

    for r in records:
        report_lines.append(
            f"{r['comparator']}: "
            f"A8={r['a8_auc']:.6f}; "
            f"Comparator={r['comparator_auc']:.6f}; "
            f"Difference={r['auc_difference']:+.6f}; "
            f"95% CI=[{r['ci_lower']:.6f}, "
            f"{r['ci_upper']:.6f}]; "
            f"raw p={r['raw_p']:.8f}; "
            f"Holm p={r['holm_adjusted_p']:.8f}."
        )

    report_lines.extend([
        "",
        "INTERPRETATION",
        "-" * 80,
        "The primary architectural comparison is A8 versus A6.",
        "Statistical significance is not equivalent to clinical significance.",
        "The locked test, conformal calibration set, and UCI cohorts remain protected.",
    ])

    OUT_REPORT.write_text(
        "\n".join(report_lines),
        encoding="utf-8"
    )

    print(
        f"CSV: {OUT_CSV}"
    )

    print(
        f"JSON: {OUT_JSON}"
    )

    print(
        f"Report: {OUT_REPORT}"
    )

    print("\n" + "=" * 80)
    print("IMPLEMENTATION 45B COMPLETE")
    print(
        "Final status: "
        "PASS_A8_PAIRED_STATISTICAL_COMPARISON"
    )
    print("=" * 80)


if __name__ == "__main__":
    main()
