from pathlib import Path
import zipfile
import pandas as pd

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

UCI_ZIP = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

UCI_FILES = {
    "Cleveland": "processed.cleveland.data",
    "Hungarian": "processed.hungarian.data",
    "Switzerland": "processed.switzerland.data",
    "VA_Long_Beach": "processed.va.data",
}

COLUMNS = [
    "age", "sex", "cp", "trestbps", "chol", "fbs",
    "restecg", "thalach", "exang", "oldpeak",
    "slope", "ca", "thal", "target"
]

print("=" * 78)
print("CVD CGS-ChebKAN — AUDIT 07")
print("UCI EXACT DUPLICATE INSPECTION")
print("=" * 78)

with zipfile.ZipFile(UCI_ZIP, "r") as z:

    for cohort, filename in UCI_FILES.items():

        with z.open(filename) as f:
            df = pd.read_csv(
                f,
                header=None,
                names=COLUMNS,
                na_values=["?"]
            )

        dup_mask = df.duplicated(
            keep=False
        )

        duplicates = df.loc[dup_mask].copy()

        print("\n" + "=" * 78)
        print(cohort)
        print("=" * 78)

        print(
            f"Total rows: {len(df)}"
        )

        print(
            f"Exact duplicate rows involved: "
            f"{len(duplicates)}"
        )

        if len(duplicates) == 0:
            print("No exact duplicates.")
            continue

        print("\nDuplicate records:")

        print(
            duplicates.to_string(
                index=True
            )
        )

        print("\nDuplicate groups:")

        group_sizes = (
            df.groupby(
                list(df.columns),
                dropna=False
            )
            .size()
            .reset_index(name="count")
        )

        repeated = group_sizes[
            group_sizes["count"] > 1
        ]

        print(
            repeated.to_string(
                index=False
            )
        )

print("\n" + "=" * 78)
print("AUDIT 07 COMPLETED")
print("=" * 78)