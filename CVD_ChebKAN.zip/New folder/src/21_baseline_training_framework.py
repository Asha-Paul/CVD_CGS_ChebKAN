# ================================================================
# IMPLEMENTATION 21
# REPRODUCIBLE BASELINE TRAINING FRAMEWORK
# ================================================================
#
# Project:
#   CGS-ChebKAN Cardiovascular Disease Study
#
# Purpose:
#   Validate the common experimental/training infrastructure before
#   implementing and training the individual baseline models.
#
# IMPORTANT:
#   This script performs INFRASTRUCTURE VALIDATION ONLY.
#   It does NOT train the final research models.
#   It does NOT use the conformal calibration set.
#   It does NOT use the locked test set for model development.
#
# Frozen methodology:
#   Development/CV       = 49,000
#   Conformal calibration = 7,000
#   Locked test          = 14,000
#
# Nested CV:
#   Outer = 5 folds
#   Inner = 4 folds
#
# Primary Kaggle representation:
#   All 11 predictors
#
# Missing values:
#   Median fitted ONLY on the active training fold.
#
# ADASYN:
#   Not used in primary pipeline.
#
# ================================================================

from pathlib import Path
from datetime import datetime
import json
import random
import sys
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import (
    StratifiedKFold,
)
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


# ================================================================
# 1. PROJECT CONFIGURATION
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data"
PROCESSED_DIR = DATA_DIR / "processed"

RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR = RESULTS_DIR / "figures"
CHECKPOINT_DIR = RESULTS_DIR / "checkpoints"

LOG_DIR = PROJECT_ROOT / "logs"


for directory in [
    PROCESSED_DIR,
    RESULTS_DIR,
    TABLES_DIR,
    FIGURES_DIR,
    CHECKPOINT_DIR,
    LOG_DIR,
]:
    directory.mkdir(
        parents=True,
        exist_ok=True
    )


# ================================================================
# 2. REPRODUCIBILITY
# ================================================================

RANDOM_STATE = 2026

np.random.seed(RANDOM_STATE)
random.seed(RANDOM_STATE)

warnings.filterwarnings("ignore")


# ================================================================
# 3. FROZEN DATA FILES
# ================================================================

DEV_FILE = (
    PROCESSED_DIR /
    "kaggle_development_cv.csv"
)

CALIBRATION_FILE = (
    PROCESSED_DIR /
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROCESSED_DIR /
    "kaggle_locked_test.csv"
)


EXPECTED_ROWS = {
    "development": 49000,
    "calibration": 7000,
    "test": 14000,
}


# ================================================================
# 4. FROZEN FEATURES
# ================================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"

EXPECTED_N_FEATURES = 11


# ================================================================
# 5. CLINICAL GROUPS
# ================================================================

CLINICAL_GROUPS = {

    "demographic": [
        "age",
        "gender",
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


# ================================================================
# 6. NESTED CV CONFIGURATION
# ================================================================

N_OUTER = 5
N_INNER = 4

OUTER_SHUFFLE = True
INNER_SHUFFLE = True

CV_RANDOM_STATE = 2026


# ================================================================
# 7. PRINT HEADER
# ================================================================

print("=" * 78)
print("IMPLEMENTATION 21")
print("REPRODUCIBLE BASELINE TRAINING FRAMEWORK")
print("=" * 78)

print()
print("Project:")
print(PROJECT_ROOT)

print()
print("Timestamp:")
print(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

print()


# ================================================================
# 8. ENVIRONMENT CHECK
# ================================================================

print("1. ENVIRONMENT CHECK")
print("-" * 78)

print("Python:")
print(sys.version)

print()
print("NumPy:")
print(np.__version__)

print()
print("Pandas:")
print(pd.__version__)

print()


# ================================================================
# 9. VERIFY DATA FILES
# ================================================================

print("2. DATA FILE VALIDATION")
print("-" * 78)

DATA_FILES = {
    "development": DEV_FILE,
    "calibration": CALIBRATION_FILE,
    "test": TEST_FILE,
}

file_errors = []

for name, file_path in DATA_FILES.items():

    print(f"{name}:")
    print(f"  {file_path}")

    if file_path.exists():

        print("  STATUS: EXISTS")

    else:

        print("  STATUS: MISSING")

        file_errors.append(
            f"Missing required file: {file_path}"
        )

print()


# ================================================================
# 10. STOP IF FILES ARE MISSING
# ================================================================

if file_errors:

    print("=" * 78)
    print("IMPLEMENTATION 21 FAILED")
    print("=" * 78)

    print()

    for error in file_errors:
        print("ERROR:", error)

    print()

    sys.exit(1)


# ================================================================
# 11. LOAD DATA
# ================================================================

print("3. LOADING FROZEN PARTITIONS")
print("-" * 78)

development = pd.read_csv(
    DEV_FILE
)

calibration = pd.read_csv(
    CALIBRATION_FILE
)

locked_test = pd.read_csv(
    TEST_FILE
)

print(
    f"Development rows: {len(development):,}"
)

print(
    f"Calibration rows: {len(calibration):,}"
)

print(
    f"Locked test rows: {len(locked_test):,}"
)

print()


# ================================================================
# 12. ROW-COUNT VALIDATION
# ================================================================

print("4. PARTITION SIZE VALIDATION")
print("-" * 78)

partition_errors = []

actual_rows = {
    "development": len(development),
    "calibration": len(calibration),
    "test": len(locked_test),
}

for name in EXPECTED_ROWS:

    expected = EXPECTED_ROWS[name]
    actual = actual_rows[name]

    print(
        f"{name}: "
        f"expected={expected:,}, "
        f"actual={actual:,}"
    )

    if expected != actual:

        partition_errors.append(
            f"{name} expected {expected} rows "
            f"but found {actual}"
        )

if partition_errors:

    for error in partition_errors:
        print("ERROR:", error)

else:

    print()
    print("Partition sizes: PASS")

print()


# ================================================================
# 13. COLUMN VALIDATION
# ================================================================

print("5. COLUMN VALIDATION")
print("-" * 78)

column_errors = []

required_columns = FEATURES + [TARGET]

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:

        column_errors.append(
            f"{partition_name} missing columns: "
            f"{missing_columns}"
        )

    extra_columns = [
        column
        for column in df.columns
        if column not in required_columns
        and column != "id"
    ]

    if extra_columns:

        print(
            f"{partition_name}: "
            f"additional non-model columns = "
            f"{extra_columns}"
        )

    else:

        print(
            f"{partition_name}: required columns present"
        )

if column_errors:

    for error in column_errors:
        print("ERROR:", error)

else:

    print()
    print("Column validation: PASS")

print()


# ================================================================
# 14. FEATURE COUNT
# ================================================================

print("6. FEATURE COUNT VALIDATION")
print("-" * 78)

print(
    f"Expected predictor count: "
    f"{EXPECTED_N_FEATURES}"
)

print(
    f"Actual predictor count: "
    f"{len(FEATURES)}"
)

if len(FEATURES) != EXPECTED_N_FEATURES:

    print("ERROR: Feature count mismatch.")

    sys.exit(1)

else:

    print("Feature count: PASS")

print()


# ================================================================
# 15. TARGET VALIDATION
# ================================================================

print("7. TARGET VALIDATION")
print("-" * 78)

target_errors = []

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    unique_targets = sorted(
        df[TARGET]
        .dropna()
        .unique()
        .tolist()
    )

    missing_target = int(
        df[TARGET].isna().sum()
    )

    print(
        f"{partition_name}: "
        f"unique={unique_targets}, "
        f"missing={missing_target}"
    )

    if unique_targets != [0, 1]:

        target_errors.append(
            f"{partition_name} target is not binary 0/1."
        )

    if missing_target != 0:

        target_errors.append(
            f"{partition_name} contains missing target values."
        )

if target_errors:

    for error in target_errors:
        print("ERROR:", error)

else:

    print()
    print("Target validation: PASS")

print()


# ================================================================
# 16. CLASS DISTRIBUTION
# ================================================================

print("8. CLASS DISTRIBUTION")
print("-" * 78)

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    counts = (
        df[TARGET]
        .value_counts()
        .sort_index()
    )

    total = len(df)

    print()
    print(partition_name)

    for cls in [0, 1]:

        count = int(
            counts.get(cls, 0)
        )

        percentage = (
            100.0 * count / total
        )

        print(
            f"  Class {cls}: "
            f"{count:,} "
            f"({percentage:.4f}%)"
        )

print()


# ================================================================
# 17. ID VALIDATION
# ================================================================

print("9. ID VALIDATION")
print("-" * 78)

id_errors = []

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    if "id" not in df.columns:

        id_errors.append(
            f"{partition_name} does not contain ID column."
        )

        continue

    duplicate_ids = int(
        df["id"].duplicated().sum()
    )

    unique_ids = int(
        df["id"].nunique()
    )

    print(
        f"{partition_name}: "
        f"unique IDs={unique_ids:,}, "
        f"duplicate IDs={duplicate_ids}"
    )

    if duplicate_ids != 0:

        id_errors.append(
            f"{partition_name} contains duplicate IDs."
        )

if id_errors:

    for error in id_errors:
        print("ERROR:", error)

else:

    print()
    print("Within-partition ID validation: PASS")

print()


# ================================================================
# 18. CROSS-PARTITION DISJOINTNESS
# ================================================================

print("10. CROSS-PARTITION DISJOINTNESS")
print("-" * 78)

dev_ids = set(
    development["id"].astype(int)
)

cal_ids = set(
    calibration["id"].astype(int)
)

test_ids = set(
    locked_test["id"].astype(int)
)

overlap_dev_cal = (
    dev_ids & cal_ids
)

overlap_dev_test = (
    dev_ids & test_ids
)

overlap_cal_test = (
    cal_ids & test_ids
)

print(
    f"Development ∩ Calibration: "
    f"{len(overlap_dev_cal)}"
)

print(
    f"Development ∩ Test: "
    f"{len(overlap_dev_test)}"
)

print(
    f"Calibration ∩ Test: "
    f"{len(overlap_cal_test)}"
)

if (
    len(overlap_dev_cal) > 0
    or
    len(overlap_dev_test) > 0
    or
    len(overlap_cal_test) > 0
):

    print()
    print(
        "ERROR: Partition overlap detected."
    )

    sys.exit(1)

else:

    print()
    print(
        "Partition disjointness: PASS"
    )

print()


# ================================================================
# 19. TOTAL PARTITION COVERAGE
# ================================================================

print("11. PARTITION COVERAGE")
print("-" * 78)

all_partition_ids = (
    dev_ids |
    cal_ids |
    test_ids
)

total_unique_ids = len(
    all_partition_ids
)

total_rows = (
    len(development)
    +
    len(calibration)
    +
    len(locked_test)
)

print(
    f"Total rows across partitions: "
    f"{total_rows:,}"
)

print(
    f"Unique IDs across partitions: "
    f"{total_unique_ids:,}"
)

if total_rows != 70000:

    print(
        "ERROR: Total partition rows "
        "are not 70,000."
    )

    sys.exit(1)

if total_unique_ids != 70000:

    print(
        "ERROR: Total unique IDs "
        "are not 70,000."
    )

    sys.exit(1)

print()
print("Partition coverage: PASS")

print()


# ================================================================
# 20. DUPLICATE RECORD CHECK
# ================================================================

print("12. DUPLICATE RECORD CHECK")
print("-" * 78)

duplicate_errors = []

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    duplicate_records = int(
        df.duplicated(
            subset=FEATURES + [TARGET]
        ).sum()
    )

    print(
        f"{partition_name}: "
        f"duplicate predictor/target rows="
        f"{duplicate_records}"
    )

    if duplicate_records > 0:

        duplicate_errors.append(
            f"{partition_name} contains "
            f"duplicate predictor/target records."
        )

if duplicate_errors:

    for error in duplicate_errors:
        print("ERROR:", error)

else:

    print()
    print("Duplicate record validation: PASS")

print()


# ================================================================
# 21. MISSINGNESS AUDIT
# ================================================================

print("13. MISSINGNESS AUDIT")
print("-" * 78)

for partition_name, df in [
    ("development", development),
    ("calibration", calibration),
    ("locked_test", locked_test),
]:

    print()
    print(partition_name)

    missing = (
        df[FEATURES]
        .isna()
        .sum()
    )

    for feature in FEATURES:

        count = int(
            missing[feature]
        )

        if count > 0:

            percentage = (
                100.0 * count / len(df)
            )

            print(
                f"  {feature}: "
                f"{count:,} "
                f"({percentage:.4f}%)"
            )

        else:

            print(
                f"  {feature}: 0"
            )

print()


# ================================================================
# 22. CLINICAL GROUP VALIDATION
# ================================================================

print("14. CLINICAL GROUP VALIDATION")
print("-" * 78)

grouped_features = []

for group_name, group_features in CLINICAL_GROUPS.items():

    print()
    print(
        f"{group_name}:"
    )

    for feature in group_features:

        print(
            f"  - {feature}"
        )

        grouped_features.append(
            feature
        )

if (
    len(grouped_features)
    != len(FEATURES)
):

    print()
    print(
        "ERROR: Clinical group count "
        "does not match predictor count."
    )

    sys.exit(1)

if (
    len(set(grouped_features))
    != len(grouped_features)
):

    print()
    print(
        "ERROR: Duplicate clinical group assignment."
    )

    sys.exit(1)

if (
    set(grouped_features)
    != set(FEATURES)
):

    print()
    print(
        "ERROR: Clinical groups do not exactly "
        "cover the 11 predictors."
    )

    sys.exit(1)

print()
print("Clinical grouping: PASS")

print()


# ================================================================
# 23. PREPROCESSING POLICY
# ================================================================

print("15. PREPROCESSING POLICY")
print("-" * 78)

PREPROCESSING_POLICY = {

    "imputation":
        "Median imputation fitted only on active training fold",

    "scaling":
        "StandardScaler fitted only on active training fold",

    "validation":
        "Validation fold transformed using training-fold statistics",

    "calibration":
        "Calibration set protected from model-development fitting",

    "locked_test":
        "Locked test protected from model-development fitting",

    "feature_selection":
        "Any feature selection performed only inside training folds",

    "adasyn":
        "Not used in primary pipeline",
}


for key, value in PREPROCESSING_POLICY.items():

    print(
        f"{key}:"
    )

    print(
        f"  {value}"
    )

print()


# ================================================================
# 24. BUILD A TEST PREPROCESSING PIPELINE
# ================================================================

print("16. FOLD-SPECIFIC PREPROCESSING TEST")
print("-" * 78)

# Use only the Development partition for this test.
#
# This is NOT model training.
# It verifies that preprocessing can be fitted on a training
# subset and applied to a validation subset without leakage.

outer_splitter = StratifiedKFold(
    n_splits=N_OUTER,
    shuffle=OUTER_SHUFFLE,
    random_state=CV_RANDOM_STATE,
)


X_dev = development[
    FEATURES
].copy()

y_dev = development[
    TARGET
].astype(int).copy()


outer_fold_records = []


for outer_fold, (
    train_index,
    validation_index
) in enumerate(
    outer_splitter.split(
        X_dev,
        y_dev
    ),
    start=1
):

    X_train = X_dev.iloc[
        train_index
    ].copy()

    X_validation = X_dev.iloc[
        validation_index
    ].copy()

    y_train = y_dev.iloc[
        train_index
    ].copy()

    y_validation = y_dev.iloc[
        validation_index
    ].copy()

    # ------------------------------------------------------------
    # Median imputation
    # ------------------------------------------------------------

    imputer = SimpleImputer(
        strategy="median"
    )

    X_train_imputed = (
        imputer.fit_transform(
            X_train
        )
    )

    X_validation_imputed = (
        imputer.transform(
            X_validation
        )
    )

    # ------------------------------------------------------------
    # Scaling
    # ------------------------------------------------------------

    scaler = StandardScaler()

    X_train_scaled = (
        scaler.fit_transform(
            X_train_imputed
        )
    )

    X_validation_scaled = (
        scaler.transform(
            X_validation_imputed
        )
    )

    # ------------------------------------------------------------
    # Validation checks
    # ------------------------------------------------------------

    if np.isnan(
        X_train_scaled
    ).any():

        print(
            f"ERROR: NaN remains in "
            f"outer fold {outer_fold} training data."
        )

        sys.exit(1)

    if np.isnan(
        X_validation_scaled
    ).any():

        print(
            f"ERROR: NaN remains in "
            f"outer fold {outer_fold} validation data."
        )

        sys.exit(1)

    if not np.isfinite(
        X_train_scaled
    ).all():

        print(
            f"ERROR: Non-finite values in "
            f"outer fold {outer_fold} training data."
        )

        sys.exit(1)

    if not np.isfinite(
        X_validation_scaled
    ).all():

        print(
            f"ERROR: Non-finite values in "
            f"outer fold {outer_fold} validation data."
        )

        sys.exit(1)

    outer_fold_records.append({

        "outer_fold":
            outer_fold,

        "train_n":
            len(train_index),

        "validation_n":
            len(validation_index),

        "train_positive":
            int(y_train.sum()),

        "validation_positive":
            int(y_validation.sum()),

        "train_negative":
            int((y_train == 0).sum()),

        "validation_negative":
            int((y_validation == 0).sum()),

        "train_nan_after_imputation":
            int(
                np.isnan(
                    X_train_imputed
                ).sum()
            ),

        "validation_nan_after_imputation":
            int(
                np.isnan(
                    X_validation_imputed
                ).sum()
            ),

        "train_nan_after_scaling":
            int(
                np.isnan(
                    X_train_scaled
                ).sum()
            ),

        "validation_nan_after_scaling":
            int(
                np.isnan(
                    X_validation_scaled
                ).sum()
            ),
    })

    print(
        f"Outer fold {outer_fold}: "
        f"train={len(train_index):,}, "
        f"validation={len(validation_index):,}, "
        f"preprocessing=PASS"
    )


print()


# ================================================================
# 25. OUTER FOLD COVERAGE
# ================================================================

print("17. OUTER FOLD COVERAGE")
print("-" * 78)

validation_counts = np.zeros(
    len(development),
    dtype=int
)

for outer_fold, (
    train_index,
    validation_index
) in enumerate(
    outer_splitter.split(
        X_dev,
        y_dev
    ),
    start=1
):

    validation_counts[
        validation_index
    ] += 1


if not np.all(
    validation_counts == 1
):

    print(
        "ERROR: Some Development records "
        "do not appear exactly once in outer "
        "validation."
    )

    sys.exit(1)

print(
    "Every Development record appears "
    "exactly once in outer validation."
)

print(
    "Outer-fold coverage: PASS"
)

print()


# ================================================================
# 26. INNER CV VALIDATION
# ================================================================

print("18. INNER CV VALIDATION")
print("-" * 78)

inner_errors = []

for outer_fold, (
    outer_train_index,
    outer_validation_index
) in enumerate(
    outer_splitter.split(
        X_dev,
        y_dev
    ),
    start=1
):

    X_outer_train = X_dev.iloc[
        outer_train_index
    ]

    y_outer_train = y_dev.iloc[
        outer_train_index
    ]

    inner_splitter = StratifiedKFold(
        n_splits=N_INNER,
        shuffle=INNER_SHUFFLE,
        random_state=CV_RANDOM_STATE,
    )

    inner_validation_counts = np.zeros(
        len(X_outer_train),
        dtype=int
    )

    inner_fold_count = 0

    for (
        inner_train_index,
        inner_validation_index
    ) in inner_splitter.split(
        X_outer_train,
        y_outer_train
    ):

        inner_fold_count += 1

        inner_validation_counts[
            inner_validation_index
        ] += 1

    if inner_fold_count != N_INNER:

        inner_errors.append(
            f"Outer fold {outer_fold}: "
            f"expected {N_INNER} inner folds."
        )

    if not np.all(
        inner_validation_counts == 1
    ):

        inner_errors.append(
            f"Outer fold {outer_fold}: "
            f"inner validation coverage failed."
        )

    print(
        f"Outer fold {outer_fold}: "
        f"inner CV = PASS"
    )


if inner_errors:

    print()

    for error in inner_errors:
        print(
            "ERROR:",
            error
        )

    sys.exit(1)

print()


# ================================================================
# 27. CALIBRATION PROTECTION
# ================================================================

print("19. CONFORMAL CALIBRATION PROTECTION")
print("-" * 78)

calibration_ids = set(
    calibration["id"].astype(int)
)

if (
    calibration_ids &
    dev_ids
):

    print(
        "ERROR: Calibration records overlap "
        "with Development records."
    )

    sys.exit(1)

if (
    calibration_ids &
    test_ids
):

    print(
        "ERROR: Calibration records overlap "
        "with locked test records."
    )

    sys.exit(1)

print(
    "Calibration partition is completely "
    "separated from Development and Test."
)

print(
    "Calibration protection: PASS"
)

print()


# ================================================================
# 28. LOCKED TEST PROTECTION
# ================================================================

print("20. LOCKED TEST PROTECTION")
print("-" * 78)

if (
    test_ids &
    dev_ids
):

    print(
        "ERROR: Locked test overlaps Development."
    )

    sys.exit(1)

if (
    test_ids &
    calibration_ids
):

    print(
        "ERROR: Locked test overlaps Calibration."
    )

    sys.exit(1)

print(
    "Locked test partition is completely "
    "separated from Development and Calibration."
)

print(
    "Locked-test protection: PASS"
)

print()


# ================================================================
# 29. NESTED CV SUMMARY TABLE
# ================================================================

print("21. NESTED CV SUMMARY")
print("-" * 78)

cv_summary = pd.DataFrame(
    outer_fold_records
)

print(
    cv_summary.to_string(
        index=False
    )
)

print()


# ================================================================
# 30. SAVE CV AUDIT TABLE
# ================================================================

cv_audit_file = (
    TABLES_DIR /
    "implementation21_nested_cv_framework_audit.csv"
)

cv_summary.to_csv(
    cv_audit_file,
    index=False
)

print(
    "Saved:"
)

print(
    cv_audit_file
)

print()


# ================================================================
# 31. MODEL DEVELOPMENT PROTECTION MATRIX
# ================================================================

print("22. MODEL DEVELOPMENT PROTECTION MATRIX")
print("-" * 78)

PROTECTION_MATRIX = {

    "Development_CV": {
        "model_training": True,
        "inner_cv": True,
        "outer_cv": True,
        "hyperparameter_selection": True,
        "feature_selection_ablation": True,
    },

    "Conformal_Calibration": {
        "model_training": False,
        "inner_cv": False,
        "outer_cv": False,
        "hyperparameter_selection": False,
        "feature_selection_ablation": False,
    },

    "Locked_Test": {
        "model_training": False,
        "inner_cv": False,
        "outer_cv": False,
        "hyperparameter_selection": False,
        "feature_selection_ablation": False,
    },
}


for partition, rules in PROTECTION_MATRIX.items():

    print()
    print(partition)

    for rule, status in rules.items():

        print(
            f"  {rule}: "
            f"{status}"
        )

print()


# ================================================================
# 32. FROZEN MODEL LIST
# ================================================================

print("23. FROZEN BASELINE MODEL LIST")
print("-" * 78)

BASELINE_MODELS = [

    "Logistic Regression",

    "Random Forest",

    "XGBoost",

    "MLP",

    "Vanilla B-spline KAN",

    "Vanilla Chebyshev-KAN",

    "Alternative-basis KAN",

    "Previous TabNet + AutoEncoder-Transformer + ResMLP",
]


for index, model in enumerate(
    BASELINE_MODELS,
    start=1
):

    print(
        f"{index:02d}. {model}"
    )

print()


# ================================================================
# 33. METRICS
# ================================================================

print("24. FROZEN PERFORMANCE METRICS")
print("-" * 78)

METRICS = [

    "Accuracy",

    "Precision",

    "Recall / Sensitivity",

    "Specificity",

    "F1-score",

    "ROC-AUC",

    "PR-AUC",

    "Brier score",

    "Expected Calibration Error",
]


for metric in METRICS:

    print(
        f"- {metric}"
    )

print()


# ================================================================
# 34. LEAKAGE RULES
# ================================================================

print("25. LEAKAGE RULES")
print("-" * 78)

LEAKAGE_RULES = [

    "No preprocessing statistics fitted using validation data.",

    "No preprocessing statistics fitted using calibration data.",

    "No preprocessing statistics fitted using locked test data.",

    "No feature selection fitted using validation data.",

    "No feature selection fitted using calibration data.",

    "No feature selection fitted using locked test data.",

    "No hyperparameter tuning using calibration data.",

    "No hyperparameter tuning using locked test data.",

    "No model selection using calibration data.",

    "No model selection using locked test data.",

    "No UCI data used in Kaggle model development.",

    "ADASYN not used in the primary pipeline.",
]


for rule in LEAKAGE_RULES:

    print(
        f"[PASS] {rule}"
    )

print()


# ================================================================
# 35. FINAL AUDIT CONDITIONS
# ================================================================

print("26. FINAL IMPLEMENTATION 21 AUDIT")
print("-" * 78)

FINAL_ERRORS = []

if len(development) != 49000:
    FINAL_ERRORS.append(
        "Development partition size incorrect."
    )

if len(calibration) != 7000:
    FINAL_ERRORS.append(
        "Calibration partition size incorrect."
    )

if len(locked_test) != 14000:
    FINAL_ERRORS.append(
        "Locked test partition size incorrect."
    )

if len(FEATURES) != 11:
    FINAL_ERRORS.append(
        "Primary feature count incorrect."
    )

if TARGET in FEATURES:
    FINAL_ERRORS.append(
        "Target included in predictors."
    )

if (
    dev_ids &
    cal_ids
):
    FINAL_ERRORS.append(
        "Development/calibration overlap."
    )

if (
    dev_ids &
    test_ids
):
    FINAL_ERRORS.append(
        "Development/test overlap."
    )

if (
    cal_ids &
    test_ids
):
    FINAL_ERRORS.append(
        "Calibration/test overlap."
    )

if (
    total_unique_ids != 70000
):
    FINAL_ERRORS.append(
        "Partition coverage is not exactly 70,000 unique IDs."
    )

if not np.all(
    validation_counts == 1
):
    FINAL_ERRORS.append(
        "Outer validation coverage failed."
    )

if inner_errors:
    FINAL_ERRORS.extend(
        inner_errors
    )


# ================================================================
# 36. FINAL RESULT
# ================================================================

print()

if FINAL_ERRORS:

    print("=" * 78)
    print("IMPLEMENTATION 21 FAILED")
    print("=" * 78)

    print()

    for index, error in enumerate(
        FINAL_ERRORS,
        start=1
    ):

        print(
            f"{index:02d}. {error}"
        )

    print()

    sys.exit(1)


print("=" * 78)
print("IMPLEMENTATION 21 PASS")
print("=" * 78)

print()

print(
    "The common baseline training framework "
    "has passed infrastructure validation."
)

print()

print("Verified:")

print(
    "  [PASS] 49,000-record Development partition"
)

print(
    "  [PASS] 7,000-record conformal calibration partition"
)

print(
    "  [PASS] 14,000-record locked test partition"
)

print(
    "  [PASS] 11-feature primary representation"
)

print(
    "  [PASS] Binary target validation"
)

print(
    "  [PASS] Partition disjointness"
)

print(
    "  [PASS] 70,000-record partition coverage"
)

print(
    "  [PASS] Fold-specific median imputation"
)

print(
    "  [PASS] Fold-specific standardization"
)

print(
    "  [PASS] 5-fold outer CV"
)

print(
    "  [PASS] 4-fold inner CV"
)

print(
    "  [PASS] Outer validation coverage"
)

print(
    "  [PASS] Inner validation coverage"
)

print(
    "  [PASS] Calibration protection"
)

print(
    "  [PASS] Locked-test protection"
)

print(
    "  [PASS] ADASYN excluded from primary pipeline"
)

print()

print(
    "NO BASELINE MODEL WAS TRAINED BY THIS SCRIPT."
)

print()

print(
    "Next stage:"
)

print(
    "Implementation 22 - Logistic Regression baseline."
)

print()

# ================================================================
# 37. SAVE COMPLETE AUDIT JSON
# ================================================================

audit_output = (
    TABLES_DIR /
    "implementation21_framework_audit.json"
)


audit_record = {

    "implementation":
        "21",

    "name":
        "Reproducible Baseline Training Framework",

    "timestamp":
        datetime.now().isoformat(),

    "status":
        "PASS",

    "project_root":
        str(PROJECT_ROOT),

    "partitions": {
        "development": len(development),
        "calibration": len(calibration),
        "locked_test": len(locked_test),
    },

    "features":
        FEATURES,

    "target":
        TARGET,

    "clinical_groups":
        CLINICAL_GROUPS,

    "nested_cv": {
        "outer_folds": N_OUTER,
        "inner_folds": N_INNER,
        "random_state": CV_RANDOM_STATE,
        "stratified": True,
    },

    "preprocessing": {
        "imputation":
            "median fitted on active training fold only",
        "scaling":
            "standardization fitted on active training fold only",
    },

    "adasyn":
        "excluded from primary pipeline",

    "baseline_models":
        BASELINE_MODELS,

    "metrics":
        METRICS,

    "calibration_protected":
        True,

    "locked_test_protected":
        True,

    "model_training_performed":
        False,

    "outer_fold_summary":
        outer_fold_records,
}


with open(
    audit_output,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        audit_record,
        f,
        indent=2,
        default=str
    )


print(
    "Framework audit saved:"
)

print(
    audit_output
)

print()

print("=" * 78)
print("END OF IMPLEMENTATION 21")
print("=" * 78)