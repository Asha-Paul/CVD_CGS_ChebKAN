
# ============================================================
# Implementation50_Final_A8_Interpretability.py
# Final A8 CGS-ChebKAN Interpretability Analysis
#
# PURPOSE
#   Generate manuscript-ready interpretability analyses for the
#   FROZEN FINAL A8 CGS-ChebKAN model.
#
# ANALYSES
#   1. Load the FINAL A8 checkpoint (NO retraining)
#   2. Verify architecture and parameter count
#   3. Verify final A8 feature/group configuration
#   4. Verify Development-only preprocessing metadata
#   5. Global permutation importance on the LOCKED TEST set
#   6. Clinical-group permutation importance
#   7. Chebyshev univariate response curves
#   8. Group-gate analysis
#   9. Cross-group interaction response analysis
#  10. Sparse/active-edge coefficient analysis
#
# IMPORTANT PROTECTION RULES
#   - NO retraining
#   - NO hyperparameter tuning
#   - NO test-based model selection
#   - Locked test is used only for post-hoc interpretation
#   - No labels are used to modify the model
#
# IMPORTANT INTERPRETATION RULE
#   Permutation importance here is POST-HOC TEST-SET INTERPRETATION.
#   It must NOT be described as a feature-selection procedure.
#
# Expected final A8:
#   Parameters = 1,924
#   Chebyshev degree K = 5
#   Group embedding = 16
#   Groups:
#       demographic
#       physiological_metabolic
#       lifestyle
#
# Expected final A8 features:
#   age, gender, height, weight, ap_hi, ap_lo,
#   cholesterol, gluc, smoke, alco, active
#
# ============================================================

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

ROOT = Path.cwd()

# Final A8 checkpoint candidates.
CHECKPOINT_CANDIDATES = [
    ROOT / "results" / "models" / "implementation46_final_a8_checkpoint.pt",
    ROOT / "results" / "models" / "implementation46_a8_final_checkpoint.pt",
    ROOT / "results" / "models" / "final_a8_checkpoint.pt",
    ROOT / "models" / "implementation46_final_a8_checkpoint.pt",
    ROOT / "models" / "final_a8_checkpoint.pt",
]

# Final locked-test predictions.
PREDICTION_CANDIDATES = [
    ROOT / "results" / "tables" / "implementation46_final_a8_locked_test_predictions.csv",
    ROOT / "results" / "tables" / "implementation46_a8_locked_test_predictions.csv",
]

# Development data.
DEV_CANDIDATES = [
    ROOT / "data" / "processed" / "kaggle_development_cv.csv",
    ROOT / "data" / "processed" / "kaggle_development.csv",
]

# Controlled BP file as fallback.
KAGGLE_CANDIDATES = [
    ROOT / "data" / "processed" / "kaggle_bp_quality_controlled.csv",
]

OUTPUT_TABLE_DIR = ROOT / "results" / "tables"
OUTPUT_FIG_DIR = ROOT / "results" / "figures"

OUTPUT_TABLE_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_FIG_DIR.mkdir(parents=True, exist_ok=True)

SEED = 20261006
N_PERMUTATIONS = 30
N_RESPONSE_POINTS = 100
N_INTERACTION_POINTS = 50

np.random.seed(SEED)
torch.manual_seed(SEED)

# ------------------------------------------------------------
# 2. FIND FILES
# ------------------------------------------------------------

def find_first_existing(candidates):
    for p in candidates:
        if p.exists():
            return p
    return None


checkpoint_file = find_first_existing(CHECKPOINT_CANDIDATES)
prediction_file = find_first_existing(PREDICTION_CANDIDATES)
dev_file = find_first_existing(DEV_CANDIDATES)

if checkpoint_file is None:
    # Recursive search for checkpoint files.
    candidates = []
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix.lower() in [".pt", ".pth"]:
            name = p.name.lower()
            if "a8" in name or "implementation46" in name:
                candidates.append(p)

    if len(candidates) == 1:
        checkpoint_file = candidates[0]
    elif len(candidates) > 1:
        candidates = sorted(
            candidates,
            key=lambda x: (
                "final" not in x.name.lower(),
                "a8" not in x.name.lower(),
                "implementation46" not in x.name.lower(),
            )
        )
        checkpoint_file = candidates[0]

if prediction_file is None:
    raise FileNotFoundError(
        "Final A8 locked-test prediction file not found."
    )

if checkpoint_file is None:
    raise FileNotFoundError(
        "\nFinal A8 checkpoint not found.\n"
        "This script requires the actual Implementation46 A8 checkpoint "
        "because the Chebyshev response and group-gate analyses must "
        "use the learned model parameters.\n\n"
        "Expected examples:\n"
        "results/models/implementation46_final_a8_checkpoint.pt\n"
        "results/models/final_a8_checkpoint.pt\n"
    )

print("=" * 78)
print("IMPLEMENTATION50 — FINAL A8 INTERPRETABILITY ANALYSIS")
print("=" * 78)
print(f"Checkpoint:       {checkpoint_file}")
print(f"Predictions:      {prediction_file}")
print(f"Development file: {dev_file}")

# ------------------------------------------------------------
# 3. LOAD CHECKPOINT
# ------------------------------------------------------------

device = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print(f"Device: {device}")

checkpoint = torch.load(
    checkpoint_file,
    map_location=device,
)

if not isinstance(checkpoint, dict):
    raise ValueError(
        "Checkpoint must be a dictionary containing model_state_dict "
        "and model metadata."
    )

print("\nCHECKPOINT KEYS")
print("-" * 78)
print(list(checkpoint.keys()))

state_dict = checkpoint.get("model_state_dict")

if state_dict is None:
    # Support checkpoints where the state dict itself is stored.
    if all(isinstance(v, torch.Tensor) for v in checkpoint.values()):
        state_dict = checkpoint
    else:
        raise KeyError(
            "model_state_dict not found in checkpoint."
        )

features = checkpoint.get(
    "features",
    [
        "age",
        "gender",
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
        "smoke",
        "alco",
        "active",
    ],
)

groups = checkpoint.get(
    "groups",
    {
        "demographic": ["age", "gender"],
        "physiological_metabolic": [
            "height",
            "weight",
            "ap_hi",
            "ap_lo",
            "cholesterol",
            "gluc",
        ],
        "lifestyle": [
            "smoke",
            "alco",
            "active",
        ],
    },
)

group_indices = checkpoint.get("group_indices")

K = int(
    checkpoint.get(
        "cheb_degree",
        5,
    )
)

embedding_dim = int(
    checkpoint.get(
        "embedding_dim",
        checkpoint.get(
            "embedding_dimension",
            16,
        ),
    )
)

print("\nMODEL METADATA")
print("-" * 78)
print(f"Features:          {features}")
print(f"Chebyshev degree:  {K}")
print(f"Embedding dim:     {embedding_dim}")
print(f"Groups:            {groups}")

# ------------------------------------------------------------
# 4. MODEL DEFINITION
# ------------------------------------------------------------

class GroupChebKANBranch(nn.Module):

    def __init__(
        self,
        n_features,
        degree,
        embedding_dim,
    ):
        super().__init__()

        self.n_features = n_features
        self.degree = degree
        self.embedding_dim = embedding_dim

        # Each input feature has K+1 Chebyshev coefficients.
        self.coefficients = nn.Parameter(
            torch.zeros(
                n_features,
                degree + 1,
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(n_features)
        )

        self.projection = nn.Linear(
            n_features,
            embedding_dim,
        )

        self.activation = nn.SiLU()

    def chebyshev_basis(self, x):

        # x shape: [N, F]
        T0 = torch.ones_like(x)

        if self.degree == 0:
            return T0.unsqueeze(-1)

        T1 = x

        basis = [
            T0,
            T1,
        ]

        for k in range(2, self.degree + 1):

            Tk = (
                2.0 * x * basis[-1]
                -
                basis[-2]
            )

            basis.append(Tk)

        return torch.stack(
            basis,
            dim=-1,
        )

    def univariate_output(self, x):

        basis = self.chebyshev_basis(x)

        # [N,F,K+1] * [F,K+1]
        values = (
            basis
            *
            self.coefficients.unsqueeze(0)
        ).sum(dim=-1)

        values = values + self.bias.unsqueeze(0)

        return values

    def forward(self, x):

        values = self.univariate_output(x)

        h = self.projection(values)

        return self.activation(h)


class A8_CGS_ChebKAN(nn.Module):

    def __init__(
        self,
        group_feature_counts,
        degree=5,
        embedding_dim=16,
    ):
        super().__init__()

        self.degree = degree
        self.embedding_dim = embedding_dim

        self.branches = nn.ModuleList()

        for n_features in group_feature_counts:
            self.branches.append(
                GroupChebKANBranch(
                    n_features=n_features,
                    degree=degree,
                    embedding_dim=embedding_dim,
                )
            )

        self.gate_logits = nn.Parameter(
            torch.zeros(
                len(group_feature_counts)
            )
        )

        # A8 pairwise interactions:
        # demo*phys, demo*life, phys*life
        self.interaction_projection = nn.Linear(
            embedding_dim * 3,
            embedding_dim,
        )

        self.interaction_activation = nn.SiLU()

        # [gated embedding 16 + interaction embedding 16]
        self.output_layer = nn.Linear(
            embedding_dim * 2,
            1,
        )

    def forward(
        self,
        group_inputs,
        return_details=False,
    ):

        branch_embeddings = []

        for branch, x in zip(
            self.branches,
            group_inputs,
        ):
            branch_embeddings.append(
                branch(x)
            )

        gates = torch.softmax(
            self.gate_logits,
            dim=0,
        )

        h_gate = sum(
            gates[i] * branch_embeddings[i]
            for i in range(len(branch_embeddings))
        )

        demo = branch_embeddings[0]
        phys = branch_embeddings[1]
        life = branch_embeddings[2]

        interactions = torch.cat(
            [
                demo * phys,
                demo * life,
                phys * life,
            ],
            dim=1,
        )

        h_interaction = self.interaction_activation(
            self.interaction_projection(
                interactions
            )
        )

        combined = torch.cat(
            [
                h_gate,
                h_interaction,
            ],
            dim=1,
        )

        logits = self.output_layer(
            combined
        ).squeeze(1)

        if return_details:
            return {
                "logits": logits,
                "probabilities": torch.sigmoid(logits),
                "branch_embeddings": branch_embeddings,
                "gates": gates,
                "interaction_embedding": h_interaction,
                "gated_embedding": h_gate,
            }

        return logits


group_feature_counts = [
    len(groups["demographic"]),
    len(groups["physiological_metabolic"]),
    len(groups["lifestyle"]),
]

model = A8_CGS_ChebKAN(
    group_feature_counts=group_feature_counts,
    degree=K,
    embedding_dim=embedding_dim,
).to(device)

# ------------------------------------------------------------
# 5. LOAD STATE DICT STRICTLY
# ------------------------------------------------------------

try:
    model.load_state_dict(
        state_dict,
        strict=True,
    )
except RuntimeError as e:
    print("\nSTRICT LOAD FAILED")
    print(e)
    raise

model.eval()

parameter_count = sum(
    p.numel()
    for p in model.parameters()
)

print("\nMODEL VERIFICATION")
print("-" * 78)
print(f"Parameter count: {parameter_count:,}")
print(f"Expected:        1,924")
print(f"Chebyshev K:     {K}")
print(f"Embedding dim:   {embedding_dim}")

if parameter_count != 1924:
    raise ValueError(
        f"Expected final A8 parameter count 1,924, "
        f"but reconstructed model has {parameter_count:,}."
    )

if K != 5:
    raise ValueError(
        f"Expected final A8 Chebyshev degree K=5, found K={K}."
    )

if embedding_dim != 16:
    raise ValueError(
        f"Expected final A8 embedding dimension 16, "
        f"found {embedding_dim}."
    )

# ------------------------------------------------------------
# 6. LOAD LOCKED TEST FEATURES
# ------------------------------------------------------------
#
# The locked-test prediction CSV intentionally contains only
# id / label / probability / prediction. It does not contain the
# 11 input features.
#
# Therefore use the original controlled Kaggle data and recover
# the exact 14,000 locked-test IDs through the ID column.
# ------------------------------------------------------------

raw_data_file = find_first_existing(KAGGLE_CANDIDATES)

if raw_data_file is None:
    raise FileNotFoundError(
        "\nCould not find:\n"
        "data/processed/kaggle_bp_quality_controlled.csv\n"
        "\nThis file is required to recover the 11 locked-test "
        "feature values using their IDs.\n"
    )

raw = pd.read_csv(raw_data_file)

required_features = features + ["id"]

missing_raw = [
    c for c in required_features
    if c not in raw.columns
]

if missing_raw:
    raise ValueError(
        f"Required features missing from controlled Kaggle file: "
        f"{missing_raw}"
    )

test_ids = pd.read_csv(prediction_file)["id"]

if test_ids.duplicated().any():
    raise ValueError("Duplicate IDs in final A8 prediction file.")

if raw["id"].duplicated().any():
    raise ValueError(
        "Duplicate IDs in controlled Kaggle data."
    )

test_df = raw[
    raw["id"].isin(test_ids)
].copy()

if len(test_df) != len(test_ids):
    raise ValueError(
        f"Could not recover exact locked-test cohort. "
        f"Expected {len(test_ids):,}; recovered {len(test_df):,}."
    )

# Preserve EXACT prediction-file order.
test_df = (
    test_df
    .set_index("id")
    .loc[test_ids]
    .reset_index()
)

if not np.array_equal(
    test_df["id"].to_numpy(),
    test_ids.to_numpy(),
):
    raise ValueError(
        "Locked-test ID ordering mismatch."
    )

print("\nLOCKED-TEST FEATURE RECOVERY")
print("-" * 78)
print(f"Expected records: {len(test_ids):,}")
print(f"Recovered records: {len(test_df):,}")
print("Exact ID order: YES")

# ------------------------------------------------------------
# 7. PREPROCESSING
# ------------------------------------------------------------
#
# A8 preprocessing:
#   - median imputation using Development only
#   - normalization to [-1,1] using Development-only min/max
#
# Metadata are retrieved from checkpoint when available.
#
# If exact metadata are not present, this script searches the
# development file and computes them from Development ONLY.
# ------------------------------------------------------------

# Development file is strongly preferred.
if dev_file is None:
    # Recover Development records by excluding final test IDs.
    # This is only a fallback; no test labels are used.
    dev_file = raw_data_file
    dev_df = raw[
        ~raw["id"].isin(test_ids)
    ].copy()
else:
    dev_df = pd.read_csv(dev_file)

if not all(
    c in dev_df.columns
    for c in features
):
    raise ValueError(
        "Development file does not contain all final A8 features."
    )

# Try checkpoint preprocessing metadata first.
impute_medians = checkpoint.get(
    "impute_medians",
    checkpoint.get(
        "median_values",
        None,
    ),
)

feature_min = checkpoint.get(
    "feature_min",
    checkpoint.get(
        "min_values",
        None,
    ),
)

feature_max = checkpoint.get(
    "feature_max",
    checkpoint.get(
        "max_values",
        None,
    ),
)

def metadata_to_dict(metadata, feature_names):

    if metadata is None:
        return None

    if isinstance(metadata, dict):
        return {
            str(k): float(v)
            for k, v in metadata.items()
            if str(k) in feature_names
        }

    if isinstance(metadata, (list, tuple, np.ndarray)):
        if len(metadata) != len(feature_names):
            return None
        return {
            feature_names[i]: float(metadata[i])
            for i in range(len(feature_names))
        }

    return None


impute_medians = metadata_to_dict(
    impute_medians,
    features,
)

feature_min = metadata_to_dict(
    feature_min,
    features,
)

feature_max = metadata_to_dict(
    feature_max,
    features,
)

# If exact preprocessing metadata were not stored in the
# checkpoint, fit them ONLY on Development.
if (
    impute_medians is None
    or feature_min is None
    or feature_max is None
):

    print(
        "\nCheckpoint preprocessing metadata incomplete; "
        "reconstructing from Development only."
    )

    impute_medians = {}
    feature_min = {}
    feature_max = {}

    for f in features:

        values = pd.to_numeric(
            dev_df[f],
            errors="coerce",
        )

        median = float(
            values.median()
        )

        if not np.isfinite(median):
            raise ValueError(
                f"Could not compute Development median for {f}."
            )

        impute_medians[f] = median

        filled = values.fillna(median)

        feature_min[f] = float(
            filled.min()
        )

        feature_max[f] = float(
            filled.max()
        )

print("\nPREPROCESSING AUDIT")
print("-" * 78)
print("Imputation source: Development only")
print("Scaling source:    Development only")

# ------------------------------------------------------------
# 8. PREPROCESS DATA TO [-1,1]
# ------------------------------------------------------------

def preprocess_frame(frame):

    x_out = np.zeros(
        (len(frame), len(features)),
        dtype=np.float32,
    )

    for j, f in enumerate(features):

        values = pd.to_numeric(
            frame[f],
            errors="coerce",
        ).to_numpy(
            dtype=np.float64
        )

        values = np.where(
            np.isfinite(values),
            values,
            impute_medians[f],
        )

        lo = feature_min[f]
        hi = feature_max[f]

        if hi <= lo:
            x_scaled = np.zeros_like(values)
        else:
            x_scaled = (
                2.0 *
                (values - lo)
                /
                (hi - lo)
                -
                1.0
            )

        x_scaled = np.clip(
            x_scaled,
            -1.0,
            1.0,
        )

        x_out[:, j] = x_scaled.astype(
            np.float32
        )

    return x_out


X_test = preprocess_frame(
    test_df
)

# ------------------------------------------------------------
# 9. BUILD GROUP MATRICES
# ------------------------------------------------------------

feature_index = {
    f: i
    for i, f in enumerate(features)
}

group_arrays = []

for group_name in [
    "demographic",
    "physiological_metabolic",
    "lifestyle",
]:

    idx = [
        feature_index[f]
        for f in groups[group_name]
    ]

    group_arrays.append(
        idx
    )

X_groups = [
    X_test[:, idx]
    for idx in group_arrays
]

X_group_tensors = [
    torch.tensor(
        x,
        dtype=torch.float32,
        device=device,
    )
    for x in X_groups
]

# ------------------------------------------------------------
# 10. PREDICTION FUNCTION
# ------------------------------------------------------------

@torch.no_grad()
def predict_probability(
    group_arrays_local
):

    tensors = [
        torch.tensor(
            x,
            dtype=torch.float32,
            device=device,
        )
        for x in group_arrays_local
    ]

    details = model(
        tensors,
        return_details=True,
    )

    return (
        details["probabilities"]
        .detach()
        .cpu()
        .numpy()
    )


base_prob = predict_probability(
    X_groups
)

# Compare with Implementation46 probabilities.
locked_pred = pd.read_csv(
    prediction_file
)

reference_prob = locked_pred[
    "probability"
].to_numpy(
    dtype=float
)

max_prediction_difference = float(
    np.max(
        np.abs(
            base_prob
            -
            reference_prob
        )
    )
)

mean_prediction_difference = float(
    np.mean(
        np.abs(
            base_prob
            -
            reference_prob
        )
    )
)

print("\nMODEL PREDICTION REPRODUCTION")
print("-" * 78)
print(
    f"Maximum probability difference: "
    f"{max_prediction_difference:.10f}"
)
print(
    f"Mean absolute probability difference: "
    f"{mean_prediction_difference:.10f}"
)

# Strict tolerance.
if max_prediction_difference > 1e-5:
    raise ValueError(
        "Reconstructed A8 model does not reproduce the final "
        "Implementation46 probabilities within tolerance."
    )

print("Prediction reproduction: PASS")

# ------------------------------------------------------------
# 11. GROUP GATES
# ------------------------------------------------------------

with torch.no_grad():

    details = model(
        X_group_tensors,
        return_details=True,
    )

    gate_values = (
        details["gates"]
        .detach()
        .cpu()
        .numpy()
    )

gate_names = [
    "demographic",
    "physiological_metabolic",
    "lifestyle",
]

gate_df = pd.DataFrame(
    {
        "group": gate_names,
        "gate_weight": gate_values,
    }
)

print("\nFINAL A8 GROUP GATES")
print("-" * 78)

for _, row in gate_df.iterrows():
    print(
        f"{row['group']:28s}: "
        f"{row['gate_weight']:.6f}"
    )

# ------------------------------------------------------------
# 12. GLOBAL PERMUTATION IMPORTANCE
# ------------------------------------------------------------
#
# Importance:
#   baseline ROC-AUC - ROC-AUC after feature permutation
#
# Positive value = performance decreases after permutation.
#
# This is a post-hoc interpretation analysis on the locked test
# set. It does NOT change the model.
# ------------------------------------------------------------

y_test = locked_pred[
    "true_label"
].to_numpy(
    dtype=int
)

from sklearn.metrics import roc_auc_score

baseline_auc = roc_auc_score(
    y_test,
    base_prob,
)

rng = np.random.default_rng(SEED)

importance_rows = []

for feature_pos, feature_name in enumerate(features):

    group_name = None
    local_position = None

    for gname, gfeatures in groups.items():

        if feature_name in gfeatures:
            group_name = gname
            local_position = gfeatures.index(
                feature_name
            )
            break

    drops = []

    for r in range(N_PERMUTATIONS):

        permuted_groups = [
            arr.copy()
            for arr in X_groups
        ]

        permuted_groups[
            gate_names.index(group_name)
        ][:, local_position] = rng.permutation(
            permuted_groups[
                gate_names.index(group_name)
            ][:, local_position]
        )

        perm_prob = predict_probability(
            permuted_groups
        )

        perm_auc = roc_auc_score(
            y_test,
            perm_prob,
        )

        drops.append(
            baseline_auc - perm_auc
        )

    importance_rows.append(
        {
            "feature": feature_name,
            "group": group_name,
            "baseline_auc": baseline_auc,
            "mean_auc_drop": float(np.mean(drops)),
            "std_auc_drop": float(np.std(drops, ddof=1)),
            "median_auc_drop": float(np.median(drops)),
            "min_auc_drop": float(np.min(drops)),
            "max_auc_drop": float(np.max(drops)),
            "n_permutations": N_PERMUTATIONS,
        }
    )

importance_df = pd.DataFrame(
    importance_rows
).sort_values(
    "mean_auc_drop",
    ascending=False,
).reset_index(
    drop=True
)

# ------------------------------------------------------------
# 13. GROUP PERMUTATION IMPORTANCE
# ------------------------------------------------------------

group_importance_rows = []

for group_name in gate_names:

    group_idx = gate_names.index(
        group_name
    )

    drops = []

    for r in range(N_PERMUTATIONS):

        permuted_groups = [
            arr.copy()
            for arr in X_groups
        ]

        permuted_groups[
            group_idx
        ] = permuted_groups[
            group_idx
        ][
            rng.permutation(
                len(permuted_groups[group_idx])
            )
        ]

        perm_prob = predict_probability(
            permuted_groups
        )

        perm_auc = roc_auc_score(
            y_test,
            perm_prob,
        )

        drops.append(
            baseline_auc - perm_auc
        )

    group_importance_rows.append(
        {
            "group": group_name,
            "gate_weight": gate_values[group_idx],
            "baseline_auc": baseline_auc,
            "mean_auc_drop": float(np.mean(drops)),
            "std_auc_drop": float(np.std(drops, ddof=1)),
            "median_auc_drop": float(np.median(drops)),
            "n_permutations": N_PERMUTATIONS,
        }
    )

group_importance_df = pd.DataFrame(
    group_importance_rows
).sort_values(
    "mean_auc_drop",
    ascending=False,
).reset_index(
    drop=True
)

# ------------------------------------------------------------
# 14. CHEBYSHEV RESPONSE CURVES
# ------------------------------------------------------------
#
# For each feature:
#   vary that feature over its Development-derived scaled
#   range while keeping all other locked-test features fixed.
#
# The resulting average predicted probability is a partial
# response curve for the learned univariate KAN component.
#
# Because A8 also contains interactions, this is an averaged
# model-response analysis rather than a causal effect.
# ------------------------------------------------------------

response_rows = []

for feature_name in features:

    feature_pos = feature_index[
        feature_name
    ]

    group_name = None
    local_position = None
    group_idx = None

    for gi, gname in enumerate(gate_names):

        if feature_name in groups[gname]:

            group_name = gname
            group_idx = gi

            local_position = groups[
                gname
            ].index(feature_name)

            break

    if group_name is None:
        raise ValueError(
            f"Feature {feature_name} not assigned to group."
        )

    original = X_groups[
        group_idx
    ][:, local_position].copy()

    grid = np.linspace(
        -1.0,
        1.0,
        N_RESPONSE_POINTS,
    )

    for value in grid:

        response_groups = [
            arr.copy()
            for arr in X_groups
        ]

        response_groups[
            group_idx
        ][:, local_position] = value

        prob = predict_probability(
            response_groups
        )

        response_rows.append(
            {
                "feature": feature_name,
                "group": group_name,
                "scaled_value": float(value),
                "mean_predicted_probability": float(
                    np.mean(prob)
                ),
                "median_predicted_probability": float(
                    np.median(prob)
                ),
                "std_predicted_probability": float(
                    np.std(prob)
                ),
            }
        )

    # Restore is implicit because X_groups itself was not changed.

response_df = pd.DataFrame(
    response_rows
)

# ------------------------------------------------------------
# 15. CROSS-GROUP INTERACTION RESPONSE ANALYSIS
# ------------------------------------------------------------
#
# Evaluate representative group pairs by varying two selected
# clinical variables simultaneously over their scaled ranges.
#
# This is a model-response surface, not a causal interaction.
#
# We select the strongest feature within each group according
# to the permutation importance calculated above.
# ------------------------------------------------------------

top_feature_by_group = {}

for group_name in gate_names:

    subset = importance_df[
        importance_df["group"] == group_name
    ]

    if len(subset) == 0:
        continue

    top_feature_by_group[group_name] = (
        subset.sort_values(
            "mean_auc_drop",
            ascending=False,
        ).iloc[0]["feature"]
    )

print("\nTOP FEATURE BY CLINICAL GROUP")
print("-" * 78)

for group_name, feature_name in top_feature_by_group.items():
    print(
        f"{group_name:28s}: {feature_name}"
    )

interaction_pairs = [
    (
        "demographic",
        "physiological_metabolic",
    ),
    (
        "demographic",
        "lifestyle",
    ),
    (
        "physiological_metabolic",
        "lifestyle",
    ),
]

interaction_rows = []

for group_a, group_b in interaction_pairs:

    feature_a = top_feature_by_group[group_a]
    feature_b = top_feature_by_group[group_b]

    gi_a = gate_names.index(group_a)
    gi_b = gate_names.index(group_b)

    li_a = groups[
        group_a
    ].index(feature_a)

    li_b = groups[
        group_b
    ].index(feature_b)

    grid_a = np.linspace(
        -1.0,
        1.0,
        N_INTERACTION_POINTS,
    )

    grid_b = np.linspace(
        -1.0,
        1.0,
        N_INTERACTION_POINTS,
    )

    # Use a fixed subsample for computational control.
    n_surface = min(
        2000,
        len(X_test),
    )

    surface_idx = np.linspace(
        0,
        len(X_test) - 1,
        n_surface,
        dtype=int,
    )

    base_surface_groups = [
        arr[
            surface_idx
        ].copy()
        for arr in X_groups
    ]

    for va in grid_a:

        for vb in grid_b:

            surface_groups = [
                arr.copy()
                for arr in base_surface_groups
            ]

            surface_groups[
                gi_a
            ][:, li_a] = va

            surface_groups[
                gi_b
            ][:, li_b] = vb

            prob = predict_probability(
                surface_groups
            )

            interaction_rows.append(
                {
                    "group_a": group_a,
                    "feature_a": feature_a,
                    "group_b": group_b,
                    "feature_b": feature_b,
                    "scaled_value_a": float(va),
                    "scaled_value_b": float(vb),
                    "mean_predicted_probability": float(
                        np.mean(prob)
                    ),
                }
            )

interaction_df = pd.DataFrame(
    interaction_rows
)

# ------------------------------------------------------------
# 16. SPARSITY / ACTIVE EDGE ANALYSIS
# ------------------------------------------------------------

sparsity_rows = []

for branch_idx, group_name in enumerate(
    gate_names
):

    branch = model.branches[
        branch_idx
    ]

    coeff = (
        branch.coefficients
        .detach()
        .cpu()
        .numpy()
    )

    group_features = groups[
        group_name
    ]

    for fi, feature_name in enumerate(
        group_features
    ):

        for k in range(K + 1):

            value = float(
                coeff[fi, k]
            )

            sparsity_rows.append(
                {
                    "group": group_name,
                    "feature": feature_name,
                    "chebyshev_degree": k,
                    "coefficient": value,
                    "absolute_coefficient": abs(value),
                    "active_at_1e-4": int(
                        abs(value) > 1e-4
                    ),
                    "active_at_1e-3": int(
                        abs(value) > 1e-3
                    ),
                    "active_at_1e-2": int(
                        abs(value) > 1e-2
                    ),
                }
            )

sparsity_df = pd.DataFrame(
    sparsity_rows
)

# Feature-level coefficient magnitude.
feature_coeff_df = (
    sparsity_df
    .groupby(
        ["group", "feature"],
        as_index=False,
    )
    .agg(
        l1_coefficient_sum=(
            "absolute_coefficient",
            "sum",
        ),
        max_absolute_coefficient=(
            "absolute_coefficient",
            "max",
        ),
        active_edges_1e_4=(
            "active_at_1e-4",
            "sum",
        ),
        active_edges_1e_3=(
            "active_at_1e-3",
            "sum",
        ),
        active_edges_1e_2=(
            "active_at_1e-2",
            "sum",
        ),
    )
)

# ------------------------------------------------------------
# 17. SAVE TABLES
# ------------------------------------------------------------

importance_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_feature_permutation_importance.csv"
)

group_importance_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_group_permutation_importance.csv"
)

gate_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_group_gates.csv"
)

response_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_chebyshev_response_curves.csv"
)

interaction_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_cross_group_interactions.csv"
)

sparsity_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_chebyshev_coefficients.csv"
)

feature_coeff_csv = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_feature_coefficient_summary.csv"
)

importance_df.to_csv(
    importance_csv,
    index=False,
)

group_importance_df.to_csv(
    group_importance_csv,
    index=False,
)

gate_df.to_csv(
    gate_csv,
    index=False,
)

response_df.to_csv(
    response_csv,
    index=False,
)

interaction_df.to_csv(
    interaction_csv,
    index=False,
)

sparsity_df.to_csv(
    sparsity_csv,
    index=False,
)

feature_coeff_df.to_csv(
    feature_coeff_csv,
    index=False,
)

# ------------------------------------------------------------
# 18. FEATURE IMPORTANCE FIGURE
# ------------------------------------------------------------

plot_df = importance_df.sort_values(
    "mean_auc_drop",
    ascending=True,
)

plt.figure(
    figsize=(8, 6)
)

plt.barh(
    plot_df["feature"],
    plot_df["mean_auc_drop"],
)

plt.xlabel(
    "Mean decrease in ROC-AUC after permutation"
)

plt.ylabel("Feature")

plt.title(
    "A8 CGS-ChebKAN Feature Permutation Importance"
)

plt.tight_layout()

importance_fig = (
    OUTPUT_FIG_DIR /
    "implementation50_a8_feature_permutation_importance.png"
)

plt.savefig(
    importance_fig,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

# ------------------------------------------------------------
# 19. GROUP IMPORTANCE FIGURE
# ------------------------------------------------------------

plot_group = group_importance_df.sort_values(
    "mean_auc_drop",
    ascending=True,
)

plt.figure(
    figsize=(8, 5)
)

plt.barh(
    plot_group["group"],
    plot_group["mean_auc_drop"],
)

plt.xlabel(
    "Mean decrease in ROC-AUC after group permutation"
)

plt.ylabel("Clinical group")

plt.title(
    "A8 CGS-ChebKAN Clinical-Group Importance"
)

plt.tight_layout()

group_fig = (
    OUTPUT_FIG_DIR /
    "implementation50_a8_group_permutation_importance.png"
)

plt.savefig(
    group_fig,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

# ------------------------------------------------------------
# 20. CHEBYSHEV RESPONSE FIGURES
# ------------------------------------------------------------

for feature_name in features:

    subset = response_df[
        response_df["feature"] == feature_name
    ]

    plt.figure(
        figsize=(7, 5)
    )

    plt.plot(
        subset["scaled_value"],
        subset["mean_predicted_probability"],
        linewidth=2,
    )

    plt.xlabel(
        f"{feature_name} (scaled to [-1, 1])"
    )

    plt.ylabel(
        "Mean predicted probability"
    )

    plt.title(
        f"A8 Chebyshev Response: {feature_name}"
    )

    plt.ylim(
        0,
        1,
    )

    plt.grid(
        alpha=0.25
    )

    plt.tight_layout()

    out = (
        OUTPUT_FIG_DIR /
        f"implementation50_a8_response_{feature_name}.png"
    )

    plt.savefig(
        out,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

# ------------------------------------------------------------
# 21. INTERACTION SURFACE FIGURES
# ------------------------------------------------------------

for group_a, group_b in interaction_pairs:

    subset = interaction_df[
        (interaction_df["group_a"] == group_a)
        &
        (interaction_df["group_b"] == group_b)
    ].copy()

    if len(subset) == 0:
        continue

    feature_a = subset[
        "feature_a"
    ].iloc[0]

    feature_b = subset[
        "feature_b"
    ].iloc[0]

    pivot = subset.pivot(
        index="scaled_value_a",
        columns="scaled_value_b",
        values="mean_predicted_probability",
    )

    plt.figure(
        figsize=(7, 6)
    )

    plt.imshow(
        pivot.to_numpy(),
        origin="lower",
        aspect="auto",
        extent=[
            -1,
            1,
            -1,
            1,
        ],
    )

    plt.xlabel(
        f"{feature_b} (scaled)"
    )

    plt.ylabel(
        f"{feature_a} (scaled)"
    )

    plt.title(
        f"Cross-Group Response: "
        f"{feature_a} × {feature_b}"
    )

    plt.colorbar(
        label="Mean predicted probability"
    )

    plt.tight_layout()

    out = (
        OUTPUT_FIG_DIR /
        f"implementation50_a8_interaction_"
        f"{feature_a}_{feature_b}.png"
    )

    plt.savefig(
        out,
        dpi=300,
        bbox_inches="tight",
    )

    plt.close()

# ------------------------------------------------------------
# 22. PROTOCOL / SUMMARY JSON
# ------------------------------------------------------------

protocol = {
    "implementation": "Implementation50",
    "purpose": (
        "Final A8 CGS-ChebKAN post-hoc interpretability analysis"
    ),
    "model": "A8 CGS-ChebKAN",
    "checkpoint": str(checkpoint_file),
    "locked_test_prediction_file": str(prediction_file),
    "locked_test_n": int(len(test_df)),
    "parameter_count": int(parameter_count),
    "chebyshev_degree": int(K),
    "embedding_dimension": int(embedding_dim),
    "features": features,
    "groups": groups,
    "device": str(device),
    "permutation_repetitions": N_PERMUTATIONS,
    "response_points": N_RESPONSE_POINTS,
    "interaction_points": N_INTERACTION_POINTS,
    "retraining": False,
    "hyperparameter_tuning": False,
    "test_used_for_model_selection": False,
    "interpretation_is_posthoc": True,
    "prediction_reproduction_max_abs_difference": max_prediction_difference,
    "prediction_reproduction_mean_abs_difference": mean_prediction_difference,
}

protocol_file = (
    OUTPUT_TABLE_DIR /
    "implementation50_a8_interpretability_protocol.json"
)

with open(
    protocol_file,
    "w",
    encoding="utf-8",
) as f:

    json.dump(
        protocol,
        f,
        indent=2,
    )

# ------------------------------------------------------------
# 23. FINAL CONSOLE REPORT
# ------------------------------------------------------------

print("\n" + "=" * 78)
print("FINAL A8 INTERPRETABILITY SUMMARY")
print("=" * 78)

print("\nGROUP GATES")
print("-" * 78)

for _, row in gate_df.iterrows():

    print(
        f"{row['group']:28s}: "
        f"{row['gate_weight']:.6f}"
    )

print("\nFEATURE PERMUTATION IMPORTANCE")
print("-" * 78)

for _, row in importance_df.iterrows():

    print(
        f"{row['feature']:15s} "
        f"{row['mean_auc_drop']:+.6f}"
    )

print("\nGROUP PERMUTATION IMPORTANCE")
print("-" * 78)

for _, row in group_importance_df.iterrows():

    print(
        f"{row['group']:28s} "
        f"{row['mean_auc_drop']:+.6f}"
    )

print("\nCHEBYSHEV COEFFICIENT SUMMARY")
print("-" * 78)

print(
    feature_coeff_df[
        [
            "group",
            "feature",
            "l1_coefficient_sum",
            "max_absolute_coefficient",
            "active_edges_1e_3",
            "active_edges_1e_2",
        ]
    ].to_string(index=False)
)

print("\n" + "=" * 78)
print("AUDIT STATUS")
print("=" * 78)

print("PASS_FINAL_A8_INTERPRETABILITY")
print(f"Locked test records: {len(test_df):,}")
print(f"Parameters: {parameter_count:,}")
print(f"Chebyshev degree: {K}")
print(f"Embedding dimension: {embedding_dim}")
print("Retraining: NO")
print("Hyperparameter tuning: NO")
print("Test used for model selection: NO")
print("Interpretability analysis: POST-HOC")
print(
    "Prediction reproduction: PASS "
    f"(max abs diff={max_prediction_difference:.10f})"
)

print("\nOUTPUT FILES")
print("-" * 78)

for pth in [
    importance_csv,
    group_importance_csv,
    gate_csv,
    response_csv,
    interaction_csv,
    sparsity_csv,
    feature_coeff_csv,
    protocol_file,
    importance_fig,
    group_fig,
]:

    print(pth)

print("\nIndividual Chebyshev response figures:")
for feature_name in features:
    print(
        OUTPUT_FIG_DIR /
        f"implementation50_a8_response_{feature_name}.png"
    )

print("\nCross-group interaction figures:")
for group_a, group_b in interaction_pairs:

    feature_a = top_feature_by_group[group_a]
    feature_b = top_feature_by_group[group_b]

    print(
        OUTPUT_FIG_DIR /
        f"implementation50_a8_interaction_"
        f"{feature_a}_{feature_b}.png"
    )
