# ============================================================
# IMPLEMENTATION 43B-2
# A6 ROW_INDEX -> KAGGLE ID RECONCILIATION
# ============================================================
#
# PURPOSE
# -------
# Establish whether the A6 outer-CV prediction file
#
#   implementation31b_reduced_corrected_a6_outer_predictions.csv
#
# can be mapped from:
#
#   row_index = 0 ... 48,999
#
# to the original Kaggle observation IDs.
#
# A mapping is accepted ONLY if:
#
# 1. It contains exactly 49,000 unique Kaggle IDs.
# 2. All IDs belong to the verified common 49k baseline cohort.
# 3. A6 y_true matches the Kaggle source target.
# 4. A6 y_true matches RF y_true.
# 5. A6 y_true matches XGBoost y_true.
# 6. A6 y_true matches MLP y_true.
# 7. A6 y_true matches B-spline KAN y_true.
# 8. A6 y_true matches vanilla Chebyshev KAN y_true.
#
# NO:
#   - retraining
#   - statistical testing
#   - locked test
#   - UCI
#
# ============================================================

import json
import hashlib
import warnings
from pathlib import Path

import numpy as np
import pandas as pd


# ============================================================
# PATHS
# ============================================================

RESULTS_DIR = Path("results") / "tables"

SOURCE_FILE = (
    Path("data")
    / "processed"
    / "kaggle_bp_quality_controlled.csv"
)

A6_FILE = (
    RESULTS_DIR
    / "implementation31b_reduced_corrected_a6_outer_predictions.csv"
)

BASELINE_FILES = {

    "Random_Forest":
        RESULTS_DIR
        / "implementation23_random_forest_outer_predictions.csv",

    "XGBoost":
        RESULTS_DIR
        / "implementation24_xgboost_outer_predictions.csv",

    "MLP":
        RESULTS_DIR
        / "implementation25_mlp_outer_predictions.csv",

    "B-spline_KAN":
        RESULTS_DIR
        / "implementation26_bspline_kan_outer_predictions.csv",

    "Vanilla_Chebyshev_KAN":
        RESULTS_DIR
        / "implementation27_chebyshev_outer_predictions.csv",
}


# ============================================================
# OUTPUTS
# ============================================================

SUMMARY_FILE = (
    RESULTS_DIR
    / "implementation43B2_A6_row_index_reconciliation.csv"
)

JSON_FILE = (
    RESULTS_DIR
    / "implementation43B2_A6_row_index_reconciliation.json"
)

REPORT_FILE = (
    RESULTS_DIR
    / "implementation43B2_A6_row_index_reconciliation_report.txt"
)

CANDIDATE_FILE = (
    RESULTS_DIR
    / "implementation43B2_candidate_mapping_audit.csv"
)

MAPPING_FILE = (
    RESULTS_DIR
    / "implementation43B2_verified_A6_row_index_to_kaggle_id.csv"
)


# ============================================================
# CONSTANTS
# ============================================================

TOTAL_ROWS = 70000
DEV_ROWS = 49000

SEEDS_TO_TEST = [
    0,
    1,
    7,
    10,
    42,
    100,
    123,
    1234,
    2024,
    2025,
    2026,
    6102026,
    20261006,
]


# ============================================================
# UTILITIES
# ============================================================

def require_file(path):

    if not path.exists():

        raise FileNotFoundError(
            f"\nRequired file not found:\n{path}"
        )


def sha256(path):

    h = hashlib.sha256()

    with open(path, "rb") as f:

        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b""
        ):

            h.update(chunk)

    return h.hexdigest()


def header(title):

    print()
    print("=" * 60)
    print(title)
    print("=" * 60)


# ============================================================
# LOAD SOURCE
# ============================================================

def load_source():

    header(
        "LOADING KAGGLE SOURCE"
    )

    require_file(
        SOURCE_FILE
    )

    df = pd.read_csv(
        SOURCE_FILE
    )

    print(
        f"Source: {SOURCE_FILE}"
    )

    print(
        f"Rows: {len(df):,}"
    )

    print(
        f"SHA256: {sha256(SOURCE_FILE)}"
    )

    if len(df) != TOTAL_ROWS:

        raise RuntimeError(
            "Kaggle source does not contain "
            "70,000 rows."
        )

    required = [
        "id",
        "cardio"
    ]

    for col in required:

        if col not in df.columns:

            raise RuntimeError(
                f"Missing source column: {col}"
            )

    if df["id"].duplicated().any():

        raise RuntimeError(
            "Kaggle source IDs are not unique."
        )

    df["id"] = (
        pd.to_numeric(
            df["id"],
            errors="raise"
        )
        .astype(int)
    )

    df["cardio"] = (
        pd.to_numeric(
            df["cardio"],
            errors="raise"
        )
        .astype(int)
    )

    return df


# ============================================================
# LOAD A6
# ============================================================

def load_a6():

    header(
        "LOADING A6 PREDICTIONS"
    )

    require_file(
        A6_FILE
    )

    df = pd.read_csv(
        A6_FILE
    )

    print(
        f"File: {A6_FILE}"
    )

    print(
        f"Rows: {len(df):,}"
    )

    print(
        f"Columns: {list(df.columns)}"
    )

    required = [
        "row_index",
        "outer_fold",
        "y_true",
        "probability"
    ]

    for col in required:

        if col not in df.columns:

            raise RuntimeError(
                f"A6 missing column: {col}"
            )

    if len(df) != DEV_ROWS:

        raise RuntimeError(
            f"A6 contains {len(df):,} rows; "
            f"expected 49,000."
        )

    df["row_index"] = (
        pd.to_numeric(
            df["row_index"],
            errors="raise"
        )
        .astype(int)
    )

    df["y_true"] = (
        pd.to_numeric(
            df["y_true"],
            errors="raise"
        )
        .astype(int)
    )

    expected = set(
        range(DEV_ROWS)
    )

    actual = set(
        df["row_index"]
    )

    print(
        f"row_index range: "
        f"{df['row_index'].min()} - "
        f"{df['row_index'].max()}"
    )

    print(
        f"Unique row_index: "
        f"{df['row_index'].nunique():,}"
    )

    if actual != expected:

        raise RuntimeError(
            "A6 row_index is not exactly "
            "0...48,999."
        )

    print(
        "PASS: A6 contains exactly "
        "49,000 unique row indices."
    )

    # Critical:
    # Always use row_index order for reconciliation.
    a6 = (
        df
        .sort_values(
            "row_index"
        )
        .reset_index(
            drop=True
        )
    )

    return a6


# ============================================================
# LOAD BASELINES
# ============================================================

def load_baselines():

    header(
        "LOADING VALIDATED BASELINE PREDICTIONS"
    )

    baselines = {}

    for name, path in BASELINE_FILES.items():

        require_file(
            path
        )

        df = pd.read_csv(
            path
        )

        print(
            f"{name:30s} "
            f"rows={len(df):,} "
            f"columns={list(df.columns)}"
        )

        if len(df) != DEV_ROWS:

            raise RuntimeError(
                f"{name}: expected 49,000 rows."
            )

        if "id" not in df.columns:

            raise RuntimeError(
                f"{name}: no id column."
            )

        if "y_true" not in df.columns:

            raise RuntimeError(
                f"{name}: no y_true column."
            )

        df["id"] = (
            pd.to_numeric(
                df["id"],
                errors="raise"
            )
            .astype(int)
        )

        df["y_true"] = (
            pd.to_numeric(
                df["y_true"],
                errors="raise"
            )
            .astype(int)
        )

        if df["id"].nunique() != DEV_ROWS:

            raise RuntimeError(
                f"{name}: duplicate IDs."
            )

        baselines[name] = df

    return baselines


# ============================================================
# COMMON BASELINE COHORT
# ============================================================

def common_baseline_ids(
    baselines
):

    header(
        "ESTABLISHING COMMON 49,000-ROW BASELINE COHORT"
    )

    names = list(
        baselines.keys()
    )

    common_ids = set(
        baselines[
            names[0]
        ]["id"]
    )

    for name in names[1:]:

        ids = set(
            baselines[
                name
            ]["id"]
        )

        common_ids &= ids

        print(
            f"{name:30s} "
            f"intersection={len(common_ids):,}"
        )

    print()

    print(
        f"Final common identity count: "
        f"{len(common_ids):,}"
    )

    if len(common_ids) != DEV_ROWS:

        raise RuntimeError(
            "The five baseline models do not "
            "share exactly 49,000 IDs."
        )

    print(
        "PASS: Five baseline models share "
        "exactly the same 49,000 IDs."
    )

    return common_ids


# ============================================================
# SAFE TARGET VERIFICATION
# ============================================================
#
# THIS FIXES THE ERROR IN THE PREVIOUS VERSION.
#
# We NEVER use:
#
#     indexed.loc[mapped_ids]
#
# before checking that all IDs are present.
# ============================================================

def verify_candidate(
    candidate_name,
    mapped_ids,
    a6,
    source,
    baselines,
    common_ids
):

    mapped_ids = np.asarray(
        mapped_ids,
        dtype=int
    )

    result = {

        "candidate":
            candidate_name,

        "rows":
            len(mapped_ids),

        "unique_ids":
            len(
                np.unique(
                    mapped_ids
                )
            ),

        "all_ids_in_common_49k":
            False,

        "all_ids_in_source":
            False,

        "a6_target_matches_source":
            False,

        "all_baseline_targets_match":
            False,

        "fully_verified":
            False,

        "source_target_mismatches":
            np.nan,

        "baseline_target_mismatches":
            np.nan,
    }

    # --------------------------------------------------------
    # Size
    # --------------------------------------------------------

    if len(mapped_ids) != DEV_ROWS:

        return result

    # --------------------------------------------------------
    # Unique
    # --------------------------------------------------------

    if (
        result["unique_ids"]
        != DEV_ROWS
    ):

        return result

    # --------------------------------------------------------
    # Common 49k membership
    # --------------------------------------------------------

    candidate_set = set(
        mapped_ids
    )

    if candidate_set != common_ids:

        return result

    result[
        "all_ids_in_common_49k"
    ] = True

    # --------------------------------------------------------
    # Source membership
    # --------------------------------------------------------

    source_ids = set(
        source["id"]
    )

    if not candidate_set.issubset(
        source_ids
    ):

        return result

    result[
        "all_ids_in_source"
    ] = True

    # --------------------------------------------------------
    # A6 target vs source
    # --------------------------------------------------------

    source_map = (
        source
        .set_index("id")
        ["cardio"]
    )

    source_targets = (
        source_map
        .reindex(
            mapped_ids
        )
        .to_numpy()
    )

    a6_targets = (
        a6["y_true"]
        .to_numpy()
    )

    source_mismatch = (
        source_targets
        !=
        a6_targets
    )

    result[
        "source_target_mismatches"
    ] = int(
        source_mismatch.sum()
    )

    result[
        "a6_target_matches_source"
    ] = (
        result[
            "source_target_mismatches"
        ] == 0
    )

    # --------------------------------------------------------
    # Baseline targets
    # --------------------------------------------------------

    total_baseline_mismatches = 0

    baseline_ok = True

    for name, df in baselines.items():

        baseline_map = (
            df
            .set_index("id")
            ["y_true"]
        )

        baseline_targets = (
            baseline_map
            .reindex(
                mapped_ids
            )
            .to_numpy()
        )

        mismatch = (
            baseline_targets
            !=
            a6_targets
        )

        n_mismatch = int(
            mismatch.sum()
        )

        total_baseline_mismatches += (
            n_mismatch
        )

        if n_mismatch != 0:

            baseline_ok = False

    result[
        "baseline_target_mismatches"
    ] = (
        total_baseline_mismatches
    )

    result[
        "all_baseline_targets_match"
    ] = baseline_ok

    # --------------------------------------------------------
    # Final
    # --------------------------------------------------------

    result[
        "fully_verified"
    ] = (

        result[
            "rows"
        ] == DEV_ROWS

        and

        result[
            "unique_ids"
        ] == DEV_ROWS

        and

        result[
            "all_ids_in_common_49k"
        ]

        and

        result[
            "all_ids_in_source"
        ]

        and

        result[
            "a6_target_matches_source"
        ]

        and

        result[
            "all_baseline_targets_match"
        ]
    )

    return result


# ============================================================
# CANDIDATE 1
# DIRECT SOURCE POSITION
# ============================================================

def candidate_direct_source_position(
    source
):

    source_ids = (
        source["id"]
        .to_numpy()
    )

    return source_ids[
        np.arange(
            DEV_ROWS
        )
    ]


# ============================================================
# CANDIDATE 2
# SORTED COMMON DEVELOPMENT IDS
# ============================================================

def candidate_sorted_common_ids(
    common_ids
):

    return np.asarray(
        sorted(
            common_ids
        ),
        dtype=int
    )


# ============================================================
# CANDIDATE 3
# STRATIFIED TRAIN_TEST_SPLIT
# ============================================================

def generate_split_candidates(
    source
):

    try:

        from sklearn.model_selection import (
            train_test_split
        )

    except ImportError:

        raise RuntimeError(
            "scikit-learn is required. "
            "Install it in the current virtual environment."
        )

    indices = np.arange(
        len(source)
    )

    target = (
        source["cardio"]
        .to_numpy()
    )

    candidates = []

    for seed in SEEDS_TO_TEST:

        print(
            f"Testing random_state={seed}"
        )

        try:

            dev_idx, remainder_idx = (
                train_test_split(

                    indices,

                    test_size=0.30,

                    random_state=seed,

                    stratify=target
                )
            )

        except Exception as exc:

            print(
                f"  FAILED: {exc}"
            )

            continue

        if len(dev_idx) != DEV_ROWS:

            continue

        candidates.append({

            "name":
                f"stratified_seed_{seed}_returned_order",

            "seed":
                seed,

            "order":
                "returned_order",

            "indices":
                np.asarray(
                    dev_idx
                ),
        })

        candidates.append({

            "name":
                f"stratified_seed_{seed}_sorted_order",

            "seed":
                seed,

            "order":
                "sorted_source_position",

            "indices":
                np.sort(
                    np.asarray(
                        dev_idx
                    )
                ),
        })

    return candidates


# ============================================================
# MAIN CANDIDATE SEARCH
# ============================================================

def search_candidates(
    source,
    a6,
    baselines,
    common_ids
):

    header(
        "EVALUATING A6 -> KAGGLE ID CANDIDATES"
    )

    candidates = []

    # --------------------------------------------------------
    # Direct source row position
    # --------------------------------------------------------

    print(
        "\nCandidate 1:"
    )

    print(
        "A6 row_index interpreted as "
        "direct Kaggle source row position."
    )

    mapped = (
        candidate_direct_source_position(
            source
        )
    )

    result = verify_candidate(

        "direct_source_row_position",

        mapped,

        a6,

        source,

        baselines,

        common_ids
    )

    candidates.append(
        (
            result,
            mapped
        )
    )

    print(
        f"  Common 49k IDs: "
        f"{result['all_ids_in_common_49k']}"
    )

    print(
        f"  Target mismatches: "
        f"{result['source_target_mismatches']}"
    )

    print(
        f"  Fully verified: "
        f"{result['fully_verified']}"
    )

    # --------------------------------------------------------
    # Sorted common IDs
    # --------------------------------------------------------

    print(
        "\nCandidate 2:"
    )

    print(
        "A6 row_index interpreted as "
        "position in sorted common 49k IDs."
    )

    mapped = (
        candidate_sorted_common_ids(
            common_ids
        )
    )

    result = verify_candidate(

        "sorted_common_49k_id_position",

        mapped,

        a6,

        source,

        baselines,

        common_ids
    )

    candidates.append(
        (
            result,
            mapped
        )
    )

    print(
        f"  Common 49k IDs: "
        f"{result['all_ids_in_common_49k']}"
    )

    print(
        f"  Target mismatches: "
        f"{result['source_target_mismatches']}"
    )

    print(
        f"  Fully verified: "
        f"{result['fully_verified']}"
    )

    # --------------------------------------------------------
    # Stratified split candidates
    # --------------------------------------------------------

    header(
        "TESTING STRATIFIED 70/30 DEVELOPMENT SPLITS"
    )

    split_candidates = (
        generate_split_candidates(
            source
        )
    )

    for item in split_candidates:

        mapped = (
            source[
                "id"
            ]
            .to_numpy()
            [
                item[
                    "indices"
                ]
            ]
        )

        result = verify_candidate(

            item["name"],

            mapped,

            a6,

            source,

            baselines,

            common_ids
        )

        candidates.append(
            (
                result,
                mapped
            )
        )

        print(
            f"seed={item['seed']:8d} | "
            f"order={item['order']:25s} | "
            f"common="
            f"{result['all_ids_in_common_49k']} | "
            f"mismatch="
            f"{result['source_target_mismatches']} | "
            f"verified="
            f"{result['fully_verified']}"
        )

    return candidates


# ============================================================
# SAVE MAPPING
# ============================================================

def save_mapping(
    mapped_ids,
    a6,
    source
):

    source_map = (
        source
        .set_index("id")
        ["cardio"]
    )

    output = pd.DataFrame({

        "row_index":
            a6["row_index"].to_numpy(),

        "kaggle_id":
            mapped_ids,

        "a6_y_true":
            a6["y_true"].to_numpy(),

        "source_cardio":
            source_map
            .reindex(
                mapped_ids
            )
            .to_numpy(),

        "outer_fold":
            a6["outer_fold"].to_numpy(),

        "probability":
            a6["probability"].to_numpy(),
    })

    output[
        "target_match"
    ] = (
        output[
            "a6_y_true"
        ]
        ==
        output[
            "source_cardio"
        ]
    )

    output.to_csv(
        MAPPING_FILE,
        index=False
    )

    return output


# ============================================================
# SAVE REPORT
# ============================================================

def save_outputs(
    candidates,
    verified
):

    rows = []

    for result, mapped in candidates:

        rows.append(
            result
        )

    summary = pd.DataFrame(
        rows
    )

    summary.to_csv(
        SUMMARY_FILE,
        index=False
    )

    candidate_audit = (
        summary.copy()
    )

    candidate_audit.to_csv(
        CANDIDATE_FILE,
        index=False
    )

    payload = {

        "implementation":
            "43B-2",

        "purpose":
            "A6 row_index to Kaggle ID reconciliation",

        "total_source_rows":
            TOTAL_ROWS,

        "development_rows":
            DEV_ROWS,

        "locked_test_used":
            False,

        "uci_used":
            False,

        "model_retrained":
            False,

        "number_of_verified_candidates":
            len(verified),

        "verified_candidates": [
            {
                "candidate":
                    r["candidate"],

                "source_target_mismatches":
                    int(
                        r[
                            "source_target_mismatches"
                        ]
                    ),

                "baseline_target_mismatches":
                    int(
                        r[
                            "baseline_target_mismatches"
                        ]
                    ),
            }
            for r, _ in verified
        ],
    }

    with open(
        JSON_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            payload,
            f,
            indent=2
        )

    # --------------------------------------------------------
    # Report
    # --------------------------------------------------------

    lines = []

    lines.append(
        "IMPLEMENTATION 43B-2"
    )

    lines.append(
        "A6 ROW_INDEX -> KAGGLE ID RECONCILIATION"
    )

    lines.append(
        "=" * 70
    )

    lines.append("")

    lines.append(
        "Source rows: 70,000"
    )

    lines.append(
        "A6 outer-CV rows: 49,000"
    )

    lines.append(
        "Locked test used: FALSE"
    )

    lines.append(
        "UCI used: FALSE"
    )

    lines.append(
        "Model retrained: FALSE"
    )

    lines.append("")

    lines.append(
        "CANDIDATE RESULTS"
    )

    lines.append(
        "-" * 70
    )

    for result, _ in candidates:

        lines.append(

            f"{result['candidate']} | "
            f"common_49k="
            f"{result['all_ids_in_common_49k']} | "
            f"source_match="
            f"{result['a6_target_matches_source']} | "
            f"baseline_match="
            f"{result['all_baseline_targets_match']} | "
            f"verified="
            f"{result['fully_verified']}"
        )

    lines.append("")

    if len(verified) == 1:

        result, mapped = verified[0]

        lines.append(
            "FINAL STATUS"
        )

        lines.append(
            "PASS_A6_ROW_INDEX_RECONCILED"
        )

        lines.append("")

        lines.append(
            f"Verified candidate: "
            f"{result['candidate']}"
        )

        lines.append(
            f"Verified rows: "
            f"{len(mapped):,}"
        )

        lines.append(
            f"Source target mismatches: "
            f"{result['source_target_mismatches']}"
        )

        lines.append(
            f"Baseline target mismatches: "
            f"{result['baseline_target_mismatches']}"
        )

    elif len(verified) > 1:

        lines.append(
            "FINAL STATUS"
        )

        lines.append(
            "MULTIPLE_VERIFIED_MAPPINGS_REQUIRE_REVIEW"
        )

    else:

        lines.append(
            "FINAL STATUS"
        )

        lines.append(
            "A6_ROW_INDEX_MAPPING_NOT_ESTABLISHED"
        )

        lines.append("")

        lines.append(
            "Paired statistical testing involving "
            "A6 must NOT be performed."
        )

    with open(
        REPORT_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "\n".join(
                lines
            )
        )


# ============================================================
# MAIN
# ============================================================

def main():

    warnings.filterwarnings(
        "ignore"
    )

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # Load
    # --------------------------------------------------------

    source = load_source()

    a6 = load_a6()

    baselines = load_baselines()

    common_ids = (
        common_baseline_ids(
            baselines
        )
    )

    # --------------------------------------------------------
    # Search
    # --------------------------------------------------------

    candidates = search_candidates(

        source,

        a6,

        baselines,

        common_ids
    )

    # --------------------------------------------------------
    # Identify verified candidates
    # --------------------------------------------------------

    verified = [
        item
        for item in candidates
        if item[0][
            "fully_verified"
        ]
    ]

    # --------------------------------------------------------
    # Save unique verified mapping
    # --------------------------------------------------------

    mapping = None

    if len(verified) == 1:

        result, mapped = verified[0]

        mapping = save_mapping(

            mapped,

            a6,

            source
        )

    # --------------------------------------------------------
    # Save reports
    # --------------------------------------------------------

    save_outputs(
        candidates,
        verified
    )

    # --------------------------------------------------------
    # Final output
    # --------------------------------------------------------

    header(
        "IMPLEMENTATION 43B-2 COMPLETE"
    )

    print(
        f"\nSummary:"
    )

    print(
        SUMMARY_FILE
    )

    print(
        f"\nCandidate audit:"
    )

    print(
        CANDIDATE_FILE
    )

    print(
        f"\nJSON:"
    )

    print(
        JSON_FILE
    )

    print(
        f"\nReport:"
    )

    print(
        REPORT_FILE
    )

    print()

    if len(verified) == 1:

        result, mapped = verified[0]

        print(
            "VERIFIED CANDIDATE:"
        )

        print(
            result["candidate"]
        )

        print(
            f"\nVerified rows: "
            f"{len(mapped):,}"
        )

        print(
            f"Source target mismatches: "
            f"{result['source_target_mismatches']}"
        )

        print(
            f"Baseline target mismatches: "
            f"{result['baseline_target_mismatches']}"
        )

        print(
            f"\nVerified mapping:"
        )

        print(
            MAPPING_FILE
        )

        print(
            "\nSTATUS:"
        )

        print(
            "PASS_A6_ROW_INDEX_RECONCILED"
        )

    elif len(verified) > 1:

        print(
            "STATUS:"
        )

        print(
            "MULTIPLE_VERIFIED_MAPPINGS_REQUIRE_REVIEW"
        )

    else:

        print(
            "No verified A6 mapping was found."
        )

        print(
            "\nSTATUS:"
        )

        print(
            "A6_ROW_INDEX_MAPPING_NOT_ESTABLISHED"
        )


if __name__ == "__main__":

    main()