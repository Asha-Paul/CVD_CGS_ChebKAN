
# ============================================================
# Implementation49_Final_A8_Calibration_DCA_CORRECTED.py
# Final A8 locked-test calibration + Decision Curve Analysis
#
# CORRECTED VERSION:
#   Does NOT require statsmodels.
#   Uses scipy.optimize for logistic calibration fitting.
#
# IMPORTANT:
#   - No retraining
#   - No hyperparameter tuning
#   - No use of conformal calibration cohort
#   - No threshold tuning
#   - Locked test used only for final evaluation
#
# ============================================================

from pathlib import Path
import json
import time
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.metrics import (
    brier_score_loss,
    roc_auc_score,
    average_precision_score,
)
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

# ------------------------------------------------------------
# 1. PATHS
# ------------------------------------------------------------

ROOT = Path.cwd()

CANDIDATE_FILES = [
    ROOT / "results" / "tables" / "implementation46_final_a8_locked_test_predictions.csv",
    ROOT / "results" / "tables" / "implementation46_a8_locked_test_predictions.csv",
    ROOT / "results" / "tables" / "implementation46_locked_test_predictions.csv",
]

OUTPUT_TABLE_DIR = ROOT / "results" / "tables"
OUTPUT_FIG_DIR = ROOT / "results" / "figures"

OUTPUT_TABLE_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_FIG_DIR.mkdir(parents=True, exist_ok=True)

N_BOOTSTRAP = 2000
SEED = 20261006
CI_LEVEL = 0.95
THRESHOLD = 0.50
N_BINS = 10
EPS = 1e-6

# ------------------------------------------------------------
# 2. FIND FINAL A8 PREDICTION FILE
# ------------------------------------------------------------

prediction_file = None

for p in CANDIDATE_FILES:
    if p.exists():
        prediction_file = p
        break

if prediction_file is None:
    candidates = []
    for p in ROOT.rglob("*.csv"):
        name = p.name.lower()
        if "implementation46" in name and "prediction" in name:
            candidates.append(p)

    if len(candidates) == 1:
        prediction_file = candidates[0]
    elif len(candidates) > 1:
        candidates = sorted(
            candidates,
            key=lambda x: (
                "final" not in x.name.lower(),
                "a8" not in x.name.lower(),
                "locked" not in x.name.lower(),
                "test" not in x.name.lower(),
            )
        )
        prediction_file = candidates[0]

if prediction_file is None:
    raise FileNotFoundError(
        "\nFinal A8 locked-test prediction file was not found.\n"
        "Expected:\n"
        "results/tables/implementation46_final_a8_locked_test_predictions.csv\n"
    )

print("=" * 78)
print("IMPLEMENTATION49 — FINAL A8 CALIBRATION + DECISION CURVE ANALYSIS")
print("=" * 78)
print(f"Prediction file: {prediction_file}")

# ------------------------------------------------------------
# 3. LOAD AND AUDIT
# ------------------------------------------------------------

df = pd.read_csv(prediction_file)

required = [
    "id",
    "true_label",
    "probability",
    "prediction_050",
]

missing = [c for c in required if c not in df.columns]

if missing:
    raise ValueError(
        f"Required columns missing: {missing}\n"
        f"Available columns: {list(df.columns)}"
    )

if df["id"].duplicated().any():
    raise ValueError("Duplicate IDs detected.")

y = pd.to_numeric(df["true_label"], errors="coerce").to_numpy()
p = pd.to_numeric(df["probability"], errors="coerce").to_numpy()
pred = pd.to_numeric(df["prediction_050"], errors="coerce").to_numpy()

if np.isnan(y).any() or np.isnan(p).any() or np.isnan(pred).any():
    raise ValueError("Missing/non-numeric values detected.")

y = y.astype(int)
pred = pred.astype(int)

if not np.all(np.isin(y, [0, 1])):
    raise ValueError("true_label must contain only 0 and 1.")

if not np.all(np.isin(pred, [0, 1])):
    raise ValueError("prediction_050 must contain only 0 and 1.")

if np.any(p < 0) or np.any(p > 1):
    raise ValueError("Probability values must be between 0 and 1.")

expected_pred = (p >= THRESHOLD).astype(int)

if not np.array_equal(pred, expected_pred):
    mismatch = int(np.sum(pred != expected_pred))
    raise ValueError(
        f"prediction_050 disagrees with probability threshold "
        f"in {mismatch:,} rows."
    )

n = len(y)

if n != 14000:
    print(
        f"WARNING: Expected 14,000 locked-test rows; found {n:,}."
    )

prevalence = float(np.mean(y))

print(f"Rows loaded: {n:,}")
print(f"Columns: {list(df.columns)}")
print(f"Duplicate IDs: {df['id'].duplicated().sum():,}")

print("\nLOCKED-TEST AUDIT")
print("-" * 78)
print(f"Negative class (0): {np.sum(y == 0):,}")
print(f"Positive class (1): {np.sum(y == 1):,}")
print(f"Prevalence:          {prevalence:.6f}")
print(f"Threshold:           {THRESHOLD:.2f}")

# ------------------------------------------------------------
# 4. BASIC METRIC CONSISTENCY
# ------------------------------------------------------------

auc = roc_auc_score(y, p)
prauc = average_precision_score(y, p)
brier = brier_score_loss(y, p)

print("\nFINAL A8 CONSISTENCY CHECK")
print("-" * 78)
print(f"ROC-AUC : {auc:.6f}")
print(f"PR-AUC  : {prauc:.6f}")
print(f"Brier   : {brier:.6f}")

# ------------------------------------------------------------
# 5. NUMERIC LOGIT
# ------------------------------------------------------------

def safe_logit(prob):
    prob = np.clip(
        np.asarray(prob, dtype=float),
        EPS,
        1.0 - EPS,
    )
    return np.log(prob / (1.0 - prob))

logit_p = safe_logit(p)

# ------------------------------------------------------------
# 6. LOGISTIC CALIBRATION WITHOUT STATSMODELS
#
# Fit:
#   logit(P(Y=1)) = intercept + slope * logit(predicted probability)
#
# Maximum likelihood is optimized with scipy.optimize.
# ------------------------------------------------------------

def logistic_nll(params, x, y_true):
    intercept = params[0]
    slope = params[1]

    z = intercept + slope * x

    # Stable logistic loss.
    loss = np.logaddexp(0.0, z) - y_true * z

    return float(np.sum(loss))


def fit_calibration(x, y_true):

    initial = np.array([0.0, 1.0], dtype=float)

    result = minimize(
        logistic_nll,
        initial,
        args=(x, y_true),
        method="BFGS",
        options={
            "maxiter": 500,
            "gtol": 1e-8,
        },
    )

    if not result.success:
        # A converged solution may occasionally return a
        # precision-warning message. Accept only finite values.
        if not np.all(np.isfinite(result.x)):
            raise RuntimeError(
                f"Calibration optimization failed: {result.message}"
            )

    return float(result.x[0]), float(result.x[1])


cal_intercept, cal_slope = fit_calibration(
    logit_p,
    y,
)

# Calibration-in-the-large:
# constant shift required to align the mean predicted probability
# with the observed prevalence.
observed_logit = safe_logit(prevalence)
mean_pred_logit = float(np.mean(logit_p))

calibration_in_large = observed_logit - mean_pred_logit

print("\nCALIBRATION")
print("-" * 78)
print(f"Calibration intercept : {cal_intercept:.6f}")
print(f"Calibration slope     : {cal_slope:.6f}")
print(f"Calibration-in-large  : {calibration_in_large:.6f}")
print(f"Brier score           : {brier:.6f}")

# ------------------------------------------------------------
# 7. ECE AND MAXIMUM CALIBRATION ERROR
# ------------------------------------------------------------

edges = np.linspace(0.0, 1.0, N_BINS + 1)

bin_records = []

ece = 0.0
max_cal_error = 0.0

for i in range(N_BINS):

    left = edges[i]
    right = edges[i + 1]

    if i == N_BINS - 1:
        mask = (p >= left) & (p <= right)
    else:
        mask = (p >= left) & (p < right)

    count = int(np.sum(mask))

    if count == 0:
        bin_records.append(
            {
                "bin": i + 1,
                "lower": left,
                "upper": right,
                "n": 0,
                "mean_predicted": np.nan,
                "observed_event_rate": np.nan,
                "absolute_error": np.nan,
                "weighted_error": 0.0,
            }
        )
        continue

    mean_pred = float(np.mean(p[mask]))
    observed = float(np.mean(y[mask]))
    abs_error = abs(mean_pred - observed)
    weighted_error = (count / n) * abs_error

    ece += weighted_error
    max_cal_error = max(max_cal_error, abs_error)

    bin_records.append(
        {
            "bin": i + 1,
            "lower": left,
            "upper": right,
            "n": count,
            "mean_predicted": mean_pred,
            "observed_event_rate": observed,
            "absolute_error": abs_error,
            "weighted_error": weighted_error,
        }
    )

bins_df = pd.DataFrame(bin_records)

print(f"ECE                   : {ece:.6f}")
print(f"Maximum calibration error: {max_cal_error:.6f}")

# ------------------------------------------------------------
# 8. BOOTSTRAP CALIBRATION METRICS
# ------------------------------------------------------------

rng = np.random.default_rng(SEED)

boot_intercept = []
boot_slope = []
boot_cal_large = []
boot_ece = []
boot_max_error = []
boot_brier = []

start = time.time()


def calibration_statistics(y_b, p_b):

    p_b = np.clip(
        p_b.astype(float),
        EPS,
        1.0 - EPS,
    )

    x_b = safe_logit(p_b)

    if len(np.unique(y_b)) < 2:
        return None

    try:
        intercept_b, slope_b = fit_calibration(
            x_b,
            y_b,
        )

        prev_b = float(np.mean(y_b))

        if prev_b <= 0.0 or prev_b >= 1.0:
            return None

        cal_large_b = (
            safe_logit(prev_b)
            -
            float(np.mean(x_b))
        )

        ece_b = 0.0
        max_err_b = 0.0

        for j in range(N_BINS):

            left = edges[j]
            right = edges[j + 1]

            if j == N_BINS - 1:
                mask_b = (p_b >= left) & (p_b <= right)
            else:
                mask_b = (p_b >= left) & (p_b < right)

            count_b = int(np.sum(mask_b))

            if count_b == 0:
                continue

            mean_pred_b = float(np.mean(p_b[mask_b]))
            observed_b = float(np.mean(y_b[mask_b]))

            err_b = abs(mean_pred_b - observed_b)

            ece_b += (
                count_b / len(y_b)
            ) * err_b

            max_err_b = max(
                max_err_b,
                err_b,
            )

        brier_b = float(
            brier_score_loss(y_b, p_b)
        )

        return (
            intercept_b,
            slope_b,
            cal_large_b,
            ece_b,
            max_err_b,
            brier_b,
        )

    except Exception:
        return None


for b in range(N_BOOTSTRAP):

    sample_idx = rng.integers(
        0,
        n,
        size=n,
    )

    result = calibration_statistics(
        y[sample_idx],
        p[sample_idx],
    )

    if result is None:
        continue

    (
        i_b,
        s_b,
        cl_b,
        e_b,
        m_b,
        br_b,
    ) = result

    boot_intercept.append(i_b)
    boot_slope.append(s_b)
    boot_cal_large.append(cl_b)
    boot_ece.append(e_b)
    boot_max_error.append(m_b)
    boot_brier.append(br_b)

    if (b + 1) % 250 == 0:
        elapsed = time.time() - start
        print(
            f"Bootstrap {b + 1:,}/{N_BOOTSTRAP:,} "
            f"({elapsed:.1f} s)"
        )

elapsed = time.time() - start

boot_intercept = np.asarray(boot_intercept)
boot_slope = np.asarray(boot_slope)
boot_cal_large = np.asarray(boot_cal_large)
boot_ece = np.asarray(boot_ece)
boot_max_error = np.asarray(boot_max_error)
boot_brier = np.asarray(boot_brier)

print("\nVALID BOOTSTRAP REPLICATES")
print("-" * 78)
print(f"Requested: {N_BOOTSTRAP:,}")
print(f"Valid:     {len(boot_intercept):,}")


def percentile_ci(values, level=0.95):

    alpha = 1.0 - level

    return (
        float(np.quantile(values, alpha / 2.0)),
        float(np.quantile(values, 1.0 - alpha / 2.0)),
    )


ci_intercept = percentile_ci(
    boot_intercept,
    CI_LEVEL,
)

ci_slope = percentile_ci(
    boot_slope,
    CI_LEVEL,
)

ci_cal_large = percentile_ci(
    boot_cal_large,
    CI_LEVEL,
)

ci_ece = percentile_ci(
    boot_ece,
    CI_LEVEL,
)

ci_max_error = percentile_ci(
    boot_max_error,
    CI_LEVEL,
)

ci_brier = percentile_ci(
    boot_brier,
    CI_LEVEL,
)

# ------------------------------------------------------------
# 9. CALIBRATION SUMMARY
# ------------------------------------------------------------

summary_rows = [
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "Brier score",
        "Estimate": brier,
        "CI_lower": ci_brier[0],
        "CI_upper": ci_brier[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_brier),
    },
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "Calibration intercept",
        "Estimate": cal_intercept,
        "CI_lower": ci_intercept[0],
        "CI_upper": ci_intercept[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_intercept),
    },
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "Calibration slope",
        "Estimate": cal_slope,
        "CI_lower": ci_slope[0],
        "CI_upper": ci_slope[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_slope),
    },
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "Calibration-in-the-large",
        "Estimate": calibration_in_large,
        "CI_lower": ci_cal_large[0],
        "CI_upper": ci_cal_large[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_cal_large),
    },
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "ECE",
        "Estimate": ece,
        "CI_lower": ci_ece[0],
        "CI_upper": ci_ece[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_ece),
    },
    {
        "Model": "A8 CGS-ChebKAN",
        "Evaluation": "Kaggle locked test",
        "Metric": "Maximum calibration error",
        "Estimate": max_cal_error,
        "CI_lower": ci_max_error[0],
        "CI_upper": ci_max_error[1],
        "CI_level": CI_LEVEL,
        "Bootstrap_replicates": len(boot_max_error),
    },
]

summary_df = pd.DataFrame(summary_rows)

# ------------------------------------------------------------
# 10. CALIBRATION FIGURE
# ------------------------------------------------------------

fig = plt.figure(figsize=(7, 6))

valid_bins = bins_df["n"] > 0

plt.plot(
    [0, 1],
    [0, 1],
    linestyle="--",
    linewidth=1.5,
    label="Perfect calibration",
)

plt.plot(
    bins_df.loc[valid_bins, "mean_predicted"],
    bins_df.loc[valid_bins, "observed_event_rate"],
    marker="o",
    linewidth=2,
    label="A8 CGS-ChebKAN",
)

plt.xlabel("Mean predicted probability")
plt.ylabel("Observed event rate")
plt.title("Calibration of A8 CGS-ChebKAN on the Locked Test Set")
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.grid(alpha=0.25)
plt.legend()
plt.tight_layout()

calibration_fig = (
    OUTPUT_FIG_DIR /
    "implementation49_a8_calibration_curve.png"
)

plt.savefig(
    calibration_fig,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

# ------------------------------------------------------------
# 11. DECISION CURVE ANALYSIS
# ------------------------------------------------------------

thresholds = np.round(
    np.arange(0.01, 0.951, 0.01),
    2,
)

dca_rows = []

for pt in thresholds:

    y_pred_t = (p >= pt).astype(int)

    tp = int(
        np.sum(
            (y == 1) &
            (y_pred_t == 1)
        )
    )

    fp = int(
        np.sum(
            (y == 0) &
            (y_pred_t == 1)
        )
    )

    nb_model = (
        tp / n
        -
        (fp / n)
        *
        (pt / (1.0 - pt))
    )

    nb_all = (
        prevalence
        -
        (1.0 - prevalence)
        *
        (pt / (1.0 - pt))
    )

    dca_rows.append(
        {
            "threshold": float(pt),
            "net_benefit_model": float(nb_model),
            "net_benefit_treat_all": float(nb_all),
            "net_benefit_treat_none": 0.0,
            "n_treated_model": int(np.sum(y_pred_t)),
            "tp": tp,
            "fp": fp,
        }
    )

dca_df = pd.DataFrame(dca_rows)

dca_df["advantage_vs_treat_all"] = (
    dca_df["net_benefit_model"]
    -
    dca_df["net_benefit_treat_all"]
)

dca_df["advantage_vs_treat_none"] = (
    dca_df["net_benefit_model"]
)

positive_vs_none = dca_df[
    dca_df["net_benefit_model"] > 0
]

better_than_all = dca_df[
    dca_df["net_benefit_model"]
    >
    dca_df["net_benefit_treat_all"]
]

if len(positive_vs_none) > 0:
    positive_range = (
        float(positive_vs_none["threshold"].min()),
        float(positive_vs_none["threshold"].max()),
    )
else:
    positive_range = None

if len(better_than_all) > 0:
    better_all_range = (
        float(better_than_all["threshold"].min()),
        float(better_than_all["threshold"].max()),
    )
else:
    better_all_range = None

print("\nDECISION CURVE ANALYSIS")
print("-" * 78)

if positive_range:
    print(
        "Positive net benefit range: "
        f"{positive_range[0]:.2f}–{positive_range[1]:.2f}"
    )
else:
    print("Positive net benefit range: none")

if better_all_range:
    print(
        "Better than treat-all range: "
        f"{better_all_range[0]:.2f}–{better_all_range[1]:.2f}"
    )
else:
    print("Better than treat-all range: none")

# ------------------------------------------------------------
# 12. DCA FIGURE
# ------------------------------------------------------------

fig = plt.figure(figsize=(8, 6))

plt.plot(
    dca_df["threshold"],
    dca_df["net_benefit_model"],
    linewidth=2,
    label="A8 CGS-ChebKAN",
)

plt.plot(
    dca_df["threshold"],
    dca_df["net_benefit_treat_all"],
    linestyle="--",
    linewidth=1.5,
    label="Treat all",
)

plt.plot(
    dca_df["threshold"],
    dca_df["net_benefit_treat_none"],
    linestyle=":",
    linewidth=1.5,
    label="Treat none",
)

plt.axhline(
    0,
    linewidth=0.8,
)

plt.xlabel("Threshold probability")
plt.ylabel("Net benefit")
plt.title("Decision Curve Analysis — A8 CGS-ChebKAN")
plt.xlim(0.01, 0.95)
plt.grid(alpha=0.25)
plt.legend()
plt.tight_layout()

dca_fig = (
    OUTPUT_FIG_DIR /
    "implementation49_a8_dca.png"
)

plt.savefig(
    dca_fig,
    dpi=300,
    bbox_inches="tight",
)

plt.close()

# ------------------------------------------------------------
# 13. PROTOCOL
# ------------------------------------------------------------

protocol = {
    "implementation": "Implementation49",
    "purpose": "Final A8 locked-test calibration and DCA",
    "model": "A8 CGS-ChebKAN",
    "prediction_file": str(prediction_file),
    "n_locked_test": int(n),
    "positive_count": int(np.sum(y == 1)),
    "negative_count": int(np.sum(y == 0)),
    "prevalence": prevalence,
    "classification_threshold": THRESHOLD,
    "calibration_bins": N_BINS,
    "bootstrap_replicates_requested": N_BOOTSTRAP,
    "bootstrap_replicates_valid": int(len(boot_intercept)),
    "confidence_level": CI_LEVEL,
    "bootstrap_method": "ordinary percentile bootstrap",
    "random_seed": SEED,
    "calibration_optimizer": "scipy.optimize.minimize BFGS",
    "statsmodels_used": False,
    "retraining": False,
    "hyperparameter_tuning": False,
    "conformal_calibration_cohort_used": False,
    "locked_test_used_for_model_selection": False,
    "locked_test_used_only_for_final_evaluation": True,
    "dca_threshold_start": 0.01,
    "dca_threshold_end": 0.95,
    "dca_threshold_step": 0.01,
}

# ------------------------------------------------------------
# 14. SAVE OUTPUTS
# ------------------------------------------------------------

summary_csv = (
    OUTPUT_TABLE_DIR /
    "implementation49_a8_calibration_summary.csv"
)

summary_json = (
    OUTPUT_TABLE_DIR /
    "implementation49_a8_calibration_summary.json"
)

bins_csv = (
    OUTPUT_TABLE_DIR /
    "implementation49_a8_calibration_bins.csv"
)

dca_csv = (
    OUTPUT_TABLE_DIR /
    "implementation49_a8_dca.csv"
)

protocol_json = (
    OUTPUT_TABLE_DIR /
    "implementation49_a8_calibration_protocol.json"
)

summary_df.to_csv(
    summary_csv,
    index=False,
)

bins_df.to_csv(
    bins_csv,
    index=False,
)

dca_df.to_csv(
    dca_csv,
    index=False,
)

with open(summary_json, "w", encoding="utf-8") as f:
    json.dump(
        {
            "model": "A8 CGS-ChebKAN",
            "evaluation": "Kaggle locked test",
            "point_metrics": {
                "ROC_AUC": auc,
                "PR_AUC": prauc,
                "Brier": brier,
            },
            "calibration": summary_df.to_dict(
                orient="records"
            ),
        },
        f,
        indent=2,
    )

with open(protocol_json, "w", encoding="utf-8") as f:
    json.dump(
        protocol,
        f,
        indent=2,
    )

# ------------------------------------------------------------
# 15. FINAL REPORT
# ------------------------------------------------------------

print("\n" + "=" * 78)
print("FINAL A8 CALIBRATION RESULTS")
print("=" * 78)

for _, row in summary_df.iterrows():

    print(
        f"{row['Metric']:28s} "
        f"{row['Estimate']:.6f} "
        f"({row['CI_lower']:.6f}, {row['CI_upper']:.6f})"
    )

print("\n" + "=" * 78)
print("FINAL DCA SUMMARY")
print("=" * 78)

if positive_range:
    print(
        f"Positive net benefit: "
        f"{positive_range[0]:.2f}–{positive_range[1]:.2f}"
    )
else:
    print("Positive net benefit: none")

if better_all_range:
    print(
        f"Better than treat-all: "
        f"{better_all_range[0]:.2f}–{better_all_range[1]:.2f}"
    )
else:
    print("Better than treat-all: none")

print("\n" + "=" * 78)
print("AUDIT STATUS")
print("=" * 78)
print("PASS_FINAL_A8_CALIBRATION_DCA")
print(f"Locked test: {n:,}")
print("Retraining: NO")
print("Hyperparameter tuning: NO")
print("Conformal calibration cohort used: NO")
print("Locked test used for final evaluation only: YES")
print(f"Bootstrap replicates requested: {N_BOOTSTRAP:,}")
print(f"Valid bootstrap replicates: {len(boot_intercept):,}")
print(f"Runtime: {elapsed:.2f} seconds")

print("\nOUTPUT FILES")
print("-" * 78)
print(summary_csv)
print(summary_json)
print(bins_csv)
print(dca_csv)
print(protocol_json)
print(calibration_fig)
print(dca_fig)
