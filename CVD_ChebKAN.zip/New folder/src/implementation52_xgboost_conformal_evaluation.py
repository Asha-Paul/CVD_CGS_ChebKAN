# ============================================================
# IMPLEMENTATION 52: XGBOOST CLASS-CONDITIONAL SPLIT CONFORMAL
# ============================================================
# Fits the exact selected Implementation 51 configuration on all
# development rows, calibrates ONLY on the separate 7,000-row
# calibration partition, and evaluates conformal sets on locked test.
#
# Does not use locked-test labels to choose hyperparameters or quantiles.
# Does not overwrite Implementation 47 (A8) conformal outputs.
# ============================================================

import json
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score
from xgboost import XGBClassifier

ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DATA = ROOT / "data" / "processed"
OUT = ROOT / "results" / "tables"
DEV_FILE = DATA / "kaggle_development_cv.csv"
CAL_FILE = DATA / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA / "kaggle_locked_test.csv"
A8_PRED_FILE = OUT / "implementation46_final_a8_locked_test_predictions.csv"
XGB51_PRED_FILE = OUT / "implementation51_xgboost_locked_test_predictions.csv"

FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]
TARGET = "cardio"
SEED = 2026
ALPHAS = {"90": 0.10, "95": 0.05}

def finite_sample_quantile(scores, alpha):
    scores = np.sort(np.asarray(scores, dtype=float))
    k = int(np.ceil((len(scores) + 1) * (1.0 - alpha)))
    # Standard split-conformal convention: +infinity if k > n.
    if k > len(scores):
        return float("inf")
    return float(scores[k - 1])

def make_prediction_sets(p1, q0, q1):
    # For binary classification: class c included if 1 - p(c|x) <= q_c.
    p1 = np.asarray(p1, dtype=float)
    p0 = 1.0 - p1
    include0 = (1.0 - p0) <= q0
    include1 = (1.0 - p1) <= q1
    sets = []
    for a, b in zip(include0, include1):
        if a and b:
            sets.append("{0,1}")
        elif a:
            sets.append("{0}")
        elif b:
            sets.append("{1}")
        else:
            sets.append("{}")
    return np.asarray(sets, dtype=object), include0, include1

def summarize(y, sets, include0, include1, alpha_label, q0, q1):
    y = np.asarray(y, dtype=int)
    covered = np.where(y == 0, include0, include1)
    sizes = include0.astype(int) + include1.astype(int)
    return {
        "model": "XGBoost Implementation 51 final fit",
        "confidence_level": int(alpha_label),
        "nominal_coverage": int(alpha_label) / 100.0,
        "n_test": int(len(y)),
        "empirical_coverage": float(np.mean(covered)),
        "mean_set_size": float(np.mean(sizes)),
        "singleton_rate": float(np.mean(sizes == 1)),
        "two_class_rate": float(np.mean(sizes == 2)),
        "empty_rate": float(np.mean(sizes == 0)),
        "class0_inclusion_rate_among_true_class0": float(np.mean(include0[y == 0])),
        "class1_inclusion_rate_among_true_class1": float(np.mean(include1[y == 1])),
        "q_class0": q0,
        "q_class1": q1,
    }

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for f in [DEV_FILE, CAL_FILE, TEST_FILE, A8_PRED_FILE, XGB51_PRED_FILE]:
        if not f.exists():
            raise FileNotFoundError(f"Missing required file:\n{f}")

    dev = pd.read_csv(DEV_FILE)
    cal = pd.read_csv(CAL_FILE)
    test = pd.read_csv(TEST_FILE)
    xgb51_pred = pd.read_csv(XGB51_PRED_FILE)
    a8_pred = pd.read_csv(A8_PRED_FILE)

    for name, df, expected in [
        ("development", dev, 49000), ("calibration", cal, 7000), ("locked test", test, 14000)
    ]:
        required = ["id", TARGET] + FEATURES
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"{name} missing columns: {missing}")
        if len(df) != expected:
            raise ValueError(f"{name} has {len(df)} rows, expected {expected}")
        if df["id"].duplicated().any():
            raise ValueError(f"Duplicate IDs in {name}")
        if df[TARGET].isna().any() or set(df[TARGET].unique()) != {0, 1}:
            raise ValueError(f"{name} target must be complete and binary.")

    # Confirm saved Implementation 51 predictions correspond to the test IDs/labels.
    if set(xgb51_pred["id"]) != set(test["id"]):
        raise ValueError("Implementation 51 prediction IDs do not match locked-test IDs.")
    xgb_join = test[["id", TARGET]].merge(
        xgb51_pred[["id", "true_label", "probability"]],
        on="id", how="left", validate="one_to_one"
    )
    if not np.array_equal(xgb_join[TARGET].to_numpy(), xgb_join["true_label"].to_numpy()):
        raise ValueError("Implementation 51 prediction labels do not match test labels.")

    # Check disjoint partitions.
    if set(dev.id) & set(cal.id) or set(dev.id) & set(test.id) or set(cal.id) & set(test.id):
        raise ValueError("Development/calibration/test IDs overlap.")

    # These are the selected Implementation 51 hyperparameters, fixed from development CV.
    # Refit the same pipeline on all development data; do not reselect using test.
    model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", XGBClassifier(
            objective="binary:logistic",
            eval_metric="logloss",
            tree_method="hist",
            random_state=SEED,
            n_jobs=-1,
            verbosity=0,
            colsample_bytree=0.8,
            learning_rate=0.05,
            max_depth=5,
            n_estimators=200,
            subsample=0.8,
        ))
    ])
    print("Fitting fixed Implementation 51 XGBoost configuration on development data...")
    model.fit(dev[FEATURES], dev[TARGET].astype(int))

    # Calibrate class-conditional nonconformity quantiles using calibration rows only.
    p_cal = model.predict_proba(cal[FEATURES])[:, 1]
    y_cal = cal[TARGET].astype(int).to_numpy()
    cal_scores = pd.DataFrame({
        "id": cal["id"].to_numpy(),
        "true_label": y_cal,
        "probability_class1": p_cal,
        "nonconformity_score": np.where(y_cal == 1, 1.0 - p_cal, p_cal)
    })
    quantiles = {}
    for level, alpha in ALPHAS.items():
        q0 = finite_sample_quantile(cal_scores.loc[y_cal == 0, "nonconformity_score"], alpha)
        q1 = finite_sample_quantile(cal_scores.loc[y_cal == 1, "nonconformity_score"], alpha)
        quantiles[level] = {"q_class0": q0, "q_class1": q1, "alpha": alpha}

    # Locked test probabilities generated by the same final-fit pipeline.
    p_test = model.predict_proba(test[FEATURES])[:, 1]
    y_test = test[TARGET].astype(int).to_numpy()
    auc_test = float(roc_auc_score(y_test, p_test))
    auc_saved = float(roc_auc_score(xgb_join[TARGET], xgb_join["probability"]))
    print(f"Recomputed XGBoost ROC-AUC from refitted pipeline: {auc_test:.6f}")
    print(f"Saved Implementation 51 prediction ROC-AUC:        {auc_saved:.6f}")
    print("If these differ slightly, retain the saved Implementation 51 predictions for the AUC table;")
    print("this script's purpose is to regenerate conformal results for the fixed selected configuration.")

    summary_rows = []
    pred_frames = []
    for level, vals in quantiles.items():
        q0, q1 = vals["q_class0"], vals["q_class1"]
        sets, inc0, inc1 = make_prediction_sets(p_test, q0, q1)
        summary_rows.append(summarize(y_test, sets, inc0, inc1, level, q0, q1))
        pred_frames.append(pd.DataFrame({
            "confidence_level": int(level),
            "id": test["id"].to_numpy(),
            "true_label": y_test,
            "probability_class1": p_test,
            "q0": q0,
            "q1": q1,
            "prediction_set": sets,
            "prediction_set_size": inc0.astype(int) + inc1.astype(int),
            "covered": np.where(y_test == 0, inc0, inc1).astype(int)
        }))

    summary_path = OUT / "implementation52_xgboost_conformal_summary.csv"
    pred_path = OUT / "implementation52_xgboost_conformal_test_predictions.csv"
    cal_path = OUT / "implementation52_xgboost_conformal_calibration_scores.csv"
    protocol_path = OUT / "implementation52_xgboost_conformal_protocol.json"

    pd.DataFrame(summary_rows).to_csv(summary_path, index=False)
    pd.concat(pred_frames, ignore_index=True).to_csv(pred_path, index=False)
    cal_scores.to_csv(cal_path, index=False)
    protocol = {
        "implementation": 52,
        "purpose": "Regenerate XGBoost conformal metrics for the fixed Implementation 51 selected configuration",
        "features": FEATURES,
        "model": "XGBClassifier with median imputation",
        "fixed_parameters": {
            "colsample_bytree": 0.8, "learning_rate": 0.05,
            "max_depth": 5, "n_estimators": 200, "subsample": 0.8,
            "objective": "binary:logistic", "eval_metric": "logloss",
            "tree_method": "hist", "random_state": SEED
        },
        "development_rows": len(dev),
        "calibration_rows": len(cal),
        "locked_test_rows": len(test),
        "calibration_used_for": "class-conditional split-conformal quantiles only",
        "locked_test_used_for_selection_or_quantiles": False,
        "score": "1 - p(true class | x)",
        "quantile_rule": "k = ceil((n_class + 1) * (1-alpha)); kth smallest score; infinity if k > n",
        "alphas": ALPHAS,
        "locked_test_roc_auc_refit": auc_test,
        "locked_test_roc_auc_saved_implementation51_predictions": auc_saved,
        "note": "The refit should reproduce Implementation 51's saved probabilities if package versions and training determinism match. Investigate any material discrepancy before combining conformal and ROC-AUC reporting.",
        "timestamp": datetime.now().isoformat(timespec="seconds")
    }
    with open(protocol_path, "w", encoding="utf-8") as f:
        json.dump(protocol, f, indent=2)

    print("\nCONFORMAL SUMMARY")
    print(pd.DataFrame(summary_rows).to_string(index=False))
    print("\nSaved summary:", summary_path)
    print("Saved test prediction sets:", pred_path)
    print("Saved calibration scores:", cal_path)
    print("Saved protocol:", protocol_path)
    print("\nIMPORTANT: If refitted ROC-AUC differs materially from the saved Implementation 51 AUC, do not combine outputs until resolved.")

if __name__ == "__main__":
    main()
