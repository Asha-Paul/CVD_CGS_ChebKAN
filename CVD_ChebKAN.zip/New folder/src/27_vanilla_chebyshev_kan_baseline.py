# ============================================================================
# IMPLEMENTATION 27 — VANILLA CHEBYSHEV-KAN BASELINE
# CORRECTED VERSION: BASIS COMPLEXITY TUNED BY INNER CV
# ============================================================================
#
# Purpose:
#   Evaluate a vanilla Chebyshev-KAN baseline using the same nested-CV
#   protocol as the B-spline KAN baseline.
#
# IMPORTANT CORRECTION:
#   The previous Chebyshev implementation fixed K=5.
#   The B-spline implementation tuned grid_size={5,8}.
#
#   To make the comparison more defensible, this version tunes:
#
#       Chebyshev degree K = {3, 5, 7}
#
#   together with:
#
#       learning_rate = {1e-3, 3e-4}
#       L2             = {1e-5, 1e-4, 1e-3}
#
#   Total inner-CV configurations:
#
#       3 × 2 × 3 = 18
#
# Frozen evaluation protocol:
#   Dataset             : Kaggle Cardiovascular Disease Dataset
#   Development         : 49,000
#   Conformal           : 7,000 PROTECTED
#   Locked test         : 14,000 PROTECTED
#   Features            : 11
#   Architecture        : 11 -> 16 -> 1
#   Basis               : Chebyshev polynomial, first kind
#   Degree               : selected from {3,5,7} by inner CV
#   Clinical grouping   : NO
#   Sparse group gates  : NO
#   ADASYN              : NO
#   Conformal prediction: NO
#   Imputation           : fold-specific median
#   Scaling              : fold-specific MinMax [-1,1]
#   Outer CV             : 5-fold stratified
#   Inner CV             : 4-fold stratified
#
# Data-flow:
#   Outer training -> preprocessing -> inner CV -> hyperparameter selection
#   -> internal early stopping -> outer validation.
#
# Calibration and locked test data are NEVER used for model selection.
#
# ============================================================================

import os
import sys
import json
import random
import warnings
from datetime import datetime

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader


# ============================================================================
# 0. GLOBAL CONFIGURATION
# ============================================================================

warnings.filterwarnings("ignore")

PROJECT_ROOT = r"E:\CVD_CGS_ChebKAN"

DATA_DIR = os.path.join(
    PROJECT_ROOT,
    "data",
    "processed"
)

RESULTS_DIR = os.path.join(
    PROJECT_ROOT,
    "results",
    "tables"
)

DEV_FILE = os.path.join(
    DATA_DIR,
    "kaggle_development_cv.csv"
)

CAL_FILE = os.path.join(
    DATA_DIR,
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = os.path.join(
    DATA_DIR,
    "kaggle_locked_test.csv"
)

TARGET = "cardio"

ID_COL = "id"


# ---------------------------------------------------------------------------
# Frozen 11-feature representation
# ---------------------------------------------------------------------------

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

RANDOM_STATE = 2026


# ---------------------------------------------------------------------------
# Nested CV
# ---------------------------------------------------------------------------

N_OUTER = 5
N_INNER = 4


# ---------------------------------------------------------------------------
# Model architecture
# ---------------------------------------------------------------------------

HIDDEN_DIM = 16


# ---------------------------------------------------------------------------
# IMPORTANT:
# Chebyshev polynomial degree is now tuned by inner CV.
#
# T_0, ..., T_K are used.
# ---------------------------------------------------------------------------

CHEBYSHEV_DEGREES = [
    3,
    5,
    7,
]


# ---------------------------------------------------------------------------
# Hyperparameter search
# ---------------------------------------------------------------------------

LEARNING_RATES = [
    1e-3,
    3e-4,
]

L2_VALUES = [
    1e-5,
    1e-4,
    1e-3,
]


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

MAX_EPOCHS = 150

PATIENCE = 15

BATCH_SIZE = 512


# ---------------------------------------------------------------------------
# Device
# ---------------------------------------------------------------------------

DEVICE = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)


# ============================================================================
# 1. REPRODUCIBILITY
# ============================================================================

def set_seed(seed=RANDOM_STATE):

    random.seed(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True

    torch.backends.cudnn.benchmark = False


set_seed()


# ============================================================================
# 2. DIRECTORY SETUP
# ============================================================================

def ensure_directories():

    os.makedirs(
        RESULTS_DIR,
        exist_ok=True
    )


# ============================================================================
# 3. EXPECTED CALIBRATION / TEST PROTECTION
# ============================================================================

EXPECTED_DEV_ROWS = 49000
EXPECTED_CAL_ROWS = 7000
EXPECTED_TEST_ROWS = 14000


# ============================================================================
# 4. ECE
# ============================================================================

def calculate_ece(
    y_true,
    probabilities,
    n_bins=10
):

    y_true = np.asarray(
        y_true
    )

    probabilities = np.asarray(
        probabilities
    )

    bin_edges = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    for i in range(n_bins):

        if i == n_bins - 1:

            mask = (
                (probabilities >= bin_edges[i])
                &
                (probabilities <= bin_edges[i + 1])
            )

        else:

            mask = (
                (probabilities >= bin_edges[i])
                &
                (probabilities < bin_edges[i + 1])
            )

        if not np.any(mask):
            continue

        confidence = (
            probabilities[mask].mean()
        )

        accuracy = (
            y_true[mask].mean()
        )

        ece += (
            np.sum(mask)
            /
            len(y_true)
        ) * abs(
            accuracy - confidence
        )

    return float(ece)


# ============================================================================
# 5. METRICS
# ============================================================================

def calculate_metrics(
    y_true,
    probabilities
):

    y_true = np.asarray(
        y_true
    ).astype(int)

    probabilities = np.asarray(
        probabilities
    )

    predictions = (
        probabilities >= 0.5
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1]
    ).ravel()

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    return {

        "accuracy": float(
            accuracy_score(
                y_true,
                predictions
            )
        ),

        "precision": float(
            precision_score(
                y_true,
                predictions,
                zero_division=0
            )
        ),

        "sensitivity": float(
            sensitivity
        ),

        "specificity": float(
            specificity
        ),

        "f1": float(
            f1_score(
                y_true,
                predictions,
                zero_division=0
            )
        ),

        "roc_auc": float(
            roc_auc_score(
                y_true,
                probabilities
            )
        ),

        "pr_auc": float(
            average_precision_score(
                y_true,
                probabilities
            )
        ),

        "brier": float(
            brier_score_loss(
                y_true,
                probabilities
            )
        ),

        "ece": float(
            calculate_ece(
                y_true,
                probabilities
            )
        ),
    }


# ============================================================================
# 6. CHEBYSHEV-KAN LAYER
# ============================================================================

class ChebyshevKANLayer(nn.Module):
    """
    Vanilla Chebyshev-KAN layer.

    For each input x_i:

        phi_i(x_i)
        =
        sum_{k=0}^{K}
            a_{i,k} T_k(x_i)

    where T_k is the Chebyshev polynomial of the first kind.

    Recurrence:

        T_0(x) = 1

        T_1(x) = x

        T_k(x)
        =
        2xT_{k-1}(x)
        -
        T_{k-2}(x)

    Coefficients are learned directly.

    No:
        - clinical grouping
        - group gates
        - attention
        - sparse fusion
        - conformal prediction
    """

    def __init__(
        self,
        in_features,
        out_features,
        degree
    ):

        super().__init__()

        self.in_features = (
            in_features
        )

        self.out_features = (
            out_features
        )

        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                degree + 1
            )
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02
        )


    def chebyshev_basis(
        self,
        x
    ):
        """
        Compute T_0(x), ..., T_K(x).

        Input:
            x: [batch, features]

        Output:
            [batch, features, degree+1]
        """

        t0 = torch.ones_like(
            x
        )

        if self.degree == 0:

            return t0.unsqueeze(-1)

        t1 = x

        basis = [
            t0,
            t1
        ]

        for k in range(
            2,
            self.degree + 1
        ):

            tk = (
                2.0
                * x
                * basis[-1]
                -
                basis[-2]
            )

            basis.append(
                tk
            )

        return torch.stack(
            basis,
            dim=-1
        )


    def forward(
        self,
        x
    ):

        basis = self.chebyshev_basis(
            x
        )

        output = torch.einsum(
            "bdk,mdk->bm",
            basis,
            self.coefficients
        )

        return output


# ============================================================================
# 7. VANILLA CHEBYSHEV-KAN MODEL
# ============================================================================

class VanillaChebyshevKAN(
    nn.Module
):

    """
    Architecture:

        11
         |
         v
    Chebyshev-KAN
         |
        16
         |
       SiLU
         |
    Chebyshev-KAN
         |
         1

    Degree K is supplied as a hyperparameter.
    """

    def __init__(
        self,
        input_dim,
        hidden_dim,
        degree
    ):

        super().__init__()

        self.layer1 = (
            ChebyshevKANLayer(
                in_features=input_dim,
                out_features=hidden_dim,
                degree=degree
            )
        )

        self.activation = nn.SiLU()

        self.layer2 = (
            ChebyshevKANLayer(
                in_features=hidden_dim,
                out_features=1,
                degree=degree
            )
        )


    def forward(
        self,
        x
    ):

        x = self.layer1(
            x
        )

        x = self.activation(
            x
        )

        x = self.layer2(
            x
        )

        return x.squeeze(-1)


# ============================================================================
# 8. PARAMETER COUNT
# ============================================================================

def count_parameters(
    model
):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ============================================================================
# 9. MODEL TRAINING
# ============================================================================

def train_model(
    X_train,
    y_train,
    X_internal_val,
    y_internal_val,
    degree,
    learning_rate,
    l2,
    max_epochs=MAX_EPOCHS,
    patience=PATIENCE,
):

    set_seed(
        RANDOM_STATE
    )

    X_train_tensor = torch.tensor(
        X_train,
        dtype=torch.float32
    )

    y_train_tensor = torch.tensor(
        y_train,
        dtype=torch.float32
    )

    X_val_tensor = torch.tensor(
        X_internal_val,
        dtype=torch.float32
    )

    y_val_tensor = torch.tensor(
        y_internal_val,
        dtype=torch.float32
    )

    train_dataset = TensorDataset(
        X_train_tensor,
        y_train_tensor
    )

    generator = (
        torch.Generator()
        .manual_seed(
            RANDOM_STATE
        )
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        generator=generator
    )

    model = VanillaChebyshevKAN(
        input_dim=len(FEATURES),
        hidden_dim=HIDDEN_DIM,
        degree=degree
    ).to(DEVICE)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=l2
    )

    criterion = nn.BCEWithLogitsLoss()

    best_auc = -np.inf

    best_state = None

    best_epoch = 1

    epochs_without_improvement = 0

    for epoch in range(
        1,
        max_epochs + 1
    ):

        model.train()

        for batch_x, batch_y in train_loader:

            batch_x = batch_x.to(
                DEVICE
            )

            batch_y = batch_y.to(
                DEVICE
            )

            optimizer.zero_grad()

            logits = model(
                batch_x
            )

            loss = criterion(
                logits,
                batch_y
            )

            loss.backward()

            optimizer.step()

        # ---------------------------------------------------------------
        # Internal validation
        # ---------------------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                X_val_tensor.to(
                    DEVICE
                )
            )

            val_probabilities = (
                torch.sigmoid(
                    val_logits
                )
                .cpu()
                .numpy()
            )

        try:

            val_auc = roc_auc_score(
                y_internal_val,
                val_probabilities
            )

        except Exception:

            val_auc = 0.5

        if val_auc > best_auc:

            best_auc = val_auc

            best_state = {
                key: value.detach()
                .cpu()
                .clone()

                for key, value
                in model.state_dict().items()
            }

            best_epoch = epoch

            epochs_without_improvement = 0

        else:

            epochs_without_improvement += 1

        if (
            epochs_without_improvement
            >= patience
        ):

            break

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    model = model.to(
        DEVICE
    )

    return (
        model,
        best_auc,
        best_epoch
    )


# ============================================================================
# 10. PREDICTION
# ============================================================================

def predict_probability(
    model,
    X
):

    model.eval()

    X_tensor = torch.tensor(
        X,
        dtype=torch.float32
    )

    probabilities = []

    with torch.no_grad():

        for start in range(
            0,
            len(X_tensor),
            BATCH_SIZE
        ):

            batch = X_tensor[
                start:
                start + BATCH_SIZE
            ].to(
                DEVICE
            )

            logits = model(
                batch
            )

            probs = torch.sigmoid(
                logits
            )

            probabilities.append(
                probs.cpu().numpy()
            )

    return np.concatenate(
        probabilities
    )


# ============================================================================
# 11. LOAD DATA
# ============================================================================

def load_data():

    print(
        "=" * 72
    )

    print(
        "IMPLEMENTATION 27 — "
        "VANILLA CHEBYSHEV-KAN BASELINE"
    )

    print(
        "CORRECTED: K TUNED BY INNER CV"
    )

    print(
        "=" * 72
    )

    print(
        "\nEnvironment"
    )

    print(
        "-" * 72
    )

    print(
        f"Python: {sys.version}"
    )

    print(
        f"Platform: {sys.platform}"
    )

    print(
        f"NumPy: {np.__version__}"
    )

    print(
        f"Pandas: {pd.__version__}"
    )

    print(
        f"PyTorch: {torch.__version__}"
    )

    print(
        f"Device: {DEVICE}"
    )

    if torch.cuda.is_available():

        print(
            "GPU: "
            f"{torch.cuda.get_device_name(0)}"
        )

    print(
        "\n" + "=" * 72
    )

    print(
        "1. INPUT FILE VERIFICATION"
    )

    print(
        "=" * 72
    )

    for path in [
        DEV_FILE,
        CAL_FILE,
        TEST_FILE
    ]:

        if os.path.exists(path):

            print(
                f"EXISTS: {path}"
            )

        else:

            print(
                f"MISSING: {path}"
            )

            raise FileNotFoundError(
                path
            )

    dev = pd.read_csv(
        DEV_FILE
    )

    cal = pd.read_csv(
        CAL_FILE
    )

    test = pd.read_csv(
        TEST_FILE
    )

    print(
        "\n" + "=" * 72
    )

    print(
        "2. LOAD DATA"
    )

    print(
        "=" * 72
    )

    print(
        f"Development: {dev.shape}"
    )

    print(
        f"Calibration: {cal.shape}"
    )

    print(
        f"Locked test: {test.shape}"
    )

    return (
        dev,
        cal,
        test
    )


# ============================================================================
# 12. DATA VALIDATION
# ============================================================================

def validate_data(
    dev,
    cal,
    test
):

    print(
        "\n" + "=" * 72
    )

    print(
        "3. DATA VALIDATION"
    )

    print(
        "=" * 72
    )

    expected_sizes = {
        "Development": EXPECTED_DEV_ROWS,
        "Calibration": EXPECTED_CAL_ROWS,
        "Locked test": EXPECTED_TEST_ROWS,
    }

    datasets = {
        "Development": dev,
        "Calibration": cal,
        "Locked test": test,
    }

    errors = []

    for name, df in datasets.items():

        expected = expected_sizes[
            name
        ]

        if len(df) == expected:

            print(
                f"{name}: "
                f"{len(df)} rows -> PASS"
            )

        else:

            print(
                f"{name}: "
                f"{len(df)} rows -> ERROR"
            )

            errors.append(
                f"{name} size mismatch"
            )

    missing_features = [
        feature
        for feature in FEATURES
        if feature not in dev.columns
    ]

    if len(missing_features) == 0:

        print(
            "All 11 predictors available -> PASS"
        )

    else:

        print(
            "Missing predictors: "
            f"{missing_features}"
        )

        errors.append(
            "Missing predictors"
        )

    unique_targets = sorted(
        dev[TARGET]
        .dropna()
        .unique()
        .tolist()
    )

    if unique_targets == [0, 1]:

        print(
            "Binary target -> PASS"
        )

    else:

        print(
            f"Target values: "
            f"{unique_targets} -> ERROR"
        )

        errors.append(
            "Target not binary"
        )

    if errors:

        raise RuntimeError(
            "; ".join(errors)
        )


# ============================================================================
# 13. TARGET DISTRIBUTION
# ============================================================================

def print_target_distribution(
    dev,
    cal,
    test
):

    print(
        "\n" + "=" * 72
    )

    print(
        "4. TARGET DISTRIBUTION"
    )

    print(
        "=" * 72
    )

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked test", test),
    ]:

        counts = (
            df[TARGET]
            .value_counts()
            .sort_index()
        )

        print(
            f"{name}: "
            f"class 0 = "
            f"{counts.get(0, 0)}, "
            f"class 1 = "
            f"{counts.get(1, 0)}"
        )


# ============================================================================
# 14. PARTITION DISJOINTNESS
# ============================================================================

def check_partition_disjointness(
    dev,
    cal,
    test
):

    print(
        "\n" + "=" * 72
    )

    print(
        "5. PARTITION DISJOINTNESS"
    )

    print(
        "=" * 72
    )

    if ID_COL not in dev.columns:

        print(
            "ID column unavailable."
        )

        return

    dev_ids = set(
        dev[ID_COL].astype(int)
    )

    cal_ids = set(
        cal[ID_COL].astype(int)
    )

    test_ids = set(
        test[ID_COL].astype(int)
    )

    dc = len(
        dev_ids & cal_ids
    )

    dt = len(
        dev_ids & test_ids
    )

    ct = len(
        cal_ids & test_ids
    )

    print(
        f"Development × Calibration: {dc}"
    )

    print(
        f"Development × Test: {dt}"
    )

    print(
        f"Calibration × Test: {ct}"
    )

    if (
        dc == 0
        and dt == 0
        and ct == 0
    ):

        print(
            "Partition disjointness -> PASS"
        )

    else:

        raise RuntimeError(
            "Partition overlap detected."
        )


# ============================================================================
# 15. MISSINGNESS
# ============================================================================

def print_missingness(
    dev,
    cal,
    test
):

    print(
        "\n" + "=" * 72
    )

    print(
        "6. MISSINGNESS AUDIT"
    )

    print(
        "=" * 72
    )

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked test", test),
    ]:

        print(
            f"\n{name}"
        )

        found = False

        for feature in FEATURES:

            count = int(
                df[feature]
                .isna()
                .sum()
            )

            if count > 0:

                found = True

                percentage = (
                    100.0
                    * count
                    / len(df)
                )

                print(
                    f"  {feature}: "
                    f"{count} "
                    f"({percentage:.4f}%)"
                )

        if not found:

            print(
                "  No missing predictor values."
            )


# ============================================================================
# 16. FROZEN PROTOCOL
# ============================================================================

def print_protocol():

    print(
        "\n" + "=" * 72
    )

    print(
        "7. FROZEN CHEBYSHEV-KAN PROTOCOL"
    )

    print(
        "=" * 72
    )

    print(
        f"Features: {len(FEATURES)}"
    )

    print(
        f"Architecture: "
        f"{len(FEATURES)} -> "
        f"{HIDDEN_DIM} -> 1"
    )

    print(
        "Basis: Chebyshev polynomial "
        "of the first kind"
    )

    print(
        "Polynomial degree search: "
        f"{CHEBYSHEV_DEGREES}"
    )

    print(
        "Polynomial complexity: "
        "selected ONLY by inner CV"
    )

    print(
        "Input normalization: "
        "fold-specific MinMax to [-1, 1]"
    )

    print(
        "Clinical grouping: NO"
    )

    print(
        "Sparse group gates: NO"
    )

    print(
        "ADASYN: NO"
    )

    print(
        "Conformal prediction: NO"
    )

    print(
        "Median imputation: fold-specific"
    )

    print(
        "Outer CV: 5 folds"
    )

    print(
        "Inner CV: 4 folds"
    )

    print(
        "Calibration set: PROTECTED"
    )

    print(
        "Locked test: PROTECTED"
    )


# ============================================================================
# 17. NESTED CROSS-VALIDATION
# ============================================================================

def run_nested_cv(
    dev
):

    X = dev[
        FEATURES
    ].copy()

    y = dev[
        TARGET
    ].astype(int).copy()

    if ID_COL in dev.columns:

        ids = dev[
            ID_COL
        ].copy()

    else:

        ids = pd.Series(
            np.arange(
                len(dev)
            ),
            name="row_id"
        )

    outer_cv = StratifiedKFold(
        n_splits=N_OUTER,
        shuffle=True,
        random_state=RANDOM_STATE
    )

    inner_cv = StratifiedKFold(
        n_splits=N_INNER,
        shuffle=True,
        random_state=RANDOM_STATE
    )

    fold_results = []

    selected_hyperparameters = []

    pooled_predictions = []

    fold_number = 0

    for (
        outer_train_idx,
        outer_val_idx
    ) in outer_cv.split(
        X,
        y
    ):

        fold_number += 1

        print(
            "\n" + "-" * 72
        )

        print(
            f"OUTER FOLD "
            f"{fold_number}/{N_OUTER}"
        )

        print(
            "-" * 72
        )

        X_outer_train = X.iloc[
            outer_train_idx
        ].copy()

        y_outer_train = y.iloc[
            outer_train_idx
        ].copy()

        X_outer_val = X.iloc[
            outer_val_idx
        ].copy()

        y_outer_val = y.iloc[
            outer_val_idx
        ].copy()

        print(
            f"Training rows: "
            f"{len(X_outer_train)}"
        )

        print(
            f"Validation rows: "
            f"{len(X_outer_val)}"
        )

        # ================================================================
        # INNER-CV HYPERPARAMETER SEARCH
        # ================================================================

        print(
            "\nInner-CV hyperparameter search:"
        )

        configs = []

        for degree in CHEBYSHEV_DEGREES:

            for learning_rate in LEARNING_RATES:

                for l2 in L2_VALUES:

                    configs.append(
                        (
                            degree,
                            learning_rate,
                            l2
                        )
                    )

        config_results = []

        for config_idx, (
            degree,
            learning_rate,
            l2
        ) in enumerate(
            configs,
            start=1
        ):

            inner_scores = []

            for (
                inner_train_idx,
                inner_val_idx
            ) in inner_cv.split(
                X_outer_train,
                y_outer_train
            ):

                X_inner_train = (
                    X_outer_train.iloc[
                        inner_train_idx
                    ].copy()
                )

                y_inner_train = (
                    y_outer_train.iloc[
                        inner_train_idx
                    ].copy()
                )

                X_inner_val = (
                    X_outer_train.iloc[
                        inner_val_idx
                    ].copy()
                )

                y_inner_val = (
                    y_outer_train.iloc[
                        inner_val_idx
                    ].copy()
                )

                # --------------------------------------------------------
                # Fold-specific median imputation
                # --------------------------------------------------------

                imputer = SimpleImputer(
                    strategy="median"
                )

                X_inner_train_imp = (
                    imputer.fit_transform(
                        X_inner_train
                    )
                )

                X_inner_val_imp = (
                    imputer.transform(
                        X_inner_val
                    )
                )

                # --------------------------------------------------------
                # Fold-specific MinMax scaling
                # --------------------------------------------------------

                scaler = MinMaxScaler(
                    feature_range=(-1, 1)
                )

                X_inner_train_scaled = (
                    scaler.fit_transform(
                        X_inner_train_imp
                    )
                )

                X_inner_val_scaled = (
                    scaler.transform(
                        X_inner_val_imp
                    )
                )

                # --------------------------------------------------------
                # Internal split for early stopping
                # --------------------------------------------------------

                internal_split = StratifiedKFold(
                    n_splits=10,
                    shuffle=True,
                    random_state=RANDOM_STATE
                )

                (
                    fit_idx,
                    early_stop_idx
                ) = next(
                    internal_split.split(
                        X_inner_train_scaled,
                        y_inner_train
                    )
                )

                X_fit = (
                    X_inner_train_scaled[
                        fit_idx
                    ]
                )

                y_fit = (
                    y_inner_train
                    .iloc[fit_idx]
                    .to_numpy()
                )

                X_early = (
                    X_inner_train_scaled[
                        early_stop_idx
                    ]
                )

                y_early = (
                    y_inner_train
                    .iloc[early_stop_idx]
                    .to_numpy()
                )

                model, _, _ = train_model(
                    X_fit,
                    y_fit,
                    X_early,
                    y_early,
                    degree=degree,
                    learning_rate=learning_rate,
                    l2=l2
                )

                inner_probabilities = (
                    predict_probability(
                        model,
                        X_inner_val_scaled
                    )
                )

                inner_auc = roc_auc_score(
                    y_inner_val,
                    inner_probabilities
                )

                inner_scores.append(
                    inner_auc
                )

            mean_inner_auc = float(
                np.mean(
                    inner_scores
                )
            )

            config_results.append({

                "degree": degree,

                "learning_rate":
                    learning_rate,

                "l2": l2,

                "mean_inner_auc":
                    mean_inner_auc
            })

            print(
                f"      Config "
                f"{config_idx}/"
                f"{len(configs)}: "
                f"K={degree}, "
                f"lr={learning_rate}, "
                f"L2={l2}, "
                f"AUC="
                f"{mean_inner_auc:.6f}"
            )

        # ================================================================
        # BEST CONFIGURATION
        # ================================================================

        best_config = max(
            config_results,
            key=lambda item:
                item["mean_inner_auc"]
        )

        best_degree = (
            best_config["degree"]
        )

        best_lr = (
            best_config["learning_rate"]
        )

        best_l2 = (
            best_config["l2"]
        )

        best_inner_auc = (
            best_config["mean_inner_auc"]
        )

        print(
            "\nBest inner-CV ROC-AUC: "
            f"{best_inner_auc:.6f}"
        )

        print(
            "Selected hyperparameters:"
        )

        print(
            f"  polynomial_degree: "
            f"{best_degree}"
        )

        print(
            f"  learning_rate: "
            f"{best_lr}"
        )

        print(
            f"  l2: "
            f"{best_l2}"
        )

        # ================================================================
        # OUTER TRAINING PREPROCESSING
        # ================================================================

        outer_imputer = SimpleImputer(
            strategy="median"
        )

        X_outer_train_imp = (
            outer_imputer.fit_transform(
                X_outer_train
            )
        )

        X_outer_val_imp = (
            outer_imputer.transform(
                X_outer_val
            )
        )

        outer_scaler = MinMaxScaler(
            feature_range=(-1, 1)
        )

        X_outer_train_scaled = (
            outer_scaler.fit_transform(
                X_outer_train_imp
            )
        )

        X_outer_val_scaled = (
            outer_scaler.transform(
                X_outer_val_imp
            )
        )

        # ================================================================
        # INTERNAL EARLY-STOPPING SPLIT
        # ================================================================

        internal_split = StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=RANDOM_STATE
        )

        (
            fit_idx,
            early_stop_idx
        ) = next(
            internal_split.split(
                X_outer_train_scaled,
                y_outer_train
            )
        )

        X_fit = (
            X_outer_train_scaled[
                fit_idx
            ]
        )

        y_fit = (
            y_outer_train
            .iloc[fit_idx]
            .to_numpy()
        )

        X_early = (
            X_outer_train_scaled[
                early_stop_idx
            ]
        )

        y_early = (
            y_outer_train
            .iloc[early_stop_idx]
            .to_numpy()
        )

        # ================================================================
        # TRAIN SELECTED OUTER-FOLD MODEL
        # ================================================================

        model, best_internal_auc, best_epoch = (
            train_model(
                X_fit,
                y_fit,
                X_early,
                y_early,
                degree=best_degree,
                learning_rate=best_lr,
                l2=best_l2
            )
        )

        parameter_count = (
            count_parameters(
                model
            )
        )

        print(
            f"Best internal-validation epoch: "
            f"{best_epoch}"
        )

        print(
            f"Trainable parameters: "
            f"{parameter_count}"
        )

        # ================================================================
        # OUTER VALIDATION
        # ================================================================

        outer_probabilities = (
            predict_probability(
                model,
                X_outer_val_scaled
            )
        )

        metrics = calculate_metrics(
            y_outer_val.to_numpy(),
            outer_probabilities
        )

        print(
            "\nOuter validation metrics:"
        )

        print(
            f"  Accuracy: "
            f"{metrics['accuracy']:.6f}"
        )

        print(
            f"  Precision: "
            f"{metrics['precision']:.6f}"
        )

        print(
            f"  Sensitivity: "
            f"{metrics['sensitivity']:.6f}"
        )

        print(
            f"  Specificity: "
            f"{metrics['specificity']:.6f}"
        )

        print(
            f"  F1: "
            f"{metrics['f1']:.6f}"
        )

        print(
            f"  ROC-AUC: "
            f"{metrics['roc_auc']:.6f}"
        )

        print(
            f"  PR-AUC: "
            f"{metrics['pr_auc']:.6f}"
        )

        print(
            f"  Brier: "
            f"{metrics['brier']:.6f}"
        )

        print(
            f"  ECE: "
            f"{metrics['ece']:.6f}"
        )

        fold_record = {

            "fold":
                fold_number,

            "training_rows":
                len(X_outer_train),

            "validation_rows":
                len(X_outer_val),

            "best_inner_auc":
                best_inner_auc,

            "polynomial_degree":
                best_degree,

            "learning_rate":
                best_lr,

            "l2":
                best_l2,

            "best_internal_auc":
                best_internal_auc,

            "best_internal_epoch":
                best_epoch,

            "parameter_count":
                parameter_count,
        }

        fold_record.update(
            metrics
        )

        fold_results.append(
            fold_record
        )

        selected_hyperparameters.append({

            "fold":
                fold_number,

            "polynomial_degree":
                best_degree,

            "learning_rate":
                best_lr,

            "l2":
                best_l2,

            "best_inner_auc":
                best_inner_auc,

            "best_internal_auc":
                best_internal_auc,

            "best_internal_epoch":
                best_epoch,

            "parameter_count":
                parameter_count,
        })

        # ================================================================
        # OUTER PREDICTIONS
        # ================================================================

        fold_predictions = pd.DataFrame({

            "id":
                ids.iloc[
                    outer_val_idx
                ].to_numpy(),

            "fold":
                fold_number,

            "y_true":
                y_outer_val.to_numpy(),

            "probability":
                outer_probabilities,

            "prediction":
                (
                    outer_probabilities
                    >= 0.5
                ).astype(int)
        })

        pooled_predictions.append(
            fold_predictions
        )

    return (
        fold_results,
        selected_hyperparameters,
        pooled_predictions
    )


# ============================================================================
# 18. AGGREGATE RESULTS
# ============================================================================

def aggregate_results(
    fold_results
):

    metric_names = [
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "brier",
        "ece",
    ]

    aggregate = {}

    print(
        "\n" + "=" * 72
    )

    print(
        "9. AGGREGATE OUTER-CV RESULTS"
    )

    print(
        "=" * 72
    )

    for metric in metric_names:

        values = [
            result[metric]
            for result in fold_results
        ]

        mean_value = float(
            np.mean(values)
        )

        std_value = float(
            np.std(
                values,
                ddof=1
            )
        )

        aggregate[
            f"{metric}_mean"
        ] = mean_value

        aggregate[
            f"{metric}_std"
        ] = std_value

        print(
            f"{metric.upper()}: "
            f"{mean_value:.6f} "
            f"± "
            f"{std_value:.6f}"
        )

    return aggregate


# ============================================================================
# 19. POOLED RESULTS
# ============================================================================

def pooled_results(
    pooled_predictions
):

    pooled = pd.concat(
        pooled_predictions,
        ignore_index=True
    )

    pooled = (
        pooled
        .sort_values(
            by="id"
        )
        .reset_index(
            drop=True
        )
    )

    metrics = calculate_metrics(
        pooled["y_true"].to_numpy(),
        pooled["probability"].to_numpy()
    )

    print(
        "\n" + "=" * 72
    )

    print(
        "10. POOLED OUTER-CV RESULTS"
    )

    print(
        "=" * 72
    )

    print(
        f"Accuracy: "
        f"{metrics['accuracy']:.6f}"
    )

    print(
        f"Precision: "
        f"{metrics['precision']:.6f}"
    )

    print(
        f"Sensitivity: "
        f"{metrics['sensitivity']:.6f}"
    )

    print(
        f"Specificity: "
        f"{metrics['specificity']:.6f}"
    )

    print(
        f"F1: "
        f"{metrics['f1']:.6f}"
    )

    print(
        f"ROC-AUC: "
        f"{metrics['roc_auc']:.6f}"
    )

    print(
        f"PR-AUC: "
        f"{metrics['pr_auc']:.6f}"
    )

    print(
        f"Brier: "
        f"{metrics['brier']:.6f}"
    )

    print(
        f"ECE: "
        f"{metrics['ece']:.6f}"
    )

    return (
        pooled,
        metrics
    )


# ============================================================================
# 20. HYPERPARAMETER STABILITY
# ============================================================================

def print_hyperparameter_stability(
    selected_hyperparameters
):

    print(
        "\n" + "=" * 72
    )

    print(
        "11. HYPERPARAMETER STABILITY"
    )

    print(
        "=" * 72
    )

    hp_df = pd.DataFrame(
        selected_hyperparameters
    )

    for column in [
        "polynomial_degree",
        "learning_rate",
        "l2",
    ]:

        print(
            f"\n{column}"
        )

        counts = (
            hp_df[column]
            .value_counts()
            .sort_index()
        )

        for value, count in counts.items():

            print(
                f"  {value}: "
                f"{count}/"
                f"{len(hp_df)}"
            )


# ============================================================================
# 21. MODEL SIZE
# ============================================================================

def print_model_size(
    fold_results
):

    print(
        "\n" + "=" * 72
    )

    print(
        "12. MODEL SIZE"
    )

    print(
        "=" * 72
    )

    counts = [
        result[
            "parameter_count"
        ]
        for result in fold_results
    ]

    print(
        "Parameter count by fold:"
    )

    for count in counts:

        print(
            f"  {count}"
        )

    print(
        f"Mean parameter count: "
        f"{np.mean(counts):.0f}"
    )


# ============================================================================
# 22. OUTER-CV COVERAGE
# ============================================================================

def check_outer_coverage(
    pooled_predictions,
    expected_rows
):

    print(
        "\n" + "=" * 72
    )

    print(
        "13. OUTER-CV COVERAGE CHECK"
    )

    print(
        "=" * 72
    )

    pooled = pd.concat(
        pooled_predictions,
        ignore_index=True
    )

    actual_rows = len(
        pooled
    )

    unique_ids = (
        pooled["id"]
        .nunique()
    )

    print(
        f"Expected Development predictions: "
        f"{expected_rows}"
    )

    print(
        f"Actual outer-CV predictions: "
        f"{actual_rows}"
    )

    print(
        f"Unique prediction IDs: "
        f"{unique_ids}"
    )

    if (
        actual_rows == expected_rows
        and
        unique_ids == expected_rows
    ):

        print(
            "Every Development record "
            "appears exactly once -> PASS"
        )

    else:

        raise RuntimeError(
            "Outer-CV coverage failed."
        )


# ============================================================================
# 23. CALIBRATION / TEST PROTECTION
# ============================================================================

def check_protection(
    pooled_predictions,
    cal,
    test
):

    print(
        "\n" + "=" * 72
    )

    print(
        "14. CALIBRATION / TEST PROTECTION"
    )

    print(
        "=" * 72
    )

    pooled = pd.concat(
        pooled_predictions,
        ignore_index=True
    )

    pooled_ids = set(
        pooled["id"]
        .astype(int)
    )

    cal_ids = set(
        cal[ID_COL]
        .astype(int)
    )

    test_ids = set(
        test[ID_COL]
        .astype(int)
    )

    cal_overlap = len(
        pooled_ids & cal_ids
    )

    test_overlap = len(
        pooled_ids & test_ids
    )

    print(
        "Outer-CV predictions × Calibration: "
        f"{cal_overlap}"
    )

    print(
        "Outer-CV predictions × Locked Test: "
        f"{test_overlap}"
    )

    if cal_overlap == 0:

        print(
            "Calibration protection -> PASS"
        )

    else:

        raise RuntimeError(
            "Calibration leakage detected."
        )

    if test_overlap == 0:

        print(
            "Locked-test protection -> PASS"
        )

    else:

        raise RuntimeError(
            "Locked-test leakage detected."
        )


# ============================================================================
# 24. SAVE RESULTS
# ============================================================================

def save_results(
    fold_results,
    selected_hyperparameters,
    pooled,
    aggregate,
    pooled_metrics
):

    print(
        "\n" + "=" * 72
    )

    print(
        "15. SAVE RESULTS"
    )

    print(
        "=" * 72
    )

    fold_df = pd.DataFrame(
        fold_results
    )

    hp_df = pd.DataFrame(
        selected_hyperparameters
    )

    aggregate_df = pd.DataFrame([
        aggregate
    ])

    pooled_metrics_df = pd.DataFrame([
        pooled_metrics
    ])

    fold_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_outer_fold_results.csv"
    )

    aggregate_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_aggregate_results.csv"
    )

    hp_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_selected_hyperparameters.csv"
    )

    pooled_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_pooled_outer_cv.csv"
    )

    prediction_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_outer_predictions.csv"
    )

    record_file = os.path.join(
        RESULTS_DIR,
        "implementation27_chebyshev_experiment_record.json"
    )

    fold_df.to_csv(
        fold_file,
        index=False
    )

    aggregate_df.to_csv(
        aggregate_file,
        index=False
    )

    hp_df.to_csv(
        hp_file,
        index=False
    )

    pooled_metrics_df.to_csv(
        pooled_file,
        index=False
    )

    pooled.to_csv(
        prediction_file,
        index=False
    )

    experiment_record = {

        "implementation": 27,

        "name":
            "Vanilla Chebyshev-KAN Baseline",

        "version":
            "corrected_complexity_tuning",

        "timestamp":
            datetime.now().isoformat(),

        "project_root":
            PROJECT_ROOT,

        "dataset":
            "Kaggle Cardiovascular "
            "Disease Dataset",

        "development_rows":
            EXPECTED_DEV_ROWS,

        "calibration_rows":
            EXPECTED_CAL_ROWS,

        "locked_test_rows":
            EXPECTED_TEST_ROWS,

        "features":
            FEATURES,

        "target":
            TARGET,

        "architecture":
            f"{len(FEATURES)} -> "
            f"{HIDDEN_DIM} -> 1",

        "basis":
            "Chebyshev polynomial "
            "of the first kind",

        "degree_search":
            CHEBYSHEV_DEGREES,

        "learning_rate_search":
            LEARNING_RATES,

        "l2_search":
            L2_VALUES,

        "total_configurations_per_outer_fold":
            len(CHEBYSHEV_DEGREES)
            *
            len(LEARNING_RATES)
            *
            len(L2_VALUES),

        "normalization":
            "fold-specific MinMaxScaler "
            "to [-1,1]",

        "imputation":
            "fold-specific median",

        "clinical_grouping":
            False,

        "sparse_group_gating":
            False,

        "adasyn":
            False,

        "conformal_prediction":
            False,

        "outer_cv":
            N_OUTER,

        "inner_cv":
            N_INNER,

        "random_state":
            RANDOM_STATE,

        "batch_size":
            BATCH_SIZE,

        "max_epochs":
            MAX_EPOCHS,

        "early_stopping_patience":
            PATIENCE,

        "aggregate_results":
            aggregate,

        "pooled_results":
            pooled_metrics,

        "calibration_touched":
            False,

        "locked_test_touched":
            False,

        "status":
            "PASS",
    }

    with open(
        record_file,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            experiment_record,
            f,
            indent=2
        )

    print(
        f"Saved: {fold_file}"
    )

    print(
        f"Saved: {aggregate_file}"
    )

    print(
        f"Saved: {hp_file}"
    )

    print(
        f"Saved: {pooled_file}"
    )

    print(
        f"Saved: {prediction_file}"
    )

    print(
        f"Saved: {record_file}"
    )


# ============================================================================
# 25. FINAL SUMMARY
# ============================================================================

def print_final_summary(
    aggregate,
    pooled_metrics
):

    print(
        "\n" + "=" * 72
    )

    print(
        "IMPLEMENTATION 27 FINAL SUMMARY"
    )

    print(
        "=" * 72
    )

    print(
        "Vanilla Chebyshev-KAN "
        "pooled outer-CV ROC-AUC: "
        f"{pooled_metrics['roc_auc']:.6f}"
    )

    print(
        "Vanilla Chebyshev-KAN "
        "mean outer-CV ROC-AUC: "
        f"{aggregate['roc_auc_mean']:.6f} "
        f"± "
        f"{aggregate['roc_auc_std']:.6f}"
    )

    print(
        "Calibration set touched: False"
    )

    print(
        "Locked test touched: False"
    )

    print(
        "ADASYN used: False"
    )

    print(
        "Clinical grouping used: False"
    )

    print(
        "Sparse group gating used: False"
    )

    print(
        "Conformal prediction used: False"
    )

    print(
        "Status: PASS"
    )


# ============================================================================
# 26. MAIN
# ============================================================================

def main():

    ensure_directories()

    set_seed()

    (
        dev,
        cal,
        test
    ) = load_data()

    validate_data(
        dev,
        cal,
        test
    )

    print_target_distribution(
        dev,
        cal,
        test
    )

    check_partition_disjointness(
        dev,
        cal,
        test
    )

    print_missingness(
        dev,
        cal,
        test
    )

    print_protocol()

    (
        fold_results,
        selected_hyperparameters,
        pooled_predictions
    ) = run_nested_cv(
        dev
    )

    check_outer_coverage(
        pooled_predictions,
        expected_rows=len(dev)
    )

    aggregate = aggregate_results(
        fold_results
    )

    (
        pooled,
        pooled_metrics
    ) = pooled_results(
        pooled_predictions
    )

    print_hyperparameter_stability(
        selected_hyperparameters
    )

    print_model_size(
        fold_results
    )

    check_protection(
        pooled_predictions,
        cal,
        test
    )

    save_results(
        fold_results,
        selected_hyperparameters,
        pooled,
        aggregate,
        pooled_metrics
    )

    print_final_summary(
        aggregate,
        pooled_metrics
    )


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":

    main()