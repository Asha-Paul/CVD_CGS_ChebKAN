# ============================================================
# IMPLEMENTATION 51
# XGBOOST FINAL-FIT LOCKED-TEST EVALUATION
# ============================================================
# Purpose:
#   Select XGBoost hyperparameters using development data only,
#   refit on all 49,000 development records, and evaluate once on
#   the 14,000 locked-test records. Does not modify Implementation 24.
#
# Important:
#   - Does not use calibration data.
#   - Does not use locked-test labels for selection.
#   - Uses the original 11 predictors, median imputation, and grid.
#   - Saves test predictions and bootstrap metrics for comparison
#     against A8 on exactly the same locked-test IDs.
# ============================================================

import json
import warnings
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import (
    roc_auc_score, average_precision_score, accuracy_score,
    precision_score, recall_score, f1_score, brier_score_loss,
    confusion_matrix
)

warnings.filterwarnings("ignore")

try:
    from xgboost import XGBClassifier
except ImportError as exc:
    raise ImportError(
        "XGBoost is missing from this Python environment. "
        "Use the project's existing .venv; do not change environments yet."
    ) from exc

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"
A8_FILE = RESULTS_DIR / "implementation46_final_a8_locked_test_predictions.csv"

SEED = 2026
FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]
TARGET = "cardio"
PARAM_GRID = {
    "model__n_estimators": [200, 400],
    "model__max_depth": [3, 5],
    "model__learning_rate": [0.05, 0.10],
    "model__subsample": [0.8, 1.0],
    "model__colsample_bytree": [0.8, 1.0],
}

def auc_ci(y, p, n_boot=5000, seed=2026):
    """Class-stratified percentile bootstrap CI for ROC-AUC."""
    y = np.asarray(y, dtype=int)
    p = np.asarray(p, dtype=float)
    rng = np.random.default_rng(seed)
    i0 = np.flatnonzero(y == 0)
    i1 = np.flatnonzero(y == 1)
    values = np.empty(n_boot)
    for b in range(n_boot):
        idx = np.concatenate([
            rng.choice(i0, size=len(i0), replace=True),
            rng.choice(i1, size=len(i1), replace=True),
        ])
        values[b] = roc_auc_score(y[idx], p[idx])
    return float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))

def paired_auc_difference_ci(y, p_candidate, p_a8, n_boot=5000, seed=2027):
    """Paired, class-stratified bootstrap CI for candidate AUC minus A8 AUC."""
    y = np.asarray(y, dtype=int)
    p_candidate = np.asarray(p_candidate, dtype=float)
    p_a8 = np.asarray(p_a8, dtype=float)
    rng = np.random.default_rng(seed)
    i0 = np.flatnonzero(y == 0)
    i1 = np.flatnonzero(y == 1)
    diffs = np.empty(n_boot)
    for b in range(n_boot):
        idx = np.concatenate([
            rng.choice(i0, size=len(i0), replace=True),
            rng.choice(i1, size=len(i1), replace=True),
        ])
        diffs[b] = (
            roc_auc_score(y[idx], p_candidate[idx])
            - roc_auc_score(y[idx], p_a8[idx])
        )
    return float(np.quantile(diffs, 0.025)), float(np.quantile(diffs, 0.975))

def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    for f in [DEV_FILE, TEST_FILE, A8_FILE]:
        if not f.exists():
            raise FileNotFoundError(f"Required file not found:\n{f}")

    dev = pd.read_csv(DEV_FILE)
    test = pd.read_csv(TEST_FILE)
    a8 = pd.read_csv(A8_FILE)

    for name, df, n in [("development", dev, 49000), ("locked test", test, 14000)]:
        missing = [c for c in FEATURES + [TARGET, "id"] if c not in df.columns]
        if missing:
            raise ValueError(f"{name} file missing columns: {missing}")
        if len(df) != n:
            raise ValueError(f"{name} rows = {len(df)}, expected {n}")
        if df[TARGET].isna().any() or set(df[TARGET].unique()) != {0, 1}:
            raise ValueError(f"{name} target must be complete and binary.")

    needed_a8 = ["id", "true_label", "probability"]
    if any(c not in a8.columns for c in needed_a8):
        raise ValueError(f"A8 prediction file must contain columns {needed_a8}")

    # Align A8 predictions by ID; verify exact labels and row coverage.
    if test["id"].duplicated().any() or a8["id"].duplicated().any():
        raise ValueError("Duplicate test IDs found.")
    if set(test["id"]) != set(a8["id"]):
        raise ValueError("A8 prediction IDs do not match locked-test IDs.")
    a8 = test[["id", TARGET]].merge(
        a8[["id", "true_label", "probability"]],
        on="id", how="left", validate="one_to_one"
    )
    if not np.array_equal(a8[TARGET].to_numpy(), a8["true_label"].to_numpy()):
        raise ValueError("A8 true labels do not match locked-test labels.")
    if a8["probability"].isna().any():
        raise ValueError("Missing A8 probabilities after ID alignment.")

    X_dev = dev[FEATURES].copy()
    y_dev = dev[TARGET].astype(int).to_numpy()
    X_test = test[FEATURES].copy()
    y_test = test[TARGET].astype(int).to_numpy()

    estimator = XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        random_state=SEED,
        n_jobs=-1,
        verbosity=0
    )
    pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", estimator)
    ])
    cv = StratifiedKFold(n_splits=4, shuffle=True, random_state=SEED)

    print("=" * 72)
    print("IMPLEMENTATION 51: XGBOOST FINAL-FIT LOCKED-TEST EVALUATION")
    print(f"Development rows: {len(dev)}")
    print(f"Locked-test rows: {len(test)}")
    print("Selecting hyperparameters using development data only...")
    print("Grid combinations:", 2 * 2 * 2 * 2 * 2)
    print("Locked-test labels will not be used for selection.")
    search = GridSearchCV(
        estimator=pipeline,
        param_grid=PARAM_GRID,
        scoring="roc_auc",
        cv=cv,
        n_jobs=-1,
        refit=True,
        return_train_score=False,
        verbose=1
    )
    search.fit(X_dev, y_dev)
    # GridSearchCV refits its selected pipeline on all development records.
    best_model = search.best_estimator_
    print("Best development-CV ROC-AUC:", f"{search.best_score_:.6f}")
    print("Selected parameters:", json.dumps(search.best_params_, indent=2))

    # Single evaluation of locked test after all selection is complete.
    p_xgb = best_model.predict_proba(X_test)[:, 1]
    p_a8 = a8["probability"].to_numpy(dtype=float)
    auc_xgb = roc_auc_score(y_test, p_xgb)
    auc_a8 = roc_auc_score(y_test, p_a8)
    xgb_ci = auc_ci(y_test, p_xgb)
    delta_ci = paired_auc_difference_ci(y_test, p_xgb, p_a8)
    pred = (p_xgb >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()

    metrics = {
        "implementation": 51,
        "model": "XGBoost 11-feature final fit",
        "n_development": len(dev),
        "n_locked_test": len(test),
        "development_cv_mean_auc": float(search.best_score_),
        "selected_parameters": search.best_params_,
        "locked_test_roc_auc": float(auc_xgb),
        "locked_test_roc_auc_ci95": [float(xgb_ci[0]), float(xgb_ci[1])],
        "a8_locked_test_roc_auc_recomputed": float(auc_a8),
        "delta_auc_xgboost_minus_a8": float(auc_xgb - auc_a8),
        "paired_delta_auc_ci95": [float(delta_ci[0]), float(delta_ci[1])],
        "pr_auc_average_precision": float(average_precision_score(y_test, p_xgb)),
        "accuracy_threshold_0_5": float(accuracy_score(y_test, pred)),
        "precision_threshold_0_5": float(precision_score(y_test, pred, zero_division=0)),
        "sensitivity_threshold_0_5": float(recall_score(y_test, pred, zero_division=0)),
        "specificity_threshold_0_5": float(tn / (tn + fp)),
        "f1_threshold_0_5": float(f1_score(y_test, pred, zero_division=0)),
        "brier_score": float(brier_score_loss(y_test, p_xgb)),
        "confusion_matrix": {"TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)},
        "bootstrap_replicates": 5000,
        "bootstrap_method": "class-stratified percentile bootstrap; paired resamples for delta AUC",
        "test_used_for_selection": False,
        "calibration_used": False,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }

    pred_df = pd.DataFrame({
        "id": test["id"].to_numpy(),
        "true_label": y_test,
        "probability": p_xgb,
        "prediction_050": pred,
        "a8_probability": p_a8,
    })
    pred_path = RESULTS_DIR / "implementation51_xgboost_locked_test_predictions.csv"
    metrics_path = RESULTS_DIR / "implementation51_xgboost_locked_test_metrics.json"
    summary_path = RESULTS_DIR / "implementation51_xgboost_locked_test_metrics.csv"
    pred_df.to_csv(pred_path, index=False)
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    pd.DataFrame([{
        "model": metrics["model"],
        "n_test": len(test),
        "ROC_AUC": auc_xgb,
        "ROC_AUC_CI95_low": xgb_ci[0],
        "ROC_AUC_CI95_high": xgb_ci[1],
        "A8_ROC_AUC": auc_a8,
        "Delta_AUC_XGBoost_minus_A8": auc_xgb - auc_a8,
        "Paired_Delta_CI95_low": delta_ci[0],
        "Paired_Delta_CI95_high": delta_ci[1],
        "PR_AUC_average_precision": metrics["pr_auc_average_precision"],
        "accuracy_threshold_0.5": metrics["accuracy_threshold_0_5"],
        "precision_threshold_0.5": metrics["precision_threshold_0_5"],
        "sensitivity_threshold_0.5": metrics["sensitivity_threshold_0_5"],
        "specificity_threshold_0.5": metrics["specificity_threshold_0_5"],
        "F1_threshold_0.5": metrics["f1_threshold_0_5"],
        "Brier_score": metrics["brier_score"],
    }]).to_csv(summary_path, index=False)

    print("\nLOCKED-TEST RESULTS")
    print(f"XGBoost ROC-AUC: {auc_xgb:.6f} (95% CI {xgb_ci[0]:.6f}–{xgb_ci[1]:.6f})")
    print(f"A8 ROC-AUC recomputed: {auc_a8:.6f}")
    print(f"Delta AUC (XGBoost − A8): {auc_xgb - auc_a8:+.6f}")
    print(f"Paired 95% CI for delta: {delta_ci[0]:+.6f} to {delta_ci[1]:+.6f}")
    print("\nSaved predictions:", pred_path)
    print("Saved metrics JSON:", metrics_path)
    print("Saved metrics CSV:", summary_path)
    print("IMPORTANT: The locked test was evaluated only after development-only selection.")

if __name__ == "__main__":
    main()
