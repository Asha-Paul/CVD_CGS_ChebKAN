# ================================================================
# AUDIT 11: UCI HEART DISEASE TARGET + MISSINGNESS AUDIT
# ================================================================
#
# Purpose:
#   Audit the processed UCI Heart Disease datasets before any
#   harmonization, cleaning, imputation, or external validation.
#
# UCI cohorts:
#   1. Cleveland
#   2. Hungarian
#   3. Switzerland
#   4. VA Long Beach
#
# IMPORTANT:
#   - No records are deleted.
#   - No values are corrected.
#   - No imputation is performed.
#   - No harmonization is performed.
#   - No train/test split is performed.
#   - Target values are reported exactly as stored.
#
# ================================================================

from pathlib import Path
import zipfile
import pandas as pd
import numpy as np


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

ZIP_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "uci"
    / "heart+disease.zip"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ================================================================
# 2. UCI COLUMN NAMES
# ================================================================

COLUMNS = [
    "age",
    "sex",
    "cp",
    "trestbps",
    "chol",
    "fbs",
    "restecg",
    "thalach",
    "exang",
    "oldpeak",
    "slope",
    "ca",
    "thal",
    "target"
]


# ================================================================
# 3. PROCESSED UCI FILES
# ================================================================

UCI_FILES = {
    "Cleveland": "processed.cleveland.data",
    "Hungarian": "processed.hungarian.data",
    "Switzerland": "processed.switzerland.data",
    "VA Long Beach": "processed.va.data"
}


# ================================================================
# 4. OUTPUT FILES
# ================================================================

COHORT_SUMMARY_OUTPUT = (
    RESULTS_DIR
    / "audit11_uci_cohort_summary.csv"
)

MISSINGNESS_OUTPUT = (
    RESULTS_DIR
    / "audit11_uci_missingness.csv"
)

TARGET_OUTPUT = (
    RESULTS_DIR
    / "audit11_uci_target_distribution.csv"
)

UNIQUE_VALUES_OUTPUT = (
    RESULTS_DIR
    / "audit11_uci_unique_values.csv"
)

COMBINED_OUTPUT = (
    RESULTS_DIR
    / "audit11_uci_processed_combined_raw.csv"
)


# ================================================================
# 5. HEADER
# ================================================================

print("=" * 80)
print("AUDIT 11: UCI HEART DISEASE TARGET + MISSINGNESS AUDIT")
print("=" * 80)

print("\nZIP file:")
print(ZIP_PATH)


# ================================================================
# 6. CHECK ZIP
# ================================================================

if not ZIP_PATH.exists():

    raise FileNotFoundError(
        f"UCI ZIP file not found:\n{ZIP_PATH}"
    )


# ================================================================
# 7. OPEN ZIP
# ================================================================

with zipfile.ZipFile(ZIP_PATH, "r") as z:

    zip_names = z.namelist()

    print("\nUCI processed files found:")

    for cohort, filename in UCI_FILES.items():

        if filename in zip_names:

            print(
                f"  {cohort:<20} : FOUND"
            )

        else:

            print(
                f"  {cohort:<20} : NOT FOUND"
            )


    # ============================================================
    # 8. READ EACH COHORT
    # ============================================================

    cohort_data = {}

    for cohort, filename in UCI_FILES.items():

        print("\n" + "=" * 80)
        print(f"PROCESSING: {cohort}")
        print("=" * 80)

        if filename not in zip_names:

            print(
                f"WARNING: {filename} not found in ZIP."
            )

            continue


        # --------------------------------------------------------
        # Read directly from ZIP
        # --------------------------------------------------------

        with z.open(filename) as f:

            df = pd.read_csv(
                f,
                header=None,
                names=COLUMNS,
                na_values=["?"],
                skipinitialspace=True
            )


        cohort_data[cohort] = df.copy()


        # --------------------------------------------------------
        # Basic dimensions
        # --------------------------------------------------------

        print(
            f"\nRows    : {len(df):,}"
        )

        print(
            f"Columns : {len(df.columns)}"
        )


        # --------------------------------------------------------
        # Data types
        # --------------------------------------------------------

        print("\nData types:")

        print(
            df.dtypes.to_string()
        )


        # --------------------------------------------------------
        # Missingness
        # --------------------------------------------------------

        print("\nMissing values:")

        for col in COLUMNS:

            count = int(
                df[col].isna().sum()
            )

            pct = (
                100 * count / len(df)
            )

            print(
                f"{col:<12} : "
                f"{count:>5,} "
                f"({pct:>7.3f}%)"
            )


        # --------------------------------------------------------
        # Target distribution
        # --------------------------------------------------------

        print("\nRaw target distribution:")

        target_counts = (
            df["target"]
            .value_counts(dropna=False)
            .sort_index()
        )

        for target, count in target_counts.items():

            pct = (
                100 * count / len(df)
            )

            print(
                f"target={target!s:<6} : "
                f"{count:>5,} "
                f"({pct:>7.3f}%)"
            )


        # --------------------------------------------------------
        # Unique values
        # --------------------------------------------------------

        print("\nUnique values:")

        for col in COLUMNS:

            values = df[col].dropna().unique()

            values_sorted = sorted(
                values.tolist()
            )

            if len(values_sorted) <= 20:

                print(
                    f"{col:<12} : "
                    f"{values_sorted}"
                )

            else:

                print(
                    f"{col:<12} : "
                    f"{len(values_sorted)} unique values"
                )


        # --------------------------------------------------------
        # Descriptive statistics
        # --------------------------------------------------------

        print("\nDescriptive statistics:")

        print(
            df.describe(
                include="all"
            ).transpose().to_string()
        )


        # --------------------------------------------------------
        # Duplicate rows
        # --------------------------------------------------------

        duplicate_rows = int(
            df.duplicated().sum()
        )

        print(
            f"\nDuplicate rows: "
            f"{duplicate_rows:,}"
        )


        # --------------------------------------------------------
        # Missing target
        # --------------------------------------------------------

        missing_target = int(
            df["target"].isna().sum()
        )

        print(
            f"Missing target: "
            f"{missing_target:,}"
        )


# ================================================================
# 9. COHORT SUMMARY
# ================================================================

print("\n" + "=" * 80)
print("COHORT SUMMARY")
print("=" * 80)

cohort_summary_rows = []

for cohort, df in cohort_data.items():

    cohort_summary_rows.append({

        "cohort": cohort,

        "rows": len(df),

        "columns": len(df.columns),

        "missing_cells":
            int(df.isna().sum().sum()),

        "missing_target":
            int(df["target"].isna().sum()),

        "duplicate_rows":
            int(df.duplicated().sum()),

        "target_unique_values":
            df["target"]
            .dropna()
            .nunique(),

        "target_min":
            df["target"]
            .min(),

        "target_max":
            df["target"]
            .max()
    })


cohort_summary_df = pd.DataFrame(
    cohort_summary_rows
)

print(
    cohort_summary_df.to_string(
        index=False
    )
)

cohort_summary_df.to_csv(
    COHORT_SUMMARY_OUTPUT,
    index=False
)


# ================================================================
# 10. COMPREHENSIVE MISSINGNESS TABLE
# ================================================================

print("\n" + "=" * 80)
print("COMPREHENSIVE UCI MISSINGNESS")
print("=" * 80)

missingness_rows = []

for cohort, df in cohort_data.items():

    for col in COLUMNS:

        count = int(
            df[col].isna().sum()
        )

        pct = (
            100 * count / len(df)
        )

        missingness_rows.append({

            "cohort": cohort,

            "feature": col,

            "missing_count": count,

            "missing_percentage": pct
        })


missingness_df = pd.DataFrame(
    missingness_rows
)

print(
    missingness_df.to_string(
        index=False
    )
)

missingness_df.to_csv(
    MISSINGNESS_OUTPUT,
    index=False
)


# ================================================================
# 11. TARGET DISTRIBUTION TABLE
# ================================================================

print("\n" + "=" * 80)
print("TARGET DISTRIBUTION BY COHORT")
print("=" * 80)

target_rows = []

for cohort, df in cohort_data.items():

    counts = (
        df["target"]
        .value_counts(dropna=False)
        .sort_index()
    )

    for target, count in counts.items():

        target_rows.append({

            "cohort": cohort,

            "target": target,

            "count": int(count),

            "percentage":
                100 * count / len(df)
        })


target_df = pd.DataFrame(
    target_rows
)

print(
    target_df.to_string(
        index=False
    )
)

target_df.to_csv(
    TARGET_OUTPUT,
    index=False
)


# ================================================================
# 12. UNIQUE-VALUE TABLE
# ================================================================

print("\n" + "=" * 80)
print("UNIQUE VALUES BY COHORT")
print("=" * 80)

unique_rows = []

for cohort, df in cohort_data.items():

    for col in COLUMNS:

        values = (
            df[col]
            .dropna()
            .unique()
        )

        values_sorted = sorted(
            values.tolist()
        )

        unique_rows.append({

            "cohort": cohort,

            "feature": col,

            "n_unique":
                len(values_sorted),

            "unique_values":
                str(values_sorted)
        })


unique_df = pd.DataFrame(
    unique_rows
)

unique_df.to_csv(
    UNIQUE_VALUES_OUTPUT,
    index=False
)


# ================================================================
# 13. COMBINED RAW UCI DATASET
# ================================================================
#
# This is ONLY for auditing.
#
# We add a source/cohort column.
# No harmonization is performed.
# No target conversion is performed.
#
# ================================================================

combined_frames = []

for cohort, df in cohort_data.items():

    temp = df.copy()

    temp.insert(
        0,
        "cohort",
        cohort
    )

    combined_frames.append(
        temp
    )


combined_uci = pd.concat(
    combined_frames,
    ignore_index=True
)


combined_uci.to_csv(
    COMBINED_OUTPUT,
    index=False
)


# ================================================================
# 14. GLOBAL UCI SUMMARY
# ================================================================

print("\n" + "=" * 80)
print("GLOBAL UCI SUMMARY")
print("=" * 80)

print(
    f"Total processed UCI records : "
    f"{len(combined_uci):,}"
)

print(
    f"Total columns including cohort : "
    f"{len(combined_uci.columns)}"
)

print(
    f"Total missing cells : "
    f"{int(combined_uci.isna().sum().sum()):,}"
)


# ================================================================
# 15. TARGET VALUES ACROSS ALL COHORTS
# ================================================================

print("\n" + "=" * 80)
print("RAW TARGET VALUES ACROSS UCI")
print("=" * 80)

global_target = (
    combined_uci["target"]
    .value_counts(dropna=False)
    .sort_index()
)

for target, count in global_target.items():

    pct = (
        100 * count / len(combined_uci)
    )

    print(
        f"target={target!s:<6} : "
        f"{count:>6,} "
        f"({pct:>7.3f}%)"
    )


# ================================================================
# 16. CHECK TARGET MAPPING ISSUE
# ================================================================
#
# IMPORTANT:
#   We deliberately do NOT convert 1/2/3/4 into binary here.
#
#   This section only reports what exists.
#
# ================================================================

print("\n" + "=" * 80)
print("TARGET MAPPING CHECK")
print("=" * 80)

for cohort, df in cohort_data.items():

    values = sorted(
        df["target"]
        .dropna()
        .unique()
        .tolist()
    )

    print(
        f"{cohort:<20} : "
        f"raw target values = {values}"
    )


# ================================================================
# 17. CHECK WHETHER TARGET IS MISSING
# ================================================================

print("\n" + "=" * 80)
print("TARGET MISSINGNESS CHECK")
print("=" * 80)

target_missing_total = int(
    combined_uci["target"].isna().sum()
)

print(
    f"Total missing target values: "
    f"{target_missing_total:,}"
)

if target_missing_total == 0:

    print(
        "PASS: No processed UCI record has "
        "a missing target."
    )

else:

    print(
        "WARNING: Missing target values exist."
    )


# ================================================================
# 18. FINAL AUDIT STATUS
# ================================================================

print("\n" + "=" * 80)
print("AUDIT 11 COMPLETE")
print("=" * 80)

print("\nFiles saved:")

print(
    "\nCohort summary:"
)

print(
    COHORT_SUMMARY_OUTPUT
)

print(
    "\nMissingness:"
)

print(
    MISSINGNESS_OUTPUT
)

print(
    "\nTarget distribution:"
)

print(
    TARGET_OUTPUT
)

print(
    "\nUnique values:"
)

print(
    UNIQUE_VALUES_OUTPUT
)

print(
    "\nCombined raw UCI audit dataset:"
)

print(
    COMBINED_OUTPUT
)

print("\nIMPORTANT:")
print("No records were deleted.")
print("No values were corrected.")
print("No target mapping was applied.")
print("No harmonization was performed.")
print("No imputation was performed.")
print("No train/test split was performed.")