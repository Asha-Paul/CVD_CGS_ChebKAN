# -*- coding: utf-8 -*-
"""
Implementation 49: Nested-CV hyperparameter tuning for the existing A8 CGS-ChebKAN.

IMPORTANT
---------
- Development-only. Reads kaggle_development_cv.csv only.
- Does not read calibration or locked-test files.
- Outer 5-fold CV estimates performance of the tuning procedure.
- Inner 3-fold CV selects among a prespecified 12-configuration grid.
- Each inner-training partition is split again for early stopping.
- Imputation/scaling are fitted only on the fitting subset.
- Results are written to new implementation49_* files; earlier results are not overwritten.

Run from Windows after confirming dependencies and the DEV_FILE path.
"""

from __future__ import annotations
import json
import random
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DEV_FILE = PROJECT_ROOT / "data" / "processed" / "kaggle_development_cv.csv"
OUT_DIR = PROJECT_ROOT / "results" / "tables"
OUT_DIR.mkdir(parents=True, exist_ok=True)

SEED = 2026
TARGET = "cardio"
ID_COL = "id"
FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]
GROUPS = {
    "demographic": ["age", "gender"],
    "physiological_anthropometric_metabolic": [
        "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc"
    ],
    "lifestyle": ["smoke", "alco", "active"],
}
GROUP_ORDER = list(GROUPS.keys())
CHEB_DEGREE = 5
BATCH_SIZE = 1024
MAX_EPOCHS = 100
GATE_L1 = 1e-4
OUTER_FOLDS = 5
INNER_FOLDS = 3
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Prespecified compact grid: 12 configurations, covering all requested dimensions.
# Values are fixed before running the experiment.
CONFIGS = [
    {"config_id":"C01","lr":5e-4,"weight_decay":1e-4,"kan_l1":1e-6,"embedding_dim":8,"patience":10},
    {"config_id":"C02","lr":5e-4,"weight_decay":5e-4,"kan_l1":1e-5,"embedding_dim":16,"patience":15},
    {"config_id":"C03","lr":1e-3,"weight_decay":1e-4,"kan_l1":1e-5,"embedding_dim":24,"patience":10},
    {"config_id":"C04","lr":1e-3,"weight_decay":5e-4,"kan_l1":1e-6,"embedding_dim":8,"patience":15},
    {"config_id":"C05","lr":5e-4,"weight_decay":1e-4,"kan_l1":1e-5,"embedding_dim":16,"patience":10},
    {"config_id":"C06","lr":5e-4,"weight_decay":5e-4,"kan_l1":1e-6,"embedding_dim":24,"patience":15},
    {"config_id":"C07","lr":1e-3,"weight_decay":1e-4,"kan_l1":1e-6,"embedding_dim":16,"patience":15},
    {"config_id":"C08","lr":1e-3,"weight_decay":5e-4,"kan_l1":1e-5,"embedding_dim":24,"patience":10},
    {"config_id":"C09","lr":5e-4,"weight_decay":5e-4,"kan_l1":1e-5,"embedding_dim":8,"patience":10},
    {"config_id":"C10","lr":1e-3,"weight_decay":1e-4,"kan_l1":1e-5,"embedding_dim":8,"patience":15},
    {"config_id":"C11","lr":5e-4,"weight_decay":1e-4,"kan_l1":1e-6,"embedding_dim":24,"patience":10},
    {"config_id":"C12","lr":1e-3,"weight_decay":5e-4,"kan_l1":1e-6,"embedding_dim":16,"patience":15},
]

def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class ChebyshevKAN(nn.Module):
    def __init__(self, input_dim, output_dim, degree):
        super().__init__()
        self.degree = degree
        self.coefficients = nn.Parameter(torch.empty(output_dim, input_dim, degree + 1))
        self.bias = nn.Parameter(torch.zeros(output_dim))
        nn.init.normal_(self.coefficients, mean=0.0, std=0.02)

    def forward(self, x):
        x = torch.clamp(x, -1.0, 1.0)
        terms = [torch.ones_like(x)]
        if self.degree >= 1:
            terms.append(x)
        for _ in range(2, self.degree + 1):
            terms.append(2.0 * x * terms[-1] - terms[-2])
        basis = torch.stack(terms, dim=-1)
        return torch.einsum("bid,oid->bo", basis, self.coefficients) + self.bias

class A8Model(nn.Module):
    def __init__(self, group_sizes, embedding_dim, degree):
        super().__init__()
        self.demographic_kan = ChebyshevKAN(group_sizes["demographic"], embedding_dim, degree)
        self.physiological_kan = ChebyshevKAN(
            group_sizes["physiological_anthropometric_metabolic"], embedding_dim, degree
        )
        self.lifestyle_kan = ChebyshevKAN(group_sizes["lifestyle"], embedding_dim, degree)
        self.interaction_projection = nn.Linear(embedding_dim * 3, embedding_dim)
        self.output_layer = nn.Linear(embedding_dim * 2, 1)
        self.gate_logits = nn.Parameter(torch.zeros(3))
        self.activation = nn.SiLU()

    def forward(self, inputs):
        hd = self.activation(self.demographic_kan(inputs["demographic"]))
        hp = self.activation(self.physiological_kan(inputs["physiological_anthropometric_metabolic"]))
        hl = self.activation(self.lifestyle_kan(inputs["lifestyle"]))
        gates = torch.softmax(self.gate_logits, dim=0)
        h_gate = gates[0] * hd + gates[1] * hp + gates[2] * hl
        interactions = torch.cat([hd * hp, hd * hl, hp * hl], dim=1)
        h_interaction = self.activation(self.interaction_projection(interactions))
        return self.output_layer(torch.cat([h_gate, h_interaction], dim=1)).squeeze(1)

    def coefficient_l1(self):
        return (self.demographic_kan.coefficients.abs().sum()
                + self.physiological_kan.coefficients.abs().sum()
                + self.lifestyle_kan.coefficients.abs().sum())

def group_indices(features):
    return {name: [features.index(f) for f in GROUPS[name]] for name in GROUP_ORDER}

def tensor_groups(X, idx, device=DEVICE):
    return {name: torch.as_tensor(X[:, idx[name]], dtype=torch.float32, device=device)
            for name in GROUP_ORDER}

def fit_preprocessor(X_fit):
    imputer = SimpleImputer(strategy="median")
    Xi = imputer.fit_transform(X_fit)
    scaler = MinMaxScaler(feature_range=(-1.0, 1.0))
    return imputer, scaler, scaler.fit_transform(Xi).astype(np.float32)

def apply_preprocessor(X, imputer, scaler):
    return scaler.transform(imputer.transform(X)).astype(np.float32)

def make_loader(X, y, idx, seed):
    tensors = [torch.tensor(X[:, idx[name]], dtype=torch.float32) for name in GROUP_ORDER]
    tensors.append(torch.tensor(y.astype(np.float32), dtype=torch.float32))
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(TensorDataset(*tensors), batch_size=BATCH_SIZE, shuffle=True,
                      generator=generator, drop_last=False,
                      pin_memory=torch.cuda.is_available())

def train_one(X_fit_raw, y_fit, X_stop_raw, y_stop, config, seed):
    seed_everything(seed)
    imputer, scaler, X_fit = fit_preprocessor(X_fit_raw)
    X_stop = apply_preprocessor(X_stop_raw, imputer, scaler)
    idx = group_indices(FEATURES)
    sizes = {k: len(v) for k, v in GROUPS.items()}
    model = A8Model(sizes, config["embedding_dim"], CHEB_DEGREE).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=config["lr"], weight_decay=config["weight_decay"])
    loss_fn = nn.BCEWithLogitsLoss()
    loader = make_loader(X_fit, y_fit, idx, seed)
    stop_groups = tensor_groups(X_stop, idx)
    stop_y_t = torch.tensor(y_stop.astype(np.float32), device=DEVICE)
    best_state, best_loss, best_epoch, stale = None, float("inf"), 0, 0

    for epoch in range(1, MAX_EPOCHS + 1):
        model.train()
        for batch in loader:
            inputs = {name: batch[i].to(DEVICE, non_blocking=True)
                      for i, name in enumerate(GROUP_ORDER)}
            batch_y = batch[len(GROUP_ORDER)].to(DEVICE, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            logits = model(inputs)
            loss = loss_fn(logits, batch_y) + config["kan_l1"] * model.coefficient_l1() \
                   + GATE_L1 * model.gate_logits.abs().sum()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt.step()
        model.eval()
        with torch.no_grad():
            val_loss = loss_fn(model(stop_groups), stop_y_t).item()
        if val_loss < best_loss - 1e-6:
            best_loss, best_epoch, stale = val_loss, epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
        if stale >= config["patience"]:
            break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, imputer, scaler, best_epoch, best_loss

def predict(model, X_raw, imputer, scaler):
    X = apply_preprocessor(X_raw, imputer, scaler)
    idx = group_indices(FEATURES)
    model.eval()
    with torch.no_grad():
        logits = model(tensor_groups(X, idx))
        return torch.sigmoid(logits).cpu().numpy()

def evaluate_config(X, y, outer_train_idx, config, outer_fold):
    inner_cv = StratifiedKFold(n_splits=INNER_FOLDS, shuffle=True,
                               random_state=SEED + 100 * outer_fold)
    fold_aucs, fold_praucs, fold_briers, epochs = [], [], [], []
    for inner_fold, (fitstop_idx, val_rel_idx) in enumerate(
            inner_cv.split(np.zeros(len(outer_train_idx)), y[outer_train_idx]), start=1):
        inner_train_idx = outer_train_idx[fitstop_idx]
        inner_val_idx = outer_train_idx[val_rel_idx]
        # Early stopping split is created only within the inner-training partition.
        fit_idx, stop_idx = train_test_split(
            inner_train_idx, test_size=0.10, random_state=SEED + outer_fold * 1000 + inner_fold,
            stratify=y[inner_train_idx]
        )
        model, imputer, scaler, best_epoch, _ = train_one(
            X[fit_idx], y[fit_idx], X[stop_idx], y[stop_idx],
            config, SEED + outer_fold * 10000 + inner_fold
        )
        prob = predict(model, X[inner_val_idx], imputer, scaler)
        fold_aucs.append(roc_auc_score(y[inner_val_idx], prob))
        fold_praucs.append(average_precision_score(y[inner_val_idx], prob))
        fold_briers.append(brier_score_loss(y[inner_val_idx], prob))
        epochs.append(best_epoch)
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    return {
        "config_id": config["config_id"],
        "mean_inner_roc_auc": float(np.mean(fold_aucs)),
        "sd_inner_roc_auc": float(np.std(fold_aucs, ddof=1)),
        "mean_inner_pr_auc": float(np.mean(fold_praucs)),
        "mean_inner_brier": float(np.mean(fold_briers)),
        "inner_best_epochs": epochs,
    }

def main():
    started = time.time()
    if not DEV_FILE.exists():
        raise FileNotFoundError(f"Development CSV not found: {DEV_FILE}")
    df = pd.read_csv(DEV_FILE)
    required = [ID_COL] + FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if len(df) != 49000 or df[ID_COL].duplicated().any():
        raise ValueError(f"Expected 49,000 development rows and unique IDs; got {len(df)} rows.")
    X = df[FEATURES].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float32)
    y = df[TARGET].to_numpy(dtype=np.int64)

    print("=" * 80)
    print("IMPLEMENTATION 49 — NESTED-CV A8 HYPERPARAMETER TUNING")
    print(f"Device: {DEVICE}; development rows: {len(df):,}")
    print(f"Configurations: {len(CONFIGS)}; outer folds: {OUTER_FOLDS}; inner folds: {INNER_FOLDS}")
    print("Locked test and calibration files are not loaded.")
    print("Estimated training fits: 5 outer folds x 12 configs x 3 inner folds + 5 final outer fits.")
    print("=" * 80)

    outer_cv = StratifiedKFold(n_splits=OUTER_FOLDS, shuffle=True, random_state=SEED)
    outer_rows, inner_rows, pred_rows = [], [], []

    for outer_fold, (outer_train_idx, outer_val_idx) in enumerate(
            outer_cv.split(np.zeros(len(y)), y), start=1):
        print(f"\nOUTER FOLD {outer_fold}/{OUTER_FOLDS}: tuning on outer-training data only")
        fold_config_rows = []
        for config in CONFIGS:
            result = evaluate_config(X, y, outer_train_idx, config, outer_fold)
            row = {**config, "outer_fold": outer_fold, **result}
            inner_rows.append(row)
            fold_config_rows.append(row)
            print(f"  {config['config_id']}: inner AUC={result['mean_inner_roc_auc']:.6f}, "
                  f"PR-AUC={result['mean_inner_pr_auc']:.6f}, "
                  f"Brier={result['mean_inner_brier']:.6f}")
        tuning = pd.DataFrame(fold_config_rows)
        # Prespecified selection rule: highest mean inner ROC-AUC; tie-break on lower Brier.
        tuning = tuning.sort_values(
            ["mean_inner_roc_auc", "mean_inner_brier"], ascending=[False, True]
        )
        chosen_id = tuning.iloc[0]["config_id"]
        chosen = next(c for c in CONFIGS if c["config_id"] == chosen_id)
        print("  Selected configuration:", chosen_id, chosen)

        # Train selected configuration on outer-training data, using an internal
        # stratified stop subset. The outer validation fold is untouched until scoring.
        fit_idx, stop_idx = train_test_split(
            outer_train_idx, test_size=0.10,
            random_state=SEED + 90000 + outer_fold, stratify=y[outer_train_idx]
        )
        model, imputer, scaler, best_epoch, best_loss = train_one(
            X[fit_idx], y[fit_idx], X[stop_idx], y[stop_idx],
            chosen, SEED + 80000 + outer_fold
        )
        probs = predict(model, X[outer_val_idx], imputer, scaler)
        outer_auc = roc_auc_score(y[outer_val_idx], probs)
        outer_pr = average_precision_score(y[outer_val_idx], probs)
        outer_brier = brier_score_loss(y[outer_val_idx], probs)
        outer_rows.append({
            "outer_fold": outer_fold, "selected_config_id": chosen_id,
            **chosen, "outer_roc_auc": outer_auc, "outer_pr_auc": outer_pr,
            "outer_brier": outer_brier, "best_epoch": best_epoch,
            "best_stop_loss": best_loss, "outer_train_rows": len(outer_train_idx),
            "outer_validation_rows": len(outer_val_idx)
        })
        pred_rows.append(pd.DataFrame({
            "row_index": outer_val_idx,
            "id": df.iloc[outer_val_idx][ID_COL].to_numpy(),
            "outer_fold": outer_fold, "y_true": y[outer_val_idx],
            "probability": probs, "selected_config_id": chosen_id
        }))
        print(f"  OUTER result: AUC={outer_auc:.6f}, PR-AUC={outer_pr:.6f}, Brier={outer_brier:.6f}")
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    outer_df = pd.DataFrame(outer_rows)
    inner_df = pd.DataFrame(inner_rows)
    preds_df = pd.concat(pred_rows, ignore_index=True).sort_values("row_index")
    pooled_auc = roc_auc_score(preds_df["y_true"], preds_df["probability"])
    pooled_pr = average_precision_score(preds_df["y_true"], preds_df["probability"])
    pooled_brier = brier_score_loss(preds_df["y_true"], preds_df["probability"])

    outer_path = OUT_DIR / "implementation49_nested_cv_outer_results.csv"
    inner_path = OUT_DIR / "implementation49_nested_cv_inner_grid_results.csv"
    preds_path = OUT_DIR / "implementation49_nested_cv_oof_predictions.csv"
    summary_path = OUT_DIR / "implementation49_nested_cv_summary.json"
    outer_df.to_csv(outer_path, index=False)
    inner_df.to_csv(inner_path, index=False)
    preds_df.to_csv(preds_path, index=False)
    summary = {
        "implementation": 49,
        "purpose": "Nested-CV hyperparameter tuning of existing A8 architecture",
        "development_rows": int(len(df)),
        "outer_folds": OUTER_FOLDS,
        "inner_folds": INNER_FOLDS,
        "seed": SEED,
        "grid": CONFIGS,
        "selection_rule": "highest mean inner ROC-AUC; tie-break on lower mean inner Brier",
        "pooled_outer_oof": {
            "roc_auc": float(pooled_auc), "pr_auc": float(pooled_pr), "brier": float(pooled_brier)
        },
        "mean_outer_fold_roc_auc": float(outer_df["outer_roc_auc"].mean()),
        "sd_outer_fold_roc_auc": float(outer_df["outer_roc_auc"].std(ddof=1)),
        "selected_configs_by_outer_fold": outer_df[["outer_fold", "selected_config_id"]].to_dict("records"),
        "locked_test_used": False,
        "calibration_data_used": False,
        "elapsed_minutes": round((time.time() - started) / 60, 2),
        "caution": "This estimates the tuning procedure on development data. Do not use these results as locked-test results or select using the locked test."
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("\n" + "=" * 80)
    print("IMPLEMENTATION 49 COMPLETE")
    print(f"Pooled outer OOF ROC-AUC: {pooled_auc:.6f}")
    print(f"Pooled outer OOF PR-AUC:  {pooled_pr:.6f}")
    print(f"Pooled outer OOF Brier:   {pooled_brier:.6f}")
    print("Outer results:", outer_path)
    print("Inner grid results:", inner_path)
    print("OOF predictions:", preds_path)
    print("Summary:", summary_path)
    print(f"Elapsed minutes: {(time.time()-started)/60:.2f}")
    print("Do not inspect or load the locked test during tuning.")

if __name__ == "__main__":
    main()
