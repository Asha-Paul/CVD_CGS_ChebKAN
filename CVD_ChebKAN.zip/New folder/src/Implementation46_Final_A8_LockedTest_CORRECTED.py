# -*- coding: utf-8 -*-
"""
IMPLEMENTATION 46
FINAL A8 CGS-ChebKAN FIT + LOCKED KAGGLE TEST EVALUATION

Purpose
-------
This script performs the FINAL internal evaluation of the selected A8 architecture
after architecture selection was completed exclusively on the 49,000-record
Development cohort.

A8 was selected because it significantly improved over A6 on the exact paired
49,000-patient Development cohort.

FROZEN A8 SPECIFICATION
-----------------------
Features:
    age, gender, height, weight, ap_hi, ap_lo, cholesterol, gluc,
    smoke, alco, active

Clinical groups:
    demographic:
        age, gender
    physiological_metabolic:
        height, weight, ap_hi, ap_lo, cholesterol, gluc
    lifestyle:
        smoke, alco, active

Model:
    3 group-specific Chebyshev-KAN branches
    Chebyshev first-kind basis, degree K=5
    group embedding dimension = 16
    SiLU activation
    softmax group gates
    L1 penalty on KAN coefficients
    L1 penalty on gate logits
    pairwise cross-group Hadamard interactions
    interaction projection: 48 -> 16
    final representation: 16 gated + 16 interaction = 32
    binary output

Frozen hyperparameters:
    learning rate = 1e-3
    L2 = 1e-4
    KAN L1 = 1e-5
    gate L1 = 1e-4
    batch size = 1024
    final epochs = 54

Why 54 epochs?
    The five A8 development-CV best epochs were:
        61, 78, 54, 43, 53
    The median is 54.
    This epoch count is frozen before the locked test is evaluated.

FINAL FIT:
    Fit preprocessing on Development only.
    Fit A8 on all 49,000 Development records for 54 epochs.
    Calibration set is NOT used.
    Locked test is used only after training is complete.
    No test-based tuning or threshold selection.

LOCKED TEST:
    14,000 records.
    Primary threshold = 0.50.
    ROC-AUC and PR-AUC are threshold-independent.
    Threshold-dependent metrics are reported at 0.50 only.
    No threshold is optimized on the locked test.

Outputs:
    results/tables/implementation46_final_a8_locked_test_results.csv
    results/tables/implementation46_final_a8_locked_test_summary.json
    results/tables/implementation46_final_a8_locked_test_predictions.csv
    results/tables/implementation46_final_a8_training_history.csv
    results/tables/implementation46_final_a8_protocol.json
    results/tables/implementation46_final_a8_model.pt
"""

from __future__ import annotations

import json
import math
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


# =============================================================================
# 0. CONFIGURATION
# =============================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DEV_FILE = PROJECT_ROOT / r"data\processed\kaggle_development_cv.csv"
TEST_FILE = PROJECT_ROOT / r"data\processed\kaggle_locked_test.csv"

OUT_TABLES = PROJECT_ROOT / r"results\tables"
OUT_CHECKPOINTS = PROJECT_ROOT / r"results\checkpoints"

PRED_FILE = OUT_TABLES / "implementation46_final_a8_locked_test_predictions.csv"
RESULT_FILE = OUT_TABLES / "implementation46_final_a8_locked_test_results.csv"
SUMMARY_FILE = OUT_TABLES / "implementation46_final_a8_locked_test_summary.json"
HISTORY_FILE = OUT_TABLES / "implementation46_final_a8_training_history.csv"
PROTOCOL_FILE = OUT_TABLES / "implementation46_final_a8_protocol.json"
CHECKPOINT_FILE = OUT_CHECKPOINTS / "implementation46_final_a8_final_model.pt"

SEED = 20261006

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]
TARGET = "cardio"
ID_COL = "id"

GROUPS = {
    "demographic": ["age", "gender"],
    "physiological_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],
    "lifestyle": ["smoke", "alco", "active"],
}

CHEB_DEGREE = 5
EMBED_DIM = 16

LEARNING_RATE = 1e-3
L2 = 1e-4
KAN_L1 = 1e-5
GATE_L1 = 1e-4

BATCH_SIZE = 1024
FINAL_EPOCHS = 54

TEST_THRESHOLD = 0.50

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# =============================================================================
# 1. REPRODUCIBILITY
# =============================================================================

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    # Deterministic behavior where possible.
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# =============================================================================
# 2. CHEBYSHEV-KAN
# =============================================================================

class ChebyshevKAN(nn.Module):
    """
    Univariate Chebyshev expansion for each input feature.

    Input:
        x: [batch, n_features]

    Coefficients:
        [embedding_dim, n_features, K+1]

    Output:
        [batch, embedding_dim]
    """

    def __init__(
        self,
        n_features: int,
        embedding_dim: int,
        degree: int,
    ):
        super().__init__()

        self.n_features = n_features
        self.embedding_dim = embedding_dim
        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                embedding_dim,
                n_features,
                degree + 1,
            )
        )

        self.bias = nn.Parameter(torch.zeros(embedding_dim))

        nn.init.xavier_uniform_(self.coefficients)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x is expected to be scaled to [-1, 1].
        x = torch.clamp(x, -1.0, 1.0)

        # T0(x) = 1
        basis = [torch.ones_like(x)]

        if self.degree >= 1:
            # T1(x) = x
            basis.append(x)

        for k in range(2, self.degree + 1):
            basis.append(
                2.0 * x * basis[-1] - basis[-2]
            )

        # [batch, features, K+1]
        basis_tensor = torch.stack(basis, dim=-1)

        # coefficients:
        # [embedding, features, K+1]
        # result:
        # [batch, embedding]
        out = torch.einsum(
            "bfk,efk->be",
            basis_tensor,
            self.coefficients,
        )

        return out + self.bias

    def l1_penalty(self) -> torch.Tensor:
        return torch.sum(torch.abs(self.coefficients))


# =============================================================================
# 3. A8 MODEL
# =============================================================================

class A8_CGS_ChebKAN(nn.Module):
    """
    A8:
        Group-specific ChebKAN branches
        -> SiLU
        -> sparse softmax group-gated fusion
        -> pairwise cross-group Hadamard interactions
        -> 48 -> 16 interaction projection
        -> concatenate gated + interaction representations
        -> binary output

    Parameter count should be 1,924 for the frozen specification.
    """

    def __init__(
        self,
        group_sizes: dict[str, int],
        degree: int = CHEB_DEGREE,
        embed_dim: int = EMBED_DIM,
    ):
        super().__init__()

        self.group_names = list(group_sizes.keys())
        self.degree = degree
        self.embed_dim = embed_dim

        self.branches = nn.ModuleDict()

        for name, n_features in group_sizes.items():
            self.branches[name] = ChebBranch(
                n_features=n_features,
                embedding_dim=embed_dim,
                degree=degree,
            )

        # Three sparse fusion gates.
        self.gate_logits = nn.Parameter(
            torch.zeros(len(self.group_names))
        )

        # Three pairwise interactions:
        # demo*phys, demo*life, phys*life
        self.interaction_projection = nn.Linear(
            3 * embed_dim,
            embed_dim,
        )

        # 16 gated + 16 interaction = 32.
        self.output_layer = nn.Linear(
            2 * embed_dim,
            1,
        )

    def forward(
        self,
        group_inputs: dict[str, torch.Tensor],
    ) -> torch.Tensor:

        embeddings = []

        for name in self.group_names:
            h = self.branches[name](group_inputs[name])
            embeddings.append(h)

        # Softmax sparse group fusion.
        alpha = torch.softmax(self.gate_logits, dim=0)

        h_gate = torch.zeros_like(embeddings[0])

        for i, h in enumerate(embeddings):
            h_gate = h_gate + alpha[i] * h

        # Pairwise cross-group Hadamard interactions.
        h_demo = embeddings[0]
        h_phys = embeddings[1]
        h_life = embeddings[2]

        h_dp = h_demo * h_phys
        h_dl = h_demo * h_life
        h_pl = h_phys * h_life

        h_interactions = torch.cat(
            [h_dp, h_dl, h_pl],
            dim=1,
        )

        h_interaction = F.silu(
            self.interaction_projection(h_interactions)
        )

        final_representation = torch.cat(
            [h_gate, h_interaction],
            dim=1,
        )

        logits = self.output_layer(final_representation)

        return logits.squeeze(1)

    def kan_l1_penalty(self) -> torch.Tensor:
        penalty = torch.tensor(
            0.0,
            device=self.gate_logits.device,
        )

        for branch in self.branches.values():
            penalty = penalty + branch.kan.l1_penalty()

        return penalty

    def gate_l1_penalty(self) -> torch.Tensor:
        return torch.sum(torch.abs(self.gate_logits))

    def gate_probabilities(self) -> np.ndarray:
        with torch.no_grad():
            return (
                torch.softmax(
                    self.gate_logits.detach().cpu(),
                    dim=0,
                )
                .numpy()
            )


class ChebBranch(nn.Module):
    def __init__(
        self,
        n_features: int,
        embedding_dim: int,
        degree: int,
    ):
        super().__init__()

        self.kan = ChebyshevKAN(
            n_features=n_features,
            embedding_dim=embedding_dim,
            degree=degree,
        )

        self.activation = nn.SiLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(self.kan(x))


# =============================================================================
# 4. DATA PREPARATION
# =============================================================================

def validate_dataframe(
    df: pd.DataFrame,
    name: str,
) -> None:

    required = FEATURES + [TARGET, ID_COL]

    missing = [
        c for c in required
        if c not in df.columns
    ]

    if missing:
        raise ValueError(
            f"{name} is missing required columns: {missing}"
        )

    if df[ID_COL].duplicated().any():
        raise ValueError(
            f"{name} contains duplicate IDs."
        )

    # Missing BP values are expected after the frozen BP quality-control
    # procedure. Invalid/reversed BP values were set to NaN rather than
    # deleting records. Median imputation is performed later, using only
    # the Development cohort to fit the preprocessing parameters.
    missing_counts = (
        df[FEATURES]
        .isna()
        .sum()
        .to_dict()
    )

    unexpected_missing = {
        feature: int(count)
        for feature, count in missing_counts.items()
        if count > 0 and feature not in {"ap_hi", "ap_lo"}
    }

    if unexpected_missing:
        raise ValueError(
            f"{name} contains unexpected missing values outside "
            f"ap_hi/ap_lo: {unexpected_missing}"
        )

    if df[TARGET].isna().any():
        raise ValueError(
            f"{name} contains missing target values."
        )


def fit_preprocessor(
    df: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray]:

    X = df[FEATURES].to_numpy(
        dtype=np.float64
    )

    # Median imputation is retained as the frozen preprocessing rule.
    medians = np.nanmedian(X, axis=0)

    X_imp = X.copy()

    for j in range(X_imp.shape[1]):
        mask = ~np.isfinite(X_imp[:, j])
        X_imp[mask, j] = medians[j]

    # Min-max scaling to [-1, 1].
    x_min = np.min(X_imp, axis=0)
    x_max = np.max(X_imp, axis=0)

    return medians, np.column_stack([x_min, x_max])


def transform_features(
    df: pd.DataFrame,
    medians: np.ndarray,
    minmax: np.ndarray,
) -> np.ndarray:

    X = df[FEATURES].to_numpy(
        dtype=np.float64
    )

    X_imp = X.copy()

    for j in range(X_imp.shape[1]):
        mask = ~np.isfinite(X_imp[:, j])
        X_imp[mask, j] = medians[j]

    x_min = minmax[:, 0]
    x_max = minmax[:, 1]

    denominator = x_max - x_min
    denominator[denominator == 0] = 1.0

    X_scaled = (
        2.0 * (X_imp - x_min)
        / denominator
        - 1.0
    )

    return np.clip(
        X_scaled,
        -1.0,
        1.0,
    ).astype(np.float32)


def make_group_arrays(
    X_scaled: np.ndarray,
) -> dict[str, np.ndarray]:

    feature_to_index = {
        feature: i
        for i, feature in enumerate(FEATURES)
    }

    result = {}

    for group_name, group_features in GROUPS.items():
        indices = [
            feature_to_index[f]
            for f in group_features
        ]

        result[group_name] = X_scaled[:, indices]

    return result


# =============================================================================
# 5. TORCH DATASET
# =============================================================================

class GroupDataset(torch.utils.data.Dataset):
    def __init__(
        self,
        group_arrays: dict[str, np.ndarray],
        y: np.ndarray,
    ):
        self.group_arrays = {
            k: torch.tensor(
                v,
                dtype=torch.float32,
            )
            for k, v in group_arrays.items()
        }

        self.y = torch.tensor(
            y.astype(np.float32),
            dtype=torch.float32,
        )

        n = len(y)

        for v in self.group_arrays.values():
            if len(v) != n:
                raise ValueError(
                    "Group arrays have inconsistent lengths."
                )

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        group_item = {
            k: v[idx]
            for k, v in self.group_arrays.items()
        }

        return group_item, self.y[idx]


# =============================================================================
# 6. TRAINING
# =============================================================================

def train_final_model(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    epochs: int,
) -> pd.DataFrame:

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=L2,
    )

    criterion = nn.BCEWithLogitsLoss()

    history = []

    model.train()

    for epoch in range(1, epochs + 1):

        epoch_loss = 0.0
        n_seen = 0

        for group_batch, y_batch in loader:

            group_batch = {
                k: v.to(DEVICE)
                for k, v in group_batch.items()
            }

            y_batch = y_batch.to(DEVICE)

            optimizer.zero_grad(set_to_none=True)

            logits = model(group_batch)

            bce = criterion(
                logits,
                y_batch,
            )

            kan_penalty = (
                KAN_L1
                * model.kan_l1_penalty()
            )

            gate_penalty = (
                GATE_L1
                * model.gate_l1_penalty()
            )

            loss = (
                bce
                + kan_penalty
                + gate_penalty
            )

            loss.backward()

            optimizer.step()

            batch_n = len(y_batch)

            epoch_loss += (
                loss.detach().item() * batch_n
            )

            n_seen += batch_n

        mean_loss = epoch_loss / n_seen

        history.append(
            {
                "epoch": epoch,
                "loss": mean_loss,
            }
        )

        if (
            epoch == 1
            or epoch % 5 == 0
            or epoch == epochs
        ):
            print(
                f"Epoch {epoch:3d}/{epochs} | "
                f"loss={mean_loss:.6f}"
            )

    return pd.DataFrame(history)


# =============================================================================
# 7. PREDICTION
# =============================================================================

@torch.no_grad()
def predict_probabilities(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
) -> np.ndarray:

    model.eval()

    probabilities = []

    for group_batch, _ in loader:

        group_batch = {
            k: v.to(DEVICE)
            for k, v in group_batch.items()
        }

        logits = model(group_batch)

        probs = torch.sigmoid(logits)

        probabilities.append(
            probs.cpu().numpy()
        )

    return np.concatenate(probabilities)


# =============================================================================
# 8. METRICS
# =============================================================================

def calculate_metrics(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    threshold: float,
) -> dict:

    predictions = (
        probabilities >= threshold
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1],
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else np.nan
    )

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else np.nan
    )

    return {
        "n": int(len(y_true)),
        "prevalence": float(np.mean(y_true)),
        "threshold": float(threshold),
        "roc_auc": float(
            roc_auc_score(
                y_true,
                probabilities,
            )
        ),
        "pr_auc": float(
            average_precision_score(
                y_true,
                probabilities,
            )
        ),
        "accuracy": float(
            accuracy_score(
                y_true,
                predictions,
            )
        ),
        "precision": float(
            precision_score(
                y_true,
                predictions,
                zero_division=0,
            )
        ),
        "sensitivity": float(sensitivity),
        "specificity": float(specificity),
        "f1": float(
            f1_score(
                y_true,
                predictions,
                zero_division=0,
            )
        ),
        "brier": float(
            brier_score_loss(
                y_true,
                probabilities,
            )
        ),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


# =============================================================================
# 9. PARAMETER AUDIT
# =============================================================================

def count_parameters(model: nn.Module) -> int:
    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


def print_model_structure(
    model: nn.Module,
) -> None:

    print("\nMODEL PARAMETER AUDIT")
    print("-" * 80)

    for name, parameter in model.named_parameters():
        print(
            f"{name:45s} "
            f"{tuple(parameter.shape)!s:20s} "
            f"{parameter.numel():6d}"
        )

    print("-" * 80)
    print(
        f"Total trainable parameters: "
        f"{count_parameters(model)}"
    )


# =============================================================================
# 10. MAIN
# =============================================================================

def main():

    start_time = time.time()

    set_seed(SEED)

    OUT_TABLES.mkdir(
        parents=True,
        exist_ok=True,
    )

    OUT_CHECKPOINTS.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("=" * 80)
    print("IMPLEMENTATION 46")
    print("FINAL A8 CGS-ChebKAN FIT + LOCKED TEST EVALUATION")
    print("=" * 80)

    print("\nFROZEN PROTOCOL")
    print("-" * 80)
    print(f"Device: {DEVICE}")
    print(f"Development file: {DEV_FILE}")
    print(f"Locked test file: {TEST_FILE}")
    print(f"Final epochs: {FINAL_EPOCHS}")
    print(f"Learning rate: {LEARNING_RATE}")
    print(f"L2: {L2}")
    print(f"KAN L1: {KAN_L1}")
    print(f"Gate L1: {GATE_L1}")
    print(f"Batch size: {BATCH_SIZE}")
    print(f"Test threshold: {TEST_THRESHOLD}")
    print("Calibration data used for training: NO")
    print("Test threshold optimized on locked test: NO")
    print("Hyperparameter tuning on locked test: NO")

    # -------------------------------------------------------------------------
    # Load Development
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("1. LOADING DEVELOPMENT COHORT")
    print("=" * 80)

    if not DEV_FILE.exists():
        raise FileNotFoundError(
            f"Development file not found:\n{DEV_FILE}"
        )

    dev_df = pd.read_csv(DEV_FILE)

    validate_dataframe(
        dev_df,
        "Development",
    )

    if len(dev_df) != 49000:
        raise ValueError(
            f"Expected 49,000 Development rows; "
            f"found {len(dev_df)}."
        )

    print(f"Development rows: {len(dev_df)}")
    print(
        f"Development unique IDs: "
        f"{dev_df[ID_COL].nunique()}"
    )

    dev_missing_counts = (
        dev_df[FEATURES]
        .isna()
        .sum()
    )

    print("Expected BP missingness before preprocessing:")
    print(f"  ap_hi missing: {int(dev_missing_counts['ap_hi'])}")
    print(f"  ap_lo missing: {int(dev_missing_counts['ap_lo'])}")
    print(
        "  Other feature missing values: "
        f"{int(dev_missing_counts.drop(['ap_hi', 'ap_lo']).sum())}"
    )

    # -------------------------------------------------------------------------
    # Load Locked Test only now, after model-fitting configuration is frozen.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("2. LOADING LOCKED TEST FOR FINAL EVALUATION")
    print("=" * 80)

    if not TEST_FILE.exists():
        raise FileNotFoundError(
            f"Locked test file not found:\n{TEST_FILE}"
        )

    test_df = pd.read_csv(TEST_FILE)

    validate_dataframe(
        test_df,
        "Locked test",
    )

    if len(test_df) != 14000:
        raise ValueError(
            f"Expected 14,000 locked-test rows; "
            f"found {len(test_df)}."
        )

    # Identity protection.
    overlap = set(dev_df[ID_COL]).intersection(
        set(test_df[ID_COL])
    )

    if overlap:
        raise ValueError(
            f"Development/test ID overlap detected: "
            f"{len(overlap)} IDs."
        )

    print(f"Locked test rows: {len(test_df)}")
    print(
        f"Locked test unique IDs: "
        f"{test_df[ID_COL].nunique()}"
    )
    print(f"Development/test ID overlap: {len(overlap)}")

    # -------------------------------------------------------------------------
    # Fit preprocessing on Development ONLY.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("3. FITTING PREPROCESSING ON DEVELOPMENT ONLY")
    print("=" * 80)

    medians, minmax = fit_preprocessor(
        dev_df
    )

    X_dev = transform_features(
        dev_df,
        medians,
        minmax,
    )

    X_test = transform_features(
        test_df,
        medians,
        minmax,
    )

    y_dev = dev_df[TARGET].to_numpy(
        dtype=np.int64
    )

    y_test = test_df[TARGET].to_numpy(
        dtype=np.int64
    )

    print("Preprocessing fit source: Development only")
    print("Test data used to fit preprocessing: NO")
    print("Median imputation: Development-fitted medians only")
    print("Development BP missing values imputed:")
    print(f"  ap_hi: {int(dev_df['ap_hi'].isna().sum())}")
    print(f"  ap_lo: {int(dev_df['ap_lo'].isna().sum())}")

    # -------------------------------------------------------------------------
    # Group representations.
    # -------------------------------------------------------------------------

    dev_groups = make_group_arrays(
        X_dev
    )

    test_groups = make_group_arrays(
        X_test
    )

    # -------------------------------------------------------------------------
    # Dataset / DataLoader.
    # -------------------------------------------------------------------------

    train_dataset = GroupDataset(
        dev_groups,
        y_dev,
    )

    test_dataset = GroupDataset(
        test_groups,
        y_test,
    )

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    test_loader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )

    # -------------------------------------------------------------------------
    # Build final A8.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("4. BUILDING FINAL A8 MODEL")
    print("=" * 80)

    group_sizes = {
        name: len(features)
        for name, features in GROUPS.items()
    }

    model = A8_CGS_ChebKAN(
        group_sizes=group_sizes,
        degree=CHEB_DEGREE,
        embed_dim=EMBED_DIM,
    ).to(DEVICE)

    print_model_structure(model)

    parameter_count = count_parameters(model)

    if parameter_count != 1924:
        raise ValueError(
            f"Expected 1,924 trainable parameters; "
            f"found {parameter_count}. "
            f"Do not proceed until the architecture is reconciled."
        )

    print("\nPASS: A8 parameter count = 1,924")

    # -------------------------------------------------------------------------
    # Final training.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("5. FINAL A8 FIT ON ALL DEVELOPMENT DATA")
    print("=" * 80)

    print(
        "Training records: 49,000"
    )
    print(
        f"Frozen epoch count: {FINAL_EPOCHS}"
    )
    print(
        "Calibration set used: NO"
    )
    print(
        "Locked test labels used for training/model selection: NO"
    )

    history = train_final_model(
        model,
        train_loader,
        epochs=FINAL_EPOCHS,
    )

    history.to_csv(
        HISTORY_FILE,
        index=False,
    )

    # -------------------------------------------------------------------------
    # Save final model.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("6. SAVING FINAL A8 CHECKPOINT")
    print("=" * 80)

    gates = model.gate_probabilities()

    checkpoint = {
        "model_state_dict": model.state_dict(),
        "features": FEATURES,
        "groups": GROUPS,
        "cheb_degree": CHEB_DEGREE,
        "embedding_dim": EMBED_DIM,
        "learning_rate": LEARNING_RATE,
        "l2": L2,
        "kan_l1": KAN_L1,
        "gate_l1": GATE_L1,
        "batch_size": BATCH_SIZE,
        "final_epochs": FINAL_EPOCHS,
        "seed": SEED,
        "parameter_count": parameter_count,
        "gate_probabilities": {
            GROUPS.keys().__iter__().__next__(): float(gates[0]),
            list(GROUPS.keys())[1]: float(gates[1]),
            list(GROUPS.keys())[2]: float(gates[2]),
        },
        "preprocessing_medians": medians.tolist(),
        "preprocessing_minmax": minmax.tolist(),
        "protocol": {
            "fit_data": "kaggle_development_cv.csv",
            "calibration_used": False,
            "locked_test_used_for_training": False,
            "locked_test_used_for_tuning": False,
            "threshold_optimized_on_locked_test": False,
        },
    }

    torch.save(
        checkpoint,
        CHECKPOINT_FILE,
    )

    print(
        f"Checkpoint saved:\n{CHECKPOINT_FILE}"
    )

    print("\nFinal learned group gates:")
    for i, name in enumerate(GROUPS.keys()):
        print(
            f"  {name}: {gates[i]:.6f}"
        )

    # -------------------------------------------------------------------------
    # Locked test prediction.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("7. FINAL LOCKED-TEST EVALUATION")
    print("=" * 80)

    probabilities = predict_probabilities(
        model,
        test_loader,
    )

    if len(probabilities) != len(test_df):
        raise ValueError(
            "Prediction count does not match locked-test rows."
        )

    metrics = calculate_metrics(
        y_true=y_test,
        probabilities=probabilities,
        threshold=TEST_THRESHOLD,
    )

    prediction_df = pd.DataFrame(
        {
            "id": test_df[ID_COL].to_numpy(),
            "true_label": y_test,
            "probability": probabilities,
            "prediction_050": (
                probabilities >= TEST_THRESHOLD
            ).astype(int),
        }
    )

    prediction_df.to_csv(
        PRED_FILE,
        index=False,
    )

    result_df = pd.DataFrame(
        [metrics]
    )

    result_df.to_csv(
        RESULT_FILE,
        index=False,
    )

    print("\nFINAL LOCKED-TEST RESULTS")
    print("-" * 80)

    for key, value in metrics.items():
        if isinstance(value, float):
            print(
                f"{key:20s}: {value:.6f}"
            )
        else:
            print(
                f"{key:20s}: {value}"
            )

    # -------------------------------------------------------------------------
    # Protocol audit.
    # -------------------------------------------------------------------------

    elapsed = time.time() - start_time

    protocol = {
        "implementation": "46",
        "status": "PASS_FINAL_A8_LOCKED_TEST_EVALUATION",
        "seed": SEED,
        "device": str(DEVICE),
        "development_rows": int(len(dev_df)),
        "locked_test_rows": int(len(test_df)),
        "development_test_id_overlap": int(len(overlap)),
        "features": FEATURES,
        "groups": GROUPS,
        "chebyshev_degree": CHEB_DEGREE,
        "embedding_dimension": EMBED_DIM,
        "parameter_count": parameter_count,
        "learning_rate": LEARNING_RATE,
        "l2": L2,
        "kan_l1": KAN_L1,
        "gate_l1": GATE_L1,
        "batch_size": BATCH_SIZE,
        "final_epochs": FINAL_EPOCHS,
        "epoch_selection_basis": (
            "Median of A8 development-CV best epochs "
            "[61, 78, 54, 43, 53] = 54"
        ),
        "expected_bp_missingness_before_imputation": {
            "development_ap_hi": int(dev_df["ap_hi"].isna().sum()),
            "development_ap_lo": int(dev_df["ap_lo"].isna().sum()),
            "locked_test_ap_hi": int(test_df["ap_hi"].isna().sum()),
            "locked_test_ap_lo": int(test_df["ap_lo"].isna().sum()),
        },
        "median_imputation": {
            "enabled": True,
            "fit_source": "Development only",
            "test_values_used_to_fit_imputation": False,
        },
        "calibration_data_used_for_training": False,
        "calibration_data_used_for_threshold_selection": False,
        "locked_test_used_for_training": False,
        "locked_test_used_for_hyperparameter_tuning": False,
        "locked_test_used_for_threshold_selection": False,
        "threshold": TEST_THRESHOLD,
        "threshold_selection_method": "Fixed 0.50; no locked-test optimization",
        "test_prediction_count": int(len(probabilities)),
        "prediction_count_matches_test": (
            len(probabilities) == len(test_df)
        ),
        "elapsed_seconds": elapsed,
        "final_group_gates": {
            list(GROUPS.keys())[i]: float(gates[i])
            for i in range(len(GROUPS))
        },
    }

    with open(
        PROTOCOL_FILE,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            protocol,
            f,
            indent=2,
        )

    summary = {
        "implementation": "46",
        "status": "PASS_FINAL_A8_LOCKED_TEST_EVALUATION",
        "locked_test_metrics": metrics,
        "parameter_count": parameter_count,
        "final_epochs": FINAL_EPOCHS,
        "final_group_gates": {
            list(GROUPS.keys())[i]: float(gates[i])
            for i in range(len(GROUPS))
        },
        "development_cv_best_epochs": [
            61, 78, 54, 43, 53
        ],
        "median_selected_epoch": 54,
        "files": {
            "predictions": str(PRED_FILE),
            "results": str(RESULT_FILE),
            "history": str(HISTORY_FILE),
            "checkpoint": str(CHECKPOINT_FILE),
            "protocol": str(PROTOCOL_FILE),
        },
    }

    with open(
        SUMMARY_FILE,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            summary,
            f,
            indent=2,
        )

    print("\n" + "=" * 80)
    print("IMPLEMENTATION 46 COMPLETE")
    print("Final status: PASS_FINAL_A8_LOCKED_TEST_EVALUATION")
    print("=" * 80)

    print("\nOutputs:")
    print(f"  Results:     {RESULT_FILE}")
    print(f"  Predictions: {PRED_FILE}")
    print(f"  History:     {HISTORY_FILE}")
    print(f"  Checkpoint:  {CHECKPOINT_FILE}")
    print(f"  Protocol:    {PROTOCOL_FILE}")
    print(f"  Summary:     {SUMMARY_FILE}")


if __name__ == "__main__":
    main()
