# ============================================================
# IMPLEMENTATION 38
# UCI EXTERNAL PREDICTION-COHORT VALUE-LEVEL AUDIT
#
# Purpose:
#   Audit the EXACT UCI records used in Implementation 34
#   external predictions.
#
# Cohorts:
#   Cleveland
#   Hungarian
#   VA
#
# Checks:
#   1. Exact prediction counts
#   2. Exact source-row membership
#   3. Literal -9 sentinel values
#   4. Negative placeholder values
#   5. Missing shared features
#   6. Age validity
#   7. Sex validity
#   8. Systolic BP validity
#   9. Cholesterol category validity
#  10. Elevated glucose validity
#  11. Target validity
#  12. VA source_row=33 exclusion
#
# No model training
# No retraining
# No threshold tuning
# No prediction modification
# ============================================================

from pathlib import Path
from datetime import datetime
import json

import numpy as np
import pandas as pd


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

UCI_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "uci_harmonized"
)

PREDICTION_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation34_uci_external_predictions.csv"
)

OUTPUT_CSV = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation38_uci_prediction_cohort_value_audit.csv"
)

OUTPUT_JSON = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation38_uci_prediction_cohort_value_audit.json"
)


# ============================================================
# FILES
# ============================================================

COHORT_FILES = {
    "cleveland":
        UCI_DIR / "uci_cleveland_harmonized_shared_features.csv",

    "hungarian":
        UCI_DIR / "uci_hungarian_harmonized_shared_features.csv",

    "va":
        UCI_DIR / "uci_va_harmonized_shared_features.csv",
}


# ============================================================
# SHARED FEATURES
# ============================================================

FEATURES = [
    "age",
    "sex",
    "systolic_bp",
    "cholesterol_category",
    "elevated_glucose",
]

TARGET = "target_binary"

SOURCE_ROW = "source_row"


# ============================================================
# EXPECTED PREDICTION COUNTS
# ============================================================

EXPECTED_PREDICTION_COUNTS = {
    "cleveland": 303,
    "hungarian": 262,
    "va": 100,
}


# ============================================================
# VALIDATION RULES
# ============================================================

def check_cohort(
    cohort_name,
    source_df,
    prediction_df,
):

    print("\n" + "=" * 100)
    print(
        f"COHORT: {cohort_name.upper()}"
    )
    print("=" * 100)

    errors = []
    warnings = []

    # --------------------------------------------------------
    # BASIC COUNTS
    # --------------------------------------------------------

    print(
        f"Source rows:      {len(source_df):,}"
    )

    print(
        f"Prediction rows:  {len(prediction_df):,}"
    )

    expected_n = (
        EXPECTED_PREDICTION_COUNTS[
            cohort_name
        ]
    )

    count_pass = (
        len(prediction_df)
        == expected_n
    )

    print(
        f"Expected predictions: {expected_n:,}"
    )

    print(
        "Prediction count:",
        "PASS" if count_pass else "FAIL"
    )

    if not count_pass:
        errors.append(
            "prediction_count_mismatch"
        )

    # --------------------------------------------------------
    # SOURCE ROW MEMBERSHIP
    # --------------------------------------------------------

    source_rows = set(
        pd.to_numeric(
            source_df[SOURCE_ROW],
            errors="coerce"
        )
        .dropna()
        .astype(int)
        .tolist()
    )

    prediction_rows = set(
        pd.to_numeric(
            prediction_df[SOURCE_ROW],
            errors="coerce"
        )
        .dropna()
        .astype(int)
        .tolist()
    )

    missing_prediction_rows = (
        source_rows
        & prediction_rows
    )

    invalid_prediction_rows = (
        prediction_rows
        - source_rows
    )

    print(
        f"Prediction source-row count: "
        f"{len(prediction_rows):,}"
    )

    print(
        f"Prediction rows not found in source: "
        f"{len(invalid_prediction_rows):,}"
    )

    if invalid_prediction_rows:
        errors.append(
            "prediction_source_row_not_in_source"
        )

    # --------------------------------------------------------
    # EXACT PREDICTION RECORD EXTRACTION
    # --------------------------------------------------------

    exact_records = (
        source_df[
            source_df[SOURCE_ROW]
            .isin(prediction_rows)
        ]
        .copy()
    )

    print(
        f"Exact source records matched: "
        f"{len(exact_records):,}"
    )

    if len(exact_records) != len(prediction_df):
        errors.append(
            "prediction_source_record_count_mismatch"
        )

    # --------------------------------------------------------
    # DUPLICATE SOURCE ROWS
    # --------------------------------------------------------

    duplicate_source_rows = (
        prediction_df[SOURCE_ROW]
        .duplicated()
        .sum()
    )

    print(
        f"Duplicate prediction source rows: "
        f"{duplicate_source_rows}"
    )

    if duplicate_source_rows > 0:
        errors.append(
            "duplicate_prediction_source_rows"
        )

    # --------------------------------------------------------
    # VALUE-LEVEL CHECKS
    # --------------------------------------------------------

    print("\nValue-level checks:")

    cohort_results = {
        "cohort": cohort_name,
        "source_rows": int(len(source_df)),
        "prediction_rows": int(len(prediction_df)),
        "expected_prediction_rows": int(expected_n),
        "prediction_count_pass": bool(count_pass),
        "matched_source_records": int(len(exact_records)),
        "duplicate_prediction_source_rows":
            int(duplicate_source_rows),
    }

    # --------------------------------------------------------
    # REQUIRED COLUMNS
    # --------------------------------------------------------

    required = FEATURES + [TARGET, SOURCE_ROW]

    missing_columns = [
        c
        for c in required
        if c not in exact_records.columns
    ]

    if missing_columns:

        print(
            "Missing required columns:",
            missing_columns
        )

        errors.append(
            "missing_required_columns"
        )

        return cohort_results, errors, warnings

    # --------------------------------------------------------
    # LITERAL -9 CHECK
    # --------------------------------------------------------

    minus9_counts = {}

    for col in FEATURES + [TARGET]:

        numeric_values = pd.to_numeric(
            exact_records[col],
            errors="coerce"
        )

        count_minus9 = int(
            (numeric_values == -9).sum()
        )

        minus9_counts[col] = count_minus9

        print(
            f"{col:25s} literal -9: "
            f"{count_minus9}"
        )

        if count_minus9 > 0:
            errors.append(
                f"{col}_contains_minus9"
            )

    # --------------------------------------------------------
    # NEGATIVE VALUES
    # --------------------------------------------------------

    negative_counts = {}

    for col in FEATURES:

        numeric_values = pd.to_numeric(
            exact_records[col],
            errors="coerce"
        )

        count_negative = int(
            (numeric_values < 0).sum()
        )

        negative_counts[col] = count_negative

        print(
            f"{col:25s} negative values: "
            f"{count_negative}"
        )

        if count_negative > 0:
            errors.append(
                f"{col}_contains_negative_values"
            )

    # --------------------------------------------------------
    # MISSING VALUES
    # --------------------------------------------------------

    missing_counts = {}

    for col in FEATURES:

        count_missing = int(
            exact_records[col]
            .isna()
            .sum()
        )

        missing_counts[col] = count_missing

        print(
            f"{col:25s} missing: "
            f"{count_missing}"
        )

        if count_missing > 0:
            errors.append(
                f"{col}_contains_missing_values"
            )

    # --------------------------------------------------------
    # AGE
    # --------------------------------------------------------

    age = pd.to_numeric(
        exact_records["age"],
        errors="coerce"
    )

    age_invalid = int(
        (
            (age < 18)
            |
            (age > 100)
        )
        .sum()
    )

    print(
        f"Age invalid (<18 or >100): "
        f"{age_invalid}"
    )

    if age_invalid > 0:
        errors.append(
            "invalid_age"
        )

    print(
        f"Age range: "
        f"{age.min():.3f} - {age.max():.3f}"
    )

    # --------------------------------------------------------
    # SEX
    # --------------------------------------------------------

    sex = pd.to_numeric(
        exact_records["sex"],
        errors="coerce"
    )

    invalid_sex = int(
        (~sex.isin([0, 1]))
        .sum()
    )

    print(
        f"Invalid sex values: "
        f"{invalid_sex}"
    )

    if invalid_sex > 0:
        errors.append(
            "invalid_sex"
        )

    print(
        "Sex unique values:",
        sorted(
            sex.dropna()
            .unique()
            .tolist()
        )
    )

    # --------------------------------------------------------
    # SYSTOLIC BP
    # --------------------------------------------------------

    sbp = pd.to_numeric(
        exact_records["systolic_bp"],
        errors="coerce"
    )

    invalid_sbp = int(
        (
            (sbp < 70)
            |
            (sbp > 250)
        )
        .sum()
    )

    print(
        f"Invalid systolic BP "
        f"(<70 or >250): {invalid_sbp}"
    )

    if invalid_sbp > 0:
        errors.append(
            "invalid_systolic_bp"
        )

    print(
        f"Systolic BP range: "
        f"{sbp.min():.3f} - {sbp.max():.3f}"
    )

    # --------------------------------------------------------
    # CHOLESTEROL CATEGORY
    # --------------------------------------------------------

    chol = pd.to_numeric(
        exact_records[
            "cholesterol_category"
        ],
        errors="coerce"
    )

    invalid_chol = int(
        (~chol.isin([1, 2, 3]))
        .sum()
    )

    print(
        f"Invalid cholesterol categories: "
        f"{invalid_chol}"
    )

    if invalid_chol > 0:
        errors.append(
            "invalid_cholesterol_category"
        )

    print(
        "Cholesterol categories:",
        sorted(
            chol.dropna()
            .unique()
            .tolist()
        )
    )

    # --------------------------------------------------------
    # GLUCOSE
    # --------------------------------------------------------

    glucose = pd.to_numeric(
        exact_records[
            "elevated_glucose"
        ],
        errors="coerce"
    )

    invalid_glucose = int(
        (~glucose.isin([0, 1]))
        .sum()
    )

    print(
        f"Invalid glucose indicators: "
        f"{invalid_glucose}"
    )

    if invalid_glucose > 0:
        errors.append(
            "invalid_elevated_glucose"
        )

    print(
        "Elevated glucose values:",
        sorted(
            glucose.dropna()
            .unique()
            .tolist()
        )
    )

    # --------------------------------------------------------
    # TARGET
    # --------------------------------------------------------

    target = pd.to_numeric(
        exact_records[TARGET],
        errors="coerce"
    )

    invalid_target = int(
        (~target.isin([0, 1]))
        .sum()
    )

    print(
        f"Invalid target values: "
        f"{invalid_target}"
    )

    if invalid_target > 0:
        errors.append(
            "invalid_target"
        )

    # --------------------------------------------------------
    # VA-SPECIFIC CHECK
    # --------------------------------------------------------

    if cohort_name == "va":

        va33_present = (
            33
            in prediction_rows
        )

        print(
            f"VA source_row=33 in predictions: "
            f"{va33_present}"
        )

        if va33_present:
            errors.append(
                "invalid_va_source_row_33_in_predictions"
            )

    # --------------------------------------------------------
    # SUMMARY VALUES
    # --------------------------------------------------------

    cohort_results.update({

        "minus9_counts":
            minus9_counts,

        "negative_counts":
            negative_counts,

        "missing_counts":
            missing_counts,

        "age_min":
            float(age.min()),

        "age_max":
            float(age.max()),

        "invalid_age":
            int(age_invalid),

        "sex_unique":
            sorted(
                sex.dropna()
                .unique()
                .astype(int)
                .tolist()
            ),

        "invalid_sex":
            int(invalid_sex),

        "sbp_min":
            float(sbp.min()),

        "sbp_max":
            float(sbp.max()),

        "invalid_sbp":
            int(invalid_sbp),

        "cholesterol_unique":
            sorted(
                chol.dropna()
                .unique()
                .astype(int)
                .tolist()
            ),

        "invalid_cholesterol":
            int(invalid_chol),

        "glucose_unique":
            sorted(
                glucose.dropna()
                .unique()
                .astype(int)
                .tolist()
            ),

        "invalid_glucose":
            int(invalid_glucose),

        "invalid_target":
            int(invalid_target),

        "error_count":
            int(len(errors)),
    })

    return cohort_results, errors, warnings


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 38"
    )
    print(
        "UCI EXTERNAL PREDICTION-COHORT VALUE-LEVEL AUDIT"
    )
    print("=" * 100)

    print(
        "Timestamp:",
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    )

    # ========================================================
    # CHECK FILES
    # ========================================================

    if not PREDICTION_FILE.exists():

        raise FileNotFoundError(
            f"Prediction file not found:\n"
            f"{PREDICTION_FILE}"
        )

    for cohort, path in COHORT_FILES.items():

        if not path.exists():

            raise FileNotFoundError(
                f"{cohort} file not found:\n"
                f"{path}"
            )

    # ========================================================
    # LOAD PREDICTIONS
    # ========================================================

    predictions = pd.read_csv(
        PREDICTION_FILE
    )

    print("\nPrediction file:")
    print(
        PREDICTION_FILE
    )

    print(
        f"Total prediction rows: "
        f"{len(predictions):,}"
    )

    # ========================================================
    # GLOBAL RESULT STORAGE
    # ========================================================

    all_results = []
    all_errors = []

    # ========================================================
    # COHORT LOOP
    # ========================================================

    for cohort, path in COHORT_FILES.items():

        source = pd.read_csv(
            path
        )

        pred = predictions[
            predictions["cohort"]
            .astype(str)
            .str.lower()
            .str.strip()
            == cohort
        ].copy()

        results, errors, warnings = (
            check_cohort(
                cohort,
                source,
                pred
            )
        )

        all_results.append(
            results
        )

        if errors:

            for error in errors:

                all_errors.append({
                    "cohort": cohort,
                    "error": error
                })

    # ========================================================
    # SAVE COHORT SUMMARY
    # ========================================================

    results_df = pd.DataFrame(
        all_results
    )

    results_df.to_csv(
        OUTPUT_CSV,
        index=False
    )

    # ========================================================
    # GLOBAL STATUS
    # ========================================================

    global_pass = (
        len(all_errors) == 0
    )

    if global_pass:

        final_status = (
            "PASS_EXACT_PREDICTION_COHORTS_VALUE_CLEAN"
        )

        conclusion = (
            "The exact Cleveland, Hungarian, and VA "
            "records used for Implementation 34 "
            "external predictions contain no literal "
            "-9 sentinel values, no negative placeholder "
            "values, no missing shared features, and no "
            "invalid values under the frozen harmonization "
            "rules. The external AUC calculations are "
            "therefore supported by both row-level and "
            "value-level audits."
        )

    else:

        final_status = (
            "REVIEW_UCI_VALUE_LEVEL_AUDIT"
        )

        conclusion = (
            "One or more value-level integrity checks "
            "failed. Do not finalize the external AUC "
            "interpretation until the identified issue "
            "has been resolved."
        )

    # ========================================================
    # JSON OUTPUT
    # ========================================================

    audit = {

        "implementation":
            "38",

        "title":
            (
                "UCI External Prediction-Cohort "
                "Value-Level Audit"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "prediction_file":
            str(PREDICTION_FILE),

        "cohorts":
            results_df.to_dict(
                orient="records"
            ),

        "errors":
            all_errors,

        "global_pass":
            bool(global_pass),

        "no_model_training":
            True,

        "no_retraining":
            True,

        "no_threshold_tuning":
            True,

        "no_prediction_modification":
            True,

        "final_status":
            final_status,

        "conclusion":
            conclusion,
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            audit,
            f,
            indent=2,
            default=str
        )

    # ========================================================
    # FINAL SUMMARY
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "GLOBAL AUDIT SUMMARY"
    )
    print("=" * 100)

    print(
        f"Total cohorts audited: "
        f"{len(all_results)}"
    )

    print(
        f"Total errors: "
        f"{len(all_errors)}"
    )

    print(
        "\nFinal status:"
    )

    print(
        final_status
    )

    print(
        "\nConclusion:"
    )

    print(
        conclusion
    )

    # ========================================================
    # ERROR DETAILS
    # ========================================================

    if all_errors:

        print("\n" + "=" * 100)
        print(
            "ERROR DETAILS"
        )
        print("=" * 100)

        for item in all_errors:

            print(
                f"{item['cohort']}: "
                f"{item['error']}"
            )

    # ========================================================
    # OUTPUT FILES
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        OUTPUT_CSV
    )

    print(
        OUTPUT_JSON
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 38 COMPLETE"
    )
    print("=" * 100)


if __name__ == "__main__":
    main()