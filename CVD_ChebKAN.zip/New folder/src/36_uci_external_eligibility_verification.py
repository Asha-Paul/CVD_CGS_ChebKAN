# ============================================================
# IMPLEMENTATION 36
# UCI EXTERNAL VALIDATION ELIGIBILITY VERIFICATION
#
# Purpose:
#   1. Verify the exact shared-feature eligibility rules.
#   2. Correctly recognize target_binary.
#   3. Identify clinically invalid shared-feature records.
#   4. Specifically investigate VA systolic_bp = 0.
#   5. Compare the corrected eligibility masks with the
#      records used by Implementation 34 predictions.
#
# IMPORTANT:
#   - No model training
#   - No hyperparameter tuning
#   - No threshold tuning
#   - No UCI labels used for model selection
#   - Original harmonized datasets are NOT modified
#
# Expected primary external cohorts:
#   Cleveland  : 303
#   Hungarian  : 262
#   Switzerland: 0
#   VA         : 99 after excluding invalid SBP=0 record
#
# ============================================================

from pathlib import Path
import json
from datetime import datetime

import numpy as np
import pandas as pd


# ============================================================
# 1. PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

HARMONIZED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "uci_harmonized"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# 2. HARMONIZED FILES
# ============================================================

HARMONIZED_FILES = {

    "cleveland":
        "uci_cleveland_harmonized_shared_features.csv",

    "hungarian":
        "uci_hungarian_harmonized_shared_features.csv",

    "switzerland":
        "uci_switzerland_harmonized_shared_features.csv",

    "va":
        "uci_va_harmonized_shared_features.csv",
}


# ============================================================
# 3. IMPLEMENTATION 34 PREDICTIONS
# ============================================================

PREDICTION_FILE = (
    RESULTS_DIR
    / "implementation34_uci_external_predictions.csv"
)


# ============================================================
# 4. SHARED FEATURES
# ============================================================

SHARED_FEATURES = [
    "age",
    "sex",
    "systolic_bp",
    "cholesterol_category",
    "elevated_glucose",
]


# ============================================================
# 5. TARGET
#
# The harmonized files use target_binary.
# ============================================================

TARGET_COLUMN = "target_binary"


# ============================================================
# 6. FROZEN VALIDITY RULES
#
# These are eligibility rules, not model-training rules.
# ============================================================

VALIDITY_RULES = {

    "age": {
        "minimum": 18.0,
        "maximum": 100.0,
    },

    "sex": {
        "minimum": 0.0,
        "maximum": 1.0,
    },

    "systolic_bp": {
        "minimum": 70.0,
        "maximum": 250.0,
    },

    "cholesterol_category": {
        "minimum": 1.0,
        "maximum": 3.0,
    },

    "elevated_glucose": {
        "minimum": 0.0,
        "maximum": 1.0,
    },
}


# ============================================================
# 7. EXPECTED COHORT COUNTS
#
# Based on the previous harmonization audit.
#
# VA is expected to decrease from 100 to 99 because one
# record has systolic_bp = 0.
# ============================================================

EXPECTED_PREVIOUS_ELIGIBLE = {

    "cleveland": 303,

    "hungarian": 262,

    "switzerland": 0,

    "va": 100,
}

EXPECTED_CORRECTED_ELIGIBLE = {

    "cleveland": 303,

    "hungarian": 262,

    "switzerland": 0,

    "va": 99,
}


# ============================================================
# 8. HELPER FUNCTIONS
# ============================================================

def load_harmonized(
    cohort
):

    path = (
        HARMONIZED_DIR
        / HARMONIZED_FILES[cohort]
    )

    if not path.exists():

        raise FileNotFoundError(
            f"Harmonized file not found: {path}"
        )

    df = pd.read_csv(path)

    return df, path


def numeric_series(
    df,
    column
):

    return pd.to_numeric(
        df[column],
        errors="coerce"
    )


# ============================================================
# 9. CHECK REQUIRED COLUMNS
# ============================================================

def check_columns(
    df,
    cohort
):

    required = (
        SHARED_FEATURES
        + [TARGET_COLUMN]
    )

    missing = [
        column
        for column in required
        if column not in df.columns
    ]

    if missing:

        raise ValueError(
            f"{cohort}: missing required "
            f"columns: {missing}"
        )

    return True


# ============================================================
# 10. BUILD STRICT ELIGIBILITY MASK
# ============================================================

def build_eligibility_mask(
    df,
    cohort
):

    check_columns(
        df,
        cohort
    )

    reasons = pd.DataFrame(
        index=df.index
    )

    # --------------------------------------------------------
    # Missing-value checks
    # --------------------------------------------------------

    for feature in SHARED_FEATURES:

        reasons[
            f"{feature}_missing"
        ] = df[feature].isna()

    # --------------------------------------------------------
    # Sentinel checks
    # --------------------------------------------------------

    for feature in SHARED_FEATURES:

        numeric = numeric_series(
            df,
            feature
        )

        reasons[
            f"{feature}_minus9"
        ] = (
            numeric == -9
        )

    # --------------------------------------------------------
    # Range checks
    # --------------------------------------------------------

    for feature, limits in (
        VALIDITY_RULES.items()
    ):

        numeric = numeric_series(
            df,
            feature
        )

        reasons[
            f"{feature}_below_min"
        ] = (
            numeric < limits["minimum"]
        )

        reasons[
            f"{feature}_above_max"
        ] = (
            numeric > limits["maximum"]
        )

    # --------------------------------------------------------
    # Negative checks
    # --------------------------------------------------------

    for feature in SHARED_FEATURES:

        numeric = numeric_series(
            df,
            feature
        )

        reasons[
            f"{feature}_negative"
        ] = (
            numeric < 0
        )

    # --------------------------------------------------------
    # Any invalid condition
    # --------------------------------------------------------

    invalid_columns = list(
        reasons.columns
    )

    invalid_mask = (
        reasons[invalid_columns]
        .any(axis=1)
    )

    eligible_mask = (
        ~invalid_mask
    )

    return (
        eligible_mask,
        reasons
    )


# ============================================================
# 11. PRINT INVALID RECORDS
# ============================================================

def print_invalid_records(
    df,
    reasons,
    eligible_mask,
    cohort
):

    invalid_indices = (
        df.index[
            ~eligible_mask
        ]
        .tolist()
    )

    print("\n" + "-" * 100)

    print(
        f"INVALID RECORD REVIEW: "
        f"{cohort.upper()}"
    )

    print("-" * 100)

    print(
        f"Invalid records: "
        f"{len(invalid_indices):,}"
    )

    if len(invalid_indices) == 0:

        print(
            "No invalid shared-feature "
            "records identified."
        )

        return

    for idx in invalid_indices:

        row = df.loc[idx]

        reason_columns = [
            column
            for column in reasons.columns
            if bool(
                reasons.loc[
                    idx,
                    column
                ]
            )
        ]

        print(
            f"\nIndex: {idx}"
        )

        print(
            f"Source row: "
            f"{row.get('source_row', 'NA')}"
        )

        print(
            f"Age: "
            f"{row['age']}"
        )

        print(
            f"Sex: "
            f"{row['sex']}"
        )

        print(
            f"Systolic BP: "
            f"{row['systolic_bp']}"
        )

        print(
            f"Cholesterol category: "
            f"{row['cholesterol_category']}"
        )

        print(
            f"Elevated glucose: "
            f"{row['elevated_glucose']}"
        )

        print(
            f"Target: "
            f"{row[TARGET_COLUMN]}"
        )

        print(
            "Invalidity reasons:"
        )

        for reason in reason_columns:

            print(
                f"  - {reason}"
            )


# ============================================================
# 12. SAVE CORRECTED ELIGIBLE DATASET
#
# These are new audit outputs.
# Original harmonized files remain untouched.
# ============================================================

def save_corrected_dataset(
    df,
    eligible_mask,
    cohort
):

    corrected = (
        df.loc[
            eligible_mask
        ]
        .copy()
        .reset_index(drop=True)
    )

    output = (
        RESULTS_DIR
        / (
            "implementation36_"
            f"{cohort}_corrected_eligible.csv"
        )
    )

    corrected.to_csv(
        output,
        index=False
    )

    return (
        corrected,
        output
    )


# ============================================================
# 13. TARGET AUDIT
# ============================================================

def audit_target(
    df,
    cohort
):

    target = pd.to_numeric(
        df[TARGET_COLUMN],
        errors="coerce"
    )

    missing = int(
        target.isna().sum()
    )

    unique = sorted(
        target.dropna()
        .unique()
        .tolist()
    )

    invalid = int(
        (
            ~target.isin(
                [0, 1]
            )
        ).sum()
    )

    print("\n" + "-" * 100)

    print(
        f"TARGET AUDIT: "
        f"{cohort.upper()}"
    )

    print("-" * 100)

    print(
        f"Target column: "
        f"{TARGET_COLUMN}"
    )

    print(
        f"Missing target: "
        f"{missing}"
    )

    print(
        f"Unique target values: "
        f"{unique}"
    )

    print(
        f"Invalid non-binary target count: "
        f"{invalid}"
    )

    print(
        "Target distribution:"
    )

    print(
        target.value_counts(
            dropna=False
        )
        .sort_index()
        .to_string()
    )

    if missing > 0:

        return False

    if invalid > 0:

        return False

    return True


# ============================================================
# 14. IMPLEMENTATION 34 PREDICTION FILE AUDIT
# ============================================================

def audit_prediction_file():

    print("\n" + "=" * 100)

    print(
        "IMPLEMENTATION 34 "
        "PREDICTION FILE AUDIT"
    )

    print("=" * 100)

    if not PREDICTION_FILE.exists():

        print(
            "WARNING: Implementation 34 "
            "prediction file not found:"
        )

        print(
            PREDICTION_FILE
        )

        return None

    pred = pd.read_csv(
        PREDICTION_FILE
    )

    print(
        f"Prediction rows: "
        f"{len(pred):,}"
    )

    print(
        "Prediction columns:"
    )

    print(
        list(pred.columns)
    )

    print("\nFirst rows:")

    print(
        pred.head().to_string(
            index=False
        )
    )

    return pred


# ============================================================
# 15. IDENTIFY PREDICTION-FILE IDENTIFIERS
# ============================================================

def identify_identifier_columns(
    pred
):

    candidates = [
        "source_row",
        "index",
        "row_index",
        "original_index",
        "id",
        "record_id",
    ]

    found = [
        column
        for column in candidates
        if column in pred.columns
    ]

    return found


# ============================================================
# 16. COMPARE PREDICTIONS WITH CURRENT ELIGIBILITY
#
# This function attempts to identify whether the prediction
# file contains the invalid VA SBP=0 record.
# ============================================================

def compare_prediction_records(
    pred,
    cohort,
    original_df,
    eligible_mask
):

    if pred is None:

        return {
            "cohort": cohort,
            "prediction_file_available": False,
            "comparison_possible": False,
        }

    cohort_column = None

    for candidate in [
        "cohort",
        "dataset",
        "source_cohort",
    ]:

        if candidate in pred.columns:

            cohort_column = candidate
            break

    if cohort_column is None:

        print(
            f"\n{cohort.upper()}: "
            "prediction file has no cohort column."
        )

        return {
            "cohort": cohort,
            "prediction_file_available": True,
            "comparison_possible": False,
        }

    cohort_pred = pred[
        pred[cohort_column]
        .astype(str)
        .str.lower()
        == cohort.lower()
    ].copy()

    print("\n" + "-" * 100)

    print(
        f"PREDICTION COHORT CHECK: "
        f"{cohort.upper()}"
    )

    print("-" * 100)

    print(
        f"Prediction rows for cohort: "
        f"{len(cohort_pred):,}"
    )

    identifier_columns = (
        identify_identifier_columns(
            cohort_pred
        )
    )

    print(
        f"Identifier columns found: "
        f"{identifier_columns}"
    )

    result = {

        "cohort":
            cohort,

        "prediction_file_available":
            True,

        "comparison_possible":
            False,

        "prediction_rows":
            int(len(cohort_pred)),

        "identifier_columns":
            ",".join(
                identifier_columns
            ),
    }

    # --------------------------------------------------------
    # Direct source-row comparison
    # --------------------------------------------------------

    if (
        "source_row" in cohort_pred.columns
        and "source_row" in original_df.columns
    ):

        pred_source_rows = set(
            pd.to_numeric(
                cohort_pred[
                    "source_row"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(int)
            .tolist()
        )

        invalid_source_rows = set(
            pd.to_numeric(
                original_df.loc[
                    ~eligible_mask,
                    "source_row"
                ],
                errors="coerce"
            )
            .dropna()
            .astype(int)
            .tolist()
        )

        overlap = (
            pred_source_rows
            & invalid_source_rows
        )

        print(
            f"Invalid source rows in "
            f"prediction file: "
            f"{len(overlap):,}"
        )

        if len(overlap) > 0:

            print(
                "WARNING: Implementation 34 "
                "appears to include invalid "
                "records."
            )

            print(
                "Invalid source rows:",
                sorted(overlap)
            )

        else:

            print(
                "No invalid source rows "
                "detected in prediction file."
            )

        result[
            "comparison_possible"
        ] = True

        result[
            "invalid_records_in_predictions"
        ] = int(
            len(overlap)
        )

        result[
            "invalid_source_rows"
        ] = ",".join(
            map(
                str,
                sorted(overlap)
            )
        )

    return result


# ============================================================
# 17. MAIN
# ============================================================

def main():

    print("=" * 100)

    print(
        "IMPLEMENTATION 36"
    )

    print(
        "UCI EXTERNAL VALIDATION "
        "ELIGIBILITY VERIFICATION"
    )

    print("=" * 100)

    print(
        "Timestamp: "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    print(
        f"\nProject root: "
        f"{PROJECT_ROOT}"
    )

    print(
        f"Harmonized directory: "
        f"{HARMONIZED_DIR}"
    )

    print(
        f"Prediction file: "
        f"{PREDICTION_FILE}"
    )

    # ========================================================
    # PATH CHECKS
    # ========================================================

    if not PROJECT_ROOT.exists():

        raise FileNotFoundError(
            f"Project root not found: "
            f"{PROJECT_ROOT}"
        )

    if not HARMONIZED_DIR.exists():

        raise FileNotFoundError(
            f"Harmonized directory not found: "
            f"{HARMONIZED_DIR}"
        )

    # ========================================================
    # COLLECTIONS
    # ========================================================

    cohort_results = []

    prediction_comparison = []

    corrected_paths = {}

    # ========================================================
    # LOAD PREDICTION FILE
    # ========================================================

    prediction_df = (
        audit_prediction_file()
    )

    # ========================================================
    # COHORT LOOP
    # ========================================================

    for cohort in HARMONIZED_FILES:

        print("\n\n")

        print(
            "#" * 100
        )

        print(
            f"# COHORT: "
            f"{cohort.upper()}"
        )

        print(
            "#" * 100
        )

        # ----------------------------------------------------
        # Load
        # ----------------------------------------------------

        df, path = load_harmonized(
            cohort
        )

        print(
            f"\nInput file:"
        )

        print(
            path
        )

        print(
            f"Rows: {len(df):,}"
        )

        print(
            f"Columns: {len(df.columns)}"
        )

        print(
            "\nColumns:"
        )

        print(
            list(df.columns)
        )

        # ----------------------------------------------------
        # Required columns
        # ----------------------------------------------------

        check_columns(
            df,
            cohort
        )

        print(
            "\nRequired shared-feature "
            "columns: PASS"
        )

        # ----------------------------------------------------
        # Target
        # ----------------------------------------------------

        target_pass = audit_target(
            df,
            cohort
        )

        # ----------------------------------------------------
        # Eligibility
        # ----------------------------------------------------

        (
            eligible_mask,
            reasons
        ) = build_eligibility_mask(
            df,
            cohort
        )

        total = len(df)

        eligible = int(
            eligible_mask.sum()
        )

        invalid = (
            total
            - eligible
        )

        print("\n" + "-" * 100)

        print(
            f"STRICT ELIGIBILITY: "
            f"{cohort.upper()}"
        )

        print("-" * 100)

        print(
            f"Total records     : "
            f"{total:,}"
        )

        print(
            f"Eligible records  : "
            f"{eligible:,}"
        )

        print(
            f"Invalid records   : "
            f"{invalid:,}"
        )

        print(
            f"Eligibility rate  : "
            f"{100 * eligible / total:.3f}%"
        )

        # ----------------------------------------------------
        # Invalid record details
        # ----------------------------------------------------

        print_invalid_records(
            df,
            reasons,
            eligible_mask,
            cohort
        )

        # ----------------------------------------------------
        # Save corrected eligible dataset
        # ----------------------------------------------------

        (
            corrected,
            corrected_path
        ) = save_corrected_dataset(
            df,
            eligible_mask,
            cohort
        )

        corrected_paths[
            cohort
        ] = corrected_path

        print(
            "\nCorrected eligible dataset:"
        )

        print(
            corrected_path
        )

        # ----------------------------------------------------
        # Prediction comparison
        # ----------------------------------------------------

        comparison = (
            compare_prediction_records(
                prediction_df,
                cohort,
                df,
                eligible_mask
            )
        )

        prediction_comparison.append(
            comparison
        )

        # ----------------------------------------------------
        # Cohort summary
        # ----------------------------------------------------

        expected_old = (
            EXPECTED_PREVIOUS_ELIGIBLE[
                cohort
            ]
        )

        expected_new = (
            EXPECTED_CORRECTED_ELIGIBLE[
                cohort
            ]
        )

        cohort_result = {

            "dataset":
                cohort,

            "total_records":
                total,

            "target_column":
                TARGET_COLUMN,

            "target_audit_pass":
                target_pass,

            "previous_expected_eligible":
                expected_old,

            "strict_current_eligible":
                eligible,

            "corrected_expected_eligible":
                expected_new,

            "invalid_records":
                invalid,

            "eligibility_rate_percent":
                100 * eligible / total,

            "matches_corrected_expected":
                eligible == expected_new,

            "switzerland_excluded":
                (
                    cohort == "switzerland"
                    and eligible == 0
                ),
        }

        cohort_results.append(
            cohort_result
        )

    # ========================================================
    # SUMMARY TABLE
    # ========================================================

    summary_df = pd.DataFrame(
        cohort_results
    )

    prediction_df_summary = (
        pd.DataFrame(
            prediction_comparison
        )
    )

    # ========================================================
    # PRINT SUMMARY
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "IMPLEMENTATION 36 "
        "COHORT SUMMARY"
    )

    print("=" * 100)

    print(
        summary_df.to_string(
            index=False
        )
    )

    # ========================================================
    # EXPECTED RESULT CHECK
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "EXPECTED ELIGIBILITY CHECK"
    )

    print("=" * 100)

    all_expected = True

    for row in cohort_results:

        status = (
            "PASS"
            if row[
                "matches_corrected_expected"
            ]
            else "REVIEW"
        )

        print(
            f"{row['dataset']:15s} | "
            f"observed="
            f"{row['strict_current_eligible']:4d} | "
            f"expected="
            f"{row['corrected_expected_eligible']:4d} | "
            f"{status}"
        )

        if status != "PASS":

            all_expected = False

    # ========================================================
    # VA-SPECIFIC CHECK
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "VA SYSTOLIC BP ZERO CHECK"
    )

    print("=" * 100)

    va_df, _ = load_harmonized(
        "va"
    )

    va_sbp = numeric_series(
        va_df,
        "systolic_bp"
    )

    va_zero_mask = (
        va_sbp == 0
    )

    va_zero_count = int(
        va_zero_mask.sum()
    )

    print(
        f"VA records with "
        f"systolic_bp = 0: "
        f"{va_zero_count}"
    )

    if va_zero_count > 0:

        print(
            "\nVA zero-SBP records:"
        )

        columns_to_show = [
            column
            for column in [
                "source_row",
                "age",
                "sex",
                "systolic_bp",
                "cholesterol_category",
                "elevated_glucose",
                TARGET_COLUMN,
                "cohort",
            ]
            if column in va_df.columns
        ]

        print(
            va_df.loc[
                va_zero_mask,
                columns_to_show
            ].to_string(
                index=False
            )
        )

        print(
            "\nDecision: "
            "exclude these records from "
            "external evaluation."
        )

    else:

        print(
            "No VA zero-SBP records found."
        )

    # ========================================================
    # PREDICTION COMPARISON SUMMARY
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "IMPLEMENTATION 34 "
        "PREDICTION COMPARISON"
    )

    print("=" * 100)

    if len(
        prediction_df_summary
    ) > 0:

        print(
            prediction_df_summary.to_string(
                index=False
            )
        )

    # ========================================================
    # SAVE OUTPUTS
    # ========================================================

    summary_output = (
        RESULTS_DIR
        / "implementation36_uci_eligibility_summary.csv"
    )

    comparison_output = (
        RESULTS_DIR
        / "implementation36_uci_prediction_comparison.csv"
    )

    summary_df.to_csv(
        summary_output,
        index=False
    )

    prediction_df_summary.to_csv(
        comparison_output,
        index=False
    )

    # ========================================================
    # SAVE REASON TABLES
    # ========================================================

    for cohort in HARMONIZED_FILES:

        df, _ = load_harmonized(
            cohort
        )

        (
            eligible_mask,
            reasons
        ) = build_eligibility_mask(
            df,
            cohort
        )

        reason_table = pd.concat(
            [
                df.reset_index(
                    drop=True
                ),
                reasons.reset_index(
                    drop=True
                ),
            ],
            axis=1
        )

        reason_output = (
            RESULTS_DIR
            / (
                "implementation36_"
                f"{cohort}_eligibility_reasons.csv"
            )
        )

        reason_table.to_csv(
            reason_output,
            index=False
        )

    # ========================================================
    # PROTOCOL JSON
    # ========================================================

    protocol = {

        "implementation":
            "36",

        "title":
            (
                "UCI External Validation "
                "Eligibility Verification"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "purpose":
            (
                "Verify the exact shared-feature "
                "eligibility of UCI external "
                "validation cohorts and identify "
                "invalid records before "
                "threshold-transfer analysis."
            ),

        "no_model_training":
            True,

        "no_hyperparameter_tuning":
            True,

        "no_threshold_tuning":
            True,

        "no_dataset_modification":
            True,

        "target_column":
            TARGET_COLUMN,

        "shared_features":
            SHARED_FEATURES,

        "validity_rules":
            VALIDITY_RULES,

        "expected_previous_eligible":
            EXPECTED_PREVIOUS_ELIGIBLE,

        "expected_corrected_eligible":
            EXPECTED_CORRECTED_ELIGIBLE,

        "cohort_results":
            cohort_results,

        "prediction_comparison":
            prediction_comparison,

        "corrected_dataset_paths":
            {
                cohort:
                    str(path)
                for cohort, path
                in corrected_paths.items()
            },

        "outputs":
            [
                str(summary_output),
                str(comparison_output),
            ],
    }

    protocol_output = (
        RESULTS_DIR
        / "implementation36_uci_eligibility_protocol.json"
    )

    with open(
        protocol_output,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            protocol,
            f,
            indent=2
        )

    # ========================================================
    # FINAL STATUS
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "IMPLEMENTATION 36 FINAL STATUS"
    )

    print("=" * 100)

    print(
        f"Target column verified: "
        f"{TARGET_COLUMN}"
    )

    print(
        f"Expected eligibility "
        f"checks: "
        f"{'PASS' if all_expected else 'REVIEW'}"
    )

    print(
        f"VA zero-SBP records: "
        f"{va_zero_count}"
    )

    print(
        "\nCorrected external "
        "eligibility:"
    )

    for row in cohort_results:

        print(
            f"  {row['dataset']:15s}: "
            f"{row['strict_current_eligible']}"
        )

    # --------------------------------------------------------
    # Overall status
    # --------------------------------------------------------

    if not all_expected:

        final_status = (
            "REVIEW_ELIGIBILITY_COUNTS"
        )

    elif not all(
        row["target_audit_pass"]
        for row in cohort_results
    ):

        final_status = (
            "REVIEW_TARGET"
        )

    else:

        final_status = (
            "PASS_READY_FOR_THRESHOLD_TRANSFER"
        )

    print(
        f"\nFINAL STATUS: "
        f"{final_status}"
    )

    # ========================================================
    # OUTPUT LOCATIONS
    # ========================================================

    print("\n" + "=" * 100)

    print(
        "OUTPUT FILES"
    )

    print("=" * 100)

    print(
        summary_output
    )

    print(
        comparison_output
    )

    print(
        protocol_output
    )

    for cohort, path in (
        corrected_paths.items()
    ):

        print(
            f"{cohort}: {path}"
        )

    print("\n" + "=" * 100)

    print(
        "IMPLEMENTATION 36 COMPLETE"
    )

    print("=" * 100)

    print(
        "No model was trained."
    )

    print(
        "No threshold was selected."
    )

    print(
        "No UCI labels were used for "
        "model selection."
    )

    print(
        "Original harmonized datasets "
        "were not modified."
    )


# ============================================================
# 18. ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()