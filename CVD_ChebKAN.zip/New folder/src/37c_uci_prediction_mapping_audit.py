# ============================================================
# IMPLEMENTATION 37c
# VERIFY VA PREDICTION SOURCE-ROW SET
#
# Purpose:
#   Verify whether the 100 VA predictions produced by
#   Implementation 34 correspond exactly to the 100
#   strictly eligible VA records.
#
# No model training
# No retraining
# No threshold tuning
# No prediction deletion
# ============================================================

from pathlib import Path
import json
from datetime import datetime

import pandas as pd
import numpy as np


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

VA_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "uci_harmonized"
    / "uci_va_harmonized_shared_features.csv"
)

PREDICTION_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation34_uci_external_predictions.csv"
)

OUTPUT_CSV = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation37c_va_source_row_verification.csv"
)

OUTPUT_JSON = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation37c_va_source_row_verification.json"
)


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 37c"
    )
    print(
        "VA PREDICTION SOURCE-ROW SET VERIFICATION"
    )
    print("=" * 100)

    print(
        "Timestamp:",
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    )

    # ========================================================
    # LOAD
    # ========================================================

    if not VA_FILE.exists():

        raise FileNotFoundError(
            f"VA file not found:\n{VA_FILE}"
        )

    if not PREDICTION_FILE.exists():

        raise FileNotFoundError(
            f"Prediction file not found:\n"
            f"{PREDICTION_FILE}"
        )

    va = pd.read_csv(
        VA_FILE
    )

    pred = pd.read_csv(
        PREDICTION_FILE
    )

    # ========================================================
    # FILTER VA PREDICTIONS
    # ========================================================

    va_pred = (
        pred.loc[
            pred["cohort"]
            .astype(str)
            .str.lower()
            .str.strip()
            == "va"
        ]
        .copy()
    )

    print("\n" + "=" * 100)
    print(
        "RAW COUNTS"
    )
    print("=" * 100)

    print(
        f"VA source rows       : {len(va):,}"
    )

    print(
        f"VA prediction rows   : {len(va_pred):,}"
    )

    # ========================================================
    # NORMALIZE SOURCE ROW
    # ========================================================

    va["source_row"] = pd.to_numeric(
        va["source_row"],
        errors="coerce"
    )

    va_pred["source_row"] = pd.to_numeric(
        va_pred["source_row"],
        errors="coerce"
    )

    # ========================================================
    # FROZEN SHARED-FEATURE ELIGIBILITY
    #
    # Eligibility requires:
    #   - systolic_bp present
    #   - systolic_bp > 0
    #   - cholesterol_category present
    #   - elevated_glucose present
    #   - age present
    #   - sex present
    #   - binary target present
    #
    # ========================================================

    required_columns = [
        "age",
        "sex",
        "systolic_bp",
        "cholesterol_category",
        "elevated_glucose",
        "target_binary",
    ]

    missing_columns = [
        c
        for c in required_columns
        if c not in va.columns
    ]

    if missing_columns:

        raise ValueError(
            "Missing required columns: "
            f"{missing_columns}"
        )

    eligible_mask = (

        va["age"].notna()
        &
        va["sex"].notna()
        &
        va["systolic_bp"].notna()
        &
        (va["systolic_bp"] > 0)
        &
        va["cholesterol_category"].notna()
        &
        va["elevated_glucose"].notna()
        &
        va["target_binary"].notna()
    )

    va["strictly_eligible"] = (
        eligible_mask
    )

    eligible_va = (
        va.loc[
            eligible_mask
        ]
        .copy()
    )

    # ========================================================
    # SOURCE-ROW SETS
    # ========================================================

    expected_source_rows = set(
        eligible_va[
            "source_row"
        ]
        .astype(int)
        .tolist()
    )

    prediction_source_rows = set(
        va_pred[
            "source_row"
        ]
        .dropna()
        .astype(int)
        .tolist()
    )

    print("\n" + "=" * 100)
    print(
        "STRICT ELIGIBILITY"
    )
    print("=" * 100)

    print(
        f"Strictly eligible VA rows: "
        f"{len(expected_source_rows):,}"
    )

    print(
        f"VA prediction source rows: "
        f"{len(prediction_source_rows):,}"
    )

    # ========================================================
    # SET COMPARISON
    # ========================================================

    missing_from_predictions = (
        expected_source_rows
        -
        prediction_source_rows
    )

    extra_in_predictions = (
        prediction_source_rows
        -
        expected_source_rows
    )

    exact_set_match = (
        expected_source_rows
        ==
        prediction_source_rows
    )

    print("\n" + "=" * 100)
    print(
        "SOURCE-ROW SET COMPARISON"
    )
    print("=" * 100)

    print(
        f"Expected eligible source rows: "
        f"{len(expected_source_rows)}"
    )

    print(
        f"Prediction source rows: "
        f"{len(prediction_source_rows)}"
    )

    print(
        f"Missing from predictions: "
        f"{len(missing_from_predictions)}"
    )

    print(
        f"Extra in predictions: "
        f"{len(extra_in_predictions)}"
    )

    print(
        f"Exact source-row set match: "
        f"{'PASS' if exact_set_match else 'FAIL'}"
    )

    # ========================================================
    # INVALID SOURCE ROW 33
    # ========================================================

    invalid_row = 33

    row33_eligible = bool(
        va.loc[
            va["source_row"]
            == invalid_row,
            "strictly_eligible"
        ].iloc[0]
    )

    row33_in_predictions = (
        invalid_row
        in prediction_source_rows
    )

    print("\n" + "=" * 100)
    print(
        "SOURCE ROW 33 CHECK"
    )
    print("=" * 100)

    print(
        f"source_row 33 strictly eligible: "
        f"{row33_eligible}"
    )

    print(
        f"source_row 33 in predictions: "
        f"{row33_in_predictions}"
    )

    # ========================================================
    # SHOW DIFFERENCES IF ANY
    # ========================================================

    if missing_from_predictions:

        print("\nSource rows missing from predictions:")

        print(
            sorted(
                missing_from_predictions
            )
        )

    if extra_in_predictions:

        print("\nExtra source rows in predictions:")

        print(
            sorted(
                extra_in_predictions
            )
        )

    # ========================================================
    # CREATE FULL AUDIT TABLE
    # ========================================================

    audit = va[
        [
            "source_row",
            "age",
            "sex",
            "systolic_bp",
            "cholesterol_category",
            "elevated_glucose",
            "target_binary",
            "strictly_eligible",
        ]
    ].copy()

    audit["in_prediction_file"] = (
        audit["source_row"]
        .astype(int)
        .isin(
            prediction_source_rows
        )
    )

    audit["eligibility_prediction_consistent"] = (
        audit["strictly_eligible"]
        ==
        audit["in_prediction_file"]
    )

    audit.to_csv(
        OUTPUT_CSV,
        index=False
    )

    # ========================================================
    # FINAL DECISION
    # ========================================================

    if exact_set_match:

        final_status = (
            "PASS_IMPLEMENTATION34_VA_COHORT_CONFIRMED"
        )

        conclusion = (
            "The 100 VA predictions from "
            "Implementation 34 correspond exactly "
            "to the 100 strictly eligible VA "
            "source records. No correction or "
            "rerun of external inference is needed."
        )

    else:

        final_status = (
            "REVIEW_VA_SOURCE_ROW_MISMATCH"
        )

        conclusion = (
            "The Implementation 34 VA prediction "
            "source-row set does not exactly match "
            "the strict eligibility set. Do not "
            "modify the predictions manually. "
            "A fresh inference-only evaluation "
            "using the saved model is required."
        )

    # ========================================================
    # SAVE JSON
    # ========================================================

    protocol = {

        "implementation":
            "37c",

        "title":
            (
                "VA Prediction Source-Row "
                "Set Verification"
            ),

        "timestamp":
            datetime.now().isoformat(),

        "va_source_rows":
            int(len(va)),

        "va_strictly_eligible":
            int(len(expected_source_rows)),

        "va_prediction_rows":
            int(len(va_pred)),

        "expected_source_row_count":
            int(len(expected_source_rows)),

        "prediction_source_row_count":
            int(len(prediction_source_rows)),

        "missing_from_predictions":
            sorted(
                list(
                    missing_from_predictions
                )
            ),

        "extra_in_predictions":
            sorted(
                list(
                    extra_in_predictions
                )
            ),

        "exact_source_row_set_match":
            bool(exact_set_match),

        "source_row_33_eligible":
            bool(row33_eligible),

        "source_row_33_in_predictions":
            bool(row33_in_predictions),

        "no_model_retraining":
            True,

        "no_threshold_tuning":
            True,

        "no_prediction_modification":
            True,

        "final_status":
            final_status,

        "conclusion":
            conclusion,
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            protocol,
            f,
            indent=2
        )

    # ========================================================
    # FINAL OUTPUT
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "FINAL STATUS"
    )
    print("=" * 100)

    print(
        final_status
    )

    print(
        "\nConclusion:"
    )

    print(
        conclusion
    )

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        OUTPUT_CSV
    )

    print(
        OUTPUT_JSON
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 37c COMPLETE"
    )
    print("=" * 100)


if __name__ == "__main__":

    main()