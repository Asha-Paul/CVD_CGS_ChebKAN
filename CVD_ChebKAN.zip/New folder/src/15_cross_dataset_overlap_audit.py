# ================================================================
# AUDIT 15: NESTED CV + LEAKAGE-CONTROLLED FOLD CONSTRUCTION
# ================================================================
#
# Purpose:
#   Verify the nested cross-validation structure for the Kaggle
#   development dataset before model training.
#
# Frozen partition:
#   70,000 total
#       ├── 49,000 Development/CV
#       ├──  7,000 Conformal Calibration
#       └── 14,000 Locked Test
#
# Frozen CV strategy:
#   Outer CV: 5-fold StratifiedKFold
#   Inner CV: 4-fold StratifiedKFold
#
# Important:
#   - Calibration set is NOT used here.
#   - Locked test set is NOT used here.
#   - No model is trained.
#   - No feature selection is performed.
#   - No ADASYN is performed.
#   - No scaling is performed.
#   - No imputation is performed.
#
# This script verifies:
#   1. Correct input files
#   2. Correct sample counts
#   3. No overlap between Development/CV and calibration/test
#   4. Five outer folds
#   5. Four inner folds inside every outer-training set
#   6. No ID overlap between train/validation subsets
#   7. Stratification
#   8. Every development record appears exactly once in an
#      outer validation fold
#   9. Inner folds are constructed ONLY from the outer-training data
#  10. Calibration/test data never enter CV
#
# ================================================================

from pathlib import Path
import pandas as pd
import numpy as np

from sklearn.model_selection import StratifiedKFold


# ================================================================
# 1. PROJECT PATHS
# ================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

PROCESSED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)

RESULTS_TABLES = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

RESULTS_TABLES.mkdir(
    parents=True,
    exist_ok=True
)


CV_FILE = (
    PROCESSED_DIR
    / "kaggle_development_cv.csv"
)

CALIBRATION_FILE = (
    PROCESSED_DIR
    / "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROCESSED_DIR
    / "kaggle_locked_test.csv"
)


# ================================================================
# 2. FROZEN PARAMETERS
# ================================================================

RANDOM_STATE = 2026

N_OUTER_SPLITS = 5
N_INNER_SPLITS = 4


# ================================================================
# 3. LOAD DATA
# ================================================================

print("=" * 70)
print("AUDIT 15: NESTED CV + LEAKAGE-CONTROLLED FOLD CONSTRUCTION")
print("=" * 70)

print("\nChecking input files...")

for file_path in [
    CV_FILE,
    CALIBRATION_FILE,
    TEST_FILE
]:
    print(file_path)

    if not file_path.exists():
        raise FileNotFoundError(
            f"\nRequired file not found:\n{file_path}"
        )


print("\n" + "=" * 70)
print("LOADING PARTITIONS")
print("=" * 70)

development = pd.read_csv(CV_FILE)
calibration = pd.read_csv(CALIBRATION_FILE)
test = pd.read_csv(TEST_FILE)


# ================================================================
# 4. BASIC VALIDATION
# ================================================================

print("\nPartition sizes")
print("-" * 70)

print(
    f"Development/CV : {len(development):,}"
)

print(
    f"Calibration     : {len(calibration):,}"
)

print(
    f"Locked test     : {len(test):,}"
)


EXPECTED_DEV = 49_000
EXPECTED_CAL = 7_000
EXPECTED_TEST = 14_000

if len(development) != EXPECTED_DEV:
    raise RuntimeError(
        f"Expected {EXPECTED_DEV:,} development records, "
        f"found {len(development):,}."
    )

if len(calibration) != EXPECTED_CAL:
    raise RuntimeError(
        f"Expected {EXPECTED_CAL:,} calibration records, "
        f"found {len(calibration):,}."
    )

if len(test) != EXPECTED_TEST:
    raise RuntimeError(
        f"Expected {EXPECTED_TEST:,} test records, "
        f"found {len(test):,}."
    )


# ================================================================
# 5. REQUIRED COLUMNS
# ================================================================

required_columns = {
    "id",
    "cardio"
}

for name, dataset in [
    ("development", development),
    ("calibration", calibration),
    ("test", test)
]:

    missing = required_columns - set(dataset.columns)

    if missing:
        raise RuntimeError(
            f"{name} is missing required columns: {missing}"
        )


# ================================================================
# 6. TARGET VALIDATION
# ================================================================

print("\n" + "=" * 70)
print("STEP 1: TARGET VALIDATION")
print("=" * 70)

for name, dataset in [
    ("Development/CV", development),
    ("Calibration", calibration),
    ("Locked test", test)
]:

    unique_values = sorted(
        dataset["cardio"].dropna().unique().tolist()
    )

    print(
        f"{name}: target values = {unique_values}"
    )

    if unique_values != [0, 1]:
        raise RuntimeError(
            f"Unexpected target values in {name}: "
            f"{unique_values}"
        )

    if dataset["cardio"].isna().any():
        raise RuntimeError(
            f"Missing target detected in {name}."
        )


print("\nPASS: All partitions contain binary target {0,1}.")


# ================================================================
# 7. GLOBAL ID OVERLAP CHECK
# ================================================================

print("\n" + "=" * 70)
print("STEP 2: GLOBAL PARTITION OVERLAP")
print("=" * 70)

dev_ids = set(development["id"])
cal_ids = set(calibration["id"])
test_ids = set(test["id"])

dev_cal = dev_ids.intersection(cal_ids)
dev_test = dev_ids.intersection(test_ids)
cal_test = cal_ids.intersection(test_ids)

print(
    f"Development ∩ Calibration : {len(dev_cal)}"
)

print(
    f"Development ∩ Test        : {len(dev_test)}"
)

print(
    f"Calibration ∩ Test        : {len(cal_test)}"
)

if dev_cal or dev_test or cal_test:
    raise RuntimeError(
        "Partition-level patient overlap detected."
    )

print("\nPASS: Development, calibration, and test are disjoint.")


# ================================================================
# 8. DEVELOPMENT DUPLICATE CHECK
# ================================================================

print("\n" + "=" * 70)
print("STEP 3: DEVELOPMENT DUPLICATE AUDIT")
print("=" * 70)

if development["id"].duplicated().any():
    raise RuntimeError(
        "Duplicate IDs detected in development dataset."
    )

if development.duplicated().any():
    raise RuntimeError(
        "Duplicate complete records detected in development."
    )

print("PASS: Development IDs are unique.")
print("PASS: No duplicate complete development records.")


# ================================================================
# 9. OUTER STRATIFIED CV
# ================================================================

print("\n" + "=" * 70)
print("STEP 4: OUTER 5-FOLD STRATIFIED CV")
print("=" * 70)

X_dummy = np.zeros((len(development), 1))
y = development["cardio"].to_numpy()

outer_cv = StratifiedKFold(
    n_splits=N_OUTER_SPLITS,
    shuffle=True,
    random_state=RANDOM_STATE
)

outer_fold_records = []

outer_validation_ids = set()

outer_fold_data = []


for outer_fold, (outer_train_idx, outer_val_idx) in enumerate(
    outer_cv.split(X_dummy, y),
    start=1
):

    outer_train_ids = set(
        development.iloc[outer_train_idx]["id"]
    )

    outer_val_ids = set(
        development.iloc[outer_val_idx]["id"]
    )

    overlap = outer_train_ids.intersection(
        outer_val_ids
    )

    if overlap:
        raise RuntimeError(
            f"Outer fold {outer_fold}: "
            f"train/validation overlap detected."
        )

    # Check that this validation fold has not already
    # appeared in another outer validation fold.
    repeated_validation_ids = (
        outer_validation_ids.intersection(
            outer_val_ids
        )
    )

    if repeated_validation_ids:
        raise RuntimeError(
            f"Outer validation overlap detected in fold "
            f"{outer_fold}."
        )

    outer_validation_ids.update(
        outer_val_ids
    )

    y_train = development.iloc[
        outer_train_idx
    ]["cardio"]

    y_val = development.iloc[
        outer_val_idx
    ]["cardio"]

    outer_fold_records.append({
        "outer_fold": outer_fold,
        "train_n": len(outer_train_idx),
        "validation_n": len(outer_val_idx),
        "train_positive_rate": y_train.mean(),
        "validation_positive_rate": y_val.mean(),
        "train_class_0": int((y_train == 0).sum()),
        "train_class_1": int((y_train == 1).sum()),
        "validation_class_0": int((y_val == 0).sum()),
        "validation_class_1": int((y_val == 1).sum()),
    })

    outer_fold_data.append(
        (
            outer_fold,
            outer_train_idx,
            outer_val_idx
        )
    )


outer_summary = pd.DataFrame(
    outer_fold_records
)

print("\nOuter-fold summary:")
print(
    outer_summary.to_string(index=False)
)


# ================================================================
# 10. OUTER FOLD COVERAGE
# ================================================================

print("\n" + "=" * 70)
print("STEP 5: OUTER VALIDATION COVERAGE")
print("=" * 70)

development_id_count = len(dev_ids)

print(
    f"Unique development IDs           : "
    f"{development_id_count:,}"
)

print(
    f"Unique IDs appearing in validation: "
    f"{len(outer_validation_ids):,}"
)

if outer_validation_ids != dev_ids:
    missing_from_validation = (
        dev_ids - outer_validation_ids
    )

    unexpected_validation = (
        outer_validation_ids - dev_ids
    )

    raise RuntimeError(
        "Outer validation coverage failure.\n"
        f"Missing IDs: {len(missing_from_validation)}\n"
        f"Unexpected IDs: {len(unexpected_validation)}"
    )

print(
    "\nPASS: Every development record appears exactly "
    "once in an outer validation fold."
)


# ================================================================
# 11. INNER CV INSIDE EACH OUTER TRAINING SET
# ================================================================

print("\n" + "=" * 70)
print("STEP 6: INNER 4-FOLD CV")
print("=" * 70)

inner_fold_records = []

all_inner_validation_ids = []

for (
    outer_fold,
    outer_train_idx,
    outer_val_idx
) in outer_fold_data:

    print(
        f"\nOuter fold {outer_fold}"
    )
    print("-" * 50)

    outer_train = development.iloc[
        outer_train_idx
    ].copy()

    outer_val = development.iloc[
        outer_val_idx
    ].copy()

    # ------------------------------------------------------------
    # CRITICAL LEAKAGE CHECK
    #
    # Inner CV is created ONLY from outer_train.
    #
    # The outer validation fold is completely excluded.
    # ------------------------------------------------------------

    outer_train_ids = set(
        outer_train["id"]
    )

    outer_val_ids = set(
        outer_val["id"]
    )

    X_inner_dummy = np.zeros(
        (len(outer_train), 1)
    )

    y_inner = outer_train[
        "cardio"
    ].to_numpy()

    inner_cv = StratifiedKFold(
        n_splits=N_INNER_SPLITS,
        shuffle=True,
        random_state=RANDOM_STATE + outer_fold
    )

    inner_validation_union = set()

    for inner_fold, (
        inner_train_idx,
        inner_val_idx
    ) in enumerate(
        inner_cv.split(
            X_inner_dummy,
            y_inner
        ),
        start=1
    ):

        inner_train = outer_train.iloc[
            inner_train_idx
        ]

        inner_val = outer_train.iloc[
            inner_val_idx
        ]

        inner_train_ids = set(
            inner_train["id"]
        )

        inner_val_ids = set(
            inner_val["id"]
        )

        # --------------------------------------------------------
        # Check 1: inner train / validation overlap
        # --------------------------------------------------------

        overlap_inner = (
            inner_train_ids.intersection(
                inner_val_ids
            )
        )

        if overlap_inner:
            raise RuntimeError(
                f"Outer {outer_fold}, "
                f"Inner {inner_fold}: "
                "inner train/validation overlap."
            )

        # --------------------------------------------------------
        # Check 2: inner validation must be subset of
        #          outer training data
        # --------------------------------------------------------

        if not inner_val_ids.issubset(
            outer_train_ids
        ):
            raise RuntimeError(
                f"Outer {outer_fold}, "
                f"Inner {inner_fold}: "
                "inner validation contains records "
                "outside outer training data."
            )

        # --------------------------------------------------------
        # Check 3: inner training must be subset of
        #          outer training data
        # --------------------------------------------------------

        if not inner_train_ids.issubset(
            outer_train_ids
        ):
            raise RuntimeError(
                f"Outer {outer_fold}, "
                f"Inner {inner_fold}: "
                "inner training contains records "
                "outside outer training data."
            )

        # --------------------------------------------------------
        # Check 4: inner validation must NOT overlap
        #          outer validation
        # --------------------------------------------------------

        outer_leakage = (
            inner_val_ids.intersection(
                outer_val_ids
            )
        )

        if outer_leakage:
            raise RuntimeError(
                f"Outer {outer_fold}, "
                f"Inner {inner_fold}: "
                "outer validation leakage detected."
            )

        # --------------------------------------------------------
        # Check 5: inner training must NOT overlap
        #          outer validation
        # --------------------------------------------------------

        outer_leakage_train = (
            inner_train_ids.intersection(
                outer_val_ids
            )
        )

        if outer_leakage_train:
            raise RuntimeError(
                f"Outer {outer_fold}, "
                f"Inner {inner_fold}: "
                "outer validation appears in inner training."
            )

        # --------------------------------------------------------
        # Record inner validation IDs
        # --------------------------------------------------------

        repeated_inner_validation = (
            inner_validation_union.intersection(
                inner_val_ids
            )
        )

        if repeated_inner_validation:
            raise RuntimeError(
                f"Outer {outer_fold}: "
                "inner validation folds overlap."
            )

        inner_validation_union.update(
            inner_val_ids
        )

        y_inner_train = inner_train[
            "cardio"
        ]

        y_inner_val = inner_val[
            "cardio"
        ]

        inner_fold_records.append({
            "outer_fold": outer_fold,
            "inner_fold": inner_fold,
            "inner_train_n": len(inner_train),
            "inner_validation_n": len(inner_val),
            "inner_train_positive_rate":
                y_inner_train.mean(),
            "inner_validation_positive_rate":
                y_inner_val.mean(),
            "outer_validation_n":
                len(outer_val),
        })

        print(
            f"Inner fold {inner_fold}: "
            f"train={len(inner_train):,}, "
            f"validation={len(inner_val):,} "
            f"| outer validation={len(outer_val):,}"
        )

    # ------------------------------------------------------------
    # Inner validation coverage
    # ------------------------------------------------------------

    if inner_validation_union != outer_train_ids:

        missing_inner = (
            outer_train_ids
            - inner_validation_union
        )

        unexpected_inner = (
            inner_validation_union
            - outer_train_ids
        )

        raise RuntimeError(
            f"Outer fold {outer_fold}: "
            "inner validation coverage failure.\n"
            f"Missing: {len(missing_inner)}\n"
            f"Unexpected: {len(unexpected_inner)}"
        )

    print(
        f"PASS: Outer fold {outer_fold} "
        "inner validation coverage complete."
    )


inner_summary = pd.DataFrame(
    inner_fold_records
)


# ================================================================
# 12. EXPECTED FOLD SIZES
# ================================================================

print("\n" + "=" * 70)
print("STEP 7: EXPECTED FOLD SIZE CHECK")
print("=" * 70)

expected_outer_validation = (
    len(development) // N_OUTER_SPLITS
)

print(
    f"Expected approximate outer validation size: "
    f"{expected_outer_validation:,}"
)

print(
    "\nOuter folds:"
)

print(
    outer_summary[
        [
            "outer_fold",
            "train_n",
            "validation_n"
        ]
    ].to_string(index=False)
)


# For 49,000 records and 5 folds:
# validation = 9,800
# training   = 39,200

if not all(
    outer_summary["validation_n"]
    == 9_800
):
    raise RuntimeError(
        "Unexpected outer validation fold size."
    )

if not all(
    outer_summary["train_n"]
    == 39_200
):
    raise RuntimeError(
        "Unexpected outer training fold size."
    )

print(
    "\nPASS: All outer folds have expected sizes."
)


# ================================================================
# 13. EXPECTED INNER FOLD SIZES
# ================================================================

print("\n" + "=" * 70)
print("STEP 8: INNER FOLD SIZE CHECK")
print("=" * 70)

print(
    inner_summary[
        [
            "outer_fold",
            "inner_fold",
            "inner_train_n",
            "inner_validation_n"
        ]
    ].to_string(index=False)
)

# Each outer training set = 39,200.
# Four inner folds:
#   validation = 9,800
#   training = 29,400

if not all(
    inner_summary["inner_validation_n"]
    == 9_800
):
    raise RuntimeError(
        "Unexpected inner validation fold size."
    )

if not all(
    inner_summary["inner_train_n"]
    == 29_400
):
    raise RuntimeError(
        "Unexpected inner training fold size."
    )

print(
    "\nPASS: All inner folds have expected sizes."
)


# ================================================================
# 14. STRATIFICATION QUALITY
# ================================================================

print("\n" + "=" * 70)
print("STEP 9: STRATIFICATION QUALITY")
print("=" * 70)

overall_dev_rate = (
    development["cardio"].mean()
)

outer_summary[
    "train_rate_difference"
] = (
    outer_summary["train_positive_rate"]
    - overall_dev_rate
)

outer_summary[
    "validation_rate_difference"
] = (
    outer_summary["validation_positive_rate"]
    - overall_dev_rate
)

print(
    outer_summary[
        [
            "outer_fold",
            "train_positive_rate",
            "validation_positive_rate",
            "train_rate_difference",
            "validation_rate_difference"
        ]
    ].to_string(index=False)
)

print(
    f"\nDevelopment positive rate: "
    f"{overall_dev_rate:.6f}"
)


# ================================================================
# 15. EXPLICIT LEAKAGE-PREVENTION PROTOCOL
# ================================================================

print("\n" + "=" * 70)
print("STEP 10: LEAKAGE-PREVENTION PROTOCOL")
print("=" * 70)

protocol = pd.DataFrame([
    {
        "operation":
            "Scaling / normalization",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "Imputation",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "XGBoost feature importance",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "Boruta",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "RFE",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "Chi-square feature selection",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "ADASYN",
        "allowed_data":
            "Outer training fold only",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "Hyperparameter selection",
        "allowed_data":
            "Inner CV within outer training data",
        "forbidden_data":
            "Outer validation, calibration, locked test",
    },
    {
        "operation":
            "Model selection",
        "allowed_data":
            "Development/CV data only",
        "forbidden_data":
            "Calibration and locked test",
    },
    {
        "operation":
            "Conformal calibration",
        "allowed_data":
            "Dedicated 7,000-record calibration set",
        "forbidden_data":
            "Development CV and locked test",
    },
    {
        "operation":
            "Final test evaluation",
        "allowed_data":
            "Locked 14,000-record test set",
        "forbidden_data":
            "Any use before final model is frozen",
    },
])

print(
    protocol.to_string(index=False)
)


# ================================================================
# 16. SAVE AUDIT TABLES
# ================================================================

outer_file = (
    RESULTS_TABLES
    / "audit15_outer_cv_summary.csv"
)

inner_file = (
    RESULTS_TABLES
    / "audit15_inner_cv_summary.csv"
)

protocol_file = (
    RESULTS_TABLES
    / "audit15_leakage_prevention_protocol.csv"
)

outer_summary.to_csv(
    outer_file,
    index=False
)

inner_summary.to_csv(
    inner_file,
    index=False
)

protocol.to_csv(
    protocol_file,
    index=False
)


# ================================================================
# 17. FINAL PASS/FAIL
# ================================================================

print("\n" + "=" * 70)
print("AUDIT 15 COMPLETE")
print("=" * 70)

print("\nPASS CONDITIONS")
print("-" * 70)

print("✓ Development dataset = 49,000")
print("✓ Calibration dataset = 7,000")
print("✓ Locked test dataset = 14,000")
print("✓ No partition-level ID overlap")
print("✓ No duplicate development IDs")
print("✓ 5-fold outer stratified CV")
print("✓ Every development record appears once in outer validation")
print("✓ 4-fold inner CV inside every outer training set")
print("✓ Inner folds contain only outer-training records")
print("✓ No inner fold contains outer-validation records")
print("✓ Inner validation folds do not overlap")
print("✓ Inner validation covers each outer-training set exactly once")
print("✓ Expected outer fold sizes confirmed")
print("✓ Expected inner fold sizes confirmed")
print("✓ Stratification verified")

print("\nIMPORTANT:")
print("No model was trained.")
print("No feature selection was performed.")
print("No ADASYN was performed.")
print("No scaling was performed.")
print("No imputation was performed.")
print("No conformal calibration was performed.")
print("No locked-test evaluation was performed.")

print("\nSaved audit tables:")
print(f"  {outer_file}")
print(f"  {inner_file}")
print(f"  {protocol_file}")

print("\n" + "=" * 70)