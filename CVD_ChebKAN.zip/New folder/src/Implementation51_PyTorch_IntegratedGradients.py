# Implementation51_PyTorch_IntegratedGradients.py
# Final A8 CGS-ChebKAN interpretability using PyTorch-native Integrated Gradients.
# This script does NOT require SciPy, scikit-learn, or SHAP.
#
# Run from:
#   E:\CVD_CGS_ChebKAN
#
# Command:
#   python src\Implementation51_PyTorch_IntegratedGradients.py

import os
import json
import math
import csv
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

PROJECT = r"E:\CVD_CGS_ChebKAN"
CHECKPOINT = os.path.join(
    PROJECT, "results", "checkpoints", "implementation46_final_a8_final_model.pt"
)
TEST_FILE = os.path.join(
    PROJECT, "data", "processed", "kaggle_locked_test.csv"
)
OUT_DIR = os.path.join(PROJECT, "results", "interpretability")
TABLE_DIR = os.path.join(OUT_DIR, "tables")
FIG_DIR = os.path.join(OUT_DIR, "figures")

os.makedirs(TABLE_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)

SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]

GROUPS = {
    "demographic": ["age", "gender"],
    "physiological_metabolic": [
        "height", "weight", "ap_hi", "ap_lo", "cholesterol", "gluc"
    ],
    "lifestyle": ["smoke", "alco", "active"]
}

K = 5
EMBED_DIM = 16


def fail(msg):
    raise RuntimeError("\n[FAIL] " + msg)


def report(msg):
    print("[INFO]", msg)


def load_checkpoint():
    if not os.path.exists(CHECKPOINT):
        fail(f"Checkpoint not found: {CHECKPOINT}")

    ckpt = torch.load(CHECKPOINT, map_location="cpu", weights_only=False)

    required = [
        "model_state_dict", "features", "groups", "cheb_degree",
        "embedding_dim", "parameter_count", "preprocessing_medians",
        "preprocessing_minmax"
    ]
    missing = [x for x in required if x not in ckpt]
    if missing:
        fail(f"Checkpoint missing required keys: {missing}")

    if ckpt["features"] != FEATURES:
        fail("Checkpoint feature order does not match the frozen A8 feature order.")

    if ckpt["groups"] != GROUPS:
        fail("Checkpoint clinical groups do not match the frozen A8 grouping.")

    if int(ckpt["cheb_degree"]) != K:
        fail("Checkpoint Chebyshev degree is not K=5.")

    if int(ckpt["embedding_dim"]) != EMBED_DIM:
        fail("Checkpoint embedding dimension is not 16.")

    if int(ckpt["parameter_count"]) != 1924:
        fail(
            f"Unexpected parameter count: {ckpt['parameter_count']}. "
            "Expected final A8 count = 1924."
        )

    report("Checkpoint strict metadata validation: PASS")
    return ckpt


class ChebyshevKAN(nn.Module):
    def __init__(self, n_features, out_dim, degree=5):
        super().__init__()
        self.n_features = n_features
        self.out_dim = out_dim
        self.degree = degree
        self.coefficients = nn.Parameter(
            torch.zeros(out_dim, n_features, degree + 1)
        )
        self.bias = nn.Parameter(torch.zeros(out_dim))

    def forward(self, x):
        # x is expected in [-1, 1].
        t0 = torch.ones_like(x)
        terms = [t0]

        if self.degree >= 1:
            terms.append(x)

        for k in range(2, self.degree + 1):
            terms.append(2.0 * x * terms[-1] - terms[-2])

        T = torch.stack(terms, dim=-1)  # [B, F, K+1]

        # [B,F,K+1] x [O,F,K+1] -> [B,O]
        y = torch.einsum("bfk,ofk->bo", T, self.coefficients)
        return y + self.bias


class GroupBranch(nn.Module):
    def __init__(self, n_features, embedding_dim=16, degree=5):
        super().__init__()
        self.kan = ChebyshevKAN(
            n_features=n_features,
            out_dim=embedding_dim,
            degree=degree
        )

    def forward(self, x):
        return torch.nn.functional.silu(self.kan(x))


class A8Model(nn.Module):
    def __init__(self, group_sizes, degree=5, embedding_dim=16):
        super().__init__()

        self.branches = nn.ModuleDict({
            "demographic": GroupBranch(
                group_sizes["demographic"], embedding_dim, degree
            ),
            "physiological_metabolic": GroupBranch(
                group_sizes["physiological_metabolic"], embedding_dim, degree
            ),
            "lifestyle": GroupBranch(
                group_sizes["lifestyle"], embedding_dim, degree
            ),
        })

        self.gate_logits = nn.Parameter(torch.zeros(3))

        # Pairwise interactions:
        # demo*phys, demo*life, phys*life = 3*16 = 48.
        self.interaction_projection = nn.Linear(48, 16)

        # 16 gated fusion + 16 interaction representation.
        self.output_layer = nn.Linear(32, 1)

    def forward(self, x):
        group_names = [
            "demographic",
            "physiological_metabolic",
            "lifestyle"
        ]

        hs = []
        for g in group_names:
            idx = GROUP_INDICES[g]
            hg = self.branches[g](x[:, idx])
            hs.append(hg)

        gates = torch.softmax(self.gate_logits, dim=0)

        h_gate = (
            gates[0] * hs[0]
            + gates[1] * hs[1]
            + gates[2] * hs[2]
        )

        interactions = torch.cat([
            hs[0] * hs[1],
            hs[0] * hs[2],
            hs[1] * hs[2],
        ], dim=1)

        h_interaction = torch.nn.functional.silu(
            self.interaction_projection(interactions)
        )

        h = torch.cat([h_gate, h_interaction], dim=1)
        return self.output_layer(h).squeeze(1)


GROUP_INDICES = {
    "demographic": [0, 1],
    "physiological_metabolic": [2, 3, 4, 5, 6, 7],
    "lifestyle": [8, 9, 10],
}


def build_model(ckpt):
    model = A8Model(
        group_sizes={
            "demographic": 2,
            "physiological_metabolic": 6,
            "lifestyle": 3,
        },
        degree=K,
        embedding_dim=EMBED_DIM,
    )

    state = ckpt["model_state_dict"]
    model.load_state_dict(state, strict=True)
    model.to(DEVICE)
    model.eval()

    actual_params = sum(p.numel() for p in model.parameters())
    if actual_params != 1924:
        fail(f"Reconstructed model has {actual_params} parameters; expected 1924.")

    report("A8 strict state_dict load: PASS")
    report("A8 parameter count = 1924: PASS")
    return model


def preprocess_test(ckpt):
    if not os.path.exists(TEST_FILE):
        fail(f"Locked test file not found: {TEST_FILE}")

    df = pd.read_csv(TEST_FILE)

    missing = [f for f in FEATURES if f not in df.columns]
    if missing:
        fail(f"Locked test is missing features: {missing}")

    X = df[FEATURES].copy()

    med = np.asarray(ckpt["preprocessing_medians"], dtype=np.float64)
    mm = np.asarray(ckpt["preprocessing_minmax"], dtype=np.float64)

    if med.shape[0] != len(FEATURES):
        fail("Checkpoint preprocessing median length is incorrect.")
    if mm.shape != (len(FEATURES), 2):
        fail("Checkpoint preprocessing minmax shape is incorrect.")

    for j, f in enumerate(FEATURES):
        X[f] = pd.to_numeric(X[f], errors="coerce")
        X[f] = X[f].fillna(med[j])

    arr = X.to_numpy(dtype=np.float32)

    lo = mm[:, 0].astype(np.float32)
    hi = mm[:, 1].astype(np.float32)

    denom = hi - lo
    if np.any(denom <= 0):
        fail("Invalid preprocessing min-max range.")

    # Same min-max normalization used by the final checkpoint.
    arr = 2.0 * (arr - lo) / denom - 1.0
    arr = np.clip(arr, -1.0, 1.0)

    if not np.isfinite(arr).all():
        fail("Non-finite values remain after preprocessing.")

    y = None
    for candidate in ["cardio", "target", "label"]:
        if candidate in df.columns:
            y = pd.to_numeric(df[candidate], errors="coerce").to_numpy()
            break

    report(f"Locked test rows: {len(df)}")
    report("Preprocessing: PASS")
    return df, arr, y


def predict(model, X):
    with torch.no_grad():
        xt = torch.from_numpy(X).to(DEVICE)
        logits = model(xt)
        probs = torch.sigmoid(logits).detach().cpu().numpy()
    return probs


def verify_saved_probabilities(df, probs):
    # Implementation46 saved probabilities may be present in a prediction table.
    # Search likely final-prediction files without assuming one exists.
    candidates = []

    for root, _, files in os.walk(os.path.join(PROJECT, "results")):
        for fn in files:
            if fn.lower().endswith(".csv"):
                candidates.append(os.path.join(root, fn))

    matches = []
    for path in candidates:
        try:
            d = pd.read_csv(path, nrows=5)
        except Exception:
            continue

        cols = {c.lower() for c in d.columns}
        if "probability" in cols or "pred_probability" in cols or "y_prob" in cols:
            matches.append(path)

    # The exact saved final probability file name can differ by implementation.
    # Therefore, this check is informational rather than mandatory.
    if not matches:
        report("Saved final-probability CSV not found automatically; reproduction check skipped.")
        return

    report("Candidate probability files found; attempting exact-length/id matching.")

    # Search candidates for one with a probability column and same row count.
    for path in matches:
        try:
            d = pd.read_csv(path)
        except Exception:
            continue

        pcol = None
        for c in ["probability", "pred_probability", "y_prob"]:
            if c in d.columns:
                pcol = c
                break

        if pcol is None or len(d) != len(df):
            continue

        saved = pd.to_numeric(d[pcol], errors="coerce").to_numpy()
        if len(saved) != len(probs) or not np.isfinite(saved).all():
            continue

        diff = np.abs(saved - probs)
        report(
            f"Probability reproduction check candidate: {os.path.basename(path)}; "
            f"max_abs_diff={diff.max():.9g}, mean_abs_diff={diff.mean():.9g}"
        )
        return

    report("No automatically matching saved probability table was found; skipped.")


def integrated_gradients(
    model,
    x,
    baseline,
    steps=64,
    internal_batch=16
):
    """
    Integrated Gradients for sigmoid output probability.

    x:        [B,F]
    baseline: [B,F] or [1,F]
    Returns:  [B,F]

    Completeness is approximated by:
      sum_j attribution_j ~= f(x) - f(baseline)
    """

    model.eval()

    x = x.to(DEVICE)
    baseline = baseline.to(DEVICE)

    if baseline.shape[0] == 1 and x.shape[0] > 1:
        baseline = baseline.expand(x.shape[0], -1)

    total_grad = torch.zeros_like(x)

    # Avoid a very large graph by processing alpha values in batches.
    alphas = torch.linspace(
        1.0 / steps, 1.0, steps, device=DEVICE
    )

    for start in range(0, steps, internal_batch):
        a = alphas[start:start + internal_batch]

        # [A,B,F]
        interp = baseline.unsqueeze(0) + a[:, None, None] * (
            x.unsqueeze(0) - baseline.unsqueeze(0)
        )

        flat = interp.reshape(-1, x.shape[1]).detach()
        flat.requires_grad_(True)

        output = torch.sigmoid(model(flat))
        scalar = output.sum()

        grad = torch.autograd.grad(
            scalar,
            flat,
            create_graph=False,
            retain_graph=False
        )[0]

        grad = grad.reshape(len(a), x.shape[0], x.shape[1])
        total_grad += grad.sum(dim=0)

    avg_grad = total_grad / float(steps)
    attr = (x - baseline) * avg_grad

    return attr.detach()


def make_baseline(X):
    # Clinically neutral/simple reference in the normalized feature space:
    # the midpoint of each preprocessing range maps to 0.
    return np.zeros((1, X.shape[1]), dtype=np.float32)


def run_ig(model, X, n_samples=2000, steps=64):
    n = min(n_samples, len(X))
    # Fixed first n rows after a deterministic seed permutation.
    rng = np.random.default_rng(SEED)
    idx = rng.choice(len(X), size=n, replace=False)

    Xsel = X[idx]
    baseline = make_baseline(Xsel)

    attrs = []
    batch_size = 64

    report(
        f"Integrated Gradients: {n} test samples, "
        f"{steps} integration steps, device={DEVICE}"
    )

    for start in range(0, n, batch_size):
        xb = torch.from_numpy(Xsel[start:start + batch_size]).to(DEVICE)
        bb = torch.from_numpy(
            np.repeat(baseline, len(xb), axis=0)
        ).to(DEVICE)

        a = integrated_gradients(
            model, xb, bb,
            steps=steps,
            internal_batch=16
        )
        attrs.append(a.cpu().numpy())

        done = min(start + batch_size, n)
        if done % 256 == 0 or done == n:
            report(f"IG progress: {done}/{n}")

    attrs = np.concatenate(attrs, axis=0)

    return idx, Xsel, attrs


def save_feature_attribution(attrs):
    abs_mean = np.mean(np.abs(attrs), axis=0)
    signed_mean = np.mean(attrs, axis=0)

    out = pd.DataFrame({
        "feature": FEATURES,
        "mean_absolute_integrated_gradient": abs_mean,
        "mean_signed_integrated_gradient": signed_mean,
    }).sort_values(
        "mean_absolute_integrated_gradient",
        ascending=False
    )

    path = os.path.join(
        TABLE_DIR, "A8_integrated_gradients_global_feature_attribution.csv"
    )
    out.to_csv(path, index=False)
    report(f"Saved: {path}")
    return out


def save_group_attribution(attrs):
    rows = []

    for g, fs in GROUPS.items():
        inds = [FEATURES.index(f) for f in fs]
        vals = attrs[:, inds]

        rows.append({
            "group": g,
            "n_features": len(fs),
            "mean_absolute_group_attribution_sum":
                np.mean(np.sum(np.abs(vals), axis=1)),
            "mean_absolute_feature_attribution":
                np.mean(np.abs(vals)),
            "mean_signed_group_attribution_sum":
                np.mean(np.sum(vals, axis=1)),
        })

    out = pd.DataFrame(rows)

    path = os.path.join(
        TABLE_DIR, "A8_integrated_gradients_group_attribution.csv"
    )
    out.to_csv(path, index=False)
    report(f"Saved: {path}")
    return out


def save_sample_attributions(df, sample_indices, attrs):
    # Save a manageable long-form table.
    rows = []

    for i, original_idx in enumerate(sample_indices):
        row_id = (
            df.iloc[original_idx]["id"]
            if "id" in df.columns else original_idx
        )

        for j, feature in enumerate(FEATURES):
            rows.append({
                "test_row_index": int(original_idx),
                "id": row_id,
                "feature": feature,
                "integrated_gradient": float(attrs[i, j]),
                "absolute_integrated_gradient":
                    float(abs(attrs[i, j])),
            })

    out = pd.DataFrame(rows)

    path = os.path.join(
        TABLE_DIR, "A8_integrated_gradients_sample_level.csv"
    )
    out.to_csv(path, index=False)
    report(f"Saved: {path}")


def save_coefficient_comparison(model):
    rows = []

    for g, inds in GROUP_INDICES.items():
        branch = model.branches[g]
        coeff = branch.kan.coefficients.detach().cpu().numpy()

        # Feature-level aggregate coefficient magnitude.
        for local_j, global_j in enumerate(inds):
            feature = FEATURES[global_j]
            magnitude = float(np.mean(np.abs(coeff[:, local_j, :])))

            rows.append({
                "feature": feature,
                "group": g,
                "mean_absolute_chebyshev_coefficient": magnitude
            })

    out = pd.DataFrame(rows)

    path = os.path.join(
        TABLE_DIR, "A8_chebyshev_coefficient_feature_magnitude.csv"
    )
    out.to_csv(path, index=False)

    report(f"Saved: {path}")
    return out


def plot_global_attribution(global_df):
    d = global_df.sort_values(
        "mean_absolute_integrated_gradient",
        ascending=True
    )

    plt.figure(figsize=(8.5, 6.5))
    plt.barh(
        d["feature"],
        d["mean_absolute_integrated_gradient"]
    )
    plt.xlabel("Mean absolute Integrated Gradients attribution")
    plt.ylabel("Feature")
    plt.title("A8 Global Feature Attribution")
    plt.tight_layout()

    path = os.path.join(
        FIG_DIR, "A8_global_integrated_gradients.png"
    )
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    report(f"Saved: {path}")


def plot_signed_distribution(attrs):
    # Boxplot of attribution distributions by feature.
    plt.figure(figsize=(10, 6.5))
    plt.boxplot(
        [attrs[:, j] for j in range(len(FEATURES))],
        tick_labels=FEATURES,
        vert=True,
        showfliers=False
    )
    plt.axhline(0.0, linewidth=0.8)
    plt.ylabel("Integrated Gradients attribution")
    plt.xlabel("Feature")
    plt.title("A8 Feature Attribution Distributions")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    path = os.path.join(
        FIG_DIR, "A8_integrated_gradients_distribution.png"
    )
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    report(f"Saved: {path}")


def plot_group_attribution(group_df):
    d = group_df.sort_values(
        "mean_absolute_group_attribution_sum",
        ascending=True
    )

    plt.figure(figsize=(8, 5))
    plt.barh(
        d["group"],
        d["mean_absolute_group_attribution_sum"]
    )
    plt.xlabel("Mean absolute group attribution")
    plt.ylabel("Clinical group")
    plt.title("A8 Group-Level Integrated Gradients Attribution")
    plt.tight_layout()

    path = os.path.join(
        FIG_DIR, "A8_group_integrated_gradients.png"
    )
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()
    report(f"Saved: {path}")


def plot_ig_vs_coeff(ig_df, coeff_df):
    m = ig_df.merge(
        coeff_df[["feature", "mean_absolute_chebyshev_coefficient"]],
        on="feature",
        how="inner"
    )

    plt.figure(figsize=(7.5, 6))
    plt.scatter(
        m["mean_absolute_chebyshev_coefficient"],
        m["mean_absolute_integrated_gradient"]
    )

    for _, r in m.iterrows():
        plt.annotate(
            r["feature"],
            (
                r["mean_absolute_chebyshev_coefficient"],
                r["mean_absolute_integrated_gradient"]
            ),
            fontsize=8,
            xytext=(4, 4),
            textcoords="offset points"
        )

    plt.xlabel("Mean absolute Chebyshev coefficient magnitude")
    plt.ylabel("Mean absolute Integrated Gradients attribution")
    plt.title("A8 Coefficient Magnitude vs Feature Attribution")
    plt.tight_layout()

    path = os.path.join(
        FIG_DIR, "A8_IG_vs_Chebyshev_coefficients.png"
    )
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()

    # Pearson correlation computed without scipy.
    x = m["mean_absolute_chebyshev_coefficient"].to_numpy()
    y = m["mean_absolute_integrated_gradient"].to_numpy()

    if len(x) >= 2 and np.std(x) > 0 and np.std(y) > 0:
        corr = float(np.corrcoef(x, y)[0, 1])
    else:
        corr = float("nan")

    pd.DataFrame([{
        "n_features": len(m),
        "pearson_correlation":
            corr
    }]).to_csv(
        os.path.join(
            TABLE_DIR,
            "A8_IG_vs_Chebyshev_correlation.csv"
        ),
        index=False
    )

    report(f"IG vs coefficient Pearson correlation: {corr:.6f}")


def save_metadata(ckpt, n_samples, steps):
    meta = {
        "method": "PyTorch Integrated Gradients",
        "model": "CGS-ChebKAN A8",
        "checkpoint": CHECKPOINT,
        "parameter_count": 1924,
        "chebyshev_degree": K,
        "embedding_dimension": EMBED_DIM,
        "features": FEATURES,
        "groups": GROUPS,
        "device": str(DEVICE),
        "n_explanation_samples": int(n_samples),
        "integration_steps": int(steps),
        "baseline": "zero in normalized [-1,1] feature space",
        "locked_test_file": TEST_FILE,
        "note": (
            "Integrated Gradients is used as a complementary "
            "post-hoc attribution method; it is not reported as SHAP."
        )
    }

    path = os.path.join(
        TABLE_DIR, "A8_integrated_gradients_metadata.json"
    )
    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    report(f"Saved: {path}")


def main():
    print("=" * 78)
    print("Implementation51 - Final A8 Integrated Gradients Interpretability")
    print("=" * 78)

    report(f"Device: {DEVICE}")

    ckpt = load_checkpoint()
    model = build_model(ckpt)

    df, X, y = preprocess_test(ckpt)

    probs = predict(model, X)
    report(
        f"Prediction range: {probs.min():.6f} to {probs.max():.6f}"
    )

    verify_saved_probabilities(df, probs)

    # Explanation settings intentionally separate from model selection.
    N_SAMPLES = min(2000, len(X))
    IG_STEPS = 64

    sample_idx, Xsel, attrs = run_ig(
        model,
        X,
        n_samples=N_SAMPLES,
        steps=IG_STEPS
    )

    # Completeness diagnostic.
    x_t = torch.from_numpy(Xsel).to(DEVICE)
    b_t = torch.zeros_like(x_t)

    with torch.no_grad():
        fx = torch.sigmoid(model(x_t)).cpu().numpy()
        fb = torch.sigmoid(model(b_t)).cpu().numpy()

    completeness = attrs.sum(axis=1)
    residual = completeness - (fx - fb)

    completeness_df = pd.DataFrame({
        "sample_index": sample_idx,
        "f_x": fx,
        "f_baseline": fb,
        "sum_integrated_gradients": completeness,
        "f_x_minus_f_baseline": fx - fb,
        "completeness_residual": residual,
        "absolute_completeness_residual": np.abs(residual)
    })

    completeness_path = os.path.join(
        TABLE_DIR,
        "A8_integrated_gradients_completeness_check.csv"
    )
    completeness_df.to_csv(completeness_path, index=False)

    report(
        "Completeness mean absolute residual: "
        f"{np.mean(np.abs(residual)):.8f}"
    )

    global_df = save_feature_attribution(attrs)
    group_df = save_group_attribution(attrs)
    save_sample_attributions(df, sample_idx, attrs)
    coeff_df = save_coefficient_comparison(model)
    save_metadata(ckpt, N_SAMPLES, IG_STEPS)

    plot_global_attribution(global_df)
    plot_signed_distribution(attrs)
    plot_group_attribution(group_df)
    plot_ig_vs_coeff(global_df, coeff_df)

    # Save raw attribution matrix for reproducibility.
    raw_path = os.path.join(
        TABLE_DIR,
        "A8_integrated_gradients_raw.npy"
    )
    np.save(raw_path, attrs)
    report(f"Saved: {raw_path}")

    np.save(
        os.path.join(TABLE_DIR, "A8_integrated_gradients_sample_indices.npy"),
        sample_idx
    )

    # Save concise run summary.
    summary = {
        "status": "PASS_FINAL_A8_INTEGRATED_GRADIENTS",
        "parameter_count": 1924,
        "device": str(DEVICE),
        "test_rows": int(len(df)),
        "explanation_samples": int(N_SAMPLES),
        "integration_steps": int(IG_STEPS),
        "mean_absolute_completeness_residual":
            float(np.mean(np.abs(residual))),
        "top_features_by_mean_absolute_IG":
            global_df.head(11).to_dict(orient="records")
    }

    with open(
        os.path.join(TABLE_DIR, "A8_integrated_gradients_summary.json"),
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=2)

    print("\n" + "=" * 78)
    print("Implementation51 completed successfully.")
    print("=" * 78)
    print(f"Tables : {TABLE_DIR}")
    print(f"Figures: {FIG_DIR}")
    print("Status : PASS_FINAL_A8_INTEGRATED_GRADIENTS")


if __name__ == "__main__":
    main()
