# ============================================================
# Implementation51_Final_A8_SHAP.py
#
# SHAP-based interpretability for the FINAL A8 model
#
# No retraining
# No hyperparameter tuning
# No modification of checkpoint
# Locked test data only
# ============================================================

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import shap

warnings.filterwarnings("ignore")

# ============================================================
# 1. PATHS
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

CHECKPOINT_PATH = (
    PROJECT_ROOT
    / "results"
    / "checkpoints"
    / "implementation46_final_a8_final_model.pt"
)

TEST_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_locked_test.csv"
)

TABLES_DIR = PROJECT_ROOT / "results" / "tables"
FIGURES_DIR = PROJECT_ROOT / "results" / "figures"

TABLES_DIR.mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)

print("=" * 78)
print("IMPLEMENTATION 51 - FINAL A8 SHAP INTERPRETABILITY")
print("=" * 78)
print(f"Checkpoint: {CHECKPOINT_PATH}")
print(f"Test data : {TEST_PATH}")
print(f"Device    : {DEVICE}")

if torch.cuda.is_available():
    print(f"GPU       : {torch.cuda.get_device_name(0)}")

# ============================================================
# 2. LOAD CHECKPOINT
# ============================================================

if not CHECKPOINT_PATH.exists():
    raise FileNotFoundError(
        f"Checkpoint not found:\n{CHECKPOINT_PATH}"
    )

checkpoint = torch.load(
    CHECKPOINT_PATH,
    map_location="cpu",
    weights_only=False
)

state_dict = checkpoint["model_state_dict"]

features = list(checkpoint["features"])
groups = checkpoint["groups"]

K = int(checkpoint["cheb_degree"])
EMBED = int(checkpoint["embedding_dim"])

print("\nState-dict:")
for key, value in state_dict.items():
    print(f"{key:<65} {tuple(value.shape)}")

# ============================================================
# 3. EXACT CHEBKAN BRANCH
# ============================================================

class ExactChebKANBranch(nn.Module):

    def __init__(
        self,
        n_features,
        embedding_dim,
        degree
    ):
        super().__init__()

        self.coefficients = nn.Parameter(
            torch.zeros(
                embedding_dim,
                n_features,
                degree + 1
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(embedding_dim)
        )

    def chebyshev_basis(self, x):

        basis = [torch.ones_like(x)]

        if self.coefficients.shape[-1] > 1:
            basis.append(x)

        for k in range(
            2,
            self.coefficients.shape[-1]
        ):
            basis.append(
                2.0 * x * basis[-1] - basis[-2]
            )

        return torch.stack(basis, dim=-1)

    def forward(self, x):

        basis = self.chebyshev_basis(x)

        output = torch.einsum(
            "nfk,efk->ne",
            basis,
            self.coefficients
        )

        output = output + self.bias

        return torch.nn.functional.silu(output)


# ============================================================
# 4. EXACT A8 MODEL
# ============================================================

class ExactA8Model(nn.Module):

    def __init__(
        self,
        groups,
        degree=5,
        embedding_dim=16
    ):
        super().__init__()

        self.group_names = list(groups.keys())

        self.branches = nn.ModuleDict()

        for group_name, group_features in groups.items():

            self.branches[group_name] = nn.ModuleDict({
                "kan": ExactChebKANBranch(
                    len(group_features),
                    embedding_dim,
                    degree
                )
            })

        self.gate_logits = nn.Parameter(
            torch.zeros(len(self.group_names))
        )

        self.interaction_projection = nn.Linear(
            embedding_dim * 3,
            embedding_dim
        )

        self.output_layer = nn.Linear(
            embedding_dim * 2,
            1
        )

    def forward(self, x_by_group):

        embeddings = {}

        for group_name in self.group_names:
            embeddings[group_name] = (
                self.branches[group_name]["kan"](
                    x_by_group[group_name]
                )
            )

        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        gated = torch.zeros_like(
            embeddings[self.group_names[0]]
        )

        for i, group_name in enumerate(self.group_names):
            gated = (
                gated
                + gates[i] * embeddings[group_name]
            )

        demo = embeddings["demographic"]
        phys = embeddings["physiological_metabolic"]
        life = embeddings["lifestyle"]

        interactions = torch.cat(
            [
                demo * phys,
                demo * life,
                phys * life
            ],
            dim=1
        )

        interaction_embedding = (
            torch.nn.functional.silu(
                self.interaction_projection(interactions)
            )
        )

        fused = torch.cat(
            [gated, interaction_embedding],
            dim=1
        )

        logits = self.output_layer(
            fused
        ).squeeze(1)

        return logits


# ============================================================
# 5. LOAD MODEL
# ============================================================

model = ExactA8Model(
    groups=groups,
    degree=K,
    embedding_dim=EMBED
)

model.load_state_dict(
    state_dict,
    strict=True
)

model.to(DEVICE)
model.eval()

parameter_count = sum(
    p.numel() for p in model.parameters()
)

print("\n" + "=" * 78)
print("STRICT ARCHITECTURE VERIFICATION")
print("=" * 78)
print("STRICT LOAD: PASS")
print(f"Parameters: {parameter_count}")

if parameter_count != 1924:
    raise RuntimeError(
        f"Expected 1924 parameters, found {parameter_count}"
    )

# ============================================================
# 6. LOAD LOCKED TEST DATA
# ============================================================

if not TEST_PATH.exists():
    raise FileNotFoundError(
        f"Locked test file not found:\n{TEST_PATH}"
    )

test = pd.read_csv(TEST_PATH)

if len(test) != 14000:
    raise RuntimeError(
        f"Expected 14,000 locked-test rows; found {len(test)}"
    )

print("\nLocked test rows:", len(test))

# ============================================================
# 7. PREPROCESSING
# ============================================================

medians = checkpoint["preprocessing_medians"]
minmax = checkpoint["preprocessing_minmax"]

print("Preprocessing metadata verified.")
print("Median metadata type:", type(medians))
print("Min-max metadata type:", type(minmax))


def get_median(metadata, index):
    arr = np.asarray(
        metadata[index],
        dtype=float
    ).reshape(-1)

    return float(arr[0])


def get_minmax(metadata, index):
    arr = np.asarray(
        metadata[index],
        dtype=float
    ).reshape(-1)

    if len(arr) < 2:
        raise ValueError(
            f"Invalid min/max metadata for feature index {index}: {arr}"
        )

    return float(arr[0]), float(arr[1])


def preprocess(df):

    work = df.copy()

    for i, feature in enumerate(features):

        work[feature] = pd.to_numeric(
            work[feature],
            errors="coerce"
        )

        work[feature] = work[feature].fillna(
            get_median(medians, i)
        )

    X = work[features].astype(
        np.float32
    ).copy()

    for i, feature in enumerate(features):

        lo, hi = get_minmax(
            minmax,
            i
        )

        if hi == lo:
            X[feature] = 0.0
        else:
            X[feature] = (
                2.0
                * (
                    (X[feature] - lo)
                    / (hi - lo)
                )
                - 1.0
            )

    return X.clip(-1.0, 1.0)


X_df = preprocess(test)

print("Preprocessing: PASS")

# ============================================================
# 8. PREDICTION WRAPPER FOR SHAP
# ============================================================

def predict_probability(X_numpy):

    X_numpy = np.asarray(
        X_numpy,
        dtype=np.float32
    )

    X_tensor = torch.tensor(
        X_numpy,
        dtype=torch.float32,
        device=DEVICE
    )

    group_inputs = {}
    start = 0

    for group_name, group_features in groups.items():

        n_features = len(group_features)

        group_inputs[group_name] = (
            X_tensor[:, start:start + n_features]
        )

        start += n_features

    with torch.no_grad():

        logits = model(group_inputs)

        probabilities = torch.sigmoid(logits)

    return probabilities.detach().cpu().numpy()


X_numpy = X_df[features].values.astype(
    np.float32
)

final_probabilities = predict_probability(
    X_numpy
)

print("\nPrediction generation: PASS")
print(
    "Probability range:",
    f"{final_probabilities.min():.9f}",
    "to",
    f"{final_probabilities.max():.9f}"
)

# ============================================================
# 9. SHAP SAMPLE
# ============================================================

rng = np.random.default_rng(2026)

BACKGROUND_SIZE = 200
EXPLANATION_SIZE = 2000

background_indices = rng.choice(
    len(X_numpy),
    size=min(BACKGROUND_SIZE, len(X_numpy)),
    replace=False
)

explanation_indices = rng.choice(
    len(X_numpy),
    size=min(EXPLANATION_SIZE, len(X_numpy)),
    replace=False
)

background = X_numpy[background_indices]
explanation_data = X_numpy[explanation_indices]

print("\nSHAP background samples:", len(background))
print("SHAP explanation samples:", len(explanation_data))

# ============================================================
# 10. SHAP EXPLAINER
# ============================================================

print("\nCreating SHAP explainer...")

explainer = shap.Explainer(
    predict_probability,
    background,
    feature_names=features
)

print("SHAP explainer created.")

# ============================================================
# 11. COMPUTE SHAP VALUES
# ============================================================

print("\nComputing SHAP values...")
print("This may take some time on the RTX 3050.")

shap_result = explainer(
    explanation_data
)

shap_values = shap_result.values

if shap_values.ndim == 3:
    shap_values = shap_values[:, :, 0]

print(
    "SHAP matrix shape:",
    shap_values.shape
)

if shap_values.shape != (
    len(explanation_data),
    len(features)
):
    raise RuntimeError(
        f"Unexpected SHAP shape: {shap_values.shape}"
    )

# ============================================================
# 12. SAVE RAW SHAP VALUES
# ============================================================

shap_table = pd.DataFrame(
    shap_values,
    columns=features
)

shap_table.to_csv(
    TABLES_DIR / "implementation51_a8_shap_values.csv",
    index=False
)

# ============================================================
# 13. GLOBAL SHAP IMPORTANCE
# ============================================================

global_shap = pd.DataFrame({

    "feature": features,

    "mean_abs_shap": np.mean(
        np.abs(shap_values),
        axis=0
    ),

    "mean_shap": np.mean(
        shap_values,
        axis=0
    )
})

global_shap = global_shap.sort_values(
    "mean_abs_shap",
    ascending=False
).reset_index(drop=True)

global_shap["rank"] = np.arange(
    1,
    len(global_shap) + 1
)

global_shap.to_csv(
    TABLES_DIR / "implementation51_a8_global_shap_importance.csv",
    index=False
)

print("\nGlobal SHAP importance:")
print(
    global_shap.to_string(index=False)
)

# ============================================================
# 14. GLOBAL SHAP BAR PLOT
# ============================================================

plt.figure(figsize=(8, 6))

plt.barh(
    global_shap["feature"][::-1],
    global_shap["mean_abs_shap"][::-1]
)

plt.xlabel("Mean absolute SHAP value")
plt.ylabel("Feature")
plt.title("Final A8 Global Feature Importance")

plt.tight_layout()

plt.savefig(
    FIGURES_DIR / "implementation51_a8_global_shap_importance.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

# ============================================================
# 15. SHAP SUMMARY PLOT
# ============================================================

plt.figure()

shap.summary_plot(
    shap_values,
    explanation_data,
    feature_names=features,
    show=False
)

plt.tight_layout()

plt.savefig(
    FIGURES_DIR / "implementation51_a8_shap_summary.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

# ============================================================
# 16. GROUP-LEVEL SHAP IMPORTANCE
# ============================================================

group_rows = []

for group_name, group_features in groups.items():

    group_values = global_shap[
        global_shap["feature"].isin(group_features)
    ]

    group_rows.append({

        "group": group_name,

        "mean_abs_shap_sum":
            group_values["mean_abs_shap"].sum(),

        "mean_abs_shap_average":
            group_values["mean_abs_shap"].mean(),

        "number_of_features":
            len(group_features)
    })

group_shap = pd.DataFrame(group_rows)

group_shap["relative_contribution"] = (
    group_shap["mean_abs_shap_sum"]
    / group_shap["mean_abs_shap_sum"].sum()
)

group_shap.to_csv(
    TABLES_DIR / "implementation51_a8_group_shap_importance.csv",
    index=False
)

print("\nGroup-level SHAP:")
print(
    group_shap.to_string(index=False)
)

# ============================================================
# 17. COMPARE SHAP WITH CHEBYSHEV COEFFICIENT ANALYSIS
# ============================================================

coefficient_path = (
    TABLES_DIR
    / "implementation50_a8_feature_coefficient_importance.csv"
)

if coefficient_path.exists():

    coefficient_df = pd.read_csv(
        coefficient_path
    )

    coefficient_df = coefficient_df[
        [
            "group",
            "feature",
            "mean_abs_coefficient"
        ]
    ]

    comparison = global_shap.merge(
        coefficient_df,
        on="feature",
        how="left"
    )

    comparison["chebyshev_rank"] = (
        comparison["mean_abs_coefficient"]
        .rank(
            ascending=False,
            method="min"
        )
        .astype(int)
    )

    comparison.to_csv(
        TABLES_DIR
        / "implementation51_a8_shap_vs_chebyshev_comparison.csv",
        index=False
    )

    print(
        "\nSHAP vs Chebyshev comparison saved."
    )

# ============================================================
# 18. SAVE PREDICTIONS USED FOR SHAP
# ============================================================

shap_prediction_table = test.iloc[
    explanation_indices
].copy()

shap_prediction_table["a8_probability"] = (
    final_probabilities[explanation_indices]
)

shap_prediction_table["a8_prediction"] = (
    shap_prediction_table["a8_probability"] >= 0.50
).astype(int)

shap_prediction_table.to_csv(
    TABLES_DIR
    / "implementation51_a8_shap_prediction_cohort.csv",
    index=False
)

# ============================================================
# 19. SAVE SUMMARY
# ============================================================

summary = {

    "status": "PASS",

    "checkpoint": str(CHECKPOINT_PATH),

    "model_parameter_count": int(parameter_count),

    "locked_test_size": int(len(test)),

    "shap_background_size": int(len(background)),

    "shap_explanation_size": int(len(explanation_data)),

    "features": features,

    "top_features_by_mean_abs_shap":
        global_shap.head(10)["feature"].tolist(),

    "global_shap_importance":
        global_shap.to_dict(orient="records"),

    "group_shap_importance":
        group_shap.to_dict(orient="records")
}

with open(
    TABLES_DIR / "implementation51_a8_shap_summary.json",
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        summary,
        f,
        indent=2
    )

# ============================================================
# 20. FINISH
# ============================================================

print("\n" + "=" * 78)
print("IMPLEMENTATION 51 COMPLETED")
print("=" * 78)
print("SHAP analysis: PASS")
print(
    "Global SHAP table:",
    TABLES_DIR / "implementation51_a8_global_shap_importance.csv"
)
print(
    "Group SHAP table:",
    TABLES_DIR / "implementation51_a8_group_shap_importance.csv"
)
print(
    "Figures:",
    FIGURES_DIR
)
print("=" * 78)
