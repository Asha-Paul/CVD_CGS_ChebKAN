# ============================================================
# IMPLEMENTATION 43B-1
# IDENTITY RECONCILIATION AUDIT
# ============================================================
#
# PURPOSE
# -------
# Establish whether the 49,000 outer-CV prediction files
# correspond to exactly the same development observations.
#
# IMPORTANT
# ---------
# This script:
#   - DOES NOT retrain models
#   - DOES NOT perform statistical significance testing
#   - DOES NOT use the 14,000-row locked test set
#   - DOES NOT use UCI external data
#   - DOES NOT assume row order means observation identity
#
# The purpose is ONLY to establish a defensible common
# observation identity for paired statistical comparison.
#
# ============================================================

import os
import json
import hashlib
import warnings
from pathlib import Path

import numpy as np
import pandas as pd


# ============================================================
# CONFIGURATION
# ============================================================

PROJECT_ROOT = Path(".")

RESULTS_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

DATA_PROCESSED_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)

DATA_RAW_KAGGLE_DIR = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
)

# ------------------------------------------------------------
# Known project files
# ------------------------------------------------------------

BP_CONTROLLED_FILE = (
    DATA_PROCESSED_DIR
    / "kaggle_bp_quality_controlled.csv"
)

RAW_KAGGLE_FILE = (
    DATA_RAW_KAGGLE_DIR
    / "cardio_train 70k.csv"
)

# ------------------------------------------------------------
# Prediction files
# ------------------------------------------------------------

MODEL_FILES = {

    "CGS-ChebKAN_A6":
        "implementation31b_reduced_corrected_a6_outer_predictions.csv",

    "Logistic_Regression":
        "implementation22_logistic_outer_predictions.csv",

    "Random_Forest":
        "implementation23_random_forest_outer_predictions.csv",

    "XGBoost":
        "implementation24_xgboost_outer_predictions.csv",

    "MLP":
        "implementation25_mlp_outer_predictions.csv",

    "B-spline_KAN":
        "implementation26_bspline_kan_outer_predictions.csv",

    "Vanilla_Chebyshev_KAN":
        "implementation27_chebyshev_outer_predictions.csv",

    "Fourier_KAN":
        "implementation28_fourier_kan_outer_predictions.csv",
}


# ------------------------------------------------------------
# Expected cohort size
# ------------------------------------------------------------

EXPECTED_TOTAL_ROWS = 70000

EXPECTED_DEVELOPMENT_ROWS = 49000

EXPECTED_CALIBRATION_ROWS = 7000

EXPECTED_TEST_ROWS = 14000


# ------------------------------------------------------------
# Output files
# ------------------------------------------------------------

OUTPUT_AUDIT = (
    RESULTS_DIR
    / "implementation43B1_identity_reconciliation_audit.csv"
)

OUTPUT_JSON = (
    RESULTS_DIR
    / "implementation43B1_identity_reconciliation_audit.json"
)

OUTPUT_REPORT = (
    RESULTS_DIR
    / "implementation43B1_identity_reconciliation_report.txt"
)

OUTPUT_MAPPING = (
    RESULTS_DIR
    / "implementation43B1_identity_mapping_summary.csv"
)

OUTPUT_ID_RANGES = (
    RESULTS_DIR
    / "implementation43B1_identity_ranges.csv"
)


# ============================================================
# GENERAL FUNCTIONS
# ============================================================

def sha256_file(path):

    h = hashlib.sha256()

    with open(path, "rb") as f:

        for chunk in iter(
            lambda: f.read(1024 * 1024),
            b""
        ):

            h.update(chunk)

    return h.hexdigest()


def find_existing_file(candidates):

    for path in candidates:

        if path is not None and path.exists():

            return path

    return None


def print_header(title):

    print(
        "\n============================================================"
    )

    print(title)

    print(
        "============================================================"
    )


# ============================================================
# LOCATE KAGGLE SOURCE DATA
# ============================================================

def locate_kaggle_data():

    print_header(
        "LOCATING KAGGLE SOURCE DATA"
    )

    candidates = [

        BP_CONTROLLED_FILE,

        RAW_KAGGLE_FILE,

        DATA_PROCESSED_DIR
        / "kaggle_cardio_train.csv",

        DATA_PROCESSED_DIR
        / "kaggle_processed.csv",

        DATA_PROCESSED_DIR
        / "cardio_train.csv",
    ]

    path = find_existing_file(
        candidates
    )

    if path is None:

        print(
            "\nCould not automatically locate the "
            "Kaggle source file."
        )

        print(
            "\nChecked:"
        )

        for p in candidates:

            print(
                f"  {p}"
            )

        raise FileNotFoundError(
            "\nKaggle source data not found."
        )

    print(
        f"\nUsing source data:\n{path}"
    )

    print(
        f"SHA256: {sha256_file(path)}"
    )

    return path


# ============================================================
# LOAD KAGGLE SOURCE
# ============================================================

def load_kaggle_source():

    path = locate_kaggle_data()

    df = pd.read_csv(
        path
    )

    print(
        f"\nRows: {len(df):,}"
    )

    print(
        f"Columns: {list(df.columns)}"
    )

    if len(df) != EXPECTED_TOTAL_ROWS:

        raise RuntimeError(
            f"Expected 70,000 Kaggle rows, "
            f"found {len(df):,}."
        )

    if "id" not in df.columns:

        raise RuntimeError(
            "Kaggle source does not contain 'id'."
        )

    if "cardio" not in df.columns:

        raise RuntimeError(
            "Kaggle source does not contain 'cardio'."
        )

    return df, path


# ============================================================
# BASIC SOURCE AUDIT
# ============================================================

def audit_source(df):

    print_header(
        "KAGGLE SOURCE ID AUDIT"
    )

    ids = pd.to_numeric(
        df["id"],
        errors="coerce"
    )

    if ids.isna().any():

        raise RuntimeError(
            "Kaggle source contains invalid IDs."
        )

    ids = ids.astype(int)

    unique_ids = (
        ids.nunique()
        ==
        len(ids)
    )

    print(
        f"Rows: {len(df):,}"
    )

    print(
        f"Unique IDs: {ids.nunique():,}"
    )

    print(
        f"ID range: {ids.min()} - {ids.max()}"
    )

    print(
        f"IDs unique: {unique_ids}"
    )

    if not unique_ids:

        raise RuntimeError(
            "Kaggle source IDs are not unique."
        )

    target = pd.to_numeric(
        df["cardio"],
        errors="coerce"
    )

    if target.isna().any():

        raise RuntimeError(
            "Kaggle source target contains NaN."
        )

    target = target.astype(int)

    print(
        f"Target values: {sorted(target.unique())}"
    )

    return df.copy()


# ============================================================
# RECONSTRUCT FROZEN DEVELOPMENT COHORT
# ============================================================
#
# IMPORTANT
# ---------
# The prediction files contain 49,000 observations.
#
# We need to determine which 49,000 source observations
# they represent.
#
# Because the original partitioning script may have used a
# particular random seed, this function searches for the
# development cohort by comparing prediction IDs where
# possible.
#
# It does NOT assume that the first 49,000 rows are the
# development set.
# ============================================================

def inspect_prediction_files():

    print_header(
        "INSPECTING OUTER-CV PREDICTION FILES"
    )

    loaded = {}

    for model_name, filename in (
        MODEL_FILES.items()
    ):

        path = (
            RESULTS_DIR
            / filename
        )

        if not path.exists():

            raise FileNotFoundError(
                f"Missing prediction file:\n{path}"
            )

        df = pd.read_csv(
            path
        )

        print(
            f"\n{model_name}"
        )

        print(
            f"  File: {filename}"
        )

        print(
            f"  Rows: {len(df):,}"
        )

        print(
            f"  Columns: {list(df.columns)}"
        )

        if len(df) != EXPECTED_DEVELOPMENT_ROWS:

            raise RuntimeError(
                f"{model_name}: "
                f"expected 49,000 rows, "
                f"found {len(df):,}."
            )

        loaded[
            model_name
        ] = {

            "path":
                path,

            "data":
                df,

            "sha256":
                sha256_file(path),
        }

    return loaded


# ============================================================
# IDENTIFY ID COLUMN
# ============================================================

def identify_identity_column(
    df
):

    candidates = [

        "id",

        "row_index",

        "sample_index",
    ]

    for c in candidates:

        if c in df.columns:

            return c

    return None


# ============================================================
# IDENTIFY TARGET COLUMN
# ============================================================

def identify_target_column(
    df
):

    candidates = [

        "y_true",

        "true_label",

        "cardio",

        "target",

        "target_binary",
    ]

    for c in candidates:

        if c in df.columns:

            return c

    return None


# ============================================================
# PREDICTION FILE STRUCTURE AUDIT
# ============================================================

def audit_prediction_structures(
    loaded
):

    print_header(
        "PREDICTION FILE STRUCTURE AUDIT"
    )

    rows = []

    for model_name, info in (
        loaded.items()
    ):

        df = info[
            "data"
        ]

        identity_col = (
            identify_identity_column(
                df
            )
        )

        target_col = (
            identify_target_column(
                df
            )
        )

        identity_unique = None
        identity_min = None
        identity_max = None

        if identity_col is not None:

            identity = pd.to_numeric(
                df[identity_col],
                errors="coerce"
            )

            valid_identity = (
                not identity.isna().any()
            )

            if valid_identity:

                identity = (
                    identity.astype(int)
                )

                identity_unique = (
                    identity.nunique()
                    ==
                    len(identity)
                )

                identity_min = int(
                    identity.min()
                )

                identity_max = int(
                    identity.max()
                )

        else:

            valid_identity = False

        print(
            f"\n{model_name}"
        )

        print(
            f"  Identity column: "
            f"{identity_col}"
        )

        print(
            f"  Target column: "
            f"{target_col}"
        )

        print(
            f"  Identity valid: "
            f"{valid_identity}"
        )

        print(
            f"  Identity unique: "
            f"{identity_unique}"
        )

        if identity_min is not None:

            print(
                f"  Identity range: "
                f"{identity_min} - "
                f"{identity_max}"
            )

        rows.append({

            "model":
                model_name,

            "rows":
                len(df),

            "identity_column":
                identity_col,

            "target_column":
                target_col,

            "identity_valid":
                valid_identity,

            "identity_unique":
                identity_unique,

            "identity_min":
                identity_min,

            "identity_max":
                identity_max,
        })

    output = pd.DataFrame(
        rows
    )

    output.to_csv(
        OUTPUT_ID_RANGES,
        index=False
    )

    return output


# ============================================================
# DIRECT ID SET COMPARISON
# ============================================================
#
# This is the most important first test.
#
# If a prediction file has `id`, compare it directly with
# the original Kaggle source IDs.
#
# If it has `row_index`, determine whether those values are
# actually Kaggle IDs or positional row indices.
# ============================================================

def compare_prediction_ids_to_source(
    source_df,
    loaded
):

    print_header(
        "PREDICTION ID VS KAGGLE SOURCE AUDIT"
    )

    source_ids = set(
        pd.to_numeric(
            source_df["id"]
        )
        .astype(int)
        .tolist()
    )

    rows = []

    for model_name, info in (
        loaded.items()
    ):

        df = info[
            "data"
        ]

        identity_col = (
            identify_identity_column(
                df
            )
        )

        if identity_col is None:

            print(
                f"\n{model_name}: "
                f"NO IDENTITY COLUMN"
            )

            rows.append({

                "model":
                    model_name,

                "identity_column":
                    None,

                "identity_interpreted_as_kaggle_id":
                    False,

                "identity_unique":
                    False,

                "n_prediction_ids":
                    49000,

                "n_overlap_with_kaggle_ids":
                    None,

                "n_missing_from_kaggle":
                    None,

                "n_extra_not_in_kaggle":
                    None,

                "exact_set_match":
                    False,

                "status":
                    "UNVERIFIED",

                "reason":
                    "No observation identity in prediction file.",
            })

            continue

        identity = pd.to_numeric(
            df[identity_col],
            errors="coerce"
        )

        if identity.isna().any():

            rows.append({

                "model":
                    model_name,

                "identity_column":
                    identity_col,

                "identity_interpreted_as_kaggle_id":
                    False,

                "identity_unique":
                    False,

                "n_prediction_ids":
                    49000,

                "n_overlap_with_kaggle_ids":
                    None,

                "n_missing_from_kaggle":
                    None,

                "n_extra_not_in_kaggle":
                    None,

                "exact_set_match":
                    False,

                "status":
                    "FAIL",

                "reason":
                    "Identity column contains missing values.",
            })

            continue

        identity = (
            identity.astype(int)
        )

        prediction_ids = set(
            identity.tolist()
        )

        unique = (
            len(prediction_ids)
            ==
            len(identity)
        )

        overlap = (
            prediction_ids
            &
            source_ids
        )

        missing = (
            source_ids
            -
            prediction_ids
        )

        extra = (
            prediction_ids
            -
            source_ids
        )

        exact_match = (
            prediction_ids
            ==
            source_ids
        )

        print(
            f"\n{model_name}"
        )

        print(
            f"  Identity column: "
            f"{identity_col}"
        )

        print(
            f"  Unique: "
            f"{unique}"
        )

        print(
            f"  Overlap with Kaggle IDs: "
            f"{len(overlap):,}"
        )

        print(
            f"  Missing from source: "
            f"{len(missing):,}"
        )

        print(
            f"  Extra IDs: "
            f"{len(extra):,}"
        )

        print(
            f"  Exact 70k ID-set match: "
            f"{exact_match}"
        )

        # A 49k prediction set should normally be a subset
        # of the 70k source IDs, not equal to all 70k.
        #
        # Therefore exact_match=False is NOT a failure.
        #
        # What matters is:
        #   - all 49k prediction identities are valid source IDs
        #   - identities are unique.
        subset_valid = (
            unique
            and
            len(extra) == 0
            and
            len(overlap) == 49000
        )

        if subset_valid:

            status = "PASS"

            reason = (
                "All 49,000 prediction identities are "
                "unique valid Kaggle IDs."
            )

        else:

            status = "FAIL"

            reason = (
                "Prediction identity values cannot be "
                "treated directly as Kaggle IDs."
            )

        rows.append({

            "model":
                model_name,

            "identity_column":
                identity_col,

            "identity_interpreted_as_kaggle_id":
                True,

            "identity_unique":
                unique,

            "n_prediction_ids":
                len(prediction_ids),

            "n_overlap_with_kaggle_ids":
                len(overlap),

            "n_missing_from_kaggle":
                len(missing),

            "n_extra_not_in_kaggle":
                len(extra),

            "exact_set_match":
                exact_match,

            "status":
                status,

            "reason":
                reason,
        })

    return pd.DataFrame(
        rows
    )


# ============================================================
# DETERMINE DEVELOPMENT COHORT FROM ID-BASED FILES
# ============================================================
#
# The intersection of exact 49k ID sets from valid prediction
# files can reveal the common development cohort.
#
# We DO NOT assume all prediction files use the same identity
# system.
# ============================================================

def determine_common_cohort(
    source_df,
    loaded,
    id_audit
):

    print_header(
        "DETERMINING COMMON 49,000-ROW DEVELOPMENT COHORT"
    )

    valid_sets = {}

    for _, row in (
        id_audit.iterrows()
    ):

        model_name = row[
            "model"
        ]

        if row[
            "status"
        ] != "PASS":

            continue

        identity_col = row[
            "identity_column"
        ]

        df = loaded[
            model_name
        ][
            "data"
        ]

        ids = pd.to_numeric(
            df[
                identity_col
            ],
            errors="coerce"
        ).astype(int)

        valid_sets[
            model_name
        ] = set(
            ids.tolist()
        )

    if len(valid_sets) == 0:

        print(
            "\nNo prediction file contains an "
            "identity set that can be treated as "
            "Kaggle IDs."
        )

        return None

    print(
        "\nValid direct Kaggle-ID prediction sets:"
    )

    for model_name, ids in (
        valid_sets.items()
    ):

        print(
            f"  {model_name}: "
            f"{len(ids):,} IDs"
        )

    # Start with the first set
    common_ids = set(
        next(
            iter(
                valid_sets.values()
            )
        )
    )

    for ids in (
        list(
            valid_sets.values()
        )[1:]
    ):

        common_ids &= ids

    print(
        f"\nIntersection size: "
        f"{len(common_ids):,}"
    )

    if len(common_ids) == 49000:

        print(
            "\nPASS: "
            "A common 49,000-observation identity "
            "set has been established."
        )

        return common_ids

    print(
        "\nThe intersection is not 49,000."
    )

    print(
        "This means at least one prediction file uses "
        "a different identity convention or cohort."
    )

    return common_ids


# ============================================================
# TARGET ALIGNMENT USING DIRECT KAGGLE IDs
# ============================================================

def verify_target_after_alignment(
    source_df,
    loaded,
    id_audit,
    common_ids
):

    print_header(
        "TARGET VERIFICATION AFTER IDENTITY ALIGNMENT"
    )

    if common_ids is None:

        print(
            "No common cohort available."
        )

        return pd.DataFrame()

    source_indexed = (
        source_df
        .copy()
        .set_index("id")
    )

    rows = []

    for _, audit in (
        id_audit.iterrows()
    ):

        model_name = audit[
            "model"
        ]

        if audit[
            "status"
        ] != "PASS":

            continue

        identity_col = audit[
            "identity_column"
        ]

        df = loaded[
            model_name
        ][
            "data"
        ]

        identity = pd.to_numeric(
            df[
                identity_col
            ],
            errors="coerce"
        ).astype(int)

        temp = pd.DataFrame({

            "id":
                identity,

            "prediction_target":
                pd.to_numeric(
                    df[
                        identify_target_column(
                            df
                        )
                    ],
                    errors="coerce"
                ).astype(int)
        })

        temp = temp[
            temp[
                "id"
            ].isin(
                common_ids
            )
        ]

        temp = (
            temp
            .drop_duplicates(
                "id"
            )
            .set_index("id")
        )

        source_target = (
            source_indexed.loc[
                list(
                    common_ids
                ),
                "cardio"
            ]
            .astype(int)
        )

        prediction_target = (
            temp.loc[
                list(
                    common_ids
                ),
                "prediction_target"
            ]
            .astype(int)
        )

        matches = np.array_equal(

            source_target.to_numpy(),

            prediction_target.to_numpy()
        )

        mismatch_count = int(
            np.sum(
                source_target.to_numpy()
                !=
                prediction_target.to_numpy()
            )
        )

        print(
            f"\n{model_name}"
        )

        print(
            f"  Common observations: "
            f"{len(common_ids):,}"
        )

        print(
            f"  Target matches source: "
            f"{matches}"
        )

        print(
            f"  Target mismatches: "
            f"{mismatch_count:,}"
        )

        rows.append({

            "model":
                model_name,

            "n_common":
                len(common_ids),

            "target_matches_source":
                matches,

            "target_mismatch_count":
                mismatch_count,

            "status":
                "PASS"
                if matches
                else "FAIL",
        })

    return pd.DataFrame(
        rows
    )


# ============================================================
# REPORT
# ============================================================

def create_report(
    source_path,
    structure_audit,
    id_audit,
    common_ids,
    target_audit
):

    lines = []

    lines.append(
        "IMPLEMENTATION 43B-1"
    )

    lines.append(
        "IDENTITY RECONCILIATION AUDIT"
    )

    lines.append(
        "=" * 70
    )

    lines.append("")

    lines.append(
        f"Source data: {source_path}"
    )

    lines.append(
        f"Expected Kaggle rows: "
        f"{EXPECTED_TOTAL_ROWS:,}"
    )

    lines.append(
        f"Expected development rows: "
        f"{EXPECTED_DEVELOPMENT_ROWS:,}"
    )

    lines.append("")

    lines.append(
        "PURPOSE"
    )

    lines.append(
        "-" * 70
    )

    lines.append(
        "Establish whether the outer-CV prediction files "
        "correspond to the same observations."
    )

    lines.append(
        "Row order is not assumed to represent observation "
        "identity."
    )

    lines.append(
        "No statistical testing was performed."
    )

    lines.append(
        "No model was retrained."
    )

    lines.append(
        "The locked 14,000-row test set was not used."
    )

    lines.append("")

    lines.append(
        "PREDICTION FILE STRUCTURE"
    )

    lines.append(
        "-" * 70
    )

    for _, row in (
        structure_audit.iterrows()
    ):

        lines.append(
            f"{row['model']}: "
            f"identity={row['identity_column']}, "
            f"target={row['target_column']}, "
            f"unique={row['identity_unique']}"
        )

    lines.append("")

    lines.append(
        "IDENTITY VS SOURCE"
    )

    lines.append(
        "-" * 70
    )

    for _, row in (
        id_audit.iterrows()
    ):

        lines.append(
            f"{row['model']}: "
            f"{row['status']} - "
            f"{row['reason']}"
        )

    lines.append("")

    if common_ids is not None:

        lines.append(
            f"Common identity intersection: "
            f"{len(common_ids):,}"
        )

    else:

        lines.append(
            "Common identity intersection: "
            "NOT ESTABLISHED"
        )

    lines.append("")

    lines.append(
        "TARGET VERIFICATION AFTER ALIGNMENT"
    )

    lines.append(
        "-" * 70
    )

    if len(target_audit) == 0:

        lines.append(
            "Not performed because a common identity "
            "cohort was not established."
        )

    else:

        for _, row in (
            target_audit.iterrows()
        ):

            lines.append(
                f"{row['model']}: "
                f"{row['status']} - "
                f"mismatches="
                f"{row['target_mismatch_count']}"
            )

    lines.append("")

    lines.append(
        "FINAL STATUS"
    )

    lines.append(
        "-" * 70
    )

    direct_models = (
        id_audit[
            id_audit[
                "status"
            ]
            ==
            "PASS"
        ]
    )

    if (
        common_ids is not None
        and
        len(common_ids) == 49000
        and
        len(target_audit) > 0
        and
        target_audit[
            "status"
        ].eq(
            "PASS"
        ).all()
    ):

        lines.append(
            "PASS_COMMON_49000_COHORT_ESTABLISHED"
        )

        lines.append(
            "Paired statistical comparison can proceed "
            "for models with exact identity alignment."
        )

    elif len(direct_models) > 0:

        lines.append(
            "PARTIAL_IDENTITY_RECONCILIATION"
        )

        lines.append(
            "Some models have valid direct identities, "
            "but a complete common cohort has not yet "
            "been established."
        )

    else:

        lines.append(
            "IDENTITY_RECONCILIATION_INCOMPLETE"
        )

        lines.append(
            "Do not perform paired statistical testing yet."
        )

    with open(
        OUTPUT_REPORT,
        "w",
        encoding="utf-8"
    ) as f:

        f.write(
            "\n".join(lines)
        )


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    source_path,
    structure_audit,
    id_audit,
    common_ids,
    target_audit
):

    payload = {

        "implementation":
            "43B-1",

        "purpose":
            "Identity reconciliation before paired "
            "outer-CV statistical testing.",

        "source_file":
            str(source_path),

        "source_sha256":
            sha256_file(
                source_path
            ),

        "expected_total_rows":
            EXPECTED_TOTAL_ROWS,

        "expected_development_rows":
            EXPECTED_DEVELOPMENT_ROWS,

        "locked_test_used":
            False,

        "retraining":
            False,

        "common_identity_count":
            (
                None
                if common_ids is None
                else len(common_ids)
            ),

        "prediction_structure_audit":
            structure_audit.replace(
                {np.nan: None}
            ).to_dict(
                orient="records"
            ),

        "identity_audit":
            id_audit.replace(
                {np.nan: None}
            ).to_dict(
                orient="records"
            ),

        "target_audit":
            target_audit.replace(
                {np.nan: None}
            ).to_dict(
                orient="records"
            ),
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            payload,
            f,
            indent=2,
            default=str
        )


# ============================================================
# MAIN
# ============================================================

def main():

    warnings.filterwarnings(
        "ignore"
    )

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    # --------------------------------------------------------
    # 1. LOAD KAGGLE SOURCE
    # --------------------------------------------------------

    source_df, source_path = (
        load_kaggle_source()
    )

    source_df = audit_source(
        source_df
    )

    # --------------------------------------------------------
    # 2. LOAD PREDICTION FILES
    # --------------------------------------------------------

    loaded = (
        inspect_prediction_files()
    )

    # --------------------------------------------------------
    # 3. STRUCTURE AUDIT
    # --------------------------------------------------------

    structure_audit = (
        audit_prediction_structures(
            loaded
        )
    )

    # --------------------------------------------------------
    # 4. DIRECT ID AUDIT
    # --------------------------------------------------------

    id_audit = (
        compare_prediction_ids_to_source(
            source_df,
            loaded
        )
    )

    # --------------------------------------------------------
    # 5. COMMON COHORT
    # --------------------------------------------------------

    common_ids = (
        determine_common_cohort(
            source_df,
            loaded,
            id_audit
        )
    )

    # --------------------------------------------------------
    # 6. TARGET ALIGNMENT
    # --------------------------------------------------------

    target_audit = (
        verify_target_after_alignment(
            source_df,
            loaded,
            id_audit,
            common_ids
        )
    )

    # --------------------------------------------------------
    # 7. SAVE CSV AUDIT
    # --------------------------------------------------------

    id_audit.to_csv(
        OUTPUT_AUDIT,
        index=False
    )

    # --------------------------------------------------------
    # 8. REPORT
    # --------------------------------------------------------

    create_report(
        source_path,
        structure_audit,
        id_audit,
        common_ids,
        target_audit
    )

    # --------------------------------------------------------
    # 9. JSON
    # --------------------------------------------------------

    save_json(
        source_path,
        structure_audit,
        id_audit,
        common_ids,
        target_audit
    )

    # --------------------------------------------------------
    # 10. FINAL CONSOLE
    # --------------------------------------------------------

    print_header(
        "IMPLEMENTATION 43B-1 COMPLETE"
    )

    print(
        f"\nAudit CSV:"
    )

    print(
        OUTPUT_AUDIT
    )

    print(
        f"\nAudit JSON:"
    )

    print(
        OUTPUT_JSON
    )

    print(
        f"\nReport:"
    )

    print(
        OUTPUT_REPORT
    )

    if common_ids is not None:

        print(
            f"\nCommon identity count: "
            f"{len(common_ids):,}"
        )

    else:

        print(
            "\nCommon identity count: "
            "NOT ESTABLISHED"
        )

    print(
        "\nIMPORTANT:"
    )

    print(
        "  No statistical testing was performed."
    )

    print(
        "  No model was retrained."
    )

    print(
        "  Locked test set was not used."
    )

    print(
        "  UCI data was not used."
    )

    # --------------------------------------------------------
    # FINAL STATUS
    # --------------------------------------------------------

    if (
        common_ids is not None
        and
        len(common_ids) == 49000
        and
        len(target_audit) > 0
        and
        target_audit[
            "status"
        ].eq(
            "PASS"
        ).all()
    ):

        print(
            "\nSTATUS:"
        )

        print(
            "PASS_COMMON_49000_COHORT_ESTABLISHED"
        )

    else:

        print(
            "\nSTATUS:"
        )

        print(
            "PARTIAL_IDENTITY_RECONCILIATION"
        )


if __name__ == "__main__":

    main()