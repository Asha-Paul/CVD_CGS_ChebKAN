# ================================================================
# IMPLEMENTATION 28
# ALTERNATIVE-BASIS KAN BASELINE
#
# Model:
#   Vanilla Fourier-Basis KAN
#
# Purpose:
#   Compare an alternative functional basis against:
#       - B-spline KAN
#       - Chebyshev-KAN
#
# Frozen experimental protocol:
#   - Kaggle Development set only for model development
#   - 49,000 Development samples
#   - 5-fold outer Stratified CV
#   - 4-fold inner Stratified CV
#   - all 11 Kaggle predictors
#   - fold-specific median imputation
#   - fold-specific MinMax scaling to [-1, 1]
#   - Fourier basis
#   - K = {3, 5, 7}
#   - learning rate = {1e-3, 3e-4}
#   - L2 = {1e-5, 1e-4, 1e-3}
#   - 18 configurations per outer fold
#   - early stopping using an internal validation split
#   - no ADASYN
#   - no clinical grouping
#   - no sparse group gates
#   - no conformal prediction
#   - calibration set untouched
#   - locked test set untouched
#
# Architecture:
#   11 -> 16 -> 1
#
# Fourier basis:
#   phi(x) = a0 + sum_{k=1}^K [
#                a_k cos(k*pi*x)
#                + b_k sin(k*pi*x)
#            ]
#
# Each KAN edge has its own Fourier expansion.
#
# Author: CVD-CGS-ChebKAN project
# ================================================================

import os
import json
import time
import random
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    confusion_matrix,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader


warnings.filterwarnings("ignore")


# ================================================================
# 1. GLOBAL CONFIGURATION
# ================================================================

RANDOM_STATE = 2026

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"

DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
CAL_FILE = DATA_DIR / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"

# Output prefix
OUTPUT_PREFIX = "implementation28_fourier_kan"

TARGET = "cardio"

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

# ------------------------------------------------
# Nested CV
# ------------------------------------------------

OUTER_SPLITS = 5
INNER_SPLITS = 4

# ------------------------------------------------
# Fourier complexity
# ------------------------------------------------

FOURIER_DEGREES = [3, 5, 7]

# ------------------------------------------------
# Optimization grid
# ------------------------------------------------

LEARNING_RATES = [1e-3, 3e-4]
L2_VALUES = [1e-5, 1e-4, 1e-3]

# ------------------------------------------------
# Network
# ------------------------------------------------

HIDDEN_DIM = 16

# ------------------------------------------------
# Training
# ------------------------------------------------

MAX_EPOCHS = 150
PATIENCE = 15
BATCH_SIZE = 512

# Internal validation fraction
INTERNAL_VAL_FRACTION = 0.10

# ------------------------------------------------
# Device
# ------------------------------------------------

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# ================================================================
# 2. REPRODUCIBILITY
# ================================================================

def set_seed(seed=RANDOM_STATE):

    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    # Deterministic behavior for reproducibility
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ================================================================
# 3. DEVICE INFORMATION
# ================================================================

def print_environment():

    print("=" * 72)
    print("IMPLEMENTATION 28: ALTERNATIVE-BASIS FOURIER-KAN")
    print("=" * 72)

    print("\nEnvironment")
    print("-" * 72)

    print(f"Python/PyTorch version: {torch.__version__}")
    print(f"NumPy version: {np.__version__}")
    print(f"Pandas version: {pd.__version__}")
    print(f"Device: {DEVICE}")

    if torch.cuda.is_available():

        print(
            f"CUDA device: "
            f"{torch.cuda.get_device_name(0)}"
        )

        print(
            f"CUDA memory: "
            f"{torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB"
        )

    else:
        print("CUDA available: False")


# ================================================================
# 4. FILE VALIDATION
# ================================================================

def validate_files():

    print("\n" + "=" * 72)
    print("1. DATA FILE VALIDATION")
    print("=" * 72)

    files = {
        "Development": DEV_FILE,
        "Calibration": CAL_FILE,
        "Locked Test": TEST_FILE,
    }

    for name, path in files.items():

        exists = path.exists()

        print(
            f"{name}: {path} -> "
            f"{'FOUND' if exists else 'MISSING'}"
        )

        if not exists:
            raise FileNotFoundError(
                f"Required file not found: {path}"
            )


# ================================================================
# 5. LOAD DATA
# ================================================================

def load_data():

    dev = pd.read_csv(DEV_FILE)
    cal = pd.read_csv(CAL_FILE)
    test = pd.read_csv(TEST_FILE)

    print("\nDataset shapes")
    print("-" * 72)

    print(f"Development: {dev.shape}")
    print(f"Calibration : {cal.shape}")
    print(f"Locked Test : {test.shape}")

    expected = {
        "Development": 49000,
        "Calibration": 7000,
        "Locked Test": 14000,
    }

    actual = {
        "Development": len(dev),
        "Calibration": len(cal),
        "Locked Test": len(test),
    }

    for name in expected:

        if actual[name] != expected[name]:

            raise AssertionError(
                f"{name} size mismatch. "
                f"Expected {expected[name]}, "
                f"got {actual[name]}"
            )

    print("Partition sizes -> PASS")

    return dev, cal, test


# ================================================================
# 6. DATA INTEGRITY
# ================================================================

def validate_data_integrity(dev, cal, test):

    print("\n" + "=" * 72)
    print("2. DATA INTEGRITY")
    print("=" * 72)

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked Test", test),
    ]:

        if TARGET not in df.columns:
            raise AssertionError(
                f"{TARGET} missing from {name}"
            )

        missing_target = df[TARGET].isna().sum()

        print(
            f"{name}: target missing = "
            f"{missing_target}"
        )

        if missing_target != 0:
            raise AssertionError(
                f"Missing target values in {name}"
            )

        unique_targets = sorted(
            df[TARGET].astype(int).unique().tolist()
        )

        print(
            f"{name}: target values = "
            f"{unique_targets}"
        )

        if unique_targets != [0, 1]:
            raise AssertionError(
                f"Target is not binary in {name}"
            )

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked Test", test),
    ]:

        missing_features = [
            f for f in FEATURES
            if f not in df.columns
        ]

        if missing_features:
            raise AssertionError(
                f"{name} missing features: "
                f"{missing_features}"
            )

    # ID checks
    if "id" in dev.columns:

        dev_ids = set(dev["id"])
        cal_ids = set(cal["id"])
        test_ids = set(test["id"])

        print(
            f"Development × Calibration overlap: "
            f"{len(dev_ids & cal_ids)}"
        )

        print(
            f"Development × Locked Test overlap: "
            f"{len(dev_ids & test_ids)}"
        )

        print(
            f"Calibration × Locked Test overlap: "
            f"{len(cal_ids & test_ids)}"
        )

        assert len(dev_ids & cal_ids) == 0
        assert len(dev_ids & test_ids) == 0
        assert len(cal_ids & test_ids) == 0

    print("Partition disjointness -> PASS")


# ================================================================
# 7. MISSINGNESS AUDIT
# ================================================================

def print_missingness(dev, cal, test):

    print("\n" + "=" * 72)
    print("3. MISSINGNESS AUDIT")
    print("=" * 72)

    for name, df in [
        ("Development", dev),
        ("Calibration", cal),
        ("Locked Test", test),
    ]:

        print(f"\n{name}")

        for feature in FEATURES:

            n_missing = int(
                df[feature].isna().sum()
            )

            pct = (
                100.0 * n_missing / len(df)
            )

            if n_missing > 0:

                print(
                    f"  {feature}: "
                    f"{n_missing} "
                    f"({pct:.4f}%)"
                )


# ================================================================
# 8. FOURIER BASIS LAYER
# ================================================================

class FourierKANLayer(nn.Module):
    """
    One Fourier-basis KAN layer.

    Input:
        [batch, in_features]

    Output:
        [batch, out_features]

    For each input-output edge:

        phi(x) =
            a0
            + sum_{k=1}^K [
                a_k cos(k*pi*x)
                + b_k sin(k*pi*x)
            ]

    The final output is the sum of the
    learned univariate functions over input
    dimensions.
    """

    def __init__(
        self,
        in_features,
        out_features,
        K,
    ):

        super().__init__()

        self.in_features = in_features
        self.out_features = out_features
        self.K = K

        # Number of Fourier coefficients per edge:
        #
        # a0
        # + K cosine coefficients
        # + K sine coefficients
        #
        # = 2K + 1
        self.n_basis = 2 * K + 1

        # Coefficients:
        #
        # [out_features, in_features, n_basis]
        self.coefficients = nn.Parameter(
            torch.empty(
                out_features,
                in_features,
                self.n_basis,
            )
        )

        # Output bias
        self.bias = nn.Parameter(
            torch.zeros(out_features)
        )

        self.reset_parameters()

    def reset_parameters(self):

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02,
        )

        nn.init.zeros_(self.bias)

    def forward(self, x):

        # --------------------------------------------------------
        # x shape:
        # [batch, in_features]
        # --------------------------------------------------------

        basis_functions = []

        # Constant basis
        basis_functions.append(
            torch.ones_like(x)
        )

        # Fourier harmonics
        for k in range(1, self.K + 1):

            angle = k * np.pi * x

            basis_functions.append(
                torch.cos(angle)
            )

            basis_functions.append(
                torch.sin(angle)
            )

        # --------------------------------------------------------
        # [batch, in_features, 2K+1]
        # --------------------------------------------------------

        basis = torch.stack(
            basis_functions,
            dim=-1,
        )

        # --------------------------------------------------------
        # coefficients:
        # [out_features, in_features, 2K+1]
        #
        # basis:
        # [batch, in_features, 2K+1]
        #
        # output:
        # [batch, out_features]
        # --------------------------------------------------------

        output = torch.einsum(
            "bik,oik->bo",
            basis,
            self.coefficients,
        )

        output = output + self.bias

        return output


# ================================================================
# 9. VANILLA FOURIER-KAN MODEL
# ================================================================

class FourierKAN(nn.Module):

    def __init__(
        self,
        input_dim,
        hidden_dim,
        K,
    ):

        super().__init__()

        self.layer1 = FourierKANLayer(
            input_dim,
            hidden_dim,
            K,
        )

        self.activation = nn.SiLU()

        self.layer2 = FourierKANLayer(
            hidden_dim,
            1,
            K,
        )

    def forward(self, x):

        x = self.layer1(x)

        x = self.activation(x)

        x = self.layer2(x)

        return x.squeeze(-1)


# ================================================================
# 10. PARAMETER COUNT
# ================================================================

def count_parameters(model):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ================================================================
# 11. METRICS
# ================================================================

def expected_calibration_error(
    y_true,
    probabilities,
    n_bins=10,
):

    y_true = np.asarray(y_true)
    probabilities = np.asarray(probabilities)

    bins = np.linspace(
        0.0,
        1.0,
        n_bins + 1,
    )

    ece = 0.0

    for i in range(n_bins):

        if i == n_bins - 1:

            mask = (
                (probabilities >= bins[i])
                &
                (probabilities <= bins[i + 1])
            )

        else:

            mask = (
                (probabilities >= bins[i])
                &
                (probabilities < bins[i + 1])
            )

        if not np.any(mask):
            continue

        confidence = probabilities[mask].mean()

        accuracy = y_true[mask].mean()

        fraction = mask.mean()

        ece += (
            fraction
            *
            abs(confidence - accuracy)
        )

    return float(ece)


def calculate_metrics(
    y_true,
    probabilities,
):

    y_true = np.asarray(y_true).astype(int)

    probabilities = np.asarray(
        probabilities
    )

    predictions = (
        probabilities >= 0.5
    ).astype(int)

    accuracy = accuracy_score(
        y_true,
        predictions,
    )

    precision = precision_score(
        y_true,
        predictions,
        zero_division=0,
    )

    sensitivity = recall_score(
        y_true,
        predictions,
        zero_division=0,
    )

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        predictions,
        labels=[0, 1],
    ).ravel()

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    f1 = f1_score(
        y_true,
        predictions,
        zero_division=0,
    )

    roc_auc = roc_auc_score(
        y_true,
        probabilities,
    )

    pr_auc = average_precision_score(
        y_true,
        probabilities,
    )

    brier = brier_score_loss(
        y_true,
        probabilities,
    )

    ece = expected_calibration_error(
        y_true,
        probabilities,
    )

    return {
        "Accuracy": accuracy,
        "Precision": precision,
        "Sensitivity": sensitivity,
        "Specificity": specificity,
        "F1": f1,
        "ROC_AUC": roc_auc,
        "PR_AUC": pr_auc,
        "Brier": brier,
        "ECE": ece,
    }


# ================================================================
# 12. MODEL TRAINING
# ================================================================

def train_model(
    X_train,
    y_train,
    K,
    learning_rate,
    l2,
    seed=RANDOM_STATE,
):

    set_seed(seed)

    # ------------------------------------------------------------
    # Internal validation split
    # ------------------------------------------------------------

    inner_split = StratifiedKFold(
        n_splits=10,
        shuffle=True,
        random_state=seed,
    )

    train_idx, val_idx = next(
        inner_split.split(
            X_train,
            y_train,
        )
    )

    X_fit = X_train[train_idx]
    X_val = X_train[val_idx]

    y_fit = y_train[train_idx]
    y_val = y_train[val_idx]

    # ------------------------------------------------------------
    # Convert to tensors
    # ------------------------------------------------------------

    X_fit_tensor = torch.tensor(
        X_fit,
        dtype=torch.float32,
    )

    y_fit_tensor = torch.tensor(
        y_fit,
        dtype=torch.float32,
    )

    X_val_tensor = torch.tensor(
        X_val,
        dtype=torch.float32,
    ).to(DEVICE)

    y_val_tensor = torch.tensor(
        y_val,
        dtype=torch.float32,
    ).to(DEVICE)

    dataset = TensorDataset(
        X_fit_tensor,
        y_fit_tensor,
    )

    loader = DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        drop_last=False,
    )

    # ------------------------------------------------------------
    # Model
    # ------------------------------------------------------------

    model = FourierKAN(
        input_dim=len(FEATURES),
        hidden_dim=HIDDEN_DIM,
        K=K,
    ).to(DEVICE)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=l2,
    )

    criterion = nn.BCEWithLogitsLoss()

    best_auc = -np.inf
    best_epoch = 1
    best_state = None

    epochs_without_improvement = 0

    # ------------------------------------------------------------
    # Training loop
    # ------------------------------------------------------------

    for epoch in range(1, MAX_EPOCHS + 1):

        model.train()

        for batch_X, batch_y in loader:

            batch_X = batch_X.to(
                DEVICE,
                non_blocking=True,
            )

            batch_y = batch_y.to(
                DEVICE,
                non_blocking=True,
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(batch_X)

            loss = criterion(
                logits,
                batch_y,
            )

            loss.backward()

            optimizer.step()

        # --------------------------------------------------------
        # Internal validation
        # --------------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                X_val_tensor
            )

            val_probabilities = (
                torch.sigmoid(
                    val_logits
                )
                .detach()
                .cpu()
                .numpy()
            )

        val_auc = roc_auc_score(
            y_val,
            val_probabilities,
        )

        if val_auc > best_auc + 1e-8:

            best_auc = val_auc
            best_epoch = epoch

            best_state = {
                key: value.detach().cpu().clone()
                for key, value
                in model.state_dict().items()
            }

            epochs_without_improvement = 0

        else:

            epochs_without_improvement += 1

        if (
            epochs_without_improvement
            >= PATIENCE
        ):

            break

    # ------------------------------------------------------------
    # Restore best model
    # ------------------------------------------------------------

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    model.eval()

    return (
        model,
        best_auc,
        best_epoch,
    )


# ================================================================
# 13. PREDICTION
# ================================================================

def predict_model(
    model,
    X,
):

    model.eval()

    X_tensor = torch.tensor(
        X,
        dtype=torch.float32,
    ).to(DEVICE)

    probabilities = []

    with torch.no_grad():

        # Predict in manageable batches
        for start in range(
            0,
            len(X_tensor),
            4096,
        ):

            end = min(
                start + 4096,
                len(X_tensor),
            )

            batch = X_tensor[
                start:end
            ]

            logits = model(batch)

            probs = torch.sigmoid(
                logits
            )

            probabilities.append(
                probs.detach()
                .cpu()
                .numpy()
            )

    return np.concatenate(
        probabilities
    )


# ================================================================
# 14. FOLD-SPECIFIC PREPROCESSING
# ================================================================

def fit_preprocessor(X_train):

    imputer = SimpleImputer(
        strategy="median"
    )

    scaler = MinMaxScaler(
        feature_range=(-1, 1)
    )

    X_imp = imputer.fit_transform(
        X_train
    )

    X_scaled = scaler.fit_transform(
        X_imp
    )

    return imputer, scaler


def transform_data(
    X,
    imputer,
    scaler,
):

    X_imp = imputer.transform(X)

    X_scaled = scaler.transform(
        X_imp
    )

    return X_scaled.astype(
        np.float32
    )


# ================================================================
# 15. HYPERPARAMETER SEARCH
# ================================================================

def inner_cv_search(
    X_outer_train,
    y_outer_train,
    outer_fold,
):

    print(
        "\nInner-CV hyperparameter search:"
    )

    inner_cv = StratifiedKFold(
        n_splits=INNER_SPLITS,
        shuffle=True,
        random_state=(
            RANDOM_STATE
            + outer_fold
        ),
    )

    search_results = []

    configurations = []

    for K in FOURIER_DEGREES:

        for lr in LEARNING_RATES:

            for l2 in L2_VALUES:

                configurations.append(
                    (
                        K,
                        lr,
                        l2,
                    )
                )

    total_configs = len(
        configurations
    )

    for config_number, (
        K,
        lr,
        l2,
    ) in enumerate(
        configurations,
        start=1,
    ):

        fold_auc_values = []

        for (
            inner_train_idx,
            inner_val_idx,
        ) in inner_cv.split(
            X_outer_train,
            y_outer_train,
        ):

            X_inner_train = (
                X_outer_train[
                    inner_train_idx
                ]
            )

            X_inner_val = (
                X_outer_train[
                    inner_val_idx
                ]
            )

            y_inner_train = (
                y_outer_train[
                    inner_train_idx
                ]
            )

            y_inner_val = (
                y_outer_train[
                    inner_val_idx
                ]
            )

            # ----------------------------------------------------
            # Fold-specific preprocessing
            # ----------------------------------------------------

            imputer, scaler = (
                fit_preprocessor(
                    X_inner_train
                )
            )

            X_inner_train_proc = (
                transform_data(
                    X_inner_train,
                    imputer,
                    scaler,
                )
            )

            X_inner_val_proc = (
                transform_data(
                    X_inner_val,
                    imputer,
                    scaler,
                )
            )

            # ----------------------------------------------------
            # Train
            # ----------------------------------------------------

            model, best_auc, best_epoch = (
                train_model(
                    X_inner_train_proc,
                    y_inner_train,
                    K=K,
                    learning_rate=lr,
                    l2=l2,
                    seed=(
                        RANDOM_STATE
                        + outer_fold
                    ),
                )
            )

            # ----------------------------------------------------
            # Validate
            # ----------------------------------------------------

            val_probabilities = (
                predict_model(
                    model,
                    X_inner_val_proc,
                )
            )

            val_auc = roc_auc_score(
                y_inner_val,
                val_probabilities,
            )

            fold_auc_values.append(
                val_auc
            )

            # Explicit cleanup
            del model

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        mean_auc = float(
            np.mean(
                fold_auc_values
            )
        )

        std_auc = float(
            np.std(
                fold_auc_values,
                ddof=1,
            )
            if len(fold_auc_values) > 1
            else 0.0
        )

        search_results.append(
            {
                "K": K,
                "learning_rate": lr,
                "l2": l2,
                "mean_inner_auc": mean_auc,
                "std_inner_auc": std_auc,
            }
        )

        print(
            f"      Config "
            f"{config_number}/{total_configs}: "
            f"K={K}, "
            f"lr={lr}, "
            f"L2={l2}, "
            f"AUC={mean_auc:.6f}"
        )

    # ------------------------------------------------------------
    # Select best configuration
    # ------------------------------------------------------------

    search_df = pd.DataFrame(
        search_results
    )

    search_df = search_df.sort_values(
        by=[
            "mean_inner_auc",
            "std_inner_auc",
        ],
        ascending=[
            False,
            True,
        ],
    ).reset_index(
        drop=True
    )

    best = search_df.iloc[0]

    best_config = {
        "K": int(best["K"]),
        "learning_rate": float(
            best["learning_rate"]
        ),
        "l2": float(best["l2"]),
    }

    print(
        "\nBest inner-CV ROC-AUC: "
        f"{best['mean_inner_auc']:.6f}"
    )

    print("Selected hyperparameters:")
    print(
        f"  Fourier degree: "
        f"{best_config['K']}"
    )
    print(
        f"  learning_rate: "
        f"{best_config['learning_rate']}"
    )
    print(
        f"  l2: "
        f"{best_config['l2']}"
    )

    return (
        best_config,
        search_df,
    )


# ================================================================
# 16. OUTER NESTED CV
# ================================================================

def run_nested_cv(
    X_dev,
    y_dev,
):

    print("\n" + "=" * 72)
    print("4. NESTED 5 × 4 CROSS-VALIDATION")
    print("=" * 72)

    outer_cv = StratifiedKFold(
        n_splits=OUTER_SPLITS,
        shuffle=True,
        random_state=RANDOM_STATE,
    )

    outer_results = []
    selected_parameters = []
    pooled_predictions = []

    all_dev_ids = np.arange(
        len(X_dev)
    )

    start_time = time.time()

    for outer_fold, (
        outer_train_idx,
        outer_val_idx,
    ) in enumerate(
        outer_cv.split(
            X_dev,
            y_dev,
        ),
        start=1,
    ):

        print("\n")
        print("=" * 72)
        print(
            f"OUTER FOLD "
            f"{outer_fold}/{OUTER_SPLITS}"
        )
        print("=" * 72)

        X_outer_train = X_dev[
            outer_train_idx
        ]

        X_outer_val = X_dev[
            outer_val_idx
        ]

        y_outer_train = y_dev[
            outer_train_idx
        ]

        y_outer_val = y_dev[
            outer_val_idx
        ]

        print(
            f"Training rows: "
            f"{len(X_outer_train)}"
        )

        print(
            f"Validation rows: "
            f"{len(X_outer_val)}"
        )

        # --------------------------------------------------------
        # Inner CV hyperparameter selection
        # --------------------------------------------------------

        best_config, search_df = (
            inner_cv_search(
                X_outer_train,
                y_outer_train,
                outer_fold,
            )
        )

        # --------------------------------------------------------
        # Outer training preprocessing
        # --------------------------------------------------------

        imputer, scaler = (
            fit_preprocessor(
                X_outer_train
            )
        )

        X_outer_train_proc = (
            transform_data(
                X_outer_train,
                imputer,
                scaler,
            )
        )

        X_outer_val_proc = (
            transform_data(
                X_outer_val,
                imputer,
                scaler,
            )
        )

        # --------------------------------------------------------
        # Train final model for this outer fold
        # --------------------------------------------------------

        model, best_internal_auc, best_epoch = (
            train_model(
                X_outer_train_proc,
                y_outer_train,
                K=best_config["K"],
                learning_rate=(
                    best_config[
                        "learning_rate"
                    ]
                ),
                l2=best_config["l2"],
                seed=(
                    RANDOM_STATE
                    + outer_fold
                    + 1000
                ),
            )
        )

        # --------------------------------------------------------
        # Outer validation prediction
        # --------------------------------------------------------

        outer_probabilities = (
            predict_model(
                model,
                X_outer_val_proc,
            )
        )

        metrics = calculate_metrics(
            y_outer_val,
            outer_probabilities,
        )

        parameter_count = (
            count_parameters(model)
        )

        print(
            "\nBest inner-CV ROC-AUC: "
            f"{best_internal_auc:.6f}"
        )

        print(
            "Selected hyperparameters:"
        )

        print(
            f"  Fourier degree: "
            f"{best_config['K']}"
        )

        print(
            f"  learning_rate: "
            f"{best_config['learning_rate']}"
        )

        print(
            f"  l2: "
            f"{best_config['l2']}"
        )

        print(
            f"Best internal-validation "
            f"epoch: {best_epoch}"
        )

        print(
            f"Trainable parameters: "
            f"{parameter_count}"
        )

        print(
            "\nOuter validation metrics:"
        )

        print(
            f"  Accuracy: "
            f"{metrics['Accuracy']:.6f}"
        )

        print(
            f"  Precision: "
            f"{metrics['Precision']:.6f}"
        )

        print(
            f"  Sensitivity: "
            f"{metrics['Sensitivity']:.6f}"
        )

        print(
            f"  Specificity: "
            f"{metrics['Specificity']:.6f}"
        )

        print(
            f"  F1: "
            f"{metrics['F1']:.6f}"
        )

        print(
            f"  ROC-AUC: "
            f"{metrics['ROC_AUC']:.6f}"
        )

        print(
            f"  PR-AUC: "
            f"{metrics['PR_AUC']:.6f}"
        )

        print(
            f"  Brier: "
            f"{metrics['Brier']:.6f}"
        )

        print(
            f"  ECE: "
            f"{metrics['ECE']:.6f}"
        )

        # --------------------------------------------------------
        # Save outer results
        # --------------------------------------------------------

        result_row = {
            "outer_fold": outer_fold,
            "K": best_config["K"],
            "learning_rate": best_config[
                "learning_rate"
            ],
            "l2": best_config["l2"],
            "best_internal_auc": (
                best_internal_auc
            ),
            "best_epoch": best_epoch,
            "parameter_count": parameter_count,
            **metrics,
        }

        outer_results.append(
            result_row
        )

        selected_parameters.append(
            result_row
        )

        # --------------------------------------------------------
        # Save pooled outer predictions
        # --------------------------------------------------------

        for local_index, (
            global_index,
            true_label,
            probability,
        ) in enumerate(
            zip(
                outer_val_idx,
                y_outer_val,
                outer_probabilities,
            )
        ):

            pooled_predictions.append(
                {
                    "sample_index": int(
                        global_index
                    ),
                    "outer_fold": outer_fold,
                    "y_true": int(
                        true_label
                    ),
                    "probability": float(
                        probability
                    ),
                }
            )

        # Cleanup
        del model

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        elapsed = (
            time.time()
            - start_time
        )

        print(
            f"\nElapsed time: "
            f"{elapsed / 60:.2f} minutes"
        )

    return (
        pd.DataFrame(outer_results),
        pd.DataFrame(
            selected_parameters
        ),
        pd.DataFrame(
            pooled_predictions
        ),
    )


# ================================================================
# 17. AGGREGATE RESULTS
# ================================================================

def aggregate_results(
    outer_results,
):

    metric_columns = [
        "Accuracy",
        "Precision",
        "Sensitivity",
        "Specificity",
        "F1",
        "ROC_AUC",
        "PR_AUC",
        "Brier",
        "ECE",
    ]

    summary = {}

    for metric in metric_columns:

        values = outer_results[
            metric
        ].astype(float)

        summary[
            f"{metric}_mean"
        ] = float(values.mean())

        summary[
            f"{metric}_std"
        ] = float(
            values.std(
                ddof=1
            )
        )

    return summary


# ================================================================
# 18. POOLED OUTER-CV RESULTS
# ================================================================

def pooled_metrics(
    pooled_predictions,
):

    pooled_predictions = (
        pooled_predictions
        .sort_values(
            "sample_index"
        )
        .reset_index(
            drop=True
        )
    )

    y_true = pooled_predictions[
        "y_true"
    ].values

    probabilities = pooled_predictions[
        "probability"
    ].values

    metrics = calculate_metrics(
        y_true,
        probabilities,
    )

    return metrics


# ================================================================
# 19. OUTER-CV COVERAGE CHECK
# ================================================================

def check_outer_coverage(
    pooled_predictions,
):

    print("\n" + "=" * 72)
    print("5. OUTER-CV COVERAGE CHECK")
    print("=" * 72)

    expected = 49000

    actual = len(
        pooled_predictions
    )

    unique_ids = (
        pooled_predictions[
            "sample_index"
        ].nunique()
    )

    print(
        f"Expected Development predictions: "
        f"{expected}"
    )

    print(
        f"Actual outer-CV predictions: "
        f"{actual}"
    )

    print(
        f"Unique prediction IDs: "
        f"{unique_ids}"
    )

    if (
        actual != expected
        or unique_ids != expected
    ):

        raise AssertionError(
            "Outer-CV coverage failed."
        )

    counts = (
        pooled_predictions[
            "sample_index"
        ]
        .value_counts()
    )

    if not np.all(
        counts.values == 1
    ):

        raise AssertionError(
            "Some Development records "
            "do not appear exactly once."
        )

    print(
        "Every Development record "
        "appears exactly once -> PASS"
    )


# ================================================================
# 20. HYPERPARAMETER STABILITY
# ================================================================

def print_hyperparameter_stability(
    outer_results,
):

    print("\n" + "=" * 72)
    print("6. HYPERPARAMETER STABILITY")
    print("=" * 72)

    for parameter in [
        "K",
        "learning_rate",
        "l2",
    ]:

        print(f"\n{parameter}")

        counts = (
            outer_results[
                parameter
            ]
            .value_counts()
            .sort_index()
        )

        for value, count in counts.items():

            print(
                f"  {value}: "
                f"{count}/"
                f"{len(outer_results)}"
            )


# ================================================================
# 21. MODEL SIZE
# ================================================================

def print_model_size(
    outer_results,
):

    print("\n" + "=" * 72)
    print("7. MODEL SIZE")
    print("=" * 72)

    print(
        "Parameter count by fold:"
    )

    for value in outer_results[
        "parameter_count"
    ]:

        print(
            f"  {int(value)}"
        )

    print(
        "Mean parameter count: "
        f"{outer_results['parameter_count'].mean():.0f}"
    )


# ================================================================
# 22. CALIBRATION / TEST PROTECTION
# ================================================================

def check_protection(
    pooled_predictions,
    cal,
    test,
):

    print("\n" + "=" * 72)
    print("8. CALIBRATION / TEST PROTECTION")
    print("=" * 72)

    if "id" not in cal.columns:
        print(
            "ID column unavailable; "
            "partition protection verified "
            "through locked workflow."
        )
        return

    # Development IDs represented by
    # outer predictions
    #
    # Since pooled_predictions stores
    # Development row index, not ID,
    # protection is verified by the fact
    # that only Development was loaded into
    # nested CV.
    #
    # Calibration and test are never passed
    # into training or selection.

    print(
        "Outer-CV models were trained "
        "only on Development data."
    )

    print(
        "Calibration data used during "
        "model selection: False"
    )

    print(
        "Locked Test data used during "
        "model selection: False"
    )

    print(
        "Calibration/Test protection -> PASS"
    )


# ================================================================
# 23. SAVE EXPERIMENT
# ================================================================

def save_outputs(
    outer_results,
    selected_parameters,
    pooled_predictions,
    aggregate_summary,
    pooled_summary,
):

    RESULTS_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    outer_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_outer_fold_results.csv"
    )

    aggregate_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_aggregate_results.csv"
    )

    hyperparameter_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_selected_hyperparameters.csv"
    )

    pooled_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_pooled_outer_cv.csv"
    )

    predictions_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_outer_predictions.csv"
    )

    experiment_file = (
        RESULTS_DIR
        / f"{OUTPUT_PREFIX}_experiment_record.json"
    )

    # ------------------------------------------------------------
    # CSV outputs
    # ------------------------------------------------------------

    outer_results.to_csv(
        outer_file,
        index=False,
    )

    selected_parameters.to_csv(
        hyperparameter_file,
        index=False,
    )

    pooled_predictions.to_csv(
        predictions_file,
        index=False,
    )

    # Pooled summary
    pooled_df = pd.DataFrame(
        [
            pooled_summary
        ]
    )

    pooled_df.to_csv(
        pooled_file,
        index=False,
    )

    # Aggregate summary
    aggregate_df = pd.DataFrame(
        [
            aggregate_summary
        ]
    )

    aggregate_df.to_csv(
        aggregate_file,
        index=False,
    )

    # ------------------------------------------------------------
    # Experiment record
    # ------------------------------------------------------------

    experiment_record = {

        "implementation": 28,

        "experiment_name":
            "Alternative-Basis Fourier-KAN",

        "basis":
            "Fourier",

        "fourier_basis_definition":
            "a0 + sum_k[a_k cos(k*pi*x) + "
            "b_k sin(k*pi*x)]",

        "fourier_degree_search":
            FOURIER_DEGREES,

        "learning_rate_search":
            LEARNING_RATES,

        "l2_search":
            L2_VALUES,

        "number_of_configurations_per_outer_fold":
            len(FOURIER_DEGREES)
            * len(LEARNING_RATES)
            * len(L2_VALUES),

        "features":
            FEATURES,

        "number_of_features":
            len(FEATURES),

        "architecture":
            "11 -> 16 -> 1",

        "hidden_dimension":
            HIDDEN_DIM,

        "outer_cv":
            OUTER_SPLITS,

        "inner_cv":
            INNER_SPLITS,

        "random_state":
            RANDOM_STATE,

        "preprocessing":
            {
                "imputation":
                    "fold-specific median",

                "scaling":
                    "fold-specific MinMaxScaler [-1,1]",

                "global_preprocessing":
                    False,
            },

        "adasyn":
            False,

        "clinical_grouping":
            False,

        "sparse_group_gating":
            False,

        "conformal_prediction":
            False,

        "calibration_set_used":
            False,

        "locked_test_used":
            False,

        "max_epochs":
            MAX_EPOCHS,

        "early_stopping_patience":
            PATIENCE,

        "batch_size":
            BATCH_SIZE,

        "aggregate_outer_cv":
            aggregate_summary,

        "pooled_outer_cv":
            pooled_summary,

        "status":
            "PASS",
    }

    with open(
        experiment_file,
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            experiment_record,
            f,
            indent=2,
        )

    print("\n" + "=" * 72)
    print("9. SAVE RESULTS")
    print("=" * 72)

    print(
        f"Saved: {outer_file}"
    )

    print(
        f"Saved: {aggregate_file}"
    )

    print(
        f"Saved: {hyperparameter_file}"
    )

    print(
        f"Saved: {pooled_file}"
    )

    print(
        f"Saved: {predictions_file}"
    )

    print(
        f"Saved: {experiment_file}"
    )


# ================================================================
# 24. FINAL SUMMARY
# ================================================================

def print_final_summary(
    aggregate_summary,
    pooled_summary,
):

    print("\n" + "=" * 72)
    print(
        "IMPLEMENTATION 28 FINAL SUMMARY"
    )
    print("=" * 72)

    print(
        "Vanilla Fourier-KAN "
        "pooled outer-CV ROC-AUC: "
        f"{pooled_summary['ROC_AUC']:.6f}"
    )

    print(
        "Vanilla Fourier-KAN "
        "mean outer-CV ROC-AUC: "
        f"{aggregate_summary['ROC_AUC_mean']:.6f} "
        f"± "
        f"{aggregate_summary['ROC_AUC_std']:.6f}"
    )

    print(
        "Calibration set touched: False"
    )

    print(
        "Locked test touched: False"
    )

    print(
        "ADASYN used: False"
    )

    print(
        "Clinical grouping used: False"
    )

    print(
        "Sparse group gating used: False"
    )

    print(
        "Conformal prediction used: False"
    )

    print(
        "Status: PASS"
    )


# ================================================================
# 25. MAIN
# ================================================================

def main():

    total_start = time.time()

    set_seed(
        RANDOM_STATE
    )

    print_environment()

    validate_files()

    dev, cal, test = load_data()

    validate_data_integrity(
        dev,
        cal,
        test,
    )

    print_missingness(
        dev,
        cal,
        test,
    )

    # ------------------------------------------------------------
    # Development data ONLY
    # ------------------------------------------------------------

    X_dev = (
        dev[
            FEATURES
        ]
        .copy()
        .values
    )

    y_dev = (
        dev[
            TARGET
        ]
        .astype(int)
        .copy()
        .values
    )

    print("\n" + "=" * 72)
    print("4. FROZEN EXPERIMENTAL PROTOCOL")
    print("=" * 72)

    print(
        f"Features: {len(FEATURES)}"
    )

    print(
        f"Architecture: "
        f"{len(FEATURES)} -> "
        f"{HIDDEN_DIM} -> 1"
    )

    print(
        "Basis: Fourier"
    )

    print(
        f"Fourier degrees: "
        f"{FOURIER_DEGREES}"
    )

    print(
        "Normalization: [-1, 1]"
    )

    print(
        "Clinical grouping: False"
    )

    print(
        "Sparse gating: False"
    )

    print(
        "ADASYN: False"
    )

    print(
        "Conformal prediction: False"
    )

    print(
        f"Outer CV: "
        f"{OUTER_SPLITS}-fold"
    )

    print(
        f"Inner CV: "
        f"{INNER_SPLITS}-fold"
    )

    print(
        "Calibration set: PROTECTED"
    )

    print(
        "Locked test set: PROTECTED"
    )

    # ------------------------------------------------------------
    # Run nested CV
    # ------------------------------------------------------------

    (
        outer_results,
        selected_parameters,
        pooled_predictions,
    ) = run_nested_cv(
        X_dev,
        y_dev,
    )

    # ------------------------------------------------------------
    # Coverage
    # ------------------------------------------------------------

    check_outer_coverage(
        pooled_predictions
    )

    # ------------------------------------------------------------
    # Aggregate
    # ------------------------------------------------------------

    aggregate_summary = (
        aggregate_results(
            outer_results
        )
    )

    print("\n" + "=" * 72)
    print("10. AGGREGATE OUTER-CV RESULTS")
    print("=" * 72)

    for metric in [
        "Accuracy",
        "Precision",
        "Sensitivity",
        "Specificity",
        "F1",
        "ROC_AUC",
        "PR_AUC",
        "Brier",
        "ECE",
    ]:

        print(
            f"{metric.upper()}: "
            f"{aggregate_summary[metric + '_mean']:.6f} "
            f"± "
            f"{aggregate_summary[metric + '_std']:.6f}"
        )

    # ------------------------------------------------------------
    # Pooled
    # ------------------------------------------------------------

    pooled_summary = pooled_metrics(
        pooled_predictions
    )

    print("\n" + "=" * 72)
    print("11. POOLED OUTER-CV RESULTS")
    print("=" * 72)

    for metric, value in pooled_summary.items():

        print(
            f"{metric}: "
            f"{value:.6f}"
        )

    # ------------------------------------------------------------
    # Stability
    # ------------------------------------------------------------

    print_hyperparameter_stability(
        outer_results
    )

    # ------------------------------------------------------------
    # Model size
    # ------------------------------------------------------------

    print_model_size(
        outer_results
    )

    # ------------------------------------------------------------
    # Protection
    # ------------------------------------------------------------

    check_protection(
        pooled_predictions,
        cal,
        test,
    )

    # ------------------------------------------------------------
    # Save
    # ------------------------------------------------------------

    save_outputs(
        outer_results,
        selected_parameters,
        pooled_predictions,
        aggregate_summary,
        pooled_summary,
    )

    # ------------------------------------------------------------
    # Final summary
    # ------------------------------------------------------------

    print_final_summary(
        aggregate_summary,
        pooled_summary,
    )

    total_elapsed = (
        time.time()
        - total_start
    )

    print(
        f"\nTotal execution time: "
        f"{total_elapsed / 60:.2f} minutes"
    )


# ================================================================
# ENTRY POINT
# ================================================================

if __name__ == "__main__":

    main()