"""
IMPLEMENTATION 45
PAIRED STATISTICAL COMPARISON OF A8 VS A6 AND VERIFIED BASELINES

Purpose
-------
Development-CV-only statistical comparison after Implementation 44.

Primary question:
    Does A8 (sparse clinically-grouped ChebKAN + explicit cross-group
    interactions) improve ROC-AUC over A6 on exactly the same 49,000
    Development/CV records?

Comparators:
    A6 sparse grouped ChebKAN
    Random Forest
    XGBoost
    MLP
    B-spline KAN
    Vanilla Chebyshev KAN

STRICT PROTOCOL
---------------
- Development cohort only: 49,000 records.
- Exact paired row identity required.
- No retraining.
- No hyperparameter tuning.
- No calibration data.
- No locked test.
- No UCI data.
- 5,000 paired stratified patient-level bootstrap replicates.
- Same bootstrap indices are used for A8 and every comparator.
- 95% percentile bootstrap CI for A8 - comparator AUC.
- Two-sided empirical bootstrap p-value.
- Holm correction across the five planned comparisons.
- Results are exploratory/development-CV evidence only.

IMPORTANT
---------
A bootstrap p-value of zero cannot be reported literally as p=0.
If no bootstrap replicate crosses the null, the script reports the
Monte-Carlo floor p < 1/(B+1).

Outputs
-------
results/tables/implementation45_a8_paired_statistical_comparison.csv
results/tables/implementation45_a8_paired_statistical_comparison.json
results/tables/implementation45_a8_paired_statistical_comparison_report.txt
"""

from pathlib import Path
import json
import math
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from scipy.stats import rankdata

# ============================================================
# CONFIGURATION
# ============================================================

SEED = 20261006
BOOTSTRAP_REPS = 5000
ALPHA = 0.05

ROOT = Path(r"E:\CVD_CGS_ChebKAN")
TABLE_DIR = ROOT / "results" / "tables"

A8_FILE = TABLE_DIR / "implementation44_a8_outer_predictions.csv"
A6_FILE = TABLE_DIR / "implementation31b_reduced_corrected_a6_outer_predictions.csv"

BASELINES = {
    "Random Forest": TABLE_DIR / "implementation23_random_forest_outer_predictions.csv",
    "XGBoost": TABLE_DIR / "implementation24_xgboost_outer_predictions.csv",
    "MLP": TABLE_DIR / "implementation25_mlp_outer_predictions.csv",
    "B-spline KAN": TABLE_DIR / "implementation26_bspline_kan_outer_predictions.csv",
    "Vanilla Chebyshev KAN": TABLE_DIR / "implementation27_chebyshev_outer_predictions.csv",
}

OUT_CSV = TABLE_DIR / "implementation45_a8_paired_statistical_comparison.csv"
OUT_JSON = TABLE_DIR / "implementation45_a8_paired_statistical_comparison.json"
OUT_REPORT = TABLE_DIR / "implementation45_a8_paired_statistical_comparison_report.txt"

# ============================================================
# HELPERS
# ============================================================

def find_column(df, candidates, description):
    for c in candidates:
        if c in df.columns:
            return c
    raise ValueError(
        f"Could not find {description}. "
        f"Expected one of {candidates}; found {list(df.columns)}"
    )

def load_prediction_file(path, model_name):
    if not path.exists():
        raise FileNotFoundError(f"{model_name}: file not found: {path}")

    df = pd.read_csv(path)

    row_col = find_column(
        df,
        ["row_index"],
        f"{model_name} row-index column"
    )
    prob_col = find_column(
        df,
        ["probability", "prob", "y_prob"],
        f"{model_name} probability column"
    )
    y_col = find_column(
        df,
        ["y_true", "true_label", "cardio"],
        f"{model_name} target column"
    )

    out = pd.DataFrame({
        "row_index": pd.to_numeric(df[row_col], errors="raise").astype(int),
        "y_true": pd.to_numeric(df[y_col], errors="raise").astype(int),
        "probability": pd.to_numeric(df[prob_col], errors="raise").astype(float),
    })

    if out["row_index"].duplicated().any():
        dup = int(out["row_index"].duplicated().sum())
        raise ValueError(f"{model_name}: duplicate row_index values: {dup}")

    if not np.isfinite(out["probability"]).all():
        raise ValueError(f"{model_name}: non-finite probabilities detected")

    if ((out["probability"] < 0) | (out["probability"] > 1)).any():
        raise ValueError(f"{model_name}: probabilities outside [0,1]")

    return out

def verify_common_cohort(a8, other, model_name):
    a = a8.set_index("row_index").sort_index()
    b = other.set_index("row_index").sort_index()

    if len(a) != 49000:
        raise ValueError(f"A8 expected 49,000 rows; found {len(a)}")
    if len(b) != 49000:
        raise ValueError(f"{model_name} expected 49,000 rows; found {len(b)}")

    if not a.index.equals(b.index):
        missing = sorted(set(a.index) - set(b.index))
        extra = sorted(set(b.index) - set(a.index))
        raise ValueError(
            f"{model_name}: exact row cohort mismatch. "
            f"Missing={len(missing)}, Extra={len(extra)}"
        )

    target_mismatch = int((a["y_true"].to_numpy() != b["y_true"].to_numpy()).sum())
    if target_mismatch:
        raise ValueError(
            f"{model_name}: target mismatch count = {target_mismatch}"
        )

    if not np.array_equal(a.index.to_numpy(), np.arange(49000)):
        raise ValueError(
            f"{model_name}: common row_index is not exactly 0..48,999"
        )

    return a, b, target_mismatch

def auc(y, p):
    return float(roc_auc_score(y, p))

def stratified_bootstrap_indices(y, rng):
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)

    boot_pos = rng.choice(pos, size=len(pos), replace=True)
    boot_neg = rng.choice(neg, size=len(neg), replace=True)

    idx = np.concatenate([boot_pos, boot_neg])
    rng.shuffle(idx)
    return idx

def holm_adjust(p_values):
    """
    Holm-Bonferroni adjusted p-values.
    """
    p = np.asarray(p_values, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adjusted = np.empty(m, dtype=float)

    running = 0.0
    for rank, idx in enumerate(order):
        value = min(1.0, (m - rank) * p[idx])
        running = max(running, value)
        adjusted[idx] = running

    return adjusted

def bootstrap_pair(y, p_a8, p_cmp, reps, seed):
    """
    Paired, outcome-stratified patient-level bootstrap.

    Each replicate samples positive and negative patients independently
    with replacement, then evaluates both models on exactly those same
    sampled patient indices.
    """
    rng = np.random.default_rng(seed)

    observed_a8 = auc(y, p_a8)
    observed_cmp = auc(y, p_cmp)
    observed_diff = observed_a8 - observed_cmp

    diffs = np.empty(reps, dtype=float)
    a8_aucs = np.empty(reps, dtype=float)
    cmp_aucs = np.empty(reps, dtype=float)

    valid = 0
    for r in range(reps):
        idx = stratified_bootstrap_indices(y, rng)

        # Extremely rare degenerate bootstrap samples are rejected.
        yb = y[idx]
        if np.unique(yb).size < 2:
            continue

        aa = auc(yb, p_a8[idx])
        cc = auc(yb, p_cmp[idx])

        a8_aucs[valid] = aa
        cmp_aucs[valid] = cc
        diffs[valid] = aa - cc
        valid += 1

    if valid < reps:
        a8_aucs = a8_aucs[:valid]
        cmp_aucs = cmp_aucs[:valid]
        diffs = diffs[:valid]

    if valid < int(0.99 * reps):
        raise RuntimeError(
            f"Too many invalid bootstrap replicates: {valid}/{reps}"
        )

    lo, hi = np.percentile(diffs, [2.5, 97.5])

    # Two-sided empirical bootstrap p-value around the null 0.
    # +1 correction avoids reporting literal p=0.
    n_le_zero = int(np.sum(diffs <= 0))
    n_ge_zero = int(np.sum(diffs >= 0))
    p_left = (n_le_zero + 1) / (valid + 1)
    p_right = (n_ge_zero + 1) / (valid + 1)
    p_two = min(1.0, 2.0 * min(p_left, p_right))

    probability_a8_better = float(np.mean(diffs > 0))

    return {
        "observed_a8_auc": observed_a8,
        "observed_comparator_auc": observed_cmp,
        "observed_auc_difference": observed_diff,
        "bootstrap_ci_lower": float(lo),
        "bootstrap_ci_upper": float(hi),
        "bootstrap_reps_requested": reps,
        "bootstrap_reps_valid": valid,
        "bootstrap_probability_a8_better": probability_a8_better,
        "bootstrap_n_diff_le_zero": n_le_zero,
        "bootstrap_n_diff_ge_zero": n_ge_zero,
        "p_value_two_sided": float(p_two),
        "p_value_floor_note": (
            f"p < {1.0/(valid+1):.8f}"
            if n_le_zero == 0 or n_ge_zero == 0
            else ""
        ),
        "significant_0_05": bool(p_two < ALPHA),
        "ci_excludes_zero": bool(lo > 0 or hi < 0),
    }

# ============================================================
# MAIN
# ============================================================

def main():
    print("=" * 80)
    print("IMPLEMENTATION 45")
    print("PAIRED STATISTICAL COMPARISON OF A8 VS A6 AND VERIFIED BASELINES")
    print("=" * 80)

    print("\nSTRICT PROTECTION:")
    print("  Development cohort only: YES")
    print("  Calibration data loaded: NO")
    print("  Locked test loaded: NO")
    print("  UCI data loaded: NO")
    print("  Model retraining: NO")
    print(f"  Bootstrap replicates: {BOOTSTRAP_REPS}")
    print(f"  Seed: {SEED}")

    TABLE_DIR.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # Load A8
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("1. LOADING A8")
    print("=" * 80)

    a8 = load_prediction_file(A8_FILE, "A8")
    print(f"A8 rows: {len(a8)}")
    print(f"A8 columns: {list(a8.columns)}")

    if len(a8) != 49000:
        raise RuntimeError("A8 must contain exactly 49,000 Development rows.")

    # --------------------------------------------------------
    # Load A6 and verify exact cohort
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("2. VERIFYING A6 COMMON COHORT")
    print("=" * 80)

    a6 = load_prediction_file(A6_FILE, "A6")
    a8_ref, a6_ref, mismatch = verify_common_cohort(a8, a6, "A6")

    y = a8_ref["y_true"].to_numpy()
    p_a8 = a8_ref["probability"].to_numpy()
    p_a6 = a6_ref["probability"].to_numpy()

    print("PASS: A8/A6 exact 49,000-row paired cohort.")
    print(f"Target mismatches: {mismatch}")
    print(f"A8 pooled ROC-AUC: {auc(y, p_a8):.6f}")
    print(f"A6 pooled ROC-AUC: {auc(y, p_a6):.6f}")
    print(f"A8 - A6: {auc(y, p_a8) - auc(y, p_a6):+.6f}")

    # --------------------------------------------------------
    # Baseline loading and verification
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("3. VERIFYING ALL BASELINE COHORTS")
    print("=" * 80)

    models = {
        "A6 Sparse Grouped ChebKAN": a6_ref,
    }

    for name, path in BASELINES.items():
        df = load_prediction_file(path, name)
        _, verified, mismatch = verify_common_cohort(a8, df, name)
        models[name] = verified
        print(f"PASS: {name:25s} | rows=49,000 | target mismatches={mismatch}")

    # --------------------------------------------------------
    # Paired comparisons
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("4. PAIRED STRATIFIED BOOTSTRAP")
    print("=" * 80)

    comparison_order = [
        "A6 Sparse Grouped ChebKAN",
        "Random Forest",
        "XGBoost",
        "MLP",
        "B-spline KAN",
        "Vanilla Chebyshev KAN",
    ]

    records = []

    for i, name in enumerate(comparison_order):
        print(f"\nComparison {i+1}/{len(comparison_order)}: A8 vs {name}")

        cmp_df = models[name]

        # Ensure exact index ordering relative to A8.
        cmp_df = cmp_df.loc[a8_ref.index]

        result = bootstrap_pair(
            y=y,
            p_a8=p_a8,
            p_cmp=cmp_df["probability"].to_numpy(),
            reps=BOOTSTRAP_REPS,
            seed=SEED + 1000 + i,
        )

        result["comparison"] = f"A8 vs {name}"
        result["comparator"] = name
        records.append(result)

        print(f"  A8 AUC       : {result['observed_a8_auc']:.6f}")
        print(f"  Comparator   : {result['observed_comparator_auc']:.6f}")
        print(f"  Difference   : {result['observed_auc_difference']:+.6f}")
        print(
            f"  95% CI       : "
            f"[{result['bootstrap_ci_lower']:.6f}, "
            f"{result['bootstrap_ci_upper']:.6f}]"
        )
        print(
            f"  P(A8 better) : "
            f"{result['bootstrap_probability_a8_better']:.6f}"
        )
        print(f"  p (2-sided)  : {result['p_value_two_sided']:.8f}")

    # --------------------------------------------------------
    # Holm correction
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("5. HOLM MULTIPLE-COMPARISON CORRECTION")
    print("=" * 80)

    raw_p = [r["p_value_two_sided"] for r in records]
    holm_p = holm_adjust(raw_p)

    for r, hp in zip(records, holm_p):
        r["holm_adjusted_p"] = float(hp)
        r["holm_significant_0_05"] = bool(hp < ALPHA)

        print(
            f"{r['comparator']:25s} "
            f"raw p={r['p_value_two_sided']:.8f} "
            f"Holm p={hp:.8f} "
            f"CI excludes 0={r['ci_excludes_zero']}"
        )

    # --------------------------------------------------------
    # Fold-level AUC audit where outer_fold is available
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("6. FOLD-LEVEL AUC AUDIT")
    print("=" * 80)

    fold_records = []

    # A8 fold labels
    a8_raw = pd.read_csv(A8_FILE)
    if "outer_fold" in a8_raw.columns:
        fold_col = "outer_fold"
        row_col = "row_index"
        prob_col = "probability"
        y_col = "y_true"

        for fold in sorted(a8_raw[fold_col].unique()):
            a8f = a8_raw[a8_raw[fold_col] == fold].copy()
            y_fold = pd.to_numeric(a8f[y_col]).to_numpy()
            p_fold_a8 = pd.to_numeric(a8f[prob_col]).to_numpy()

            row_ids = a8f[row_col].astype(int).to_numpy()

            for name, path in {
                "A6 Sparse Grouped ChebKAN": A6_FILE,
                **BASELINES,
            }.items():
                df_raw = pd.read_csv(path)
                if fold_col not in df_raw.columns:
                    continue

                cf = df_raw[df_raw[fold_col] == fold].copy()
                cf = cf.set_index(row_col).loc[row_ids]

                p_cmp = pd.to_numeric(
                    cf[find_column(cf, ["probability", "prob", "y_prob"], "probability")]
                ).to_numpy()

                fold_records.append({
                    "fold": int(fold),
                    "comparator": name,
                    "a8_auc": auc(y_fold, p_fold_a8),
                    "comparator_auc": auc(y_fold, p_cmp),
                    "difference_a8_minus_comparator":
                        auc(y_fold, p_fold_a8) - auc(y_fold, p_cmp),
                })

    fold_df = pd.DataFrame(fold_records)

    if not fold_df.empty:
        fold_summary = (
            fold_df.groupby("comparator")
            .agg(
                mean_a8_auc=("a8_auc", "mean"),
                mean_comparator_auc=("comparator_auc", "mean"),
                mean_difference=("difference_a8_minus_comparator", "mean"),
                sd_difference=("difference_a8_minus_comparator", "std"),
            )
            .reset_index()
        )
    else:
        fold_summary = pd.DataFrame()

    # --------------------------------------------------------
    # Final table
    # --------------------------------------------------------
    results_df = pd.DataFrame(records)

    # Practical significance descriptors
    results_df["absolute_auc_gain"] = results_df["observed_auc_difference"]
    results_df["relative_auc_gain_percent"] = (
        results_df["observed_auc_difference"]
        / results_df["observed_comparator_auc"]
        * 100.0
    )

    # Add fold-level summaries
    if not fold_summary.empty:
        results_df = results_df.merge(
            fold_summary,
            on="comparator",
            how="left"
        )

    results_df.to_csv(OUT_CSV, index=False)

    # --------------------------------------------------------
    # Summary JSON
    # --------------------------------------------------------
    summary = {
        "implementation": "45",
        "status": "PASS_A8_PAIRED_STATISTICAL_COMPARISON",
        "seed": SEED,
        "bootstrap_replicates_requested": BOOTSTRAP_REPS,
        "alpha": ALPHA,
        "development_rows": 49000,
        "calibration_loaded": False,
        "locked_test_loaded": False,
        "uci_loaded": False,
        "retraining": False,
        "hyperparameter_tuning": False,
        "a8_pooled_auc": auc(y, p_a8),
        "a6_pooled_auc": auc(y, p_a6),
        "a8_minus_a6_auc": auc(y, p_a8) - auc(y, p_a6),
        "comparisons": results_df.to_dict(orient="records"),
    }

    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    # --------------------------------------------------------
    # Human-readable report
    # --------------------------------------------------------
    lines = []
    lines.append("=" * 80)
    lines.append("IMPLEMENTATION 45 REPORT")
    lines.append("PAIRED STATISTICAL COMPARISON OF A8 VS A6 AND VERIFIED BASELINES")
    lines.append("=" * 80)
    lines.append("")
    lines.append("PROTOCOL")
    lines.append("Development cohort only: 49,000")
    lines.append("Calibration data loaded: NO")
    lines.append("Locked test loaded: NO")
    lines.append("UCI data loaded: NO")
    lines.append("Retraining: NO")
    lines.append("Hyperparameter tuning: NO")
    lines.append(f"Bootstrap replicates: {BOOTSTRAP_REPS}")
    lines.append("Bootstrap design: outcome-stratified paired patient-level")
    lines.append("Confidence interval: 95% percentile bootstrap CI")
    lines.append("Multiple-comparison correction: Holm")
    lines.append("")
    lines.append("POOLED AUC")
    lines.append(f"A8: {auc(y, p_a8):.6f}")
    lines.append(f"A6: {auc(y, p_a6):.6f}")
    lines.append(f"A8 - A6: {auc(y, p_a8) - auc(y, p_a6):+.6f}")
    lines.append("")
    lines.append("PAIRED COMPARISONS")
    lines.append("-" * 80)

    for _, r in results_df.iterrows():
        lines.append(
            f"{r['comparator']}: "
            f"diff={r['observed_auc_difference']:+.6f}; "
            f"95% CI=[{r['bootstrap_ci_lower']:.6f}, "
            f"{r['bootstrap_ci_upper']:.6f}]; "
            f"raw p={r['p_value_two_sided']:.8f}; "
            f"Holm p={r['holm_adjusted_p']:.8f}; "
            f"CI excludes zero={r['ci_excludes_zero']}"
        )

    lines.append("")
    lines.append("INTERPRETATION")
    lines.append(
        "A8 is evaluated on exactly the same 49,000 Development/CV records "
        "as A6 and the verified baseline prediction files."
    )
    lines.append(
        "The paired bootstrap tests whether the observed AUC difference "
        "between A8 and each comparator is distinguishable from zero."
    )
    lines.append(
        "Statistical significance should not be interpreted as clinical "
        "significance; the absolute AUC differences must also be considered."
    )
    lines.append(
        "If A8 is statistically superior to A6, this supports selecting A8 "
        "for the subsequent locked-test evaluation. If not, architecture "
        "selection should consider parsimony and interpretability."
    )
    lines.append("")
    lines.append(
        "IMPORTANT: This is Development-CV evidence only. The locked test, "
        "conformal calibration set, and UCI external cohorts remain protected."
    )

    with open(OUT_REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # --------------------------------------------------------
    # Console summary
    # --------------------------------------------------------
    print("\n" + "=" * 80)
    print("7. FINAL SUMMARY")
    print("=" * 80)

    print(f"A8 pooled ROC-AUC: {auc(y, p_a8):.6f}")

    for _, r in results_df.iterrows():
        print(
            f"{r['comparator']:25s} "
            f"diff={r['observed_auc_difference']:+.6f} "
            f"95% CI=[{r['bootstrap_ci_lower']:.6f}, "
            f"{r['bootstrap_ci_upper']:.6f}] "
            f"Holm p={r['holm_adjusted_p']:.8f}"
        )

    print("\nOutputs:")
    print(OUT_CSV)
    print(OUT_JSON)
    print(OUT_REPORT)

    print("\n" + "=" * 80)
    print("IMPLEMENTATION 45 COMPLETE")
    print("Final status: PASS_A8_PAIRED_STATISTICAL_COMPARISON")
    print("=" * 80)


if __name__ == "__main__":
    main()
