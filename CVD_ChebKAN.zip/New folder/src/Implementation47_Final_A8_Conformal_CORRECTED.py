# -*- coding: utf-8 -*-
"""
IMPLEMENTATION 47
FINAL A8 CLASS-CONDITIONAL CONFORMAL PREDICTION

Purpose
-------
Apply split conformal prediction to the FINAL A8 model selected in
Implementation 45C and evaluated on the locked Kaggle test in Implementation 46.

STRICT PROTOCOL
---------------
1. The final A8 checkpoint from Implementation 46 is loaded.
2. The 7,000-record calibration cohort is used ONLY to estimate conformal
   nonconformity quantiles.
3. The locked 14,000-record test cohort is NEVER used to determine conformal
   quantiles.
4. No model retraining.
5. No hyperparameter tuning.
6. No threshold optimization.
7. No changes to the final A8 architecture.
8. The conformal calibration set is separate from both Development and
   locked test data.

Method
------
Class-conditional split conformal prediction.

For calibration example i with true class y_i:

    score_i = 1 - p(y_i | x_i)

Separate score distributions are formed for class 0 and class 1.

For miscoverage alpha, the finite-sample conformal quantile is:

    k = ceil((n_class + 1) * (1-alpha))

using the k-th smallest calibration score.

For a test patient, class c is included in the prediction set when:

    1 - p(c | x) <= q_c

Reported:
    - empirical coverage
    - average prediction-set size
    - singleton rate
    - ambiguous/two-class rate
    - empty-set rate
    - class-specific inclusion rates
    - class-specific quantiles

Expected:
    90% conformal prediction
    95% conformal prediction

Outputs
-------
results/tables/implementation47_conformal_summary.csv
results/tables/implementation47_conformal_test_predictions.csv
results/tables/implementation47_conformal_calibration_scores.csv
results/tables/implementation47_conformal_protocol.json
results/tables/implementation47_conformal_summary.json
"""

from __future__ import annotations

import json
import math
import random
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd
import torch


# =============================================================================
# 0. PROJECT CONFIGURATION
# =============================================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

CAL_FILE = PROJECT_ROOT / r"data\processed\kaggle_conformal_calibration.csv"
TEST_FILE = PROJECT_ROOT / r"data\processed\kaggle_locked_test.csv"

CHECKPOINT_FILE = (
    PROJECT_ROOT
    / r"results\checkpoints\implementation46_final_a8_final_model.pt"
)

OUT_TABLES = PROJECT_ROOT / r"results\tables"

SUMMARY_CSV = (
    OUT_TABLES
    / "implementation47_conformal_summary.csv"
)

PREDICTIONS_CSV = (
    OUT_TABLES
    / "implementation47_conformal_test_predictions.csv"
)

CAL_SCORES_CSV = (
    OUT_TABLES
    / "implementation47_conformal_calibration_scores.csv"
)

PROTOCOL_JSON = (
    OUT_TABLES
    / "implementation47_conformal_protocol.json"
)

SUMMARY_JSON = (
    OUT_TABLES
    / "implementation47_conformal_summary.json"
)

MODEL_MODULE_FILE = (
    PROJECT_ROOT
    / r"src\Implementation46_Final_A8_LockedTest_CORRECTED.py"
)

SEED = 20261006

ID_COL = "id"
TARGET = "cardio"

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

GROUPS = {
    "demographic": ["age", "gender"],
    "physiological_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],
    "lifestyle": ["smoke", "alco", "active"],
}

ALPHAS = {
    "90": 0.10,
    "95": 0.05,
}

BATCH_SIZE = 1024

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# =============================================================================
# 1. REPRODUCIBILITY
# =============================================================================

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# =============================================================================
# 2. LOAD FINAL A8 IMPLEMENTATION MODULE
# =============================================================================

def load_a8_module():
    if not MODEL_MODULE_FILE.exists():
        raise FileNotFoundError(
            f"Final A8 model-definition file not found:\n"
            f"{MODEL_MODULE_FILE}"
        )

    spec = importlib.util.spec_from_file_location(
        "implementation46_final_a8",
        str(MODEL_MODULE_FILE),
    )

    if spec is None or spec.loader is None:
        raise ImportError(
            "Could not load Implementation 46 model module."
        )

    module = importlib.util.module_from_spec(spec)

    spec.loader.exec_module(module)

    return module


# =============================================================================
# 3. DATA VALIDATION
# =============================================================================

def validate_dataset(
    df: pd.DataFrame,
    name: str,
    expected_n: int,
) -> None:

    required = FEATURES + [TARGET, ID_COL]

    missing_columns = [
        c for c in required
        if c not in df.columns
    ]

    if missing_columns:
        raise ValueError(
            f"{name} missing required columns: "
            f"{missing_columns}"
        )

    if len(df) != expected_n:
        raise ValueError(
            f"{name}: expected {expected_n} rows; "
            f"found {len(df)}."
        )

    if df[ID_COL].duplicated().any():
        raise ValueError(
            f"{name} contains duplicate IDs."
        )

    unexpected_missing = (
        df[FEATURES]
        .isna()
        .sum()
    )

    unexpected = {
        feature: int(count)
        for feature, count in unexpected_missing.items()
        if count > 0
        and feature not in {"ap_hi", "ap_lo"}
    }

    if unexpected:
        raise ValueError(
            f"{name} has unexpected missing values: {unexpected}"
        )

    if df[TARGET].isna().any():
        raise ValueError(
            f"{name} has missing target labels."
        )

    labels = set(
        df[TARGET].astype(int).unique()
    )

    if not labels.issubset({0, 1}):
        raise ValueError(
            f"{name} target is not binary 0/1: {labels}"
        )


# =============================================================================
# 4. PREPROCESSING
# =============================================================================

def transform_with_checkpoint_preprocessing(
    df: pd.DataFrame,
    medians: np.ndarray,
    minmax: np.ndarray,
) -> np.ndarray:

    X = df[FEATURES].to_numpy(
        dtype=np.float64
    )

    X_imp = X.copy()

    for j in range(X_imp.shape[1]):
        missing = ~np.isfinite(X_imp[:, j])
        X_imp[missing, j] = medians[j]

    x_min = np.asarray(
        minmax[:, 0],
        dtype=np.float64,
    )

    x_max = np.asarray(
        minmax[:, 1],
        dtype=np.float64,
    )

    denominator = x_max - x_min
    denominator[denominator == 0] = 1.0

    X_scaled = (
        2.0
        * (X_imp - x_min)
        / denominator
        - 1.0
    )

    return np.clip(
        X_scaled,
        -1.0,
        1.0,
    ).astype(np.float32)


def make_group_arrays(
    X_scaled: np.ndarray,
) -> dict[str, np.ndarray]:

    feature_to_index = {
        feature: i
        for i, feature in enumerate(FEATURES)
    }

    result = {}

    for group_name, group_features in GROUPS.items():

        indices = [
            feature_to_index[f]
            for f in group_features
        ]

        result[group_name] = X_scaled[:, indices]

    return result


# =============================================================================
# 5. DATASET
# =============================================================================

class GroupDataset(torch.utils.data.Dataset):

    def __init__(
        self,
        group_arrays: dict[str, np.ndarray],
        y: np.ndarray,
    ):

        self.group_arrays = {
            key: torch.tensor(
                value,
                dtype=torch.float32,
            )
            for key, value in group_arrays.items()
        }

        self.y = torch.tensor(
            y.astype(np.float32),
            dtype=torch.float32,
        )

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):

        return (
            {
                key: value[idx]
                for key, value in self.group_arrays.items()
            },
            self.y[idx],
        )


# =============================================================================
# 6. MODEL PREDICTION
# =============================================================================

@torch.no_grad()
def predict_probabilities(
    model,
    loader,
) -> np.ndarray:

    model.eval()

    probabilities = []

    for group_batch, _ in loader:

        group_batch = {
            key: value.to(DEVICE)
            for key, value in group_batch.items()
        }

        logits = model(group_batch)

        probabilities.append(
            torch.sigmoid(logits)
            .detach()
            .cpu()
            .numpy()
        )

    return np.concatenate(probabilities)


# =============================================================================
# 7. FINITE-SAMPLE CONFORMAL QUANTILE
# =============================================================================

def conformal_quantile(
    scores: np.ndarray,
    alpha: float,
) -> float:

    """
    Conservative finite-sample split-conformal quantile.

    k = ceil((n+1)*(1-alpha))

    The k-th order statistic is used, with k capped at n.
    """

    scores = np.asarray(
        scores,
        dtype=np.float64,
    )

    scores = scores[np.isfinite(scores)]

    n = len(scores)

    if n == 0:
        raise ValueError(
            "Cannot calculate conformal quantile with zero scores."
        )

    k = int(
        math.ceil(
            (n + 1)
            * (1.0 - alpha)
        )
    )

    k = min(
        max(k, 1),
        n,
    )

    sorted_scores = np.sort(scores)

    q = float(
        sorted_scores[k - 1]
    )

    return q


# =============================================================================
# 8. BUILD CONFORMAL SETS
# =============================================================================

def build_prediction_sets(
    probabilities: np.ndarray,
    q0: float,
    q1: float,
):
    """
    Include class 0 if:
        1 - p0 <= q0

    Include class 1 if:
        1 - p1 <= q1
    """

    p1 = np.asarray(
        probabilities,
        dtype=np.float64,
    )

    p0 = 1.0 - p1

    include0 = (
        1.0 - p0
        <= q0
    )

    include1 = (
        1.0 - p1
        <= q1
    )

    return include0, include1


def set_string(
    include0: bool,
    include1: bool,
) -> str:

    if include0 and include1:
        return "{0,1}"

    if include0:
        return "{0}"

    if include1:
        return "{1}"

    return "{}"


# =============================================================================
# 9. CONFORMAL METRICS
# =============================================================================

def conformal_metrics(
    y_true: np.ndarray,
    include0: np.ndarray,
    include1: np.ndarray,
) -> dict:

    y_true = np.asarray(
        y_true,
        dtype=int,
    )

    include0 = np.asarray(
        include0,
        dtype=bool,
    )

    include1 = np.asarray(
        include1,
        dtype=bool,
    )

    covered = np.where(
        y_true == 0,
        include0,
        include1,
    )

    set_size = (
        include0.astype(int)
        + include1.astype(int)
    )

    singleton = set_size == 1
    ambiguous = set_size == 2
    empty = set_size == 0

    class0 = y_true == 0
    class1 = y_true == 1

    class0_inclusion = (
        np.mean(include0[class0])
        if np.any(class0)
        else np.nan
    )

    class1_inclusion = (
        np.mean(include1[class1])
        if np.any(class1)
        else np.nan
    )

    return {
        "n": int(len(y_true)),
        "coverage": float(np.mean(covered)),
        "target_coverage": None,
        "average_set_size": float(np.mean(set_size)),
        "singleton_rate": float(np.mean(singleton)),
        "ambiguous_rate": float(np.mean(ambiguous)),
        "empty_rate": float(np.mean(empty)),
        "class0_count": int(np.sum(class0)),
        "class1_count": int(np.sum(class1)),
        "class0_true_inclusion_rate": float(class0_inclusion),
        "class1_true_inclusion_rate": float(class1_inclusion),
    }


# =============================================================================
# 10. MAIN
# =============================================================================

def main():

    set_seed(SEED)

    OUT_TABLES.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("=" * 80)
    print("IMPLEMENTATION 47")
    print("FINAL A8 CLASS-CONDITIONAL CONFORMAL PREDICTION")
    print("=" * 80)

    print("\nSTRICT PROTECTION")
    print("-" * 80)
    print("Final A8 checkpoint loaded: YES")
    print("Model retraining: NO")
    print("Hyperparameter tuning: NO")
    print("Calibration cohort used only for conformal calibration: YES")
    print("Locked test used for conformal quantile estimation: NO")
    print("Locked test used for threshold/conformal tuning: NO")
    print(f"Device: {DEVICE}")

    # -------------------------------------------------------------------------
    # Load model module.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("1. LOADING FINAL A8 MODEL DEFINITION")
    print("=" * 80)

    a8_module = load_a8_module()

    model = a8_module.A8_CGS_ChebKAN(
        group_sizes={
            name: len(features)
            for name, features in GROUPS.items()
        },
        degree=5,
        embed_dim=16,
    ).to(DEVICE)

    parameter_count = sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )

    if parameter_count != 1924:
        raise ValueError(
            f"Expected 1,924 A8 parameters; "
            f"found {parameter_count}."
        )

    # -------------------------------------------------------------------------
    # Load checkpoint.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("2. LOADING FINAL A8 CHECKPOINT")
    print("=" * 80)

    if not CHECKPOINT_FILE.exists():
        raise FileNotFoundError(
            f"Final A8 checkpoint not found:\n"
            f"{CHECKPOINT_FILE}"
        )

    checkpoint = torch.load(
        CHECKPOINT_FILE,
        map_location=DEVICE,
        weights_only=False,
    )

    # The final Implementation 46 checkpoint is authoritative for the trained
    # state and Development-fitted preprocessing. Some metadata names can vary
    # between script versions, so architecture validation is performed from
    # the actual checkpoint contents and strict state-dict loading.
    required_checkpoint_keys = [
        "model_state_dict",
        "features",
        "groups",
        "cheb_degree",
        "preprocessing_medians",
        "preprocessing_minmax",
    ]

    missing_checkpoint_keys = [
        key
        for key in required_checkpoint_keys
        if key not in checkpoint
    ]

    if missing_checkpoint_keys:
        raise ValueError(
            "Checkpoint is missing required fields: "
            f"{missing_checkpoint_keys}"
        )

    if checkpoint["features"] != FEATURES:
        raise ValueError(
            "Checkpoint feature list does not match frozen A8 features."
        )

    if checkpoint["groups"] != GROUPS:
        raise ValueError(
            "Checkpoint clinical groups do not match frozen A8 groups."
        )

    if int(checkpoint["cheb_degree"]) != 5:
        raise ValueError(
            "Checkpoint Chebyshev degree is not K=5."
        )

    # Embedding dimension is verified from the actual state dictionary.
    state_dict = checkpoint["model_state_dict"]

    expected_shapes = {
        "gate_logits": (3,),
        "branches.demographic.kan.coefficients": (16, 2, 6),
        "branches.demographic.kan.bias": (16,),
        "branches.physiological_metabolic.kan.coefficients": (16, 6, 6),
        "branches.physiological_metabolic.kan.bias": (16,),
        "branches.lifestyle.kan.coefficients": (16, 3, 6),
        "branches.lifestyle.kan.bias": (16,),
        "interaction_projection.weight": (16, 48),
        "interaction_projection.bias": (16,),
        "output_layer.weight": (1, 32),
        "output_layer.bias": (1,),
    }

    for key, expected_shape in expected_shapes.items():
        if key not in state_dict:
            raise ValueError(
                f"Final A8 checkpoint is missing state-dict key: {key}"
            )

        actual_shape = tuple(
            state_dict[key].shape
        )

        if actual_shape != expected_shape:
            raise ValueError(
                f"Final A8 checkpoint shape mismatch for {key}: "
                f"expected {expected_shape}, found {actual_shape}"
            )

    model.load_state_dict(
        state_dict,
        strict=True,
    )

    model.eval()

    print("PASS: A8 checkpoint strict loading.")
    print("PASS: A8 architecture verified from state-dict shapes.")
    print("PASS: Chebyshev degree K=5.")
    print("PASS: Embedding dimension = 16.")
    print(f"Parameter count: {parameter_count}")

    # -------------------------------------------------------------------------
    # Load calibration and locked test.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("3. LOADING CALIBRATION AND LOCKED TEST COHORTS")
    print("=" * 80)

    if not CAL_FILE.exists():
        raise FileNotFoundError(
            f"Calibration file not found:\n{CAL_FILE}"
        )

    if not TEST_FILE.exists():
        raise FileNotFoundError(
            f"Locked test file not found:\n{TEST_FILE}"
        )

    cal_df = pd.read_csv(CAL_FILE)
    test_df = pd.read_csv(TEST_FILE)

    validate_dataset(
        cal_df,
        "Conformal calibration",
        7000,
    )

    validate_dataset(
        test_df,
        "Locked test",
        14000,
    )

    cal_ids = set(
        cal_df[ID_COL].astype(str)
    )

    test_ids = set(
        test_df[ID_COL].astype(str)
    )

    overlap = cal_ids.intersection(
        test_ids
    )

    if overlap:
        raise ValueError(
            f"Calibration/test ID overlap detected: "
            f"{len(overlap)}"
        )

    print(
        f"Calibration rows: {len(cal_df)}"
    )
    print(
        f"Locked test rows: {len(test_df)}"
    )
    print(
        f"Calibration/test ID overlap: {len(overlap)}"
    )

    # -------------------------------------------------------------------------
    # Recover preprocessing parameters from final checkpoint.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("4. APPLYING FROZEN FINAL-MODEL PREPROCESSING")
    print("=" * 80)

    medians = np.asarray(
        checkpoint["preprocessing_medians"],
        dtype=np.float64,
    )

    minmax = np.asarray(
        checkpoint["preprocessing_minmax"],
        dtype=np.float64,
    )

    if medians.shape[0] != len(FEATURES):
        raise ValueError(
            "Checkpoint preprocessing median length mismatch."
        )

    if minmax.shape != (len(FEATURES), 2):
        raise ValueError(
            "Checkpoint preprocessing min/max shape mismatch."
        )

    X_cal = transform_with_checkpoint_preprocessing(
        cal_df,
        medians,
        minmax,
    )

    X_test = transform_with_checkpoint_preprocessing(
        test_df,
        medians,
        minmax,
    )

    print(
        "Preprocessing source: final A8 checkpoint "
        "(fitted on Development only)"
    )
    print(
        "Calibration/test data used to fit preprocessing: NO"
    )

    # -------------------------------------------------------------------------
    # Group inputs.
    # -------------------------------------------------------------------------

    cal_groups = make_group_arrays(
        X_cal
    )

    test_groups = make_group_arrays(
        X_test
    )

    y_cal = cal_df[TARGET].to_numpy(
        dtype=np.int64
    )

    y_test = test_df[TARGET].to_numpy(
        dtype=np.int64
    )

    # -------------------------------------------------------------------------
    # Datasets and loaders.
    # -------------------------------------------------------------------------

    cal_dataset = GroupDataset(
        cal_groups,
        y_cal,
    )

    test_dataset = GroupDataset(
        test_groups,
        y_test,
    )

    cal_loader = torch.utils.data.DataLoader(
        cal_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    test_loader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    # -------------------------------------------------------------------------
    # Generate probabilities.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("5. GENERATING CALIBRATION AND TEST PROBABILITIES")
    print("=" * 80)

    p_cal = predict_probabilities(
        model,
        cal_loader,
    )

    p_test = predict_probabilities(
        model,
        test_loader,
    )

    if len(p_cal) != 7000:
        raise ValueError(
            f"Expected 7,000 calibration probabilities; "
            f"found {len(p_cal)}."
        )

    if len(p_test) != 14000:
        raise ValueError(
            f"Expected 14,000 test probabilities; "
            f"found {len(p_test)}."
        )

    print(
        f"Calibration probabilities: {len(p_cal)}"
    )
    print(
        f"Locked-test probabilities: {len(p_test)}"
    )

    # -------------------------------------------------------------------------
    # Calibration nonconformity scores.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("6. COMPUTING CLASS-CONDITIONAL CALIBRATION SCORES")
    print("=" * 80)

    p_cal = np.clip(
        p_cal,
        0.0,
        1.0,
    )

    p0_cal = 1.0 - p_cal
    p1_cal = p_cal

    scores_cal = np.where(
        y_cal == 0,
        1.0 - p0_cal,
        1.0 - p1_cal,
    )

    scores_class0 = scores_cal[y_cal == 0]
    scores_class1 = scores_cal[y_cal == 1]

    print(
        f"Calibration class 0 count: "
        f"{len(scores_class0)}"
    )
    print(
        f"Calibration class 1 count: "
        f"{len(scores_class1)}"
    )

    # Save calibration scores for audit.
    cal_score_df = pd.DataFrame(
        {
            "id": cal_df[ID_COL].to_numpy(),
            "true_label": y_cal,
            "probability_class1": p_cal,
            "nonconformity_score": scores_cal,
        }
    )

    cal_score_df.to_csv(
        CAL_SCORES_CSV,
        index=False,
    )

    # -------------------------------------------------------------------------
    # Calculate conformal quantiles.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("7. COMPUTING FINITE-SAMPLE CONFORMAL QUANTILES")
    print("=" * 80)

    quantiles = {}

    for level, alpha in ALPHAS.items():

        q0 = conformal_quantile(
            scores_class0,
            alpha,
        )

        q1 = conformal_quantile(
            scores_class1,
            alpha,
        )

        quantiles[level] = {
            "alpha": alpha,
            "target_coverage": 1.0 - alpha,
            "q0": q0,
            "q1": q1,
            "n_class0": int(len(scores_class0)),
            "n_class1": int(len(scores_class1)),
        }

        print(
            f"{level}% target coverage:"
        )
        print(
            f"  q0 = {q0:.6f}"
        )
        print(
            f"  q1 = {q1:.6f}"
        )

    # -------------------------------------------------------------------------
    # Apply conformal sets to locked test.
    # -------------------------------------------------------------------------

    print("\n" + "=" * 80)
    print("8. LOCKED-TEST CONFORMAL EVALUATION")
    print("=" * 80)

    p_test = np.clip(
        p_test,
        0.0,
        1.0,
    )

    rows = []

    summary_rows = []

    for level, qinfo in quantiles.items():

        q0 = qinfo["q0"]
        q1 = qinfo["q1"]

        include0, include1 = build_prediction_sets(
            p_test,
            q0,
            q1,
        )

        metrics = conformal_metrics(
            y_test,
            include0,
            include1,
        )

        metrics["confidence_level"] = int(level)
        metrics["alpha"] = float(qinfo["alpha"])
        metrics["q0"] = float(q0)
        metrics["q1"] = float(q1)

        summary_rows.append(metrics)

        print(
            f"\n{level}% conformal prediction:"
        )
        print(
            f"  Coverage:        {metrics['coverage']:.6f}"
        )
        print(
            f"  Avg set size:    {metrics['average_set_size']:.6f}"
        )
        print(
            f"  Singleton rate:  {metrics['singleton_rate']:.6f}"
        )
        print(
            f"  Ambiguous rate:  {metrics['ambiguous_rate']:.6f}"
        )
        print(
            f"  Empty-set rate:  {metrics['empty_rate']:.6f}"
        )

        # Add one row per test patient for each confidence level.
        set_labels = [
            set_string(
                bool(a),
                bool(b),
            )
            for a, b in zip(
                include0,
                include1,
            )
        ]

        set_sizes = (
            include0.astype(int)
            + include1.astype(int)
        )

        covered = np.where(
            y_test == 0,
            include0,
            include1,
        )

        for i in range(len(test_df)):
            rows.append(
                {
                    "confidence_level": int(level),
                    "id": test_df.iloc[i][ID_COL],
                    "true_label": int(y_test[i]),
                    "probability_class1": float(p_test[i]),
                    "q0": float(q0),
                    "q1": float(q1),
                    "prediction_set": set_labels[i],
                    "prediction_set_size": int(set_sizes[i]),
                    "covered": int(covered[i]),
                }
            )

    prediction_df = pd.DataFrame(rows)

    prediction_df.to_csv(
        PREDICTIONS_CSV,
        index=False,
    )

    summary_df = pd.DataFrame(
        summary_rows
    )

    # Put useful columns first.
    ordered_columns = [
        "confidence_level",
        "alpha",
        "target_coverage",
        "n",
        "coverage",
        "average_set_size",
        "singleton_rate",
        "ambiguous_rate",
        "empty_rate",
        "class0_count",
        "class1_count",
        "class0_true_inclusion_rate",
        "class1_true_inclusion_rate",
        "q0",
        "q1",
    ]

    summary_df = summary_df[
        [
            c
            for c in ordered_columns
            if c in summary_df.columns
        ]
    ]

    summary_df.to_csv(
        SUMMARY_CSV,
        index=False,
    )

    # -------------------------------------------------------------------------
    # Protocol audit.
    # -------------------------------------------------------------------------

    protocol = {
        "implementation": "47",
        "status": "PASS_FINAL_A8_CONFORMAL_EVALUATION",
        "seed": SEED,
        "device": str(DEVICE),
        "model_checkpoint": str(CHECKPOINT_FILE),
        "model_parameter_count": int(parameter_count),
        "calibration_file": str(CAL_FILE),
        "calibration_rows": int(len(cal_df)),
        "locked_test_file": str(TEST_FILE),
        "locked_test_rows": int(len(test_df)),
        "calibration_test_id_overlap": int(len(overlap)),
        "model_retraining": False,
        "hyperparameter_tuning": False,
        "locked_test_used_for_quantile_estimation": False,
        "locked_test_used_for_model_selection": False,
        "locked_test_used_for_threshold_selection": False,
        "preprocessing_fit_source": (
            "Development-only preprocessing stored in final A8 checkpoint"
        ),
        "conformal_method": (
            "Class-conditional split conformal prediction"
        ),
        "nonconformity_score": (
            "1 - predicted probability of the true class"
        ),
        "quantile_rule": (
            "k = ceil((n_class + 1)*(1-alpha)); "
            "k-th smallest score"
        ),
        "confidence_levels": [90, 95],
        "quantiles": quantiles,
    }

    with open(
        PROTOCOL_JSON,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            protocol,
            f,
            indent=2,
        )

    summary_json = {
        "implementation": "47",
        "status": "PASS_FINAL_A8_CONFORMAL_EVALUATION",
        "results": summary_rows,
        "quantiles": quantiles,
        "files": {
            "summary_csv": str(SUMMARY_CSV),
            "prediction_sets_csv": str(PREDICTIONS_CSV),
            "calibration_scores_csv": str(CAL_SCORES_CSV),
            "protocol_json": str(PROTOCOL_JSON),
        },
    }

    with open(
        SUMMARY_JSON,
        "w",
        encoding="utf-8",
    ) as f:
        json.dump(
            summary_json,
            f,
            indent=2,
        )

    print("\n" + "=" * 80)
    print("IMPLEMENTATION 47 COMPLETE")
    print("Final status: PASS_FINAL_A8_CONFORMAL_EVALUATION")
    print("=" * 80)

    print("\nOutputs:")
    print(f"  Summary:          {SUMMARY_CSV}")
    print(f"  Test prediction sets: {PREDICTIONS_CSV}")
    print(f"  Calibration scores:  {CAL_SCORES_CSV}")
    print(f"  Protocol:         {PROTOCOL_JSON}")
    print(f"  JSON summary:     {SUMMARY_JSON}")


if __name__ == "__main__":
    main()
