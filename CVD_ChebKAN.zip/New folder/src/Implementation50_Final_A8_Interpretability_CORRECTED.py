# ============================================================
# Implementation50_Final_A8_Interpretability_FINAL.py
# Exact reconstruction of final A8 checkpoint
# ============================================================

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

# ============================================================
# 1. PATHS
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

CHECKPOINT_PATH = (
    PROJECT_ROOT
    / "results"
    / "checkpoints"
    / "implementation46_final_a8_final_model.pt"
)

TABLES_DIR = PROJECT_ROOT / "results" / "tables"
FIGURES_DIR = PROJECT_ROOT / "results" / "figures"

TABLES_DIR.mkdir(parents=True, exist_ok=True)
FIGURES_DIR.mkdir(parents=True, exist_ok=True)

LOCKED_PRED_PATH = (
    TABLES_DIR
    / "implementation46_final_a8_locked_test_predictions.csv"
)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("=" * 78)
print("IMPLEMENTATION 50 - FINAL A8 INTERPRETABILITY")
print("=" * 78)
print(f"Checkpoint: {CHECKPOINT_PATH}")
print(f"Device: {DEVICE}")

if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")

# ============================================================
# 2. LOAD CHECKPOINT
# ============================================================

if not CHECKPOINT_PATH.exists():
    raise FileNotFoundError(
        f"Checkpoint not found:\n{CHECKPOINT_PATH}"
    )

checkpoint = torch.load(
    CHECKPOINT_PATH,
    map_location="cpu",
    weights_only=False
)

state_dict = checkpoint["model_state_dict"]

print("\nState-dict:")

for key, value in state_dict.items():
    print(f"{key:<65} {tuple(value.shape)}")

parameter_count = sum(
    value.numel() for value in state_dict.values()
)

# ============================================================
# 3. CHECKPOINT METADATA
# ============================================================

features = list(checkpoint["features"])
groups = checkpoint["groups"]

K = int(checkpoint["cheb_degree"])
EMBED = int(checkpoint["embedding_dim"])

print("\nFeatures:")
print(features)

print("\nGroups:")
print(groups)

print(f"\nChebyshev degree: {K}")
print(f"Embedding dimension: {EMBED}")

print("\nSaved preprocessing metadata types:")
print(
    "preprocessing_medians:",
    type(checkpoint["preprocessing_medians"])
)

print(
    "preprocessing_minmax:",
    type(checkpoint["preprocessing_minmax"])
)

print(
    "\npreprocessing_minmax raw object:"
)
print(checkpoint["preprocessing_minmax"])

# ============================================================
# 4. EXACT CHEBKAN BRANCH
# ============================================================

class ExactChebKANBranch(nn.Module):

    def __init__(
        self,
        n_features,
        embedding_dim,
        degree
    ):
        super().__init__()

        self.coefficients = nn.Parameter(
            torch.zeros(
                embedding_dim,
                n_features,
                degree + 1
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(embedding_dim)
        )

    def chebyshev_basis(self, x):

        basis = [
            torch.ones_like(x)
        ]

        if self.coefficients.shape[-1] > 1:
            basis.append(x)

        for k in range(
            2,
            self.coefficients.shape[-1]
        ):

            basis.append(
                2.0 * x * basis[-1]
                - basis[-2]
            )

        return torch.stack(
            basis,
            dim=-1
        )

    def forward(self, x):

        basis = self.chebyshev_basis(x)

        output = torch.einsum(
            "nfk,efk->ne",
            basis,
            self.coefficients
        )

        output = output + self.bias

        return torch.nn.functional.silu(output)


# ============================================================
# 5. EXACT A8 MODEL
# ============================================================

class ExactA8Model(nn.Module):

    def __init__(
        self,
        groups,
        degree=5,
        embedding_dim=16
    ):

        super().__init__()

        self.group_names = list(groups.keys())

        self.branches = nn.ModuleDict()

        for group_name, group_features in groups.items():

            self.branches[group_name] = nn.ModuleDict({
                "kan": ExactChebKANBranch(
                    n_features=len(group_features),
                    embedding_dim=embedding_dim,
                    degree=degree
                )
            })

        self.gate_logits = nn.Parameter(
            torch.zeros(len(self.group_names))
        )

        self.interaction_projection = nn.Linear(
            embedding_dim * 3,
            embedding_dim
        )

        self.output_layer = nn.Linear(
            embedding_dim * 2,
            1
        )

    def forward(
        self,
        x_by_group,
        return_components=False
    ):

        embeddings = {}

        for group_name in self.group_names:

            embeddings[group_name] = (
                self.branches[group_name]["kan"](
                    x_by_group[group_name]
                )
            )

        gate_probabilities = torch.softmax(
            self.gate_logits,
            dim=0
        )

        gated = torch.zeros_like(
            embeddings[self.group_names[0]]
        )

        for index, group_name in enumerate(
            self.group_names
        ):

            gated = (
                gated
                + gate_probabilities[index]
                * embeddings[group_name]
            )

        demo = embeddings["demographic"]

        phys = embeddings[
            "physiological_metabolic"
        ]

        life = embeddings["lifestyle"]

        interaction_vector = torch.cat(
            [
                demo * phys,
                demo * life,
                phys * life
            ],
            dim=1
        )

        interaction_embedding = (
            torch.nn.functional.silu(
                self.interaction_projection(
                    interaction_vector
                )
            )
        )

        fused = torch.cat(
            [
                gated,
                interaction_embedding
            ],
            dim=1
        )

        logits = self.output_layer(
            fused
        ).squeeze(1)

        if return_components:

            return {
                "logits": logits,
                "probabilities": torch.sigmoid(logits),
                "embeddings": embeddings,
                "gate_probabilities": gate_probabilities,
                "gated_embedding": gated,
                "interaction_vector": interaction_vector,
                "interaction_embedding": interaction_embedding,
                "fused": fused
            }

        return logits


# ============================================================
# 6. STRICT CHECKPOINT LOAD
# ============================================================

model = ExactA8Model(
    groups=groups,
    degree=K,
    embedding_dim=EMBED
)

model.load_state_dict(
    state_dict,
    strict=True
)

model.to(DEVICE)
model.eval()

loaded_parameter_count = sum(
    parameter.numel()
    for parameter in model.parameters()
)

print("\n" + "=" * 78)
print("STRICT ARCHITECTURE VERIFICATION")
print("=" * 78)

print("STRICT LOAD: PASS")
print(f"Parameters: {loaded_parameter_count}")

if loaded_parameter_count != 1924:
    raise RuntimeError(
        "Parameter count is not 1924."
    )

print("Architecture verification: PASS")

# ============================================================
# 7. ROBUST PREPROCESSING METADATA READER
# ============================================================

medians = checkpoint[
    "preprocessing_medians"
]

minmax = checkpoint[
    "preprocessing_minmax"
]


def get_median(
    metadata,
    feature,
    feature_index
):

    # Dictionary format
    if isinstance(metadata, dict):

        value = metadata[feature]

        if isinstance(value, dict):

            for key in [
                "median",
                "value"
            ]:

                if key in value:
                    return float(value[key])

        return float(value)

    # List / tuple / ndarray format
    if isinstance(
        metadata,
        (list, tuple, np.ndarray)
    ):

        value = metadata[feature_index]

        if isinstance(
            value,
            (list, tuple, np.ndarray)
        ):

            return float(
                np.asarray(value).reshape(-1)[0]
            )

        return float(value)

    raise TypeError(
        f"Unsupported median metadata type: "
        f"{type(metadata)}"
    )


def get_minmax(
    metadata,
    feature,
    feature_index
):

    # --------------------------------------------------------
    # Dictionary format
    # --------------------------------------------------------

    if isinstance(metadata, dict):

        value = metadata[feature]

        if isinstance(value, dict):

            lower = None
            upper = None

            for key in [
                "min",
                "minimum",
                "lower"
            ]:

                if key in value:
                    lower = float(value[key])
                    break

            for key in [
                "max",
                "maximum",
                "upper"
            ]:

                if key in value:
                    upper = float(value[key])
                    break

            if lower is not None and upper is not None:
                return lower, upper

        if isinstance(
            value,
            (list, tuple, np.ndarray)
        ):

            arr = np.asarray(
                value,
                dtype=float
            ).reshape(-1)

            if len(arr) >= 2:
                return float(arr[0]), float(arr[1])

    # --------------------------------------------------------
    # List / tuple / ndarray format
    # --------------------------------------------------------

    if isinstance(
        metadata,
        (list, tuple, np.ndarray)
    ):

        arr = np.asarray(
            metadata,
            dtype=float
        )

        # Format:
        # [[min,max],
        #  [min,max], ...]
        if arr.ndim == 2:

            if arr.shape[0] == len(features):
                return (
                    float(arr[feature_index, 0]),
                    float(arr[feature_index, 1])
                )

            if arr.shape[1] == len(features):
                return (
                    float(arr[0, feature_index]),
                    float(arr[1, feature_index])
                )

        # Format:
        # [min_feature1, min_feature2, ...]
        # [max_feature1, max_feature2, ...]
        if arr.ndim == 1:

            if len(arr) == 2 * len(features):

                return (
                    float(arr[2 * feature_index]),
                    float(arr[
                        2 * feature_index + 1
                    ])
                )

    raise TypeError(
        "Unable to interpret preprocessing_minmax "
        f"for feature '{feature}'.\n"
        f"Metadata type: {type(metadata)}\n"
        f"Metadata shape: "
        f"{getattr(metadata, 'shape', None)}\n"
        f"Metadata value: {metadata}"
    )


# ============================================================
# 8. LOAD LOCKED TEST
# ============================================================

candidate_paths = [

    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_locked_test.csv",

    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_test.csv",

    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_locked_test_14000.csv"
]

test_path = None

for path in candidate_paths:

    if path.exists():

        test_path = path
        break

if test_path is None:

    processed_dir = (
        PROJECT_ROOT
        / "data"
        / "processed"
    )

    if processed_dir.exists():

        for path in processed_dir.glob(
            "*.csv"
        ):

            try:

                temp = pd.read_csv(
                    path,
                    nrows=5
                )

                if all(
                    feature in temp.columns
                    for feature in features
                ):

                    full = pd.read_csv(
                        path,
                        usecols=[features[0]]
                    )

                    if len(full) == 14000:

                        test_path = path
                        break

            except Exception:
                continue

if test_path is None:

    raise FileNotFoundError(
        "Could not locate the 14,000-row "
        "locked test dataset."
    )

print("\nLocked test:")
print(test_path)

test = pd.read_csv(
    test_path
)

if len(test) != 14000:

    raise RuntimeError(
        f"Expected 14000 test rows, "
        f"found {len(test)}"
    )

if "cardio" not in test.columns:

    if "target" in test.columns:
        test["cardio"] = test["target"]

    elif "label" in test.columns:
        test["cardio"] = test["label"]

    else:
        raise KeyError(
            "Target column not found."
        )

# ============================================================
# 9. PREPROCESS
# ============================================================

def preprocess(df):

    work = df.copy()

    for index, feature in enumerate(
        features
    ):

        work[feature] = pd.to_numeric(
            work[feature],
            errors="coerce"
        )

        median = get_median(
            medians,
            feature,
            index
        )

        work[feature] = (
            work[feature]
            .fillna(median)
        )

    X = work[
        features
    ].astype(
        np.float32
    ).copy()

    for index, feature in enumerate(
        features
    ):

        lo, hi = get_minmax(
            minmax,
            feature,
            index
        )

        if hi == lo:

            X[feature] = 0.0

        else:

            X[feature] = (
                2.0
                * (
                    (
                        X[feature] - lo
                    )
                    / (hi - lo)
                )
                - 1.0
            )

    X = X.clip(
        -1.0,
        1.0
    )

    return X


Xdf = preprocess(
    test
)

print("\nPreprocessing: PASS")

# ============================================================
# 10. MODEL PREDICTIONS
# ============================================================

X = {}

for group_name, group_features in groups.items():

    X[group_name] = torch.tensor(
        Xdf[group_features].values,
        dtype=torch.float32,
        device=DEVICE
    )

with torch.no_grad():

    output = model(
        X,
        return_components=True
    )

probabilities = (
    output["probabilities"]
    .detach()
    .cpu()
    .numpy()
)

logits = (
    output["logits"]
    .detach()
    .cpu()
    .numpy()
)

predictions = (
    probabilities >= 0.50
).astype(int)

print("\nPredictions generated: PASS")
print(
    "Probability range:",
    probabilities.min(),
    probabilities.max()
)

# ============================================================
# 11. REPRODUCTION CHECK
# ============================================================

print("\n" + "=" * 78)
print("FINAL A8 PREDICTION REPRODUCTION")
print("=" * 78)

if LOCKED_PRED_PATH.exists():

    saved = pd.read_csv(
        LOCKED_PRED_PATH
    )

    probability_columns = [
        "probability",
        "predicted_probability",
        "prob",
        "y_prob",
        "p_positive"
    ]

    probability_column = None

    for column in probability_columns:

        if column in saved.columns:

            probability_column = column
            break

    if (
        probability_column is not None
        and len(saved) == len(probabilities)
    ):

        saved_probabilities = (
            pd.to_numeric(
                saved[probability_column],
                errors="coerce"
            ).to_numpy()
        )

        max_difference = np.max(
            np.abs(
                saved_probabilities
                - probabilities
            )
        )

        mean_difference = np.mean(
            np.abs(
                saved_probabilities
                - probabilities
            )
        )

        print(
            "Saved probability column:",
            probability_column
        )

        print(
            "Maximum absolute difference:",
            f"{max_difference:.12e}"
        )

        print(
            "Mean absolute difference:",
            f"{mean_difference:.12e}"
        )

        if max_difference <= 1e-6:

            print(
                "REPRODUCTION: PASS"
            )

        elif max_difference <= 1e-4:

            print(
                "REPRODUCTION: PASS "
                "(numeric tolerance)"
            )

        else:

            raise RuntimeError(
                "Prediction reproduction failed. "
                f"Maximum difference={max_difference}"
            )

    else:

        print(
            "Saved prediction probability "
            "column could not be identified."
        )

else:

    print(
        "Saved final prediction file "
        "not found; reproduction not checked."
    )

# ============================================================
# 12. GROUP GATE ANALYSIS
# ============================================================

gate_probabilities = (
    output["gate_probabilities"]
    .detach()
    .cpu()
    .numpy()
)

gate_table = pd.DataFrame({

    "group": list(
        groups.keys()
    ),

    "gate_probability": (
        gate_probabilities
    )

})

gate_table.to_csv(
    TABLES_DIR
    / "implementation50_a8_group_gate_analysis.csv",
    index=False
)

print("\nGroup gates:")

print(
    gate_table.to_string(
        index=False
    )
)

# ============================================================
# 13. CHEBYSHEV COEFFICIENT ANALYSIS
# ============================================================

rows = []

for group_name, group_features in groups.items():

    coefficients = (
        model
        .branches[group_name]["kan"]
        .coefficients
        .detach()
        .cpu()
        .numpy()
    )

    for feature_index, feature in enumerate(
        group_features
    ):

        for degree in range(
            K + 1
        ):

            values = coefficients[
                :,
                feature_index,
                degree
            ]

            rows.append({

                "group": group_name,

                "feature": feature,

                "chebyshev_degree": degree,

                "mean_coefficient":
                    np.mean(values),

                "mean_abs_coefficient":
                    np.mean(
                        np.abs(values)
                    ),

                "max_abs_coefficient":
                    np.max(
                        np.abs(values)
                    ),

                "l2_coefficient":
                    np.sqrt(
                        np.sum(
                            values ** 2
                        )
                    )
            })

coefficient_table = pd.DataFrame(
    rows
)

coefficient_table.to_csv(
    TABLES_DIR
    / "implementation50_a8_chebyshev_coefficients.csv",
    index=False
)

feature_importance = (
    coefficient_table
    .groupby(
        ["group", "feature"],
        as_index=False
    )
    .agg({

        "mean_abs_coefficient": "mean",

        "max_abs_coefficient": "max",

        "l2_coefficient": "mean"

    })
    .sort_values(
        "mean_abs_coefficient",
        ascending=False
    )
)

feature_importance.to_csv(
    TABLES_DIR
    / "implementation50_a8_feature_coefficient_importance.csv",
    index=False
)

print("\nTop coefficient-based features:")

print(
    feature_importance.head(15)
    .to_string(index=False)
)

# ============================================================
# 14. GROUP INTERACTION ANALYSIS
# ============================================================

embeddings = output[
    "embeddings"
]

demo = (
    embeddings["demographic"]
    .detach()
    .cpu()
    .numpy()
)

phys = (
    embeddings[
        "physiological_metabolic"
    ]
    .detach()
    .cpu()
    .numpy()
)

life = (
    embeddings["lifestyle"]
    .detach()
    .cpu()
    .numpy()
)

interaction_data = {

    "demographic_x_physiological_metabolic":
        demo * phys,

    "demographic_x_lifestyle":
        demo * life,

    "physiological_metabolic_x_lifestyle":
        phys * life
}

interaction_rows = []

for name, values in interaction_data.items():

    interaction_rows.append({

        "interaction": name,

        "mean_abs_activation":
            np.mean(
                np.abs(values)
            ),

        "mean_activation":
            np.mean(values),

        "max_abs_activation":
            np.max(
                np.abs(values)
            ),

        "l2_activation":
            np.sqrt(
                np.sum(
                    values ** 2
                )
            )
    })

interaction_table = pd.DataFrame(
    interaction_rows
)

interaction_table.to_csv(
    TABLES_DIR
    / "implementation50_a8_group_interaction_summary.csv",
    index=False
)

print("\nGroup interactions:")

print(
    interaction_table.to_string(
        index=False
    )
)

# ============================================================
# 15. SAVE PREDICTIONS FOR INTERPRETABILITY
# ============================================================

prediction_output = test.copy()

prediction_output[
    "a8_logit"
] = logits

prediction_output[
    "a8_probability"
] = probabilities

prediction_output[
    "a8_prediction"
] = predictions

prediction_output.to_csv(
    TABLES_DIR
    / "implementation50_a8_interpretability_predictions.csv",
    index=False
)

# ============================================================
# 16. SAVE SUMMARY
# ============================================================

summary = {

    "status": "PASS",

    "checkpoint":
        str(CHECKPOINT_PATH),

    "device":
        str(DEVICE),

    "gpu":
        (
            torch.cuda.get_device_name(0)
            if torch.cuda.is_available()
            else "CPU"
        ),

    "parameter_count":
        int(loaded_parameter_count),

    "chebyshev_degree":
        int(K),

    "embedding_dimension":
        int(EMBED),

    "locked_test_rows":
        int(len(test)),

    "gate_probabilities": {

        group:
            float(value)

        for group, value
        in zip(
            groups.keys(),
            gate_probabilities
        )
    },

    "outputs": [

        "implementation50_a8_group_gate_analysis.csv",

        "implementation50_a8_chebyshev_coefficients.csv",

        "implementation50_a8_feature_coefficient_importance.csv",

        "implementation50_a8_group_interaction_summary.csv",

        "implementation50_a8_interpretability_predictions.csv"

    ]
}

with open(
    TABLES_DIR
    / "implementation50_a8_interpretability_summary.json",
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        summary,
        file,
        indent=2
    )

print("\n" + "=" * 78)
print("IMPLEMENTATION 50 COMPLETED")
print("=" * 78)
print("Strict loading: PASS")
print("Parameter count:", loaded_parameter_count)
print("Interpretability analysis: PASS")
print()
print(
    "Tables saved to:",
    TABLES_DIR
)
print("=" * 78)