# =============================================================================
# CVD CGS-ChebKAN
# AUDIT 08 — KAGGLE CLINICAL PLAUSIBILITY / DATA QUALITY AUDIT
# =============================================================================

from pathlib import Path
import pandas as pd
import numpy as np

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

KAGGLE_FILE = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "kaggle"
    / "cardio_train 70k.csv"
)

RESULTS_DIR = (
    PROJECT_ROOT
    / "data"
    / "processed"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

# -----------------------------------------------------------------------------
# Load data
# -----------------------------------------------------------------------------

print("=" * 78)
print("CVD CGS-ChebKAN — AUDIT 08")
print("KAGGLE CLINICAL PLAUSIBILITY / DATA QUALITY AUDIT")
print("=" * 78)

df = pd.read_csv(
    KAGGLE_FILE,
    sep=","
)

print("\nDataset:")
print(f"Rows    : {len(df):,}")
print(f"Columns : {len(df.columns)}")

# -----------------------------------------------------------------------------
# Basic integrity
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("1. BASIC DATA INTEGRITY")
print("=" * 78)

print("\nMissing values:")
missing = df.isna().sum()
missing = missing[missing > 0]

if len(missing) == 0:
    print("No standard missing values detected.")
else:
    print(missing)

print(
    f"\nExact duplicate rows: "
    f"{df.duplicated().sum():,}"
)

print(
    f"Duplicate IDs: "
    f"{df['id'].duplicated().sum():,}"
)

print("\nColumn data types:")
print(df.dtypes)

# -----------------------------------------------------------------------------
# Age
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("2. AGE PLAUSIBILITY")
print("=" * 78)

age_years = df["age"] / 365.25

age_rules = {
    "age < 18 years": age_years < 18,
    "age > 100 years": age_years > 100,
    "age 18-100 years": age_years.between(18, 100),
}

for name, mask in age_rules.items():
    print(
        f"{name:25s}: "
        f"{mask.sum():,} "
        f"({mask.mean() * 100:.3f}%)"
    )

print("\nAge summary in years:")
print(age_years.describe())

# -----------------------------------------------------------------------------
# Height
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("3. HEIGHT PLAUSIBILITY")
print("=" * 78)

height_rules = {
    "height < 100 cm": df["height"] < 100,
    "height 100-140 cm": df["height"].between(100, 140),
    "height 140-200 cm": df["height"].between(140, 200),
    "height > 200 cm": df["height"] > 200,
}

for name, mask in height_rules.items():
    print(
        f"{name:25s}: "
        f"{mask.sum():,} "
        f"({mask.mean() * 100:.3f}%)"
    )

print("\nHeight summary:")
print(df["height"].describe())

print("\nLowest 20 heights:")
print(
    df.loc[
        df["height"].nsmallest(20).index,
        ["id", "age", "gender", "height", "weight"]
    ].to_string(index=False)
)

print("\nHighest 20 heights:")
print(
    df.loc[
        df["height"].nlargest(20).index,
        ["id", "age", "gender", "height", "weight"]
    ].to_string(index=False)
)

# -----------------------------------------------------------------------------
# Weight
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("4. WEIGHT PLAUSIBILITY")
print("=" * 78)

weight_rules = {
    "weight < 30 kg": df["weight"] < 30,
    "weight 30-40 kg": df["weight"].between(30, 40),
    "weight 40-200 kg": df["weight"].between(40, 200),
    "weight > 200 kg": df["weight"] > 200,
}

for name, mask in weight_rules.items():
    print(
        f"{name:25s}: "
        f"{mask.sum():,} "
        f"({mask.mean() * 100:.3f}%)"
    )

print("\nWeight summary:")
print(df["weight"].describe())

print("\nLowest 20 weights:")
print(
    df.loc[
        df["weight"].nsmallest(20).index,
        ["id", "age", "gender", "height", "weight"]
    ].to_string(index=False)
)

print("\nHighest 20 weights:")
print(
    df.loc[
        df["weight"].nlargest(20).index,
        ["id", "age", "gender", "height", "weight"]
    ].to_string(index=False)
)

# -----------------------------------------------------------------------------
# Systolic BP
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("5. SYSTOLIC BLOOD PRESSURE — ap_hi")
print("=" * 78)

sbp_rules = {
    "ap_hi <= 0": df["ap_hi"] <= 0,
    "ap_hi 1-69": df["ap_hi"].between(1, 69),
    "ap_hi 70-89": df["ap_hi"].between(70, 89),
    "ap_hi 90-139": df["ap_hi"].between(90, 139),
    "ap_hi 140-179": df["ap_hi"].between(140, 179),
    "ap_hi 180-250": df["ap_hi"].between(180, 250),
    "ap_hi 251-300": df["ap_hi"].between(251, 300),
    "ap_hi > 300": df["ap_hi"] > 300,
}

for name, mask in sbp_rules.items():
    print(
        f"{name:25s}: "
        f"{mask.sum():,} "
        f"({mask.mean() * 100:.3f}%)"
    )

print("\nSystolic BP summary:")
print(df["ap_hi"].describe())

print("\nLowest 30 systolic values:")
print(
    df.loc[
        df["ap_hi"].nsmallest(30).index,
        ["id", "age", "gender", "height", "weight", "ap_hi", "ap_lo"]
    ].to_string(index=False)
)

print("\nHighest 30 systolic values:")
print(
    df.loc[
        df["ap_hi"].nlargest(30).index,
        ["id", "age", "gender", "height", "weight", "ap_hi", "ap_lo"]
    ].to_string(index=False)
)

# -----------------------------------------------------------------------------
# Diastolic BP
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("6. DIASTOLIC BLOOD PRESSURE — ap_lo")
print("=" * 78)

dbp_rules = {
    "ap_lo <= 0": df["ap_lo"] <= 0,
    "ap_lo 1-39": df["ap_lo"].between(1, 39),
    "ap_lo 40-59": df["ap_lo"].between(40, 59),
    "ap_lo 60-89": df["ap_lo"].between(60, 89),
    "ap_lo 90-119": df["ap_lo"].between(90, 119),
    "ap_lo 120-150": df["ap_lo"].between(120, 150),
    "ap_lo 151-200": df["ap_lo"].between(151, 200),
    "ap_lo > 200": df["ap_lo"] > 200,
}

for name, mask in dbp_rules.items():
    print(
        f"{name:25s}: "
        f"{mask.sum():,} "
        f"({mask.mean() * 100:.3f}%)"
    )

print("\nDiastolic BP summary:")
print(df["ap_lo"].describe())

print("\nLowest 30 diastolic values:")
print(
    df.loc[
        df["ap_lo"].nsmallest(30).index,
        ["id", "age", "gender", "height", "weight", "ap_hi", "ap_lo"]
    ].to_string(index=False)
)

print("\nHighest 30 diastolic values:")
print(
    df.loc[
        df["ap_lo"].nlargest(30).index,
        ["id", "age", "gender", "height", "weight", "ap_hi", "ap_lo"]
    ].to_string(index=False)
)

# -----------------------------------------------------------------------------
# Blood-pressure logical consistency
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("7. BLOOD PRESSURE LOGICAL CONSISTENCY")
print("=" * 78)

bp_invalid_order = df["ap_hi"] <= df["ap_lo"]

print(
    f"ap_hi <= ap_lo: "
    f"{bp_invalid_order.sum():,} "
    f"({bp_invalid_order.mean() * 100:.3f}%)"
)

print(
    f"ap_hi > ap_lo: "
    f"{(df['ap_hi'] > df['ap_lo']).sum():,} "
    f"({(df['ap_hi'] > df['ap_lo']).mean() * 100:.3f}%)"
)

print("\nExamples where ap_hi <= ap_lo:")

print(
    df.loc[
        bp_invalid_order,
        ["id", "age", "gender", "ap_hi", "ap_lo", "cardio"]
    ]
    .head(30)
    .to_string(index=False)
)

# -----------------------------------------------------------------------------
# Potential BP scale / digit-entry anomalies
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("8. POTENTIAL BP SCALE / DIGIT-ENTRY ANOMALIES")
print("=" * 78)

# Values above 300 are obviously outside a normal adult clinical measurement
# range and will be investigated, NOT automatically deleted.

bp_extreme = (
    (df["ap_hi"] > 300)
    | (df["ap_hi"] <= 0)
    | (df["ap_lo"] > 200)
    | (df["ap_lo"] <= 0)
)

print(
    f"Records with extreme/invalid BP candidate: "
    f"{bp_extreme.sum():,} "
    f"({bp_extreme.mean() * 100:.3f}%)"
)

print("\nCandidate records:")

print(
    df.loc[
        bp_extreme,
        [
            "id",
            "age",
            "gender",
            "height",
            "weight",
            "ap_hi",
            "ap_lo",
            "cholesterol",
            "gluc",
            "cardio",
        ]
    ]
    .sort_values(
        ["ap_hi", "ap_lo"]
    )
    .to_string(index=False)
)

# -----------------------------------------------------------------------------
# Categorical variables
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("9. CATEGORICAL VARIABLE VALIDITY")
print("=" * 78)

categorical_rules = {
    "gender": [1, 2],
    "cholesterol": [1, 2, 3],
    "gluc": [1, 2, 3],
    "smoke": [0, 1],
    "alco": [0, 1],
    "active": [0, 1],
    "cardio": [0, 1],
}

categorical_invalid = {}

for col, valid_values in categorical_rules.items():

    invalid_mask = ~df[col].isin(valid_values)

    categorical_invalid[col] = invalid_mask

    print(
        f"\n{col}"
    )
    print(
        f"Valid values: {valid_values}"
    )
    print(
        f"Invalid values: "
        f"{invalid_mask.sum():,} "
        f"({invalid_mask.mean() * 100:.3f}%)"
    )

    print(
        "Observed values:"
    )
    print(
        df[col]
        .value_counts(dropna=False)
        .sort_index()
        .to_string()
    )

# -----------------------------------------------------------------------------
# Target balance
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("10. TARGET DISTRIBUTION")
print("=" * 78)

target_counts = df["cardio"].value_counts().sort_index()
target_props = df["cardio"].value_counts(
    normalize=True
).sort_index()

print("\nCounts:")
print(target_counts)

print("\nProportions:")
print(target_props)

# -----------------------------------------------------------------------------
# Combined candidate flags
# -----------------------------------------------------------------------------

print("\n" + "=" * 78)
print("11. COMBINED CLINICAL QUALITY CANDIDATE FLAGS")
print("=" * 78)

flags = pd.DataFrame(index=df.index)

flags["invalid_age"] = (
    (age_years < 18)
    | (age_years > 100)
)

flags["height_lt_100"] = (
    df["height"] < 100
)

flags["height_gt_200"] = (
    df["height"] > 200
)

flags["weight_lt_30"] = (
    df["weight"] < 30
)

flags["weight_gt_200"] = (
    df["weight"] > 200
)

flags["sbp_nonpositive"] = (
    df["ap_hi"] <= 0
)

flags["sbp_gt_300"] = (
    df["ap_hi"] > 300
)

flags["dbp_nonpositive"] = (
    df["ap_lo"] <= 0
)

flags["dbp_gt_200"] = (
    df["ap_lo"] > 200
)

flags["bp_order_invalid"] = (
    df["ap_hi"] <= df["ap_lo"]
)

for col, invalid_mask in categorical_invalid.items():
    flags[f"invalid_{col}"] = invalid_mask

flags["any_candidate_flag"] = (
    flags.any(axis=1)
)

print("\nCandidate flag counts:")

for col in flags.columns:
    count = flags[col].sum()
    pct = count / len(df) * 100

    print(
        f"{col:25s}: "
        f"{count:6,} "
        f"({pct:7.3f}%)"
    )

# -----------------------------------------------------------------------------
# Number of simultaneous flags
# -----------------------------------------------------------------------------

flag_columns = [
    c for c in flags.columns
    if c != "any_candidate_flag"
]

flags["number_of_flags"] = (
    flags[flag_columns].sum(axis=1)
)

print("\nRecords by number of candidate flags:")

print(
    flags["number_of_flags"]
    .value_counts()
    .sort_index()
    .to_string()
)

# -----------------------------------------------------------------------------
# Candidate records for review
# -----------------------------------------------------------------------------

candidate_records = df.loc[
    flags["any_candidate_flag"]
].copy()

candidate_records["age_years"] = (
    candidate_records["age"] / 365.25
)

candidate_records["number_of_flags"] = (
    flags.loc[
        candidate_records.index,
        "number_of_flags"
    ]
)

print("\n" + "=" * 78)
print("12. CANDIDATE RECORDS FOR CLINICAL REVIEW")
print("=" * 78)

print(
    f"Records with at least one candidate flag: "
    f"{len(candidate_records):,}"
)

print("\nFirst 100 candidate records:")

display_columns = [
    "id",
    "age",
    "age_years",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
    "cardio",
    "number_of_flags",
]

print(
    candidate_records[
        display_columns
    ]
    .sort_values(
        ["number_of_flags", "id"],
        ascending=[False, True]
    )
    .head(100)
    .to_string(index=False)
)

# -----------------------------------------------------------------------------
# Save audit report
# -----------------------------------------------------------------------------

report_file = (
    RESULTS_DIR
    / "audit_08_kaggle_clinical_quality.txt"
)

with open(
    report_file,
    "w",
    encoding="utf-8"
) as f:

    f.write(
        "CVD CGS-ChebKAN — AUDIT 08\n"
        "KAGGLE CLINICAL PLAUSIBILITY / DATA QUALITY AUDIT\n"
        "=" * 78
        + "\n\n"
    )

    f.write(
        f"Rows: {len(df):,}\n"
        f"Columns: {len(df.columns)}\n\n"
    )

    f.write(
        "Candidate flag counts:\n"
    )

    for col in flags.columns:
        count = flags[col].sum()

        if col == "number_of_flags":
            continue

        f.write(
            f"{col}: {count:,} "
            f"({count / len(df) * 100:.3f}%)\n"
        )

    f.write(
        "\nIMPORTANT:\n"
        "This audit does not modify or delete any records.\n"
        "Candidate flags require methodological review before cleaning.\n"
    )

print("\n" + "=" * 78)
print("AUDIT 08 COMPLETED")
print("=" * 78)

print("\nAudit report saved to:")
print(report_file)

print("\nNO DATA WERE MODIFIED.")