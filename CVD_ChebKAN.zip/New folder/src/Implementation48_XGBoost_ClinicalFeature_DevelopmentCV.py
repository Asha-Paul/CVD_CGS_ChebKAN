"""
Implementation 48 (protocol-matched): XGBoost 11-feature vs 14-feature comparison.
Uses the Implementation 24 nested-CV protocol, with development data only.

- Same development CSV (49,000 records)
- Same 5 outer folds (StratifiedKFold, shuffle=True, random_state=2026)
- Same 4 inner folds (StratifiedKFold, shuffle=True, random_state=2026)
- Same Pipeline: median imputation + XGBClassifier
- Same hyperparameter grid and ROC-AUC selection criterion as Implementation 24
- Same grid-search configuration for both feature sets
- No calibration or locked-test data loaded
- Separate implementation48 output files; does not overwrite Implementation 24

Derived features:
  bmi = weight / (height_cm / 100)^2
  pulse_pressure = ap_hi - ap_lo
  mean_arterial_pressure = (ap_hi + 2*ap_lo) / 3

Note: This is a new nested-CV comparison, so selected hyperparameters may differ by
fold and feature set. Do not use locked-test data to choose a model.
"""

import json
import os
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, brier_score_loss, confusion_matrix
)
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

warnings.filterwarnings("ignore")

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")
DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results" / "tables"
DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

SEED = 2026
N_OUTER = 5
N_INNER = 4
ID_COL = "id"
TARGET = "cardio"

BASE_FEATURES = [
    "age", "gender", "height", "weight", "ap_hi", "ap_lo",
    "cholesterol", "gluc", "smoke", "alco", "active"
]
DERIVED_FEATURES = ["bmi", "pulse_pressure", "mean_arterial_pressure"]
FEATURE_SETS = {
    "XGBoost_11_features": BASE_FEATURES,
    "XGBoost_14_features": BASE_FEATURES + DERIVED_FEATURES,
}
PARAM_GRID = {
    "model__n_estimators": [200, 400],
    "model__max_depth": [3, 5],
    "model__learning_rate": [0.05, 0.10],
    "model__subsample": [0.8, 1.0],
    "model__colsample_bytree": [0.8, 1.0],
}


def derive_features(frame):
    out = frame.copy()
    height_m = pd.to_numeric(out["height"], errors="coerce") / 100.0
    weight = pd.to_numeric(out["weight"], errors="coerce")
    sbp = pd.to_numeric(out["ap_hi"], errors="coerce")
    dbp = pd.to_numeric(out["ap_lo"], errors="coerce")
    out["bmi"] = weight / (height_m ** 2)
    out["pulse_pressure"] = sbp - dbp
    out["mean_arterial_pressure"] = (sbp + 2.0 * dbp) / 3.0
    out[DERIVED_FEATURES] = out[DERIVED_FEATURES].replace(
        [np.inf, -np.inf], np.nan
    )
    out.loc[(~np.isfinite(height_m)) | (height_m <= 0), "bmi"] = np.nan
    return out


def calculate_ece(y_true, probabilities, n_bins=10):
    y_true = np.asarray(y_true)
    probabilities = np.asarray(probabilities)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        if i == n_bins - 1:
            mask = (probabilities >= edges[i]) & (probabilities <= edges[i + 1])
        else:
            mask = (probabilities >= edges[i]) & (probabilities < edges[i + 1])
        if np.any(mask):
            ece += np.mean(mask) * abs(
                np.mean(y_true[mask]) - np.mean(probabilities[mask])
            )
    return float(ece)


def calculate_metrics(y_true, probabilities, threshold=0.5):
    pred = (probabilities >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        "accuracy": float(accuracy_score(y_true, pred)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "sensitivity": float(recall_score(y_true, pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if tn + fp else float("nan"),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_true, probabilities)),
        "pr_auc": float(average_precision_score(y_true, probabilities)),
        "brier": float(brier_score_loss(y_true, probabilities)),
        "ece": calculate_ece(y_true, probabilities),
    }


def build_pipeline():
    model = XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        random_state=SEED,
        n_jobs=-1,
        verbosity=0,
    )
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", model),
    ])


def main():
    started = time.time()
    print("=" * 78)
    print("IMPLEMENTATION 48: PROTOCOL-MATCHED XGBOOST FEATURE COMPARISON")
    print("Nested 5x4 CV; development-only; locked test/calibration not loaded.")
    print("=" * 78)

    if not DEV_FILE.exists():
        raise FileNotFoundError(f"Development file not found: {DEV_FILE}")
    df = pd.read_csv(DEV_FILE)
    required = [ID_COL] + BASE_FEATURES + [TARGET]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Required columns missing: {missing}")
    if len(df) != 49000 or df[ID_COL].duplicated().any():
        raise RuntimeError(
            f"Expected 49,000 rows and unique IDs; found {len(df)} rows."
        )
    if df[TARGET].isna().any() or sorted(df[TARGET].unique().tolist()) != [0, 1]:
        raise RuntimeError("Target must be complete and binary {0,1}.")

    df = derive_features(df)
    y = df[TARGET].astype(int).to_numpy()
    outer_cv = StratifiedKFold(n_splits=N_OUTER, shuffle=True, random_state=SEED)
    inner_cv = StratifiedKFold(n_splits=N_INNER, shuffle=True, random_state=SEED)
    outer_splits = list(outer_cv.split(np.zeros(len(df)), y))

    print(f"Development rows: {len(df):,}; unique IDs: {df[ID_COL].nunique():,}")
    print("Derived-feature missing counts:")
    print(df[DERIVED_FEATURES].isna().sum().to_string())
    print("Grid size per outer fold:", int(np.prod([len(v) for v in PARAM_GRID.values()])))
    print("Hyperparameter selection: inner-CV ROC-AUC; same grid for both variants.")
    print("No locked-test or calibration file is opened.")

    all_predictions = []
    fold_rows = []
    selected_params = []

    for model_name, features in FEATURE_SETS.items():
        print("\n" + "=" * 78)
        print(f"MODEL: {model_name} ({len(features)} features)")
        X = df[features].copy()

        for fold_no, (train_idx, val_idx) in enumerate(outer_splits, start=1):
            print(f"\n{model_name} — outer fold {fold_no}/{N_OUTER}")
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]

            search = GridSearchCV(
                estimator=build_pipeline(),
                param_grid=PARAM_GRID,
                scoring="roc_auc",
                cv=inner_cv,
                n_jobs=-1,
                refit=True,
                return_train_score=False,
                verbose=0,
            )
            search.fit(X_train, y_train)
            prob = search.best_estimator_.predict_proba(X_val)[:, 1]
            fold_metrics = calculate_metrics(y_val, prob)

            fold_rows.append({
                "model": model_name,
                "fold": fold_no,
                "n_train": len(train_idx),
                "n_validation": len(val_idx),
                "best_inner_roc_auc": float(search.best_score_),
                **fold_metrics,
                **{
                    "selected_" + k.replace("model__", ""): v
                    for k, v in search.best_params_.items()
                },
            })
            selected_params.append({
                "model": model_name,
                "fold": fold_no,
                "best_inner_roc_auc": float(search.best_score_),
                **{
                    "selected_" + k.replace("model__", ""): v
                    for k, v in search.best_params_.items()
                },
            })
            all_predictions.append(pd.DataFrame({
                "model": model_name,
                "row_index": val_idx,
                "id": df.iloc[val_idx][ID_COL].to_numpy(),
                "outer_fold": fold_no,
                "y_true": y_val,
                "probability": prob,
                "prediction_050": (prob >= 0.5).astype(int),
            }))
            print(
                f"AUC={fold_metrics['roc_auc']:.6f}; "
                f"PR-AUC={fold_metrics['pr_auc']:.6f}; "
                f"Brier={fold_metrics['brier']:.6f}; "
                f"best params={search.best_params_}"
            )

    folds_df = pd.DataFrame(fold_rows)
    params_df = pd.DataFrame(selected_params)
    preds_df = pd.concat(all_predictions, ignore_index=True)

    folds_path = RESULTS_DIR / "implementation48_xgboost_clinical_feature_fold_results.csv"
    preds_path = RESULTS_DIR / "implementation48_xgboost_clinical_feature_oof_predictions.csv"
    params_path = RESULTS_DIR / "implementation48_xgboost_clinical_feature_selected_params.csv"
    summary_path = RESULTS_DIR / "implementation48_xgboost_clinical_feature_summary.json"

    folds_df.to_csv(folds_path, index=False)
    preds_df.to_csv(preds_path, index=False)
    params_df.to_csv(params_path, index=False)

    summary = {
        "implementation": 48,
        "purpose": "Protocol-matched nested-CV comparison of XGBoost with 11 vs 14 predictors",
        "development_rows": len(df),
        "unique_ids": int(df[ID_COL].nunique()),
        "outer_folds": N_OUTER,
        "inner_folds": N_INNER,
        "seed": SEED,
        "parameter_grid": PARAM_GRID,
        "imputation": "median fitted within pipeline during each inner-CV fit",
        "scoring": "ROC-AUC",
        "locked_test_used": False,
        "calibration_data_used": False,
        "models": {},
        "elapsed_minutes": round((time.time() - started) / 60.0, 2),
        "caution": "Development-CV only. This comparison re-runs nested CV for both feature sets; it does not evaluate the locked test.",
    }
    for model_name in FEATURE_SETS:
        p = preds_df[preds_df["model"] == model_name].sort_values("row_index")
        f = folds_df[folds_df["model"] == model_name]
        if len(p) != len(df) or p["row_index"].nunique() != len(df):
            raise RuntimeError(f"Prediction coverage failed for {model_name}")
        pooled = calculate_metrics(p["y_true"].to_numpy(), p["probability"].to_numpy())
        summary["models"][model_name] = {
            "pooled_oof_metrics": pooled,
            "mean_fold_roc_auc": float(f["roc_auc"].mean()),
            "sd_fold_roc_auc": float(f["roc_auc"].std(ddof=1)),
            "prediction_coverage_pass": True,
        }

    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("\n" + "=" * 78)
    print("IMPLEMENTATION 48 COMPLETE")
    for name, values in summary["models"].items():
        print(name, "pooled OOF:", values["pooled_oof_metrics"])
    print("Fold results:", folds_path)
    print("OOF predictions:", preds_path)
    print("Selected parameters:", params_path)
    print("Summary:", summary_path)
    print("Elapsed minutes:", summary["elapsed_minutes"])
    print("Locked test used: NO")


if __name__ == "__main__":
    main()
