# ============================================================
# 31b - CORRECTED A6
# Sparse Clinically-Grouped Chebyshev-KAN
#
# Includes:
#   1. KAN coefficient L1 regularization
#   2. Group-gate L1 regularization
#
# Reduced-runtime verification configuration
#
# Frozen methodology:
#   - 11 Kaggle features
#   - 3 clinical groups
#   - Chebyshev first-kind, K=5
#   - 16-dimensional group embeddings
#   - SiLU activation
#   - Softmax group gates
#   - Fold-specific median imputation
#   - MinMax scaling to [-1,1]
#   - Nested 5x4 stratified CV
#   - No ADASYN
#   - No conformal prediction in A6
#   - Calibration and locked test protected
#
# NOTE:
# This reduced-runtime run uses a restricted regularization grid
# to verify the corrected implementation efficiently.
# ============================================================

import os
import json
import time
import random
import warnings
from pathlib import Path
from itertools import product

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

warnings.filterwarnings("ignore")


# ============================================================
# 1. REPRODUCIBILITY
# ============================================================

SEED = 2026


def seed_everything(seed=SEED):

    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    os.environ["PYTHONHASHSEED"] = str(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


seed_everything()


# ============================================================
# 2. PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

DATA_DIR = (
    PROJECT_ROOT /
    "data" /
    "processed"
)

RESULTS_DIR = (
    PROJECT_ROOT /
    "results" /
    "tables"
)

MODELS_DIR = (
    PROJECT_ROOT /
    "results" /
    "models"
)

RESULTS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

MODELS_DIR.mkdir(
    parents=True,
    exist_ok=True
)

DEV_FILE = (
    DATA_DIR /
    "kaggle_development_cv.csv"
)

CAL_FILE = (
    DATA_DIR /
    "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    DATA_DIR /
    "kaggle_locked_test.csv"
)


# ============================================================
# 3. FEATURES
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active"
]

TARGET = "cardio"


# ============================================================
# 4. CLINICAL GROUPS
# ============================================================

GROUPS = {

    "demographic": [
        "age",
        "gender"
    ],

    "physiological_anthropometric_metabolic": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc"
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active"
    ]
}

GROUP_ORDER = list(
    GROUPS.keys()
)

GROUP_INDEXES = {

    group_name: [
        FEATURES.index(feature)
        for feature in feature_list
    ]

    for group_name,
    feature_list in GROUPS.items()
}


# ============================================================
# 5. MODEL SETTINGS
# ============================================================

CHEB_K = 5

GROUP_EMBED_DIM = 16

# Reduced-runtime search.
# Only the learning rate is varied.
LEARNING_RATES = [
    1e-3,
    3e-4
]

L2_VALUES = [
    1e-4
]

KAN_L1_VALUES = [
    1e-5
]

GATE_L1_VALUES = [
    1e-4
]

BATCH_SIZE = 1024

MAX_EPOCHS = 100

PATIENCE = 10

OUTER_FOLDS = 5

INNER_FOLDS = 4

DEVICE = torch.device(
    "cuda"
    if torch.cuda.is_available()
    else "cpu"
)


# ============================================================
# 6. ECE
# ============================================================

def expected_calibration_error(
    y_true,
    probabilities,
    n_bins=10
):

    y_true = np.asarray(
        y_true
    ).astype(int)

    probabilities = np.asarray(
        probabilities
    )

    bins = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    for i in range(n_bins):

        if i == n_bins - 1:

            mask = (
                (probabilities >= bins[i]) &
                (probabilities <= bins[i + 1])
            )

        else:

            mask = (
                (probabilities >= bins[i]) &
                (probabilities < bins[i + 1])
            )

        if not np.any(mask):
            continue

        confidence = np.mean(
            probabilities[mask]
        )

        accuracy = np.mean(
            y_true[mask]
            ==
            (probabilities[mask] >= 0.5)
        )

        ece += (
            np.sum(mask) /
            len(y_true)
        ) * abs(
            accuracy -
            confidence
        )

    return float(ece)


# ============================================================
# 7. METRICS
# ============================================================

def calculate_metrics(
    y_true,
    probabilities
):

    predictions = (
        probabilities >= 0.5
    ).astype(int)

    tn = np.sum(
        (y_true == 0) &
        (predictions == 0)
    )

    fp = np.sum(
        (y_true == 0) &
        (predictions == 1)
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else np.nan
    )

    return {

        "accuracy":
            accuracy_score(
                y_true,
                predictions
            ),

        "precision":
            precision_score(
                y_true,
                predictions,
                zero_division=0
            ),

        "sensitivity":
            recall_score(
                y_true,
                predictions,
                zero_division=0
            ),

        "specificity":
            specificity,

        "f1":
            f1_score(
                y_true,
                predictions,
                zero_division=0
            ),

        "roc_auc":
            roc_auc_score(
                y_true,
                probabilities
            ),

        "pr_auc":
            average_precision_score(
                y_true,
                probabilities
            ),

        "brier":
            brier_score_loss(
                y_true,
                probabilities
            ),

        "ece":
            expected_calibration_error(
                y_true,
                probabilities
            )
    }


# ============================================================
# 8. LOAD DATA
# ============================================================

def load_partition(
    path
):

    if not path.exists():

        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )

    df = pd.read_csv(
        path
    )

    required = (
        FEATURES +
        [TARGET]
    )

    missing = [
        column
        for column in required
        if column not in df.columns
    ]

    if missing:

        raise ValueError(
            f"Missing columns in "
            f"{path.name}: {missing}"
        )

    df = df.copy()

    df[TARGET] = (
        df[TARGET]
        .astype(int)
    )

    return df


# ============================================================
# 9. CHEBYSHEV KAN LAYER
# ============================================================

class ChebyshevKANLayer(
    nn.Module
):

    def __init__(
        self,
        in_features,
        out_features,
        degree=5
    ):

        super().__init__()

        self.in_features = (
            in_features
        )

        self.out_features = (
            out_features
        )

        self.degree = degree

        # [out, in, K+1]
        self.coeff = nn.Parameter(
            0.01 *
            torch.randn(
                out_features,
                in_features,
                degree + 1
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(
                out_features
            )
        )

    def chebyshev_basis(
        self,
        x
    ):

        basis = []

        # T0(x) = 1
        basis.append(
            torch.ones_like(x)
        )

        # T1(x) = x
        if self.degree >= 1:

            basis.append(x)

        # Tk(x) = 2xTk-1(x) - Tk-2(x)
        for k in range(
            2,
            self.degree + 1
        ):

            basis.append(
                2.0 *
                x *
                basis[-1]
                -
                basis[-2]
            )

        return torch.stack(
            basis,
            dim=-1
        )

    def forward(
        self,
        x
    ):

        # [batch, in, K+1]
        basis = (
            self.chebyshev_basis(x)
        )

        # [batch, 1, in, K+1]
        basis = basis.unsqueeze(1)

        # [1, out, in, K+1]
        coeff = (
            self.coeff.unsqueeze(0)
        )

        output = torch.sum(
            basis * coeff,
            dim=(2, 3)
        )

        return (
            output +
            self.bias
        )

    def coefficient_l1(
        self
    ):

        return torch.sum(
            torch.abs(
                self.coeff
            )
        )


# ============================================================
# 10. GROUP BRANCH
# ============================================================

class GroupChebBranch(
    nn.Module
):

    def __init__(
        self,
        n_features,
        embedding_dim=16,
        degree=5
    ):

        super().__init__()

        self.kan = (
            ChebyshevKANLayer(
                in_features=n_features,
                out_features=embedding_dim,
                degree=degree
            )
        )

        self.activation = nn.SiLU()

    def forward(
        self,
        x
    ):

        return self.activation(
            self.kan(x)
        )

    def coefficient_l1(
        self
    ):

        return (
            self.kan.coefficient_l1()
        )


# ============================================================
# 11. SPARSE GROUPED CHEBKAN
# ============================================================

class SparseGroupedChebKAN(
    nn.Module
):

    def __init__(
        self,
        group_sizes,
        embedding_dim=16,
        degree=5
    ):

        super().__init__()

        self.groups = (
            nn.ModuleDict()
        )

        for group_name in GROUP_ORDER:

            self.groups[
                group_name
            ] = GroupChebBranch(
                n_features=
                group_sizes[group_name],
                embedding_dim=
                embedding_dim,
                degree=
                degree
            )

        # Learnable pre-softmax group logits
        self.gate_logits = nn.Parameter(
            torch.zeros(
                len(GROUP_ORDER)
            )
        )

        self.output = nn.Linear(
            embedding_dim,
            1
        )

    def forward(
        self,
        group_inputs
    ):

        embeddings = []

        for group_name in GROUP_ORDER:

            h = self.groups[
                group_name
            ](
                group_inputs[
                    group_name
                ]
            )

            embeddings.append(h)

        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        fused = torch.zeros_like(
            embeddings[0]
        )

        for i in range(
            len(embeddings)
        ):

            fused = (
                fused
                +
                gates[i] *
                embeddings[i]
            )

        logits = (
            self.output(
                fused
            )
            .squeeze(1)
        )

        return logits

    def coefficient_l1(
        self
    ):

        total = torch.zeros(
            1,
            device=
            self.gate_logits.device
        )

        for group_name in GROUP_ORDER:

            total = (
                total
                +
                self.groups[
                    group_name
                ].coefficient_l1()
            )

        return total.squeeze()

    def gate_l1(
        self
    ):

        return torch.sum(
            torch.abs(
                self.gate_logits
            )
        )

    def gate_values(
        self
    ):

        return (
            torch.softmax(
                self.gate_logits.detach(),
                dim=0
            )
            .cpu()
            .numpy()
        )


# ============================================================
# 12. PREPROCESSING
# ============================================================

def fit_preprocessor(
    X_train
):

    imputer = (
        SimpleImputer(
            strategy="median"
        )
    )

    scaler = (
        MinMaxScaler(
            feature_range=(-1, 1)
        )
    )

    X_imputed = (
        imputer.fit_transform(
            X_train
        )
    )

    X_scaled = (
        scaler.fit_transform(
            X_imputed
        )
    )

    return (
        imputer,
        scaler,
        X_scaled
    )


def transform_preprocessor(
    X,
    imputer,
    scaler
):

    X_imputed = (
        imputer.transform(X)
    )

    X_scaled = (
        scaler.transform(
            X_imputed
        )
    )

    return X_scaled


# ============================================================
# 13. GROUP DATA
# ============================================================

def make_group_arrays(
    X
):

    groups = {}

    for group_name in GROUP_ORDER:

        indices = (
            GROUP_INDEXES[
                group_name
            ]
        )

        groups[group_name] = (
            X[:, indices]
            .astype(
                np.float32
            )
        )

    return groups


def make_group_tensors(
    X
):

    arrays = (
        make_group_arrays(X)
    )

    tensors = {}

    for group_name in GROUP_ORDER:

        tensors[group_name] = (
            torch.tensor(
                arrays[group_name],
                dtype=torch.float32,
                device=DEVICE
            )
        )

    return tensors


# ============================================================
# 14. SAFE DATALOADER
# ============================================================

def create_training_loader(
    X,
    y
):

    X = np.asarray(
        X,
        dtype=np.float32
    )

    y = np.asarray(
        y,
        dtype=np.float32
    )

    if X.ndim != 2:

        raise RuntimeError(
            "Training X must be 2-dimensional."
        )

    if len(X) != len(y):

        raise RuntimeError(
            "X/y size mismatch before "
            "TensorDataset construction: "
            f"X={len(X)}, y={len(y)}"
        )

    group_arrays = (
        make_group_arrays(X)
    )

    tensors = []

    for group_name in GROUP_ORDER:

        group_array = (
            group_arrays[
                group_name
            ]
        )

        if (
            len(group_array)
            != len(y)
        ):

            raise RuntimeError(
                "Group/target mismatch: "
                f"{group_name}="
                f"{len(group_array)}, "
                f"target={len(y)}"
            )

        tensors.append(
            torch.from_numpy(
                group_array
            )
        )

    tensors.append(
        torch.from_numpy(y)
    )

    dataset = TensorDataset(
        *tensors
    )

    return DataLoader(
        dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        pin_memory=torch.cuda.is_available()
    )


# ============================================================
# 15. INTERNAL EARLY STOPPING SPLIT
# ============================================================

def make_internal_split(
    y,
    seed
):

    splitter = (
        StratifiedKFold(
            n_splits=10,
            shuffle=True,
            random_state=seed
        )
    )

    dummy = np.zeros(
        (len(y), 1)
    )

    train_idx, stop_idx = (
        next(
            splitter.split(
                dummy,
                y
            )
        )
    )

    return (
        train_idx,
        stop_idx
    )


# ============================================================
# 16. MODEL TRAINING
# ============================================================

def fit_model(
    X_train,
    y_train,
    X_stop,
    y_stop,
    params,
    seed
):

    seed_everything(seed)

    # Safety checks
    if len(X_train) != len(y_train):

        raise RuntimeError(
            "fit_model training mismatch: "
            f"X={len(X_train)}, "
            f"y={len(y_train)}"
        )

    if len(X_stop) != len(y_stop):

        raise RuntimeError(
            "fit_model stopping mismatch: "
            f"X={len(X_stop)}, "
            f"y={len(y_stop)}"
        )

    model = (
        SparseGroupedChebKAN(
            group_sizes={
                group_name:
                len(
                    GROUPS[
                        group_name
                    ]
                )
                for group_name
                in GROUP_ORDER
            },
            embedding_dim=
            GROUP_EMBED_DIM,
            degree=
            CHEB_K
        )
        .to(DEVICE)
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=params["lr"],
        weight_decay=params["l2"]
    )

    criterion = (
        nn.BCEWithLogitsLoss()
    )

    loader = (
        create_training_loader(
            X_train,
            y_train
        )
    )

    stop_groups = (
        make_group_tensors(
            X_stop
        )
    )

    stop_target = torch.tensor(
        y_stop,
        dtype=torch.float32,
        device=DEVICE
    )

    best_state = None

    best_loss = np.inf

    best_epoch = 0

    patience_counter = 0

    for epoch in range(
        1,
        MAX_EPOCHS + 1
    ):

        model.train()

        for batch in loader:

            group_inputs = {}

            for i, group_name in enumerate(
                GROUP_ORDER
            ):

                group_inputs[
                    group_name
                ] = (
                    batch[i]
                    .to(
                        DEVICE,
                        non_blocking=True
                    )
                )

            batch_y = (
                batch[
                    len(GROUP_ORDER)
                ]
                .to(
                    DEVICE,
                    non_blocking=True
                )
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(
                group_inputs
            )

            bce_loss = criterion(
                logits,
                batch_y
            )

            kan_l1 = (
                model.coefficient_l1()
            )

            gate_l1 = (
                model.gate_l1()
            )

            total_loss = (
                bce_loss
                +
                params["kan_l1"] *
                kan_l1
                +
                params["gate_l1"] *
                gate_l1
            )

            total_loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                max_norm=5.0
            )

            optimizer.step()

        # ----------------------------------------------------
        # Early stopping
        # ----------------------------------------------------

        model.eval()

        with torch.no_grad():

            stop_logits = (
                model(
                    stop_groups
                )
            )

            stop_loss = (
                criterion(
                    stop_logits,
                    stop_target
                )
                .item()
            )

        if (
            stop_loss <
            best_loss - 1e-6
        ):

            best_loss = stop_loss

            best_state = {
                key:
                    value.detach()
                    .cpu()
                    .clone()

                for key, value
                in model.state_dict().items()
            }

            best_epoch = epoch

            patience_counter = 0

        else:

            patience_counter += 1

        if (
            patience_counter
            >= PATIENCE
        ):

            break

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    model.eval()

    return (
        model,
        best_epoch,
        best_loss
    )


# ============================================================
# 17. PREDICTION
# ============================================================

def predict_model(
    model,
    X
):

    model.eval()

    group_tensors = (
        make_group_tensors(
            X
        )
    )

    with torch.no_grad():

        logits = model(
            group_tensors
        )

        probabilities = (
            torch.sigmoid(
                logits
            )
            .cpu()
            .numpy()
        )

    return probabilities


# ============================================================
# 18. INNER CV
# ============================================================

def inner_cv_score(
    X_outer_train,
    y_outer_train,
    params,
    outer_fold
):

    splitter = (
        StratifiedKFold(
            n_splits=INNER_FOLDS,
            shuffle=True,
            random_state=
            SEED +
            outer_fold
        )
    )

    scores = []

    for inner_fold, (
        train_idx,
        val_idx
    ) in enumerate(
        splitter.split(
            X_outer_train,
            y_outer_train
        ),
        start=1
    ):

        # SAME indices applied to X and y
        X_train_raw = (
            X_outer_train[
                train_idx
            ]
        )

        y_train = (
            y_outer_train[
                train_idx
            ]
        )

        X_val_raw = (
            X_outer_train[
                val_idx
            ]
        )

        y_val = (
            y_outer_train[
                val_idx
            ]
        )

        # Fold-specific preprocessing
        imputer, scaler, X_train = (
            fit_preprocessor(
                X_train_raw
            )
        )

        X_val = (
            transform_preprocessor(
                X_val_raw,
                imputer,
                scaler
            )
        )

        # Internal early stopping split
        fit_idx, stop_idx = (
            make_internal_split(
                y_train,
                seed=
                SEED
                +
                outer_fold * 100
                +
                inner_fold
            )
        )

        X_fit = (
            X_train[
                fit_idx
            ]
        )

        y_fit = (
            y_train[
                fit_idx
            ]
        )

        X_stop = (
            X_train[
                stop_idx
            ]
        )

        y_stop = (
            y_train[
                stop_idx
            ]
        )

        # Additional safety checks
        assert (
            len(X_fit)
            ==
            len(y_fit)
        )

        assert (
            len(X_stop)
            ==
            len(y_stop)
        )

        model, _, _ = (
            fit_model(
                X_fit,
                y_fit,
                X_stop,
                y_stop,
                params,
                seed=
                SEED
                +
                outer_fold * 1000
                +
                inner_fold
            )
        )

        probabilities = (
            predict_model(
                model,
                X_val
            )
        )

        score = (
            roc_auc_score(
                y_val,
                probabilities
            )
        )

        scores.append(
            score
        )

        del model

        if torch.cuda.is_available():

            torch.cuda.empty_cache()

    return float(
        np.mean(scores)
    )


# ============================================================
# 19. MAIN EXPERIMENT
# ============================================================

def main():

    start_time = time.time()

    print("=" * 80)
    print(
        "CORRECTED A6 - "
        "SPARSE CLINICALLY-GROUPED CHEBYSHEV-KAN"
    )
    print(
        "KAN coefficient L1 + Group-gate L1"
    )
    print("=" * 80)

    print(
        "Python/PyTorch environment:"
    )

    print(
        "PyTorch:",
        torch.__version__
    )

    print(
        "CUDA available:",
        torch.cuda.is_available()
    )

    if torch.cuda.is_available():

        print(
            "GPU:",
            torch.cuda.get_device_name(0)
        )

    print(
        "Device:",
        DEVICE
    )

    # ========================================================
    # LOAD DATA
    # ========================================================

    dev_df = load_partition(
        DEV_FILE
    )

    cal_df = load_partition(
        CAL_FILE
    )

    test_df = load_partition(
        TEST_FILE
    )

    print("\nPartitions:")

    print(
        "Development:",
        f"{len(dev_df):,}"
    )

    print(
        "Calibration:",
        f"{len(cal_df):,}"
    )

    print(
        "Locked test:",
        f"{len(test_df):,}"
    )

    # ========================================================
    # PARTITION PROTECTION
    # ========================================================

    dev_ids = set(
        dev_df["id"]
    )

    cal_ids = set(
        cal_df["id"]
    )

    test_ids = set(
        test_df["id"]
    )

    if dev_ids & cal_ids:

        raise RuntimeError(
            "Development/calibration "
            "overlap detected."
        )

    if dev_ids & test_ids:

        raise RuntimeError(
            "Development/test "
            "overlap detected."
        )

    if cal_ids & test_ids:

        raise RuntimeError(
            "Calibration/test "
            "overlap detected."
        )

    print(
        "Partition disjointness: PASS"
    )

    print(
        "Calibration protected: YES"
    )

    print(
        "Locked test protected: YES"
    )

    # ========================================================
    # DEVELOPMENT ARRAYS
    # ========================================================

    X_dev = (
        dev_df[
            FEATURES
        ]
        .to_numpy(
            dtype=np.float32
        )
    )

    y_dev = (
        dev_df[
            TARGET
        ]
        .to_numpy(
            dtype=np.int64
        )
    )

    print(
        "\nDevelopment X shape:",
        X_dev.shape
    )

    print(
        "Development y shape:",
        y_dev.shape
    )

    # ========================================================
    # ARCHITECTURE
    # ========================================================

    print("\nArchitecture:")

    print(
        "Features:",
        len(FEATURES)
    )

    print(
        "Chebyshev degree:",
        CHEB_K
    )

    print(
        "Group embedding:",
        GROUP_EMBED_DIM
    )

    print(
        "KAN coefficient L1: YES"
    )

    print(
        "Group gate L1: YES"
    )

    print(
        "ADASYN: NO"
    )

    print(
        "Conformal prediction: NO"
    )

    print(
        "Batch size:",
        BATCH_SIZE
    )

    print(
        "Maximum epochs:",
        MAX_EPOCHS
    )

    print(
        "Patience:",
        PATIENCE
    )

    # ========================================================
    # GROUPS
    # ========================================================

    print("\nClinical groups:")

    for group_name in GROUP_ORDER:

        print(
            f"  {group_name}: "
            f"{GROUPS[group_name]}"
        )

    # ========================================================
    # HYPERPARAMETER GRID
    # ========================================================

    grid = []

    for (
        lr,
        l2,
        kan_l1,
        gate_l1
    ) in product(
        LEARNING_RATES,
        L2_VALUES,
        KAN_L1_VALUES,
        GATE_L1_VALUES
    ):

        grid.append(
            {
                "lr": lr,
                "l2": l2,
                "kan_l1": kan_l1,
                "gate_l1": gate_l1
            }
        )

    print(
        "\nHyperparameter configurations "
        "per inner fold:",
        len(grid)
    )

    # ========================================================
    # OUTER CV
    # ========================================================

    outer_splitter = (
        StratifiedKFold(
            n_splits=OUTER_FOLDS,
            shuffle=True,
            random_state=SEED
        )
    )

    outer_results = []

    search_results = []

    selected_results = []

    prediction_frames = []

    for outer_fold, (
        train_idx,
        val_idx
    ) in enumerate(
        outer_splitter.split(
            X_dev,
            y_dev
        ),
        start=1
    ):

        print("\n")
        print("=" * 80)
        print(
            f"OUTER FOLD "
            f"{outer_fold}/{OUTER_FOLDS}"
        )
        print("=" * 80)

        # Aligned indexing
        X_outer_train_raw = (
            X_dev[
                train_idx
            ]
        )

        y_outer_train = (
            y_dev[
                train_idx
            ]
        )

        X_outer_val_raw = (
            X_dev[
                val_idx
            ]
        )

        y_outer_val = (
            y_dev[
                val_idx
            ]
        )

        print(
            "Outer training:",
            len(X_outer_train_raw)
        )

        print(
            "Outer validation:",
            len(X_outer_val_raw)
        )

        assert (
            len(X_outer_train_raw)
            ==
            len(y_outer_train)
        )

        assert (
            len(X_outer_val_raw)
            ==
            len(y_outer_val)
        )

        # ====================================================
        # INNER SEARCH
        # ====================================================

        fold_search = []

        for config_id, params in enumerate(
            grid,
            start=1
        ):

            score = (
                inner_cv_score(
                    X_outer_train_raw,
                    y_outer_train,
                    params,
                    outer_fold
                )
            )

            row = {

                "outer_fold":
                    outer_fold,

                "config_id":
                    config_id,

                "lr":
                    params["lr"],

                "l2":
                    params["l2"],

                "kan_l1":
                    params["kan_l1"],

                "gate_l1":
                    params["gate_l1"],

                "inner_mean_roc_auc":
                    score
            }

            fold_search.append(
                row
            )

            search_results.append(
                row
            )

            print(
                f"Config "
                f"{config_id}/{len(grid)} | "
                f"lr={params['lr']:.0e} | "
                f"inner AUC="
                f"{score:.6f}"
            )

        fold_search_df = (
            pd.DataFrame(
                fold_search
            )
        )

        best_row = (
            fold_search_df
            .sort_values(
                "inner_mean_roc_auc",
                ascending=False
            )
            .iloc[0]
        )

        best_params = {

            "lr":
                float(
                    best_row["lr"]
                ),

            "l2":
                float(
                    best_row["l2"]
                ),

            "kan_l1":
                float(
                    best_row["kan_l1"]
                ),

            "gate_l1":
                float(
                    best_row["gate_l1"]
                )
        }

        print(
            "\nSelected:"
        )

        print(
            best_params
        )

        print(
            "Best inner AUC:",
            f"{best_row['inner_mean_roc_auc']:.6f}"
        )

        selected_results.append(
            {
                "outer_fold":
                    outer_fold,

                **best_params,

                "best_inner_roc_auc":
                    float(
                        best_row[
                            "inner_mean_roc_auc"
                        ]
                    )
            }
        )

        # ====================================================
        # OUTER PREPROCESSING
        # ====================================================

        imputer, scaler, X_outer_train = (
            fit_preprocessor(
                X_outer_train_raw
            )
        )

        X_outer_val = (
            transform_preprocessor(
                X_outer_val_raw,
                imputer,
                scaler
            )
        )

        # ====================================================
        # EARLY STOPPING SPLIT
        # ====================================================

        fit_idx, stop_idx = (
            make_internal_split(
                y_outer_train,
                seed=
                SEED +
                outer_fold
            )
        )

        X_fit = (
            X_outer_train[
                fit_idx
            ]
        )

        y_fit = (
            y_outer_train[
                fit_idx
            ]
        )

        X_stop = (
            X_outer_train[
                stop_idx
            ]
        )

        y_stop = (
            y_outer_train[
                stop_idx
            ]
        )

        # ====================================================
        # TRAIN FINAL OUTER-FOLD MODEL
        # ====================================================

        model, best_epoch, best_stop_loss = (
            fit_model(
                X_fit,
                y_fit,
                X_stop,
                y_stop,
                best_params,
                seed=
                SEED +
                10000 +
                outer_fold
            )
        )

        # ====================================================
        # OUTER VALIDATION
        # ====================================================

        probabilities = (
            predict_model(
                model,
                X_outer_val
            )
        )

        metrics = calculate_metrics(
            y_outer_val,
            probabilities
        )

        gates = (
            model.gate_values()
        )

        coefficient_l1 = float(
            model
            .coefficient_l1()
            .detach()
            .cpu()
            .item()
        )

        gate_l1 = float(
            model
            .gate_l1()
            .detach()
            .cpu()
            .item()
        )

        parameter_count = int(
            sum(
                p.numel()
                for p in model.parameters()
            )
        )

        row = {

            "outer_fold":
                outer_fold,

            **metrics,

            "best_epoch":
                best_epoch,

            "best_stop_loss":
                best_stop_loss,

            "kan_coefficient_l1_value":
                coefficient_l1,

            "gate_logit_l1_value":
                gate_l1,

            "gate_demographic":
                gates[0],

            "gate_physiological_anthropometric_metabolic":
                gates[1],

            "gate_lifestyle":
                gates[2],

            "n_parameters":
                parameter_count
        }

        outer_results.append(
            row
        )

        prediction_frames.append(
            pd.DataFrame(
                {
                    "row_index":
                        val_idx,

                    "outer_fold":
                        outer_fold,

                    "y_true":
                        y_outer_val,

                    "probability":
                        probabilities
                }
            )
        )

        # ====================================================
        # PRINT FOLD RESULT
        # ====================================================

        print("\nOuter-fold results:")

        for metric in [
            "accuracy",
            "precision",
            "sensitivity",
            "specificity",
            "f1",
            "roc_auc",
            "pr_auc",
            "brier",
            "ece"
        ]:

            print(
                f"{metric:12s}: "
                f"{metrics[metric]:.6f}"
            )

        print(
            "\nBest epoch:",
            best_epoch
        )

        print(
            "Parameters:",
            f"{parameter_count:,}"
        )

        print(
            "Group gates:"
        )

        print(
            f"  Demographic: "
            f"{gates[0]:.6f}"
        )

        print(
            f"  Physiological: "
            f"{gates[1]:.6f}"
        )

        print(
            f"  Lifestyle: "
            f"{gates[2]:.6f}"
        )

        print(
            "KAN coefficient L1:",
            f"{coefficient_l1:.6f}"
        )

        print(
            "Gate-logit L1:",
            f"{gate_l1:.6f}"
        )

        # ====================================================
        # SAVE MODEL
        # ====================================================

        model_path = (
            MODELS_DIR /
            (
                "implementation31b_reduced_"
                f"corrected_a6_fold"
                f"{outer_fold}.pt"
            )
        )

        torch.save(
            {
                "model_state_dict":
                    model.state_dict(),

                "features":
                    FEATURES,

                "groups":
                    GROUPS,

                "degree":
                    CHEB_K,

                "embedding_dim":
                    GROUP_EMBED_DIM,

                "hyperparameters":
                    best_params,

                "seed":
                    SEED
            },
            model_path
        )

        print(
            "Model saved:",
            model_path
        )

        del model

        if torch.cuda.is_available():

            torch.cuda.empty_cache()

    # ========================================================
    # FINAL OUTER RESULTS
    # ========================================================

    outer_df = (
        pd.DataFrame(
            outer_results
        )
    )

    prediction_df = (
        pd.concat(
            prediction_frames,
            ignore_index=True
        )
        .sort_values(
            "row_index"
        )
    )

    # ========================================================
    # COVERAGE
    # ========================================================

    expected = len(
        dev_df
    )

    observed = len(
        prediction_df
    )

    unique_rows = (
        prediction_df[
            "row_index"
        ]
        .nunique()
    )

    coverage_pass = (
        observed == expected
        and
        unique_rows == expected
    )

    print("\n")
    print("=" * 80)
    print("OUTER VALIDATION COVERAGE")
    print("=" * 80)

    print(
        "Expected:",
        expected
    )

    print(
        "Observed:",
        observed
    )

    print(
        "Unique:",
        unique_rows
    )

    print(
        "Coverage PASS:",
        coverage_pass
    )

    # ========================================================
    # POOLED METRICS
    # ========================================================

    pooled_metrics = calculate_metrics(
        prediction_df[
            "y_true"
        ].to_numpy(),

        prediction_df[
            "probability"
        ].to_numpy()
    )

    # ========================================================
    # SUMMARY
    # ========================================================

    metric_names = [
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "brier",
        "ece"
    ]

    summary_rows = []

    for metric in metric_names:

        summary_rows.append(
            {
                "metric":
                    metric,

                "mean":
                    outer_df[
                        metric
                    ].mean(),

                "std":
                    outer_df[
                        metric
                    ].std(
                        ddof=1
                    )
            }
        )

    summary_df = (
        pd.DataFrame(
            summary_rows
        )
    )

    # ========================================================
    # GATE STABILITY
    # ========================================================

    gate_columns = [
        "gate_demographic",
        "gate_physiological_anthropometric_metabolic",
        "gate_lifestyle"
    ]

    gate_rows = []

    for column in gate_columns:

        gate_rows.append(
            {
                "gate":
                    column,

                "mean":
                    outer_df[
                        column
                    ].mean(),

                "std":
                    outer_df[
                        column
                    ].std(
                        ddof=1
                    ),

                "min":
                    outer_df[
                        column
                    ].min(),

                "max":
                    outer_df[
                        column
                    ].max()
            }
        )

    gate_df = (
        pd.DataFrame(
            gate_rows
        )
    )

    # ========================================================
    # SAVE RESULTS
    # ========================================================

    outer_df.to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_outer_fold_results.csv",
        index=False
    )

    prediction_df.to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_outer_predictions.csv",
        index=False
    )

    summary_df.to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_summary.csv",
        index=False
    )

    pd.DataFrame(
        [pooled_metrics]
    ).to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_pooled_metrics.csv",
        index=False
    )

    pd.DataFrame(
        search_results
    ).to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_hyperparameter_search.csv",
        index=False
    )

    pd.DataFrame(
        selected_results
    ).to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_selected_hyperparameters.csv",
        index=False
    )

    gate_df.to_csv(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_gate_stability.csv",
        index=False
    )

    # ========================================================
    # PROTOCOL
    # ========================================================

    protocol = {

        "experiment":
            "A6_corrected_reduced_runtime",

        "model":
            "Sparse Clinically-Grouped Chebyshev-KAN",

        "features":
            FEATURES,

        "groups":
            GROUPS,

        "chebyshev_basis":
            "first_kind",

        "chebyshev_degree":
            CHEB_K,

        "group_embedding_dimension":
            GROUP_EMBED_DIM,

        "activation":
            "SiLU",

        "fusion":
            "softmax_weighted_group_sum",

        "kan_regularization":
            "L1_on_Chebyshev_coefficients",

        "gate_regularization":
            "L1_on_pre_softmax_gate_logits",

        "loss":
            "BCE + lambda_KAN*KAN_L1 + lambda_gate*Gate_L1",

        "learning_rates":
            LEARNING_RATES,

        "l2":
            L2_VALUES,

        "kan_l1":
            KAN_L1_VALUES,

        "gate_l1":
            GATE_L1_VALUES,

        "batch_size":
            BATCH_SIZE,

        "max_epochs":
            MAX_EPOCHS,

        "patience":
            PATIENCE,

        "outer_folds":
            OUTER_FOLDS,

        "inner_folds":
            INNER_FOLDS,

        "random_state":
            SEED,

        "adasyn":
            False,

        "conformal_prediction":
            False,

        "calibration_used":
            False,

        "locked_test_used":
            False,

        "note":
            "Reduced-runtime corrected A6. "
            "Regularization grid restricted for "
            "implementation verification."
    }

    with open(
        RESULTS_DIR /
        "implementation31b_reduced_corrected_a6_protocol.json",
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            protocol,
            file,
            indent=2
        )

    # ========================================================
    # FINAL REPORT
    # ========================================================

    elapsed_minutes = (
        time.time() -
        start_time
    ) / 60.0

    print("\n")
    print("=" * 80)
    print("CORRECTED A6 FINAL SUMMARY")
    print("=" * 80)

    print(
        "Mean outer ROC-AUC:",
        f"{outer_df['roc_auc'].mean():.6f}",
        "+/-",
        f"{outer_df['roc_auc'].std(ddof=1):.6f}"
    )

    print(
        "Pooled outer ROC-AUC:",
        f"{pooled_metrics['roc_auc']:.6f}"
    )

    print(
        "Pooled outer PR-AUC:",
        f"{pooled_metrics['pr_auc']:.6f}"
    )

    print(
        "Pooled Brier:",
        f"{pooled_metrics['brier']:.6f}"
    )

    print(
        "Pooled ECE:",
        f"{pooled_metrics['ece']:.6f}"
    )

    print("\nGroup-gate stability:")

    for _, row in gate_df.iterrows():

        print(
            f"{row['gate']}: "
            f"{row['mean']:.6f} "
            f"+/- "
            f"{row['std']:.6f}"
        )

    print("\nProtection checks:")

    print(
        "Calibration protected: PASS"
    )

    print(
        "Locked test protected: PASS"
    )

    print(
        "Outer validation coverage:",
        "PASS"
        if coverage_pass
        else "FAIL"
    )

    print(
        "\nExecution time:",
        f"{elapsed_minutes:.2f} minutes"
    )

    print("\n")
    print("=" * 80)
    print(
        "CORRECTED A6 COMPLETE"
    )
    print("=" * 80)


if __name__ == "__main__":
    main()