# ============================================================
# IMPLEMENTATION 39
# DEVELOPMENT-DERIVED THRESHOLD SELECTION
# AND CROSS-DATASET THRESHOLD TRANSFER
#
# Corrected to exactly match the saved A7 checkpoint.
#
# No model retraining
# No UCI threshold tuning
# No conformal calibration-set use
# No locked-test threshold selection
# ============================================================

from pathlib import Path
from datetime import datetime
import json

import numpy as np
import pandas as pd
import torch

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)


# ============================================================
# REPRODUCIBILITY
# ============================================================

SEED = 2026

np.random.seed(SEED)
torch.manual_seed(SEED)

if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)


# ============================================================
# PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(
    r"E:\CVD_CGS_ChebKAN"
)

DEV_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_development_cv.csv"
)

CAL_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_conformal_calibration.csv"
)

TEST_FILE = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "kaggle_locked_test.csv"
)

A7_MODEL_FILE = (
    PROJECT_ROOT
    / "results"
    / "models"
    / "implementation32_a7_final_model.pt"
)

EXTERNAL_PREDICTION_FILE = (
    PROJECT_ROOT
    / "results"
    / "tables"
    / "implementation34_uci_external_predictions.csv"
)

OUTPUT_DIR = (
    PROJECT_ROOT
    / "results"
    / "tables"
)

OUTPUT_CSV = (
    OUTPUT_DIR
    / "implementation39_threshold_transfer_results.csv"
)

OUTPUT_JSON = (
    OUTPUT_DIR
    / "implementation39_threshold_transfer_summary.json"
)

OUTPUT_VALIDATION_CSV = (
    OUTPUT_DIR
    / "implementation39_internal_validation_threshold_selection.csv"
)

OUTPUT_TEST_CSV = (
    OUTPUT_DIR
    / "implementation39_locked_test_predictions.csv"
)


# ============================================================
# FROZEN MODEL CONFIGURATION
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active",
]

TARGET = "cardio"

K = 5
EMBED_DIM = 16

EXPECTED_PARAMETER_COUNT = 1124

EXPECTED_DEV = 49000
EXPECTED_INTERNAL_TRAIN = 44100
EXPECTED_INTERNAL_VALIDATION = 4900
EXPECTED_CALIBRATION = 7000
EXPECTED_TEST = 14000


# ============================================================
# EXACT A7 CLINICAL GROUPS
# ============================================================

GROUPS = {
    "demographic": [
        "age",
        "gender",
    ],

    "physiological": [
        "height",
        "weight",
        "ap_hi",
        "ap_lo",
        "cholesterol",
        "gluc",
    ],

    "lifestyle": [
        "smoke",
        "alco",
        "active",
    ],
}


# ============================================================
# CHEBYSHEV BASIS
# ============================================================

def chebyshev_basis(
    x,
    degree
):

    basis = [
        torch.ones_like(x)
    ]

    if degree >= 1:

        basis.append(
            x
        )

    for k in range(
        2,
        degree + 1
    ):

        basis.append(
            2.0
            * x
            * basis[-1]
            - basis[-2]
        )

    return torch.stack(
        basis,
        dim=-1
    )


# ============================================================
# EXACT A7 CHEBYSHEV KAN LAYER
#
# Checkpoint:
# coefficients:
#   [out_features, in_features, degree+1]
#
# bias:
#   [out_features]
# ============================================================

class ChebyshevKANLayer(
    torch.nn.Module
):

    def __init__(
        self,
        in_features,
        out_features,
        degree=5
    ):

        super().__init__()

        self.in_features = (
            in_features
        )

        self.out_features = (
            out_features
        )

        self.degree = degree

        self.coefficients = (
            torch.nn.Parameter(
                torch.randn(
                    out_features,
                    in_features,
                    degree + 1
                )
                * 0.05
            )
        )

        self.bias = (
            torch.nn.Parameter(
                torch.zeros(
                    out_features
                )
            )
        )

    def forward(
        self,
        x
    ):

        basis = (
            chebyshev_basis(
                x,
                self.degree
            )
        )

        output = torch.einsum(
            "bid,oid->bo",
            basis,
            self.coefficients
        )

        output = (
            output
            + self.bias
        )

        return output


# ============================================================
# EXACT A7 GROUP BRANCH
# ============================================================

class GroupBranch(
    torch.nn.Module
):

    def __init__(
        self,
        in_features,
        embedding_dim=16,
        degree=5
    ):

        super().__init__()

        self.kan = (
            ChebyshevKANLayer(
                in_features,
                embedding_dim,
                degree
            )
        )

        self.activation = (
            torch.nn.SiLU()
        )

    def forward(
        self,
        x
    ):

        return self.activation(
            self.kan(x)
        )


# ============================================================
# EXACT A7 MODEL
# ============================================================

class A7Model(
    torch.nn.Module
):

    def __init__(
        self
    ):

        super().__init__()

        self.demographic = (
            GroupBranch(
                in_features=2,
                embedding_dim=16,
                degree=5
            )
        )

        self.physiological = (
            GroupBranch(
                in_features=6,
                embedding_dim=16,
                degree=5
            )
        )

        self.lifestyle = (
            GroupBranch(
                in_features=3,
                embedding_dim=16,
                degree=5
            )
        )

        self.gate_logits = (
            torch.nn.Parameter(
                torch.zeros(3)
            )
        )

        self.output_layer = (
            torch.nn.Linear(
                16,
                1
            )
        )

    def forward(
        self,
        x
    ):

        # Exact frozen feature order:
        #
        # 0 age
        # 1 gender
        # 2 height
        # 3 weight
        # 4 ap_hi
        # 5 ap_lo
        # 6 cholesterol
        # 7 gluc
        # 8 smoke
        # 9 alco
        # 10 active

        x_demographic = (
            x[
                :,
                [0, 1]
            ]
        )

        x_physiological = (
            x[
                :,
                [2, 3, 4, 5, 6, 7]
            ]
        )

        x_lifestyle = (
            x[
                :,
                [8, 9, 10]
            ]
        )

        h_demographic = (
            self.demographic(
                x_demographic
            )
        )

        h_physiological = (
            self.physiological(
                x_physiological
            )
        )

        h_lifestyle = (
            self.lifestyle(
                x_lifestyle
            )
        )

        gates = torch.softmax(
            self.gate_logits,
            dim=0
        )

        fused = (
            gates[0]
            * h_demographic
            +
            gates[1]
            * h_physiological
            +
            gates[2]
            * h_lifestyle
        )

        logits = (
            self.output_layer(
                fused
            )
        )

        return logits.squeeze(
            -1
        )


# ============================================================
# LOAD EXACT A7 CHECKPOINT
# ============================================================

def load_a7_model():

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    model = A7Model().to(
        device
    )

    checkpoint = torch.load(
        A7_MODEL_FILE,
        map_location=device,
        weights_only=False
    )

    if not isinstance(
        checkpoint,
        dict
    ):

        raise RuntimeError(
            "A7 checkpoint is not a dictionary."
        )

    required_checkpoint_keys = [
        "model_state_dict",
        "features",
        "groups",
        "group_indices",
        "cheb_degree",
        "embedding_dim",
        "learning_rate",
        "l2",
        "kan_l1",
        "gate_l1",
        "best_epoch",
        "seed",
    ]

    missing_checkpoint_keys = [
        key
        for key in required_checkpoint_keys
        if key not in checkpoint
    ]

    if missing_checkpoint_keys:

        raise RuntimeError(
            "Missing checkpoint metadata: "
            f"{missing_checkpoint_keys}"
        )

    state_dict = (
        checkpoint[
            "model_state_dict"
        ]
    )

    # --------------------------------------------------------
    # Verify frozen metadata
    # --------------------------------------------------------

    if checkpoint[
        "features"
    ] != FEATURES:

        raise RuntimeError(
            "Checkpoint feature order does not "
            "match the frozen feature order."
        )

    if int(
        checkpoint[
            "cheb_degree"
        ]
    ) != K:

        raise RuntimeError(
            "Checkpoint Chebyshev degree mismatch."
        )

    if int(
        checkpoint[
            "embedding_dim"
        ]
    ) != EMBED_DIM:

        raise RuntimeError(
            "Checkpoint embedding dimension mismatch."
        )

    # --------------------------------------------------------
    # Verify parameter count
    # --------------------------------------------------------

    checkpoint_parameter_count = sum(
        value.numel()
        for value in state_dict.values()
        if hasattr(value, "numel")
    )

    print(
        "\nCheckpoint parameter count:",
        checkpoint_parameter_count
    )

    if (
        checkpoint_parameter_count
        != EXPECTED_PARAMETER_COUNT
    ):

        raise RuntimeError(
            "Unexpected checkpoint parameter count."
        )

    # --------------------------------------------------------
    # Strict loading
    # --------------------------------------------------------

    model.load_state_dict(
        state_dict,
        strict=True
    )

    model.eval()

    print(
        "A7 checkpoint strict loading: PASS"
    )

    print(
        "A7 best epoch:",
        checkpoint["best_epoch"]
    )

    print(
        "A7 learning rate:",
        checkpoint["learning_rate"]
    )

    print(
        "A7 L2:",
        checkpoint["l2"]
    )

    print(
        "A7 KAN L1:",
        checkpoint["kan_l1"]
    )

    print(
        "A7 gate L1:",
        checkpoint["gate_l1"]
    )

    return (
        model,
        device,
        checkpoint
    )


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    dev = pd.read_csv(
        DEV_FILE
    )

    calibration = pd.read_csv(
        CAL_FILE
    )

    locked_test = pd.read_csv(
        TEST_FILE
    )

    return (
        dev,
        calibration,
        locked_test
    )


# ============================================================
# REPRODUCE A7 INTERNAL SPLIT
#
# A7:
#   Development = 49,000
#   Training = 44,100
#   Internal validation = 4,900
#
# ============================================================

def reproduce_internal_split(
    dev
):

    if len(dev) != EXPECTED_DEV:

        raise RuntimeError(
            "Development partition is not 49,000."
        )

    rng = np.random.RandomState(
        SEED
    )

    indices = np.arange(
        len(dev)
    )

    rng.shuffle(
        indices
    )

    validation_indices = (
        indices[
            -EXPECTED_INTERNAL_VALIDATION:
        ]
    )

    training_indices = (
        indices[
            :-EXPECTED_INTERNAL_VALIDATION
        ]
    )

    internal_train = (
        dev.iloc[
            training_indices
        ]
        .copy()
    )

    internal_validation = (
        dev.iloc[
            validation_indices
        ]
        .copy()
    )

    return (
        internal_train,
        internal_validation
    )


# ============================================================
# PREPROCESSING
# ============================================================

def fit_preprocessing(
    training_df
):

    X = (
        training_df[
            FEATURES
        ]
        .copy()
    )

    imputer = (
        SimpleImputer(
            strategy="median"
        )
    )

    scaler = (
        MinMaxScaler(
            feature_range=(-1, 1)
        )
    )

    X_imp = (
        imputer.fit_transform(
            X
        )
    )

    scaler.fit(
        X_imp
    )

    return (
        imputer,
        scaler
    )


def transform_data(
    df,
    imputer,
    scaler
):

    X = (
        df[
            FEATURES
        ]
        .copy()
    )

    X_imp = (
        imputer.transform(
            X
        )
    )

    X_scaled = (
        scaler.transform(
            X_imp
        )
    )

    y = (
        df[TARGET]
        .astype(int)
        .to_numpy()
    )

    return (
        X_scaled.astype(
            np.float32
        ),
        y
    )


# ============================================================
# MODEL PREDICTION
# ============================================================

def predict_probabilities(
    model,
    X,
    device,
    batch_size=2048
):

    probabilities = []

    with torch.no_grad():

        for start in range(
            0,
            len(X),
            batch_size
        ):

            end = min(
                start + batch_size,
                len(X)
            )

            xb = torch.tensor(
                X[
                    start:end
                ],
                dtype=torch.float32,
                device=device
            )

            logits = model(
                xb
            )

            probs = torch.sigmoid(
                logits
            )

            probabilities.extend(
                probs
                .detach()
                .cpu()
                .numpy()
                .tolist()
            )

    return np.asarray(
        probabilities,
        dtype=float
    )


# ============================================================
# YOUDEN J THRESHOLD
# ============================================================

def select_youden_threshold(
    y_true,
    probabilities
):

    thresholds = np.unique(
        probabilities
    )

    best_threshold = 0.5
    best_j = -np.inf
    best_sensitivity = None
    best_specificity = None

    records = []

    for threshold in thresholds:

        predictions = (
            probabilities
            >= threshold
        ).astype(int)

        tn, fp, fn, tp = (
            confusion_matrix(
                y_true,
                predictions,
                labels=[0, 1]
            )
            .ravel()
        )

        sensitivity = (
            tp / (tp + fn)
            if (tp + fn) > 0
            else 0.0
        )

        specificity = (
            tn / (tn + fp)
            if (tn + fp) > 0
            else 0.0
        )

        youden_j = (
            sensitivity
            +
            specificity
            -
            1.0
        )

        records.append({

            "threshold":
                float(threshold),

            "sensitivity":
                float(sensitivity),

            "specificity":
                float(specificity),

            "youden_j":
                float(youden_j),
        })

        if youden_j > best_j:

            best_j = (
                youden_j
            )

            best_threshold = (
                float(threshold)
            )

            best_sensitivity = (
                sensitivity
            )

            best_specificity = (
                specificity
            )

    return (
        best_threshold,
        best_j,
        best_sensitivity,
        best_specificity,
        pd.DataFrame(records)
    )


# ============================================================
# METRICS
# ============================================================

def calculate_metrics(
    y_true,
    probabilities,
    threshold
):

    predictions = (
        probabilities
        >= threshold
    ).astype(int)

    tn, fp, fn, tp = (
        confusion_matrix(
            y_true,
            predictions,
            labels=[0, 1]
        )
        .ravel()
    )

    return {

        "n":
            int(len(y_true)),

        "prevalence":
            float(
                np.mean(y_true)
            ),

        "threshold":
            float(threshold),

        "accuracy":
            float(
                accuracy_score(
                    y_true,
                    predictions
                )
            ),

        "precision":
            float(
                precision_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "sensitivity":
            float(
                recall_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "specificity":
            float(
                tn / (tn + fp)
                if (tn + fp) > 0
                else 0.0
            ),

        "f1":
            float(
                f1_score(
                    y_true,
                    predictions,
                    zero_division=0
                )
            ),

        "roc_auc":
            float(
                roc_auc_score(
                    y_true,
                    probabilities
                )
            ),

        "pr_auc":
            float(
                average_precision_score(
                    y_true,
                    probabilities
                )
            ),

        "true_negative":
            int(tn),

        "false_positive":
            int(fp),

        "false_negative":
            int(fn),

        "true_positive":
            int(tp),

        "positive_prediction_rate":
            float(
                np.mean(predictions)
            ),
    }


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 100)
    print(
        "IMPLEMENTATION 39"
    )
    print(
        "DEVELOPMENT-DERIVED THRESHOLD SELECTION "
        "AND CROSS-DATASET THRESHOLD TRANSFER"
    )
    print("=" * 100)

    print(
        "Timestamp:",
        datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    )

    # ========================================================
    # FILE CHECK
    # ========================================================

    required_files = [

        DEV_FILE,
        CAL_FILE,
        TEST_FILE,
        A7_MODEL_FILE,
        EXTERNAL_PREDICTION_FILE,
    ]

    for path in required_files:

        if not path.exists():

            raise FileNotFoundError(
                f"Required file not found:\n{path}"
            )

    # ========================================================
    # LOAD DATA
    # ========================================================

    (
        dev,
        calibration,
        locked_test
    ) = load_data()

    external_predictions = (
        pd.read_csv(
            EXTERNAL_PREDICTION_FILE
        )
    )

    print("\n" + "=" * 100)
    print(
        "PARTITION SIZES"
    )
    print("=" * 100)

    print(
        f"Development: {len(dev):,}"
    )

    print(
        f"Calibration: {len(calibration):,}"
    )

    print(
        f"Locked test: {len(locked_test):,}"
    )

    if len(dev) != 49000:
        raise RuntimeError(
            "Development size mismatch."
        )

    if len(calibration) != 7000:
        raise RuntimeError(
            "Calibration size mismatch."
        )

    if len(locked_test) != 14000:
        raise RuntimeError(
            "Locked test size mismatch."
        )

    # ========================================================
    # REPRODUCE INTERNAL SPLIT
    # ========================================================

    (
        internal_train,
        internal_validation
    ) = reproduce_internal_split(
        dev
    )

    print("\n" + "=" * 100)
    print(
        "A7 INTERNAL SPLIT"
    )
    print("=" * 100)

    print(
        f"Internal training: "
        f"{len(internal_train):,}"
    )

    print(
        f"Internal validation: "
        f"{len(internal_validation):,}"
    )

    train_ids = set(
        internal_train["id"]
        .astype(int)
        .tolist()
    )

    validation_ids = set(
        internal_validation["id"]
        .astype(int)
        .tolist()
    )

    overlap = (
        train_ids
        &
        validation_ids
    )

    print(
        f"Internal split ID overlap: "
        f"{len(overlap)}"
    )

    if overlap:

        raise RuntimeError(
            "Internal training and validation "
            "IDs overlap."
        )

    print(
        "Internal split ID overlap: 0 PASS"
    )

    # ========================================================
    # LOAD EXACT A7 MODEL
    # ========================================================

    (
        model,
        device,
        checkpoint
    ) = load_a7_model()

    # ========================================================
    # FIT PREPROCESSING ON INTERNAL TRAIN ONLY
    # ========================================================

    (
        imputer,
        scaler
    ) = fit_preprocessing(
        internal_train
    )

    # ========================================================
    # INTERNAL VALIDATION
    # ========================================================

    (
        X_val,
        y_val
    ) = transform_data(
        internal_validation,
        imputer,
        scaler
    )

    validation_probabilities = (
        predict_probabilities(
            model,
            X_val,
            device
        )
    )

    validation_auc = (
        roc_auc_score(
            y_val,
            validation_probabilities
        )
    )

    validation_pr_auc = (
        average_precision_score(
            y_val,
            validation_probabilities
        )
    )

    print("\n" + "=" * 100)
    print(
        "INTERNAL VALIDATION PERFORMANCE"
    )
    print("=" * 100)

    print(
        f"n:       {len(y_val):,}"
    )

    print(
        f"ROC-AUC: {validation_auc:.6f}"
    )

    print(
        f"PR-AUC:  {validation_pr_auc:.6f}"
    )

    # ========================================================
    # THRESHOLD SELECTION
    # ========================================================

    (
        selected_threshold,
        selected_j,
        selected_sensitivity,
        selected_specificity,
        threshold_table
    ) = select_youden_threshold(
        y_val,
        validation_probabilities
    )

    print("\n" + "=" * 100)
    print(
        "THRESHOLD SELECTION"
    )
    print("=" * 100)

    print(
        f"Criterion: Youden's J"
    )

    print(
        f"Selected threshold: "
        f"{selected_threshold:.6f}"
    )

    print(
        f"Maximum Youden J: "
        f"{selected_j:.6f}"
    )

    print(
        f"Sensitivity at selected threshold: "
        f"{selected_sensitivity:.6f}"
    )

    print(
        f"Specificity at selected threshold: "
        f"{selected_specificity:.6f}"
    )

    # ========================================================
    # SAVE INTERNAL VALIDATION PREDICTIONS
    # ========================================================

    validation_output = (
        internal_validation[
            ["id", TARGET]
        ]
        .copy()
    )

    validation_output[
        "probability"
    ] = validation_probabilities

    validation_output[
        "prediction_050"
    ] = (
        validation_probabilities
        >= 0.50
    ).astype(int)

    validation_output[
        "prediction_development_threshold"
    ] = (
        validation_probabilities
        >= selected_threshold
    ).astype(int)

    validation_output.to_csv(
        OUTPUT_VALIDATION_CSV,
        index=False
    )

    # ========================================================
    # LOCKED TEST
    #
    # The threshold is already frozen.
    # ========================================================

    (
        X_test,
        y_test
    ) = transform_data(
        locked_test,
        imputer,
        scaler
    )

    test_probabilities = (
        predict_probabilities(
            model,
            X_test,
            device
        )
    )

    test_metrics_050 = (
        calculate_metrics(
            y_test,
            test_probabilities,
            0.50
        )
    )

    test_metrics_selected = (
        calculate_metrics(
            y_test,
            test_probabilities,
            selected_threshold
        )
    )

    # ========================================================
    # SAVE LOCKED TEST PREDICTIONS
    # ========================================================

    test_output = (
        locked_test[
            ["id", TARGET]
        ]
        .copy()
    )

    test_output[
        "probability"
    ] = test_probabilities

    test_output[
        "prediction_050"
    ] = (
        test_probabilities
        >= 0.50
    ).astype(int)

    test_output[
        "prediction_development_threshold"
    ] = (
        test_probabilities
        >= selected_threshold
    ).astype(int)

    test_output.to_csv(
        OUTPUT_TEST_CSV,
        index=False
    )

    # ========================================================
    # RESULTS TABLE
    # ========================================================

    result_rows = []

    # Kaggle locked test
    result_rows.append({
        "dataset":
            "kaggle_locked_test",

        "threshold_type":
            "0.50",

        **test_metrics_050,
    })

    result_rows.append({
        "dataset":
            "kaggle_locked_test",

        "threshold_type":
            "development_youden",

        **test_metrics_selected,
    })

    # ========================================================
    # UCI EXTERNAL COHORTS
    #
    # UCI labels are used ONLY to evaluate the already
    # frozen threshold.
    # ========================================================

    for cohort in [
        "cleveland",
        "hungarian",
        "va",
    ]:

        cohort_predictions = (
            external_predictions[
                external_predictions[
                    "cohort"
                ]
                .astype(str)
                .str.lower()
                .str.strip()
                == cohort
            ]
            .copy()
        )

        if len(
            cohort_predictions
        ) == 0:

            raise RuntimeError(
                f"No predictions found for "
                f"{cohort}."
            )

        y_external = (
            cohort_predictions[
                "true_label"
            ]
            .astype(int)
            .to_numpy()
        )

        p_external = (
            cohort_predictions[
                "probability"
            ]
            .astype(float)
            .to_numpy()
        )

        metrics_050 = (
            calculate_metrics(
                y_external,
                p_external,
                0.50
            )
        )

        metrics_selected = (
            calculate_metrics(
                y_external,
                p_external,
                selected_threshold
            )
        )

        result_rows.append({
            "dataset":
                cohort,

            "threshold_type":
                "0.50",

            **metrics_050,
        })

        result_rows.append({
            "dataset":
                cohort,

            "threshold_type":
                "development_youden",

            **metrics_selected,
        })

    results_df = pd.DataFrame(
        result_rows
    )

    results_df.to_csv(
        OUTPUT_CSV,
        index=False
    )

    # ========================================================
    # PROTECTION ASSERTIONS
    # ========================================================

    # These are logical protocol assertions:
    # calibration set was loaded but never used to select
    # the threshold; UCI labels were only used after threshold
    # selection; locked test was evaluated only after selection.

    protection = {

        "calibration_used_for_threshold":
            False,

        "locked_test_used_for_threshold":
            False,

        "uci_labels_used_for_threshold":
            False,

        "model_retrained":
            False,

        "threshold_selected_once":
            True,

        "threshold_frozen_before_external_evaluation":
            True,
    }

    if not all(
        [
            protection[
                "calibration_used_for_threshold"
            ] is False,

            protection[
                "locked_test_used_for_threshold"
            ] is False,

            protection[
                "uci_labels_used_for_threshold"
            ] is False,

            protection[
                "model_retrained"
            ] is False,
        ]
    ):

        raise RuntimeError(
            "Protocol protection assertion failed."
        )

    # ========================================================
    # JSON SUMMARY
    # ========================================================

    summary = {

        "implementation":
            "39",

        "timestamp":
            datetime.now().isoformat(),

        "threshold_selection_dataset":
            "A7_internal_validation",

        "threshold_selection_n":
            int(len(y_val)),

        "threshold_selection_criterion":
            "Youden_J",

        "selected_threshold":
            float(selected_threshold),

        "maximum_youden_J":
            float(selected_j),

        "internal_validation_sensitivity":
            float(selected_sensitivity),

        "internal_validation_specificity":
            float(selected_specificity),

        "internal_validation_roc_auc":
            float(validation_auc),

        "internal_validation_pr_auc":
            float(validation_pr_auc),

        "model_checkpoint":
            str(A7_MODEL_FILE),

        "checkpoint_parameter_count":
            EXPECTED_PARAMETER_COUNT,

        "conformal_calibration_used":
            False,

        "locked_test_used_for_selection":
            False,

        "uci_labels_used_for_selection":
            False,

        "model_retrained":
            False,

        "results":
            results_df.to_dict(
                orient="records"
            ),

        "protection":
            protection,

        "interpretation":
            (
                "A single classification threshold was "
                "selected using Youden's J on the A7 "
                "internal validation subset of 4,900 "
                "Development records. The threshold was "
                "then frozen and applied unchanged to the "
                "Kaggle locked test set and UCI external "
                "cohorts. ROC-AUC is threshold-independent "
                "and is therefore not altered by threshold "
                "transfer."
            ),

        "status":
            "PASS",
    }

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            summary,
            f,
            indent=2
        )

    # ========================================================
    # PRINT FINAL RESULTS
    # ========================================================

    print("\n" + "=" * 100)
    print(
        "FINAL FROZEN THRESHOLD"
    )
    print("=" * 100)

    print(
        f"Threshold: "
        f"{selected_threshold:.6f}"
    )

    print(
        f"Youden J: "
        f"{selected_j:.6f}"
    )

    print("\n" + "=" * 100)
    print(
        "THRESHOLD TRANSFER RESULTS"
    )
    print("=" * 100)

    display_columns = [
        "dataset",
        "threshold_type",
        "n",
        "threshold",
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "positive_prediction_rate",
    ]

    print(
        results_df[
            display_columns
        ]
        .to_string(
            index=False
        )
    )

    print("\n" + "=" * 100)
    print(
        "PROTOCOL PROTECTION"
    )
    print("=" * 100)

    print(
        "Calibration set used for threshold selection: FALSE"
    )

    print(
        "Locked test used for threshold selection: FALSE"
    )

    print(
        "UCI labels used for threshold selection: FALSE"
    )

    print(
        "Model retrained: FALSE"
    )

    print(
        "Threshold selected once and frozen: TRUE"
    )

    print("\n" + "=" * 100)
    print(
        "OUTPUT FILES"
    )
    print("=" * 100)

    print(
        OUTPUT_CSV
    )

    print(
        OUTPUT_JSON
    )

    print(
        OUTPUT_VALIDATION_CSV
    )

    print(
        OUTPUT_TEST_CSV
    )

    print("\n" + "=" * 100)
    print(
        "IMPLEMENTATION 39 COMPLETE"
    )
    print("=" * 100)


if __name__ == "__main__":

    main()