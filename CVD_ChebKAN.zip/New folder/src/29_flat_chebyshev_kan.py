# ============================================================
# IMPLEMENTATION 29
# A4: FLAT CHEBYSHEV-KAN
# ============================================================
#
# Project:
# CGS-ChebKAN for Cardiovascular Disease Prediction
#
# A4 purpose:
# Isolate the effect of clinical grouping by using a single
# flat Chebyshev-KAN branch over all 11 Kaggle predictors.
#
# Frozen methodology:
# - 11 input features
# - Flat Chebyshev-KAN
# - Chebyshev first-kind basis
# - K = 5 (frozen from corrected Implementation 27)
# - Architecture: 11 -> 16 -> 1
# - SiLU activation
# - No clinical grouping
# - No sparse gates
# - No ADASYN
# - No conformal prediction
# - Nested 5 x 4 stratified CV
# - Fold-specific median imputation
# - Fold-specific MinMax scaling to [-1, 1]
# - Internal 10% validation for early stopping
# - Calibration set protected
# - Locked test set protected
#
# ============================================================

import os
import sys
import json
import time
import random
import warnings
from pathlib import Path
from itertools import product

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix
)

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

warnings.filterwarnings("ignore")


# ============================================================
# 1. PROJECT PATHS
# ============================================================

PROJECT_ROOT = Path(r"E:\CVD_CGS_ChebKAN")

DATA_DIR = PROJECT_ROOT / "data" / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
MODELS_DIR = RESULTS_DIR / "models"
LOGS_DIR = PROJECT_ROOT / "logs"

for directory in [
    TABLES_DIR,
    MODELS_DIR,
    LOGS_DIR
]:
    directory.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. REPRODUCIBILITY
# ============================================================

SEED = 2026


def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    # Deterministic behavior where possible
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed()


# ============================================================
# 3. ENVIRONMENT INFORMATION
# ============================================================

print("=" * 80)
print("IMPLEMENTATION 29 — A4 FLAT CHEBYSHEV-KAN")
print("=" * 80)

print("\n[ENVIRONMENT]")

print("Python:", sys.version)

print("NumPy:", np.__version__)
print("Pandas:", pd.__version__)
print("PyTorch:", torch.__version__)

print("Project root:", PROJECT_ROOT)

if torch.cuda.is_available():
    DEVICE = torch.device("cuda")
    print("CUDA available: True")
    print("GPU:", torch.cuda.get_device_name(0))
    print(
        "GPU memory:",
        round(torch.cuda.get_device_properties(0).total_memory / (1024 ** 3), 2),
        "GB"
    )
else:
    DEVICE = torch.device("cpu")
    print("CUDA available: False")
    print("WARNING: Running on CPU.")

print("Device used:", DEVICE)


# ============================================================
# 4. FROZEN DATA FILES
# ============================================================

DEV_FILE = DATA_DIR / "kaggle_development_cv.csv"
CAL_FILE = DATA_DIR / "kaggle_conformal_calibration.csv"
TEST_FILE = DATA_DIR / "kaggle_locked_test.csv"

required_files = [
    DEV_FILE,
    CAL_FILE,
    TEST_FILE
]

print("\n[DATA FILE CHECK]")

for file_path in required_files:
    print(file_path, "->", file_path.exists())

    if not file_path.exists():
        raise FileNotFoundError(
            f"Required file not found: {file_path}"
        )


# ============================================================
# 5. LOAD DATA
# ============================================================

dev = pd.read_csv(DEV_FILE)
cal = pd.read_csv(CAL_FILE)
test = pd.read_csv(TEST_FILE)

print("\n[PARTITIONS]")
print("Development:", dev.shape)
print("Calibration:", cal.shape)
print("Locked test:", test.shape)


# ============================================================
# 6. FEATURE DEFINITION
# ============================================================

FEATURES = [
    "age",
    "gender",
    "height",
    "weight",
    "ap_hi",
    "ap_lo",
    "cholesterol",
    "gluc",
    "smoke",
    "alco",
    "active"
]

TARGET = "cardio"

N_FEATURES = len(FEATURES)

print("\n[FROZEN FEATURES]")
print("Number of predictors:", N_FEATURES)
print(FEATURES)
print("Target:", TARGET)


# ============================================================
# 7. BASIC DATA VALIDATION
# ============================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    missing_features = [
        feature for feature in FEATURES
        if feature not in df.columns
    ]

    if TARGET not in df.columns:
        raise ValueError(
            f"{TARGET} missing from {name} partition."
        )

    if missing_features:
        raise ValueError(
            f"Missing features in {name}: {missing_features}"
        )

    print(
        f"{name}: "
        f"rows={len(df)}, "
        f"target_missing={df[TARGET].isna().sum()}"
    )


# ============================================================
# 8. TARGET VALIDATION
# ============================================================

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    unique_target = sorted(
        df[TARGET].dropna().unique().tolist()
    )

    print(
        f"{name} target values:",
        unique_target
    )

    if set(unique_target) != {0, 1}:
        raise ValueError(
            f"{name} target is not binary."
        )


# ============================================================
# 9. PARTITION INTEGRITY
# ============================================================

print("\n[PARTITION INTEGRITY]")

if "id" in dev.columns and "id" in cal.columns and "id" in test.columns:

    dev_ids = set(dev["id"])
    cal_ids = set(cal["id"])
    test_ids = set(test["id"])

    overlap_dev_cal = dev_ids.intersection(cal_ids)
    overlap_dev_test = dev_ids.intersection(test_ids)
    overlap_cal_test = cal_ids.intersection(test_ids)

    print("Development-Calibration overlap:", len(overlap_dev_cal))
    print("Development-Test overlap:", len(overlap_dev_test))
    print("Calibration-Test overlap:", len(overlap_cal_test))

    assert len(overlap_dev_cal) == 0
    assert len(overlap_dev_test) == 0
    assert len(overlap_cal_test) == 0

    print("ID disjointness: PASS")


# ============================================================
# 10. TARGET DISTRIBUTION
# ============================================================

print("\n[TARGET DISTRIBUTION]")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    counts = df[TARGET].value_counts().sort_index()

    print(
        f"{name}: "
        f"class 0 = {counts.get(0, 0)}, "
        f"class 1 = {counts.get(1, 0)}"
    )

    print(
        f"{name} positive rate = "
        f"{df[TARGET].mean():.6f}"
    )


# ============================================================
# 11. MISSINGNESS AUDIT
# ============================================================

print("\n[MISSINGNESS AUDIT]")

for name, df in [
    ("Development", dev),
    ("Calibration", cal),
    ("Locked Test", test)
]:

    missing = df[FEATURES].isna().sum()

    print(f"\n{name}")

    for feature, count in missing.items():
        if count > 0:
            print(
                f"  {feature}: {count} "
                f"({100 * count / len(df):.4f}%)"
            )


# ============================================================
# 12. CONVERT TO NUMPY
# ============================================================

X_dev = dev[FEATURES].copy()
y_dev = dev[TARGET].astype(int).values

X_cal = cal[FEATURES].copy()
y_cal = cal[TARGET].astype(int).values

X_test = test[FEATURES].copy()
y_test = test[TARGET].astype(int).values


# ============================================================
# 13. NESTED CV SETTINGS
# ============================================================

OUTER_FOLDS = 5
INNER_FOLDS = 4

outer_cv = StratifiedKFold(
    n_splits=OUTER_FOLDS,
    shuffle=True,
    random_state=SEED
)

inner_cv = StratifiedKFold(
    n_splits=INNER_FOLDS,
    shuffle=True,
    random_state=SEED
)


# ============================================================
# 14. A4 FROZEN ARCHITECTURE
# ============================================================

CHEB_K = 5
INPUT_DIM = N_FEATURES
HIDDEN_DIM = 16

print("\n[A4 ARCHITECTURE]")

print("Model: Flat Chebyshev-KAN")
print("Input dimension:", INPUT_DIM)
print("Chebyshev degree K:", CHEB_K)
print("Hidden dimension:", HIDDEN_DIM)
print("Architecture:", f"{INPUT_DIM} -> {HIDDEN_DIM} -> 1")
print("Clinical grouping: NO")
print("Sparse gates: NO")
print("ADASYN: NO")
print("Conformal prediction: NO")


# ============================================================
# 15. HYPERPARAMETER GRID
# ============================================================
#
# K is fixed at 5 because corrected Implementation 27
# selected K=5 in all five outer folds.
#
# Therefore A4 only tunes optimization/regularization
# parameters. This isolates the architecture effect.
# ============================================================

LEARNING_RATES = [
    1e-3,
    3e-4
]

L2_VALUES = [
    1e-5,
    1e-4,
    1e-3
]

HYPERPARAM_GRID = list(
    product(
        LEARNING_RATES,
        L2_VALUES
    )
)

print("\n[HYPERPARAMETER GRID]")
print("Number of configurations:", len(HYPERPARAM_GRID))

for i, (lr, l2) in enumerate(HYPERPARAM_GRID, start=1):
    print(
        f"{i:02d}: lr={lr:.0e}, "
        f"l2={l2:.0e}"
    )


# ============================================================
# 16. CHEBYSHEV BASIS
# ============================================================

class ChebyshevKANLayer(nn.Module):
    """
    Chebyshev-KAN layer.

    Each input feature x_i is represented using:

        phi_i(x_i) =
            sum_{k=0}^{K} a_{i,k} T_k(x_i)

    and each output neuron receives a weighted sum
    of these feature-wise functions.

    Weight shape:
        [output_dim, input_dim, K+1]
    """

    def __init__(
        self,
        input_dim,
        output_dim,
        degree=5
    ):
        super().__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.degree = degree

        self.coefficients = nn.Parameter(
            torch.empty(
                output_dim,
                input_dim,
                degree + 1
            )
        )

        self.bias = nn.Parameter(
            torch.zeros(output_dim)
        )

        nn.init.normal_(
            self.coefficients,
            mean=0.0,
            std=0.02
        )

    def forward(self, x):

        # x shape:
        # [batch, input_dim]

        x = torch.clamp(
            x,
            min=-1.0,
            max=1.0
        )

        # Build Chebyshev polynomials:
        #
        # T0(x) = 1
        # T1(x) = x
        # Tk(x) = 2*x*T{k-1}(x) - T{k-2}(x)

        basis = []

        T0 = torch.ones_like(x)
        basis.append(T0)

        if self.degree >= 1:

            T1 = x
            basis.append(T1)

            for k in range(2, self.degree + 1):

                Tk = (
                    2.0 * x * basis[-1]
                    - basis[-2]
                )

                basis.append(Tk)

        # [batch, input_dim, K+1]
        basis_tensor = torch.stack(
            basis,
            dim=-1
        )

        # coefficients:
        # [output_dim, input_dim, K+1]

        # Result:
        # [batch, output_dim]

        output = torch.einsum(
            "bik,oik->bo",
            basis_tensor,
            self.coefficients
        )

        output = output + self.bias

        return output


# ============================================================
# 17. FLAT CHEBYSHEV-KAN MODEL
# ============================================================

class FlatChebKAN(nn.Module):
    """
    A4 Flat Chebyshev-KAN.

    Single flat branch:

        11 inputs
            ↓
        Chebyshev-KAN
            ↓
        16-dimensional embedding
            ↓
        SiLU
            ↓
        Linear projection
            ↓
        1 logit

    No clinical grouping.
    No group gates.
    """

    def __init__(
        self,
        input_dim=11,
        hidden_dim=16,
        degree=5
    ):
        super().__init__()

        self.cheb = ChebyshevKANLayer(
            input_dim=input_dim,
            output_dim=hidden_dim,
            degree=degree
        )

        self.activation = nn.SiLU()

        self.output = nn.Linear(
            hidden_dim,
            1
        )

    def forward(self, x):

        x = self.cheb(x)

        x = self.activation(x)

        x = self.output(x)

        return x.squeeze(1)


# ============================================================
# 18. PARAMETER COUNT
# ============================================================

def count_parameters(model):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# ============================================================
# 19. DATA PREPROCESSING
# ============================================================

def fit_preprocessor(X_train):

    imputer = SimpleImputer(
        strategy="median"
    )

    scaler = MinMaxScaler(
        feature_range=(-1, 1)
    )

    X_imp = imputer.fit_transform(
        X_train
    )

    X_scaled = scaler.fit_transform(
        X_imp
    )

    return imputer, scaler


def transform_preprocessor(
    X,
    imputer,
    scaler
):

    X_imp = imputer.transform(X)

    X_scaled = scaler.transform(
        X_imp
    )

    return X_scaled.astype(
        np.float32
    )


# ============================================================
# 20. INTERNAL TRAIN/VALIDATION SPLIT
# ============================================================

def internal_split(
    X,
    y,
    validation_fraction=0.10,
    seed=SEED
):

    splitter = StratifiedKFold(
        n_splits=10,
        shuffle=True,
        random_state=seed
    )

    train_idx, val_idx = next(
        splitter.split(X, y)
    )

    return (
        train_idx,
        val_idx
    )


# ============================================================
# 21. MODEL TRAINING
# ============================================================

MAX_EPOCHS = 150
PATIENCE = 15
BATCH_SIZE = 512


def train_model(
    model,
    X_train,
    y_train,
    X_val,
    y_val,
    learning_rate,
    l2,
    max_epochs=MAX_EPOCHS,
    patience=PATIENCE
):

    model = model.to(DEVICE)

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=learning_rate,
        weight_decay=l2
    )

    criterion = nn.BCEWithLogitsLoss()

    train_dataset = TensorDataset(
        torch.tensor(
            X_train,
            dtype=torch.float32
        ),
        torch.tensor(
            y_train,
            dtype=torch.float32
        )
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        drop_last=False
    )

    X_val_tensor = torch.tensor(
        X_val,
        dtype=torch.float32,
        device=DEVICE
    )

    y_val_tensor = torch.tensor(
        y_val,
        dtype=torch.float32,
        device=DEVICE
    )

    best_auc = -np.inf
    best_state = None
    best_epoch = 0

    patience_counter = 0

    for epoch in range(
        1,
        max_epochs + 1
    ):

        model.train()

        for batch_X, batch_y in train_loader:

            batch_X = batch_X.to(
                DEVICE,
                non_blocking=True
            )

            batch_y = batch_y.to(
                DEVICE,
                non_blocking=True
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            logits = model(batch_X)

            loss = criterion(
                logits,
                batch_y
            )

            loss.backward()

            optimizer.step()

        # ----------------------------------------------------
        # Internal validation
        # ----------------------------------------------------

        model.eval()

        with torch.no_grad():

            val_logits = model(
                X_val_tensor
            )

            val_prob = torch.sigmoid(
                val_logits
            ).detach().cpu().numpy()

        try:

            val_auc = roc_auc_score(
                y_val,
                val_prob
            )

        except ValueError:

            val_auc = 0.5

        if val_auc > best_auc:

            best_auc = val_auc

            best_state = {
                key: value.detach().cpu().clone()
                for key, value in model.state_dict().items()
            }

            best_epoch = epoch

            patience_counter = 0

        else:

            patience_counter += 1

        if patience_counter >= patience:

            break

    if best_state is not None:

        model.load_state_dict(
            best_state
        )

    return (
        model,
        best_auc,
        best_epoch
    )


# ============================================================
# 22. PREDICTION
# ============================================================

def predict_probability(
    model,
    X
):

    model.eval()

    X_tensor = torch.tensor(
        X,
        dtype=torch.float32,
        device=DEVICE
    )

    with torch.no_grad():

        logits = model(
            X_tensor
        )

        probability = torch.sigmoid(
            logits
        ).detach().cpu().numpy()

    return probability


# ============================================================
# 23. METRIC CALCULATION
# ============================================================

def calculate_metrics(
    y_true,
    probability
):

    prediction = (
        probability >= 0.5
    ).astype(int)

    tn, fp, fn, tp = confusion_matrix(
        y_true,
        prediction,
        labels=[0, 1]
    ).ravel()

    sensitivity = (
        tp / (tp + fn)
        if (tp + fn) > 0
        else 0.0
    )

    specificity = (
        tn / (tn + fp)
        if (tn + fp) > 0
        else 0.0
    )

    metrics = {

        "accuracy": accuracy_score(
            y_true,
            prediction
        ),

        "precision": precision_score(
            y_true,
            prediction,
            zero_division=0
        ),

        "sensitivity": sensitivity,

        "specificity": specificity,

        "f1": f1_score(
            y_true,
            prediction,
            zero_division=0
        ),

        "roc_auc": roc_auc_score(
            y_true,
            probability
        ),

        "pr_auc": average_precision_score(
            y_true,
            probability
        ),

        "brier": brier_score_loss(
            y_true,
            probability
        )
    }

    return metrics


# ============================================================
# 24. EXPECTED CALIBRATION ERROR
# ============================================================

def expected_calibration_error(
    y_true,
    probability,
    n_bins=10
):

    bins = np.linspace(
        0.0,
        1.0,
        n_bins + 1
    )

    ece = 0.0

    for i in range(n_bins):

        lower = bins[i]
        upper = bins[i + 1]

        if i == n_bins - 1:

            mask = (
                (probability >= lower)
                &
                (probability <= upper)
            )

        else:

            mask = (
                (probability >= lower)
                &
                (probability < upper)
            )

        if np.sum(mask) == 0:
            continue

        bin_probability = np.mean(
            probability[mask]
        )

        bin_accuracy = np.mean(
            y_true[mask]
        )

        bin_fraction = (
            np.sum(mask)
            /
            len(y_true)
        )

        ece += (
            bin_fraction
            *
            abs(
                bin_probability
                -
                bin_accuracy
            )
        )

    return ece


# ============================================================
# 25. OUTPUT STORAGE
# ============================================================

fold_results = []
hyperparameter_results = []
selected_hyperparameters = []

outer_probabilities = []
outer_targets = []


# ============================================================
# 26. OUTER NESTED CV
# ============================================================

print("\n")
print("=" * 80)
print("STARTING NESTED 5 x 4 CROSS-VALIDATION")
print("=" * 80)

overall_start = time.time()


for outer_fold, (
    outer_train_idx,
    outer_val_idx
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev
    ),
    start=1
):

    fold_start = time.time()

    print("\n")
    print("-" * 80)
    print(f"OUTER FOLD {outer_fold}/{OUTER_FOLDS}")
    print("-" * 80)

    X_outer_train = X_dev.iloc[
        outer_train_idx
    ].copy()

    y_outer_train = y_dev[
        outer_train_idx
    ]

    X_outer_val = X_dev.iloc[
        outer_val_idx
    ].copy()

    y_outer_val = y_dev[
        outer_val_idx
    ]

    print(
        "Outer training size:",
        len(X_outer_train)
    )

    print(
        "Outer validation size:",
        len(X_outer_val)
    )

    print(
        "Outer training positive rate:",
        round(float(np.mean(y_outer_train)), 6)
    )

    print(
        "Outer validation positive rate:",
        round(float(np.mean(y_outer_val)), 6)
    )

    # --------------------------------------------------------
    # Inner hyperparameter search
    # --------------------------------------------------------

    config_scores = []

    for config_number, (
        learning_rate,
        l2
    ) in enumerate(
        HYPERPARAM_GRID,
        start=1
    ):

        inner_scores = []

        for inner_fold, (
            inner_train_idx,
            inner_val_idx
        ) in enumerate(
            inner_cv.split(
                X_outer_train,
                y_outer_train
            ),
            start=1
        ):

            X_inner_train_raw = (
                X_outer_train.iloc[
                    inner_train_idx
                ]
            )

            y_inner_train = (
                y_outer_train[
                    inner_train_idx
                ]
            )

            X_inner_val_raw = (
                X_outer_train.iloc[
                    inner_val_idx
                ]
            )

            y_inner_val = (
                y_outer_train[
                    inner_val_idx
                ]
            )

            # ------------------------------------------------
            # Fold-specific preprocessing
            # ------------------------------------------------

            inner_imputer, inner_scaler = (
                fit_preprocessor(
                    X_inner_train_raw
                )
            )

            X_inner_train = (
                transform_preprocessor(
                    X_inner_train_raw,
                    inner_imputer,
                    inner_scaler
                )
            )

            X_inner_val = (
                transform_preprocessor(
                    X_inner_val_raw,
                    inner_imputer,
                    inner_scaler
                )
            )

            # ------------------------------------------------
            # Internal validation for early stopping
            # ------------------------------------------------

            (
                internal_train_idx,
                internal_val_idx
            ) = internal_split(
                X_inner_train,
                y_inner_train,
                validation_fraction=0.10,
                seed=SEED + outer_fold + inner_fold
            )

            X_fit = X_inner_train[
                internal_train_idx
            ]

            y_fit = y_inner_train[
                internal_train_idx
            ]

            X_early = X_inner_train[
                internal_val_idx
            ]

            y_early = y_inner_train[
                internal_val_idx
            ]

            # ------------------------------------------------
            # Model
            # ------------------------------------------------

            set_seed(
                SEED
                +
                outer_fold * 100
                +
                inner_fold
                +
                config_number
            )

            model = FlatChebKAN(
                input_dim=INPUT_DIM,
                hidden_dim=HIDDEN_DIM,
                degree=CHEB_K
            )

            model, best_internal_auc, best_epoch = (
                train_model(
                    model=model,
                    X_train=X_fit,
                    y_train=y_fit,
                    X_val=X_early,
                    y_val=y_early,
                    learning_rate=learning_rate,
                    l2=l2
                )
            )

            # ------------------------------------------------
            # Inner validation evaluation
            # ------------------------------------------------

            inner_probability = predict_probability(
                model,
                X_inner_val
            )

            inner_auc = roc_auc_score(
                y_inner_val,
                inner_probability
            )

            inner_scores.append(
                inner_auc
            )

            print(
                f"Outer {outer_fold} | "
                f"Config {config_number:02d}/"
                f"{len(HYPERPARAM_GRID)} | "
                f"Inner {inner_fold}/"
                f"{INNER_FOLDS} | "
                f"lr={learning_rate:.0e} | "
                f"l2={l2:.0e} | "
                f"AUC={inner_auc:.6f}"
            )

            del model

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        mean_inner_auc = float(
            np.mean(inner_scores)
        )

        config_scores.append(
            {
                "outer_fold": outer_fold,
                "config_number": config_number,
                "learning_rate": learning_rate,
                "l2": l2,
                "mean_inner_auc": mean_inner_auc,
                "std_inner_auc": float(
                    np.std(
                        inner_scores,
                        ddof=1
                    )
                )
            }
        )

    # --------------------------------------------------------
    # Select best hyperparameters
    # --------------------------------------------------------

    config_scores_sorted = sorted(
        config_scores,
        key=lambda x: (
            -x["mean_inner_auc"],
            x["l2"],
            -x["learning_rate"]
        )
    )

    best_config = config_scores_sorted[0]

    best_lr = best_config[
        "learning_rate"
    ]

    best_l2 = best_config[
        "l2"
    ]

    print("\nSelected hyperparameters:")
    print(
        "Learning rate:",
        best_lr
    )

    print(
        "L2:",
        best_l2
    )

    print(
        "Best hyperparameter-search "
        "inner-CV ROC-AUC:",
        f"{best_config['mean_inner_auc']:.6f}"
    )

    for result in config_scores:

        hyperparameter_results.append(
            result
        )

    selected_hyperparameters.append(
        {
            "outer_fold": outer_fold,
            "learning_rate": best_lr,
            "l2": best_l2,
            "best_inner_cv_auc": best_config[
                "mean_inner_auc"
            ]
        }
    )

    # --------------------------------------------------------
    # Refit preprocessing using COMPLETE outer training fold
    # --------------------------------------------------------

    outer_imputer, outer_scaler = (
        fit_preprocessor(
            X_outer_train
        )
    )

    X_outer_train_processed = (
        transform_preprocessor(
            X_outer_train,
            outer_imputer,
            outer_scaler
        )
    )

    X_outer_val_processed = (
        transform_preprocessor(
            X_outer_val,
            outer_imputer,
            outer_scaler
        )
    )

    # --------------------------------------------------------
    # Internal 10% early-stopping split
    # --------------------------------------------------------

    (
        internal_train_idx,
        internal_val_idx
    ) = internal_split(
        X_outer_train_processed,
        y_outer_train,
        validation_fraction=0.10,
        seed=SEED + outer_fold
    )

    X_fit = X_outer_train_processed[
        internal_train_idx
    ]

    y_fit = y_outer_train[
        internal_train_idx
    ]

    X_early = X_outer_train_processed[
        internal_val_idx
    ]

    y_early = y_outer_train[
        internal_val_idx
    ]

    # --------------------------------------------------------
    # Final outer-fold model
    # --------------------------------------------------------

    set_seed(
        SEED + 1000 + outer_fold
    )

    final_model = FlatChebKAN(
        input_dim=INPUT_DIM,
        hidden_dim=HIDDEN_DIM,
        degree=CHEB_K
    )

    parameter_count = count_parameters(
        final_model
    )

    (
        final_model,
        final_internal_auc,
        best_epoch
    ) = train_model(
        model=final_model,
        X_train=X_fit,
        y_train=y_fit,
        X_val=X_early,
        y_val=y_early,
        learning_rate=best_lr,
        l2=best_l2
    )

    print(
        "Final selected-model internal "
        f"validation ROC-AUC: "
        f"{final_internal_auc:.6f}"
    )

    print(
        "Best epoch:",
        best_epoch
    )

    print(
        "Trainable parameters:",
        parameter_count
    )

    # --------------------------------------------------------
    # Outer validation
    # --------------------------------------------------------

    outer_probability = predict_probability(
        final_model,
        X_outer_val_processed
    )

    metrics = calculate_metrics(
        y_outer_val,
        outer_probability
    )

    metrics["ece"] = expected_calibration_error(
        y_outer_val,
        outer_probability
    )

    metrics["outer_fold"] = outer_fold
    metrics["learning_rate"] = best_lr
    metrics["l2"] = best_l2
    metrics["best_epoch"] = best_epoch
    metrics["parameter_count"] = parameter_count

    fold_results.append(
        metrics
    )

    outer_probabilities.extend(
        outer_probability.tolist()
    )

    outer_targets.extend(
        y_outer_val.tolist()
    )

    print("\nOuter validation results:")

    for metric_name in [
        "accuracy",
        "precision",
        "sensitivity",
        "specificity",
        "f1",
        "roc_auc",
        "pr_auc",
        "brier",
        "ece"
    ]:

        print(
            f"{metric_name:15s}: "
            f"{metrics[metric_name]:.6f}"
        )

    # --------------------------------------------------------
    # Save fold model
    # --------------------------------------------------------

    model_path = (
        MODELS_DIR
        /
        f"implementation29_a4_flat_chebkan_fold{outer_fold}.pt"
    )

    torch.save(
        {
            "model_state_dict": final_model.state_dict(),
            "input_dim": INPUT_DIM,
            "hidden_dim": HIDDEN_DIM,
            "chebyshev_degree": CHEB_K,
            "learning_rate": best_lr,
            "l2": best_l2,
            "parameter_count": parameter_count,
            "features": FEATURES
        },
        model_path
    )

    print(
        "Model saved:",
        model_path
    )

    fold_time = (
        time.time()
        -
        fold_start
    )

    print(
        f"Fold execution time: "
        f"{fold_time / 60:.2f} minutes"
    )

    del final_model

    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# ============================================================
# 27. AGGREGATE OUTER RESULTS
# ============================================================

results_df = pd.DataFrame(
    fold_results
)

outer_targets = np.asarray(
    outer_targets
)

outer_probabilities = np.asarray(
    outer_probabilities
)

print("\n")
print("=" * 80)
print("A4 OUTER CROSS-VALIDATION SUMMARY")
print("=" * 80)

metric_columns = [
    "accuracy",
    "precision",
    "sensitivity",
    "specificity",
    "f1",
    "roc_auc",
    "pr_auc",
    "brier",
    "ece"
]

summary_rows = []

for metric in metric_columns:

    mean_value = results_df[
        metric
    ].mean()

    std_value = results_df[
        metric
    ].std(
        ddof=1
    )

    summary_rows.append(
        {
            "metric": metric,
            "mean": mean_value,
            "std": std_value
        }
    )

    print(
        f"{metric:15s}: "
        f"{mean_value:.6f} "
        f"+/- "
        f"{std_value:.6f}"
    )


# ============================================================
# 28. POOLED OUTER PREDICTIONS
# ============================================================

pooled_metrics = calculate_metrics(
    outer_targets,
    outer_probabilities
)

pooled_metrics["ece"] = (
    expected_calibration_error(
        outer_targets,
        outer_probabilities
    )
)

print("\n[POOLED OUTER VALIDATION]")

for metric_name, value in pooled_metrics.items():

    print(
        f"{metric_name:15s}: "
        f"{value:.6f}"
    )


# ============================================================
# 29. HYPERPARAMETER STABILITY
# ============================================================

selected_df = pd.DataFrame(
    selected_hyperparameters
)

print("\n")
print("=" * 80)
print("HYPERPARAMETER STABILITY")
print("=" * 80)

print(
    "\nLearning-rate selections:"
)

print(
    selected_df[
        "learning_rate"
    ].value_counts()
)

print(
    "\nL2 selections:"
)

print(
    selected_df[
        "l2"
    ].value_counts()
)


# ============================================================
# 30. PARAMETER COUNT
# ============================================================

print("\nParameter counts by outer fold:")

print(
    results_df[
        [
            "outer_fold",
            "parameter_count"
        ]
    ].to_string(
        index=False
    )
)

print(
    "\nMean parameter count:",
    results_df[
        "parameter_count"
    ].mean()
)


# ============================================================
# 31. OUTER VALIDATION COVERAGE
# ============================================================

print("\n")
print("=" * 80)
print("OUTER VALIDATION COVERAGE")
print("=" * 80)

outer_validation_ids = []

for outer_fold, (
    _,
    outer_val_idx
) in enumerate(
    outer_cv.split(
        X_dev,
        y_dev
    ),
    start=1
):

    outer_validation_ids.extend(
        outer_val_idx.tolist()
    )

unique_validation_ids = set(
    outer_validation_ids
)

expected_ids = set(
    range(len(dev))
)

print(
    "Total validation observations:",
    len(outer_validation_ids)
)

print(
    "Unique validation observations:",
    len(unique_validation_ids)
)

print(
    "Expected development observations:",
    len(dev)
)

coverage_pass = (
    len(outer_validation_ids)
    ==
    len(dev)
    and
    unique_validation_ids
    ==
    expected_ids
)

print(
    "Each development observation "
    "used exactly once as outer validation:",
    coverage_pass
)

assert coverage_pass


# ============================================================
# 32. CALIBRATION / TEST PROTECTION
# ============================================================

print("\n")
print("=" * 80)
print("CALIBRATION / LOCKED TEST PROTECTION")
print("=" * 80)

print(
    "Conformal calibration rows:",
    len(cal)
)

print(
    "Locked test rows:",
    len(test)
)

print(
    "Calibration used for model "
    "training:",
    False
)

print(
    "Calibration used for "
    "hyperparameter selection:",
    False
)

print(
    "Calibration used for "
    "outer-fold model selection:",
    False
)

print(
    "Locked test used during "
    "model development:",
    False
)

print(
    "Locked test used for "
    "hyperparameter selection:",
    False
)

print(
    "Locked test used for "
    "early stopping:",
    False
)


# ============================================================
# 33. SAVE RESULTS
# ============================================================

fold_results_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_outer_fold_results.csv"
)

summary_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_summary.csv"
)

pooled_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_pooled_metrics.csv"
)

hyperparameter_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_hyperparameter_search.csv"
)

selected_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_selected_hyperparameters.csv"
)

protocol_path = (
    TABLES_DIR
    /
    "implementation29_a4_flat_chebkan_protocol.json"
)

results_df.to_csv(
    fold_results_path,
    index=False
)

pd.DataFrame(
    summary_rows
).to_csv(
    summary_path,
    index=False
)

pd.DataFrame(
    [pooled_metrics]
).to_csv(
    pooled_path,
    index=False
)

pd.DataFrame(
    hyperparameter_results
).to_csv(
    hyperparameter_path,
    index=False
)

selected_df.to_csv(
    selected_path,
    index=False
)


# ============================================================
# 34. SAVE PROTOCOL
# ============================================================

protocol = {

    "implementation": "29",

    "ablation": "A4",

    "model": "Flat Chebyshev-KAN",

    "purpose":
        "Isolate the effect of clinical grouping",

    "project_root":
        str(PROJECT_ROOT),

    "features":
        FEATURES,

    "target":
        TARGET,

    "input_dimension":
        INPUT_DIM,

    "hidden_dimension":
        HIDDEN_DIM,

    "architecture":
        "11 -> Chebyshev-KAN(16) -> SiLU -> Linear(1)",

    "chebyshev_basis":
        "First kind",

    "chebyshev_degree":
        CHEB_K,

    "normalization":
        "MinMaxScaler [-1, 1]",

    "imputation":
        "Fold-specific training-data median",

    "clinical_grouping":
        False,

    "sparse_gates":
        False,

    "kan_l1_regularization":
        False,

    "adasyn":
        False,

    "conformal_prediction":
        False,

    "outer_cv":
        OUTER_FOLDS,

    "inner_cv":
        INNER_FOLDS,

    "random_state":
        SEED,

    "early_stopping":
        {
            "internal_validation_fraction": 0.10,
            "max_epochs": MAX_EPOCHS,
            "patience": PATIENCE
        },

    "batch_size":
        BATCH_SIZE,

    "learning_rates":
        LEARNING_RATES,

    "l2_values":
        L2_VALUES,

    "calibration_rows":
        len(cal),

    "locked_test_rows":
        len(test),

    "calibration_used_for_training":
        False,

    "calibration_used_for_model_selection":
        False,

    "locked_test_used_for_training":
        False,

    "locked_test_used_for_model_selection":
        False,

    "locked_test_used_for_early_stopping":
        False
}

with open(
    protocol_path,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        protocol,
        file,
        indent=4
    )


# ============================================================
# 35. FINAL SUMMARY
# ============================================================

total_time = (
    time.time()
    -
    overall_start
)

print("\n")
print("=" * 80)
print("IMPLEMENTATION 29 — FINAL SUMMARY")
print("=" * 80)

print(
    "Model: A4 Flat Chebyshev-KAN"
)

print(
    "Architecture:",
    f"{INPUT_DIM} -> {HIDDEN_DIM} -> 1"
)

print(
    "Chebyshev degree:",
    CHEB_K
)

print(
    "Mean outer ROC-AUC:",
    f"{results_df['roc_auc'].mean():.6f}"
)

print(
    "Std outer ROC-AUC:",
    f"{results_df['roc_auc'].std(ddof=1):.6f}"
)

print(
    "Pooled outer ROC-AUC:",
    f"{pooled_metrics['roc_auc']:.6f}"
)

print(
    "Pooled outer PR-AUC:",
    f"{pooled_metrics['pr_auc']:.6f}"
)

print(
    "Pooled outer Brier:",
    f"{pooled_metrics['brier']:.6f}"
)

print(
    "Pooled outer ECE:",
    f"{pooled_metrics['ece']:.6f}"
)

print(
    "Calibration protected: PASS"
)

print(
    "Locked test protected: PASS"
)

print(
    "Outer validation coverage: PASS"
)

print(
    "ADASYN used: NO"
)

print(
    "Clinical grouping used: NO"
)

print(
    "Sparse gates used: NO"
)

print(
    "Conformal prediction used: NO"
)

print(
    f"Total execution time: "
    f"{total_time / 60:.2f} minutes"
)

print("\nSaved files:")

print(
    fold_results_path
)

print(
    summary_path
)

print(
    pooled_path
)

print(
    hyperparameter_path
)

print(
    selected_path
)

print(
    protocol_path
)

print("\n")
print("=" * 80)
print("IMPLEMENTATION 29 COMPLETE — STATUS: PASS")
print("=" * 80)